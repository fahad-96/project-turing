# TuringTask

Build offline in the supplied Lean 4 / Mathlib environment:

```sh
lake build
```

The project uses the preinstalled Mathlib at `/opt/mathlib4`.
