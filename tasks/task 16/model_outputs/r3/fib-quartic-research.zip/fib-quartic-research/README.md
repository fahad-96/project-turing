# Exact quartics for Fibonacci squares: offline proof research

## Bottom line

The Pell reduction is clean, but it does **not** by itself prove the requested
quartic classifications.  It parametrizes all solutions of norm `±4` as
Lucas/Fibonacci pairs, after which requiring the Fibonacci coordinate to be a
square is exactly the original hard problem.

The locally supplied Mathlib has `Pell.Solution₁ d`, not `Pell.Solution`.
It represents solutions of

```text
X^2 - d Y^2 = 1
```

in `Z[√d]`.  The useful theorem is

```lean
Pell.IsFundamental.eq_pow_of_nonneg
```

and multiplication coordinates are supplied by
`Pell.Solution₁.x_mul` and `Pell.Solution₁.y_mul`.  This API does not directly
represent the odd norm-`±4` elements `(L+F√5)/2` in the full ring of integers
of `Q(√5)`.

The rigorous reductions below identify exactly what a complete formal proof
must add.  I did not find either specialized Pocklington/Ljunggren descent in
the local Mathlib, and I do not claim a complete proof of the two hard kernels.

## 1. All norm `±4` solutions

Let `X,Y >= 0` and

```text
Y^2 - 5 X^2 = ±4.                                      (1)
```

Reduction modulo 2 shows that `X,Y` have the same parity.  If `X>0`, then
`Y<3X`: otherwise `Y^2 >= 9X^2 > 5X^2+4` (the endpoint `X=1` is checked
directly).  Also `Y<5X`.  For `X>1`, define

```text
X' = (Y-X)/2,      Y' = (5X-Y)/2.
```

The parity observation makes these integers, and direct expansion gives

```text
Y'^2 - 5X'^2 = -(Y^2 - 5X^2).                          (2)
```

Moreover `0 <= X' < X`.  The two cases with `X=1` are `(Y,X)=(1,1),(3,1)`
and are checked directly; one more step reaches `(2,0)`.  Thus strong descent
terminates, and reversing the step gives

```text
(Y,X): (2,0),(1,1),(3,1),(4,2),(7,3),(11,5),...
```

Hence, with `F_0=0,F_1=1` and `L_0=2,L_1=1`, every nonnegative solution is

```text
(Y,X) = (L_n,F_n),       Y^2-5X^2 = 4(-1)^n.           (3)
```

This descent is preferable to forcing norm `±4` into `Pell.Solution₁`.

## 2. Equation (A)

Equation (A) is

```text
y^2 + 4 = 5x^4.                                        (A)
```

If `x` were even, reduction modulo 16 would give `y^2 = 12 (mod 16)`,
impossible.  Thus `x,y` are odd.  Applying (3) with `X=x^2,Y=y` says

```text
x^2 = F_n, y=L_n, n odd.
```

Consequently (A) is *equivalent* to the odd-index part of the square-Fibonacci
theorem.  Pell plus periodic congruences has not reduced the hard content.

There is a useful direct Gaussian normalization.  In `Z[i]`, the factors
`y+2i` and `y-2i` are coprime: a common divisor has norm dividing both the odd
number `y^2+4` and `16`.  Since

```text
5=(1+2i)(1-2i),
```

unique factorization yields, after conjugating and changing signs,

```text
y+2i = ±(1+2i)(a+bi)^4,       x=a^2+b^2.               (4)
```

Writing

```text
A=a^4-6a^2b^2+b^4,  B=4ab(a^2-b^2),
```

the imaginary part of (4) is `2A+B=±2`.  Therefore the exact remaining Thue
equation is

```text
Q(a,b)=a^4-6a^2b^2+b^4+2ab(a^2-b^2)=±1.               (5)
```

It has the revealing Pell-norm factorization

```text
Q(a,b)=(a^2+ab-b^2)^2-5(ab)^2.                         (6)
```

The required specialized Pocklington lemma is

```text
Q(a,b)=±1  ->  ab=0 and a^2+b^2=1.                    (P_A)
```

Equations (4)-(6), including all parity and coprimality obligations, are a
good Lean route.  But `(P_A)` is a genuine binary-quartic descent; replacing it
with generic Pell classification merely asks which Pell powers have the
special coordinates `s=ab`, `r=a^2+ab-b^2`.

## 3. Equation (B)

Equation (B) is

```text
y^2 = 5x^4+4.                                         (B)
```

The derivation below is complete once (A) and one second specialized quartic
lemma are available.

### `x=0`

Immediately `y=2` for nonnegative `y`.

### `x` odd

Then `y` is odd, so

```text
gcd(y-2,y+2)=1,
(y-2)(y+2)=5x^4.
```

Unique factorization in the nonnegative integers gives exactly two allocations:

```text
y-2=a^4,   y+2=5b^4,   x=ab;                          (7)
y-2=5a^4,  y+2=b^4,    x=ab.                          (8)
```

Case (8) would give `b^4-5a^4=4`, impossible modulo 5 because a fourth power
modulo 5 is `0` or `1`.  Case (7) gives

```text
a^4+4=5b^4,
```

which is (A) with `(x,y)=(b,a^2)`.  Thus `a=b=1`, and `(x,y)=(1,3)`.

### `x` even

Write `x=2u`, `y=2v`.  Then

```text
v^2=20u^4+1,
A=(v-1)/2, B=(v+1)/2,
gcd(A,B)=1, AB=5u^4, B-A=1.                            (9)
```

Again there are exactly two allocations:

```text
A=a^4,  B=5b^4  ->  5b^4-a^4=1;                      (10)
A=5a^4, B=b^4   ->  b^4-5a^4=1.                      (11)
```

(10) is impossible modulo 16: if `b` is odd its left side minus 1 forces a
fourth power congruent to 4; if `b` is even it forces one congruent to 15.

The exact second hard lemma is

```text
b^4-5a^4=1  ->  (a,b)=(0,1) or (2,3).                 (P_B)
```

For positive even `x`, (9) excludes `a=0`; hence `a=2,b=3`, `u=6`, `x=12`,
`v=161`, and `y=322`.  Together with the first two branches this gives exactly

```text
(x,y)=(0,2),(1,3),(12,322).
```

For a Lean proof of `(P_B)`, form the norm-one Pell solution
`(X,Y)=(b^2,a^2)` for `d=5`.  The fundamental positive solution in Mathlib's
`Z[√5]` model is `(9,4)`, so every positive solution is `(9+4√5)^n`.  One can
prove the stronger classical lemma

```text
z^4-5t^2=1 -> (z,t)=(1,0) or (3,4),                   (P_L)
```

which says that the first Pell coordinate is a square only for powers `n=0,1`.
Substitution `t=a^2` gives `(P_B)`.  The missing descent is precisely the proof
of `(P_L)`; congruence checking alone is not sufficient.

## 4. Exact Lucas companion equations

From

```text
L_n^2-5F_n^2=4(-1)^n                                  (12)
```

the square-Lucas problem `L_n=z^2` produces

```text
n even: z^4       =5F_n^2+4,                           (LS+)
n odd:  z^4+4     =5F_n^2.                             (LS-)
```

The exact unrestricted classifications needed are

```text
z^4=5w^2+4          has no nonnegative solutions;
z^4+4=5w^2          has (z,w)=(1,1),(2,2).             (13)
```

The first assertion in (13) is elementary.  If `z` is even, reduce modulo 16.
If `z` is odd, then

```text
(z^2-2)(z^2+2)=5w^2,
gcd(z^2-2,z^2+2)=1.
```

The coprime factors must be `r^2,5s^2` in one order.  Either order requires two
integer squares to differ by 2, impossible.

For twice-square Lucas numbers `L_n=2z^2`, (12) gives

```text
n even: 4z^4       =5F_n^2+4,                          (L2+)
n odd:  4z^4+4     =5F_n^2.                            (L2-)
```

The exact classifications are

```text
4z^4=5w^2+4         has (z,w)=(1,0),(3,8);
4z^4+4=5w^2         has no nonnegative solutions.       (14)
```

The second assertion of (14) is immediate modulo 5: a fourth power is `0` or
`1`, so `4z^4+4` is `4` or `3`, never `0`.  In the first assertion `w` is even;
putting `w=2t` reduces it exactly to `(P_L)`:

```text
z^4-5t^2=1.
```

Thus the companion landscape contains two easy equations and two more hard
Pocklington/Ljunggren equations, namely `z^4+4=5w^2` and `(P_L)`.  The resulting
Lucas classifications are

```text
L_n square       <-> n=1 or n=3;     values 1,4;
L_n twice square <-> n=0 or n=6;     values 2,18.
```

## 5. Recommended Lean architecture

1. Work over `Int` for all quartics; normalize nonnegative variables at the API boundary.
2. Prove the norm-`±4` descent directly.  It is shorter than adapting `Pell.Solution₁` to half-integral units.
3. Put `(P_A)` and `(P_L)` in separate files.  These are the main deep arithmetic kernels; derive `(P_B)` from `(P_L)`.
4. For `(P_A)`, use `GaussianInt` UFD to reach (5), then formalize a published Pocklington descent for that binary quartic.
5. For `(P_L)`, use `Pell.Solution₁ 5`, prove `(9,4)` fundamental by checking `2 <= X <= 8`, and formalize the square-first-coordinate descent on powers.
6. Keep the factor-allocation lemmas generic: coprime product equal to `p*k^4` implies each factor is a fourth power with the prime `p` assigned to one side.
7. Use `omega` for parity/divisibility, `ring_nf` for identities, `nlinarith` for inequalities, and `norm_num` only for the exceptional pairs.

Do not use a finite modular sieve as the terminal argument unless a global
bound has first been proved.  Every finite collection of recurrence periods
still leaves infinitely many indices in the residue class of a known solution.

## Offline verification

`FibQuarticResearch.lean` checks the key identities and the exact equation
translations.  It intentionally states the two hard classifiers as
propositions rather than pretending Mathlib already proves them.

```bash
lean FibQuarticResearch.lean
```

The project uses the supplied local Mathlib path `/opt/mathlib4`; it is not
self-contained on an arbitrary machine.
