# TuringTask Lean 4 Project

This project formalizes and proves five theorems in `TuringTask/Basic.lean`:
1. `charSum_norm_le`: Pólya-Vinogradov inequality for non-principal multiplicative characters modulo a prime $p$.
2. `legendreSum_le`: Pólya-Vinogradov inequality for the Legendre symbol modulo an odd prime $p$.
3. `exists_not_pow_le`: Least non-$k$-th power modulo $p$ is bounded by $\sqrt{p} \log p + 1$.
4. `card_residues_sub_le`: Discrepancy bound for the number of quadratic residues among $1, \dots, N$.
5. `exists_prime_nonresidue_le`: Least quadratic non-residue prime modulo an odd prime $p$ is bounded by $\sqrt{p} \log p + 1$.

## Environment Requirements
This project is configured for the offline Lean 4 environment:
- Toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib commit: `9944fe2973b8dc0b86949101ed98232c07cd54a0` located locally at `/opt/mathlib4`
Note: The local `/opt/mathlib4` installation supplied by the environment is required for building.

## Build Instructions
In the project directory, run:
```bash
lean-offline-init
lake build
```
Or directly check the main source file:
```bash
lean TuringTask/Basic.lean
```
