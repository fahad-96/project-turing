import TuringTask.Hyper

/-!
# Bridging lemmas for the `Fin`-indexed statements
-/

namespace TuringTask

open Finset

section Bridge

variable {n m : ℕ}

/-- Support sets of a Boolean incidence function. -/
def supp (I : Fin m → Fin n → Bool) (i : Fin m) : Finset (Fin n) :=
  univ.filter (fun v => I i v = true)

lemma mem_supp {I : Fin m → Fin n → Bool} {i : Fin m} {v : Fin n} :
    v ∈ supp I i ↔ I i v = true := by simp [supp]

/-- The LLL neighbourhood of `i` equals the set of clauses sharing a variable with `i`. -/
lemma nbr_supp_eq (I : Fin m → Fin n → Bool) (i : Fin m) :
    nbr (supp I) i = univ.filter (fun j => ¬ (j = i) ∧ ∃ v, I i v = true ∧ I j v = true) := by
  ext j
  simp only [nbr, Finset.mem_filter, Finset.mem_univ, true_and, ne_eq]
  constructor
  · rintro ⟨hne, v, hv⟩
    rw [Finset.mem_inter, mem_supp, mem_supp] at hv
    exact ⟨hne, v, hv.1, hv.2⟩
  · rintro ⟨hne, v, h1, h2⟩
    exact ⟨hne, v, Finset.mem_inter.2 ⟨mem_supp.2 h1, mem_supp.2 h2⟩⟩

/-- Translate the generic conclusion into the required existential form. -/
lemma conv_concl {I : Fin m → Fin n → Bool} {c : Fin n → Bool}
    (h : ∀ i, (∃ v ∈ supp I i, c v = true) ∧ (∃ v ∈ supp I i, c v = false)) :
    ∀ i, (∃ v, I i v = true ∧ c v = true) ∧ (∃ v, I i v = true ∧ c v = false) := by
  intro i
  obtain ⟨⟨v, hv, hcv⟩, ⟨w, hw, hcw⟩⟩ := h i
  exact ⟨⟨v, mem_supp.1 hv, hcv⟩, ⟨w, mem_supp.1 hw, hcw⟩⟩

end Bridge

end TuringTask
