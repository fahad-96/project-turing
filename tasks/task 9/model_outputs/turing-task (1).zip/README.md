# TuringTask Lean 4 Formalization

This repository contains Lean 4 formal proofs of five number-theoretic theorems concerning cubic residues, Jacobi/Gauss sums, and representations of primes of the form $4p = L^2 + 27M^2$.

## Theorems

1. `card_cubic`: The number of solutions $(x, y) \in (\mathbb{Z}/p\mathbb{Z})^2$ to $x^3 + y^3 = 1$ is $p - 2 + L$.
2. `card_cube_pairs`: The number of nonzero pairs $(x, x+1)$ where both $x$ and $x+1$ are cubes in $\mathbb{Z}/p\mathbb{Z}$ satisfies $9 \cdot \#C = p - 8 + L$.
3. `card_noncube_pairs`: The number of elements $x$ such that neither $x$ nor $x+1$ is a cube, but their product $x(x+1)$ is a cube, is given by $9 \cdot \#\{\dots\} = 2(p + 1 + L)$.
4. `two_cube_iff`: 2 is a cubic residue modulo $p$ if and only if $p$ can be represented as $x^2 + 27y^2$ for integers $x, y$.
5. `cubic_sum`: The Gauss cubic period sum satisfies the cubic equation $S^3 - 3pS - pL = 0$.

All five theorems are proven with no `sorry` or `admit`, relying solely on Lean's core axioms (`propext`, `Classical.choice`, `Quot.sound`).

## Offline Build Requirements & Instructions

This project is configured for the pinned local Lean toolchain (`v4.33.0-rc1`) and local Mathlib precompiled at `/opt/mathlib4`.

### Building with Lake
```bash
lake build
```

### Direct Verification with Lean
```bash
lean TuringTask/Basic.lean
```
