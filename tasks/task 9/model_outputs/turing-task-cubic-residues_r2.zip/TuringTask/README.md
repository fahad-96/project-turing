# TuringTask — Cubic residues, Jacobi sums, and the representation 4p = L² + 27M²

Lean 4 formalisation of five classical results about a prime `p ≡ 1 (mod 3)`
and the representation `4p = L² + 27M²` with `L ≡ 1 (mod 3)`.

All five required theorems are in `TuringTask/Basic.lean`, in namespace `TuringTask`,
stated exactly as specified, and proved with no `sorry`, no `admit`, no
`native_decide`, and no new axioms.

## The five theorems

| # | Name | Statement |
|---|------|-----------|
| 1 | `card_cubic` | `#{(x,y) ∈ (ZMod p)² : x³ + y³ = 1} = p - 2 + L` |
| 2 | `card_cube_pairs` | `9 · #{x : x ≠ 0, x+1 ≠ 0, x and x+1 both cubes} = p - 8 + L` |
| 3 | `card_noncube_pairs` | `9 · #{x : x, x+1 non-cubes, x(x+1) a cube} = 2(p + 1 + L)` |
| 4 | `two_cube_iff` | `2` is a cube mod `p` ⟺ `p = x² + 27y²` for some integers `x, y` |
| 5 | `cubic_sum` | `G = Σₓ e^{2πi a x³ / p}` satisfies `G³ = 3pG + pL` for `a ≢ 0` |

## Build (offline)

The project depends on the **locally installed Mathlib** at `/opt/mathlib4`, declared
as a path dependency in `lakefile.toml`. It requires the supplied Lean/Mathlib
environment (toolchain `leanprover/lean4:v4.33.0-rc1`, Mathlib commit
`9944fe2973b8dc0b86949101ed98232c07cd54a0`). It is **not** self-contained on an
arbitrary machine: the path dependency must resolve to a compatible Mathlib.

```bash
cd TuringTask
lean-offline-init      # seeds .lake/packages from the installed Mathlib (local FS only)
lake build             # completes with no errors
```

To type-check the single file directly, without Lake:

```bash
lean TuringTask/Basic.lean
```

To re-verify the axiom usage:

```bash
cat > AxiomCheck.lean <<'EOF'
import TuringTask.Basic
#print axioms TuringTask.card_cubic
#print axioms TuringTask.card_cube_pairs
#print axioms TuringTask.card_noncube_pairs
#print axioms TuringTask.two_cube_iff
#print axioms TuringTask.cubic_sum
EOF
lake env lean AxiomCheck.lean
```

Each prints exactly `[propext, Classical.choice, Quot.sound]`.

## Proof outline

The development is self-contained on top of Mathlib's `jacobiSum` / `gaussSum` API.

**Setup.** `om` is the primitive cube root `e^{2πi/3}` in `ℂ`; `om_indep` proves `1, om`
are `ℤ`-linearly independent (via `om.im > 0`), and `adjoin_rep` shows every element of
`ℤ[om]` is `a + b·om`. `chi p hp : MulChar (ZMod p) ℂ` is a cubic character, obtained from
`MulChar.exists_mulChar_orderOf`. The central bridge `chi_eq_one_iff_cube` proves
`chi x = 1 ↔ x` is a cube (for `x ≠ 0`), using a generator of `(ZMod p)ˣ`.

**The Jacobi sum.** `jacobi_norm` gives `J·conj J = p` (from
`jacobiSum_mul_jacobiSum_inv`), and `jacobi_congr` gives `J = a + b·om` with `a ≡ 2`,
`b ≡ 0 (mod 3)` (from `exists_jacobiSum_eq_neg_one_add`, using `(om-1)² = -3om`).
Together `jacobi_struct` yields `a² - ab + b² = p`. Writing `b = 3m` gives
`4p = (2a-3m)² + 27m²` with `2a-3m ≡ 1 (mod 3)`. The arithmetic lemma `L_unique`
(a descent in `ℤ` using primality) shows this normalisation pins `L` down uniquely,
hence `jacobi_trace`: **`J + conj J = L`**.

**Counting.** `card_cube_roots` computes `#{u : u³ = c}` as `3` or `0`, and `nu_eq_sum`
identifies it with the character sum `charSum c = Σ_{j<3} χʲ(c)`. Theorem 1 follows by
grouping `x³ + y³ = 1` fiberwise and reducing the resulting double sum to the nine
Jacobi sums `J(χⁱ, χʲ)`, all evaluated in `jacobi_eval` (using
`J(χ²,χ²) = conj J(χ,χ)`, `jacobi_sq_conj`). Theorems 2 and 3 use the shifted sum
`Σₓ ψ(x)φ(x+1) = ψ(-1)J(ψ,φ)` (`sum_shift`); Theorem 3 additionally uses the weighted
sums `dsum α x = Σᵢ αⁱχⁱ(x)`, which isolate the two classes `χ(x) = om, χ(x+1) = om²`
and its swap.

**Theorem 4.** The swap involution `(x,y) ↦ (y,x)` on `{x³+y³=1}` has fixed points
exactly where `2x³ = 1`, so `card_mod_two_eq_fix` gives
`#S ≡ #{x : x³ = 2⁻¹} (mod 2)`. Since that fixed-point count is `3` or `0` and
`#S = p - 2 + L` with `p` odd, **`2` is a cube ⟺ `L` is even**. Finally
`L_even_iff_rep` shows `L` even ⟺ `L, M` both even ⟺ `p = x² + 27y²`
(the converse direction re-normalises the sign of `2x` and appeals to `L_unique`).

**Theorem 5.** The exponential sum is `Σₓ ψ_a(x³)` for the shifted standard additive
character `ψ_a`, which equals `g(χ,ψ_a) + g(χ²,ψ_a)` (the trivial-character Gauss sum
contributes `-1`, cancelling the `c = 0` correction). Mathlib's
`gaussSum_pow_eq_prod_jacobiSum` gives `g₁³ = pJ`, `g₂³ = p·conj J`, and
`gaussSum_mul_gaussSum_pow_orderOf_sub_one` gives `g₁g₂ = p`. Then
`G³ = g₁³ + g₂³ + 3g₁g₂(g₁+g₂) = p(J + conj J) + 3pG = pL + 3pG`.

## Files

- `TuringTask/Basic.lean` — all definitions, helper lemmas, and the five theorems
- `TuringTask.lean` — library root (imports `TuringTask.Basic`)
- `lakefile.toml` — package config with the local Mathlib path dependency
- `lean-toolchain` — pinned toolchain `leanprover/lean4:v4.33.0-rc1`
