import Mathlib
import TuringTask.Apps

/-!
# The five statements of the task

The theorems of `Basic.lean`, stated in exactly the same way, under different names.
-/

open Polynomial Finset

namespace TuringTask

/-! ### The five statements of the task -/

theorem primitive_sub (a b n : Nat) (hba : b < a) (hb : 1 <= b) (hab : Nat.Coprime a b)
    (hn : 2 <= n) (h2 : Not (n = 2 /\ exists t : Nat, a + b = 2 ^ t))
    (h6 : Not (a = 2 /\ b = 1 /\ n = 6)) :
    exists q : Nat, q.Prime /\ (a ^ n - b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k - b ^ k) % q = 0) := by
  obtain ⟨q, hq, hdvd, hprim⟩ := zsigmondy a b n hba hb hab hn h2 h6
  exact ⟨q, hq, Nat.mod_eq_zero_of_dvd hdvd,
    fun k hk1 hk2 hmod => hprim k hk1 hk2 (Nat.dvd_of_mod_eq_zero hmod)⟩

theorem primitive_add (a b n : Nat) (hba : b < a) (hb : 1 <= b) (hab : Nat.Coprime a b)
    (hn : 2 <= n) (h3 : Not (a = 2 /\ b = 1 /\ n = 3)) :
    exists q : Nat, q.Prime /\ (a ^ n + b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k + b ^ k) % q = 0) := by
  obtain ⟨q, hq, hdvd, hprim⟩ := zsigmondy_add a b n hba hb hab hn h3
  exact ⟨q, hq, Nat.mod_eq_zero_of_dvd hdvd,
    fun k hk1 hk2 hmod => hprim k hk1 hk2 (Nat.dvd_of_mod_eq_zero hmod)⟩

theorem divisors_card_le (a n : Nat) (ha : 2 <= a) (hn : 1 <= n) :
    n.divisors.card <= (a ^ n - 1).primeFactors.card + 2 :=
  card_divisors_bound a n ha hn

theorem pow_sub_one_eq_prime_pow (a n q m : Nat) (ha : 2 <= a) (hn : 2 <= n) (hq : q.Prime)
    (hm : 2 <= m) (h : a ^ n - 1 = q ^ m) :
    a = 3 /\ n = 2 /\ q = 2 /\ m = 3 :=
  prime_pow_eq a n q m ha hn hq hm h

theorem primeFactors_pow_sub_one (a m n : Nat) (ha : 2 <= a) (hm : 1 <= m) (hmn : m < n)
    (h : (a ^ m - 1).primeFactors = (a ^ n - 1).primeFactors) :
    m = 1 /\ n = 2 /\ exists t : Nat, a + 1 = 2 ^ t :=
  same_prime_factors a m n ha hm hmn h

end TuringTask
