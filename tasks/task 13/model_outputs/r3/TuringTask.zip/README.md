# TuringTask

This project uses the supplied Lean 4 and local Mathlib installation.

Build offline from this directory with:

```sh
lean-offline-init
lake build
```

## Status

The requested five-theorem development is incomplete. The checked partial
results and the missing Mathlib bridges are documented in `RESEARCH.md` and
`RESULTANT_RESEARCH.md`. No axioms or proof placeholders were added.
