import Mathlib

open scoped BigOperators

noncomputable section

def mur (n : Nat) : Real := ArithmeticFunction.moebius n

lemma mur_abs_le_one (n : Nat) : |mur n| ≤ 1 := by
  change |(ArithmeticFunction.moebius n : Real)| ≤ 1
  rw [← Int.cast_abs]
  exact_mod_cast ArithmeticFunction.abs_moebius_le_one (n := n)

lemma summable_mur_div_sq : Summable (fun n : Nat => mur n / (n : Real) ^ 2) := by
  apply Summable.of_norm_bounded ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2))
  intro n
  have hnabs : |(n : Real)| = (n : Real) := abs_of_nonneg (Nat.cast_nonneg n)
  calc
    ‖mur n / (n : Real) ^ 2‖ = |mur n| / (n : Real) ^ 2 := by
      rw [Real.norm_eq_abs, abs_div, abs_pow, hnabs]
    _ ≤ 1 / (n : Real) ^ 2 :=
      div_le_div_of_nonneg_right (mur_abs_le_one n) (sq_nonneg _)

lemma lseries_moebius_two :
    LSeries (fun n => (ArithmeticFunction.moebius n : Complex)) 2 =
      (6 / Real.pi ^ 2 : Real) := by
  have hprod := ArithmeticFunction.LSeries_zeta_mul_Lseries_moebius (s := (2 : Complex)) (by norm_num)
  have hz : LSeries (fun n => (ArithmeticFunction.zeta n : Complex)) 2 =
      (Real.pi ^ 2 / 6 : Real) := by
    rw [LSeries]
    have hc := Complex.ofRealCLM.hasSum hasSum_zeta_two
    have hc' : HasSum (LSeries.term (fun n => (ArithmeticFunction.zeta n : Complex)) 2)
        ((Real.pi ^ 2 / 6 : Real) : Complex) := by
      apply Filter.Tendsto.congr (fun s => ?_) hc
      apply Finset.sum_congr rfl
      intro n hn
      by_cases hn0 : n = 0
      · simp [hn0, LSeries.term]
      · simp [hn0, LSeries.term, Complex.cpow_natCast]
    exact hc'.tsum_eq
  rw [hz] at hprod
  apply (mul_left_cancel₀ (show ((Real.pi ^ 2 / 6 : Real) : Complex) ≠ 0 by
    exact_mod_cast div_ne_zero (pow_ne_zero 2 Real.pi_ne_zero) (by norm_num : (6 : Real) ≠ 0)))
  rw [hprod]
  push_cast
  field_simp

lemma hasSum_mur_div_sq :
    HasSum (fun n : Nat => mur n / (n : Real) ^ 2) (6 / Real.pi ^ 2) := by
  have htsum : (∑' n : Nat, mur n / (n : Real) ^ 2) = 6 / Real.pi ^ 2 := by
    apply Complex.ofReal_injective
    rw [Complex.ofReal_tsum]
    calc
      ∑' (n : Nat), ((mur n / (n : Real) ^ 2 : Real) : Complex) =
          LSeries (fun n => (ArithmeticFunction.moebius n : Complex)) 2 := by
            rw [LSeries]
            congr 1
            funext n
            by_cases hn : n = 0
            · simp [hn, mur, LSeries.term]
            · simp [hn, mur, LSeries.term, Complex.cpow_natCast]
      _ = ((6 / Real.pi ^ 2 : Real) : Complex) := lseries_moebius_two
  rw [← htsum]
  exact summable_mur_div_sq.hasSum
