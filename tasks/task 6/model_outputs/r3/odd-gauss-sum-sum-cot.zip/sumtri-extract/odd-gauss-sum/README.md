# Odd quadratic and triangular Gauss sums

This project proves the exact task statements

```lean
TuringTask.sum_sq
TuringTask.sum_tri
TuringTask.sum_legendre
TuringTask.sum_sq_mul
TuringTask.sum_cot
```

The quadratic proof constructs the normalized finite Fourier matrix, diagonalizes its
fourth-order action using a collected eigenbasis, proves the norm of its trace,
and computes its determinant phase with the Vandermonde product. The two
possible negative signs are then eliminated from the eigenvalue
multiplicities. `OddGaussSum.lean` converts the resulting `ZMod` sum to the
literal `Finset.range` complex exponential and handles every odd `n`, including
`n = 1`.

For an odd prime modulus, `sum_legendre` evaluates the Legendre-symbol-weighted
range sum with any integer scale, including the scale-zero case modulo `p`.
For distinct odd primes, `sum_sq_mul` evaluates the product of the two scaled
quadratic sums as `rt (p * q)` by quadratic reciprocity and a complete mod-4
phase analysis.

For a prime congruent to `3` modulo `4`, `sum_cot` takes imaginary parts in
`sum_legendre` to obtain the Legendre sine transform. It combines this with
the finite cotangent sine transform in `TuringTask/CotMain.lean` and the zero
sum of the quadratic character. Both sums in the theorem remain literal
`Finset.range p` sums, including their vanishing `k = 0` terms.

The cotangent transform is developed without placeholders in
`TuringTask/CotPointwise.lean`, `TuringTask/Fourier.lean`, and
`TuringTask/CotMain.lean`.

The triangular proof completes the square using the inverse of `2` modulo the
odd modulus. It evaluates the resulting unit-twisted DFT trace. Reindexing rows
changes the normalized determinant by the permutation sign; `DoubleSign.lean`
proves that the doubling permutation has sign
`(-1)^(q*(q+1)/2)`. This determinant-sensitive sign resolves the four residue
classes modulo `8`, after which `Triangular.lean` converts back to the exact
real-exponential statement.

The project uses the supplied local Mathlib installation and is not standalone
on an arbitrary machine. In the provided environment, check it offline with:

```sh
lean-offline-init
lake build
lake env lean Audit.lean
```

`lean-offline-init` links Mathlib's already installed local dependencies into
`.lake/packages`; it does not download anything. No network access or remote
dependency fetch is required.
