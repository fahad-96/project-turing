# Project Turing - Task 30 golden answer

Lean 4 project with complete proofs of five results on Dedekind sums `s(h, k)`: Knopp's Hecke
identity, the integrality of `2 gcd(3, k) k s(h, k)`, the congruence of `12 k s(h, k)` modulo `8`
for odd `k`, the criterion `s(h, k) = 0` iff `k | h^2 + 1`, and the criterion for
`s(a, k) = s(b, k)` for a prime `k`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Dedekind.lean`: the sawtooth function, the multiplication formula and the basic
  rules for Dedekind sums.
- `TuringTask/Formulas.lean`: integer formulas for `s(h, k)` with `gcd(h, k) = 1`.
- `TuringTask/Reciprocity.lean`: the reciprocity law by counting lattice points.
- `TuringTask/ModEight.lean`: theorem 3, by induction on the odd modulus.
- `TuringTask/Criteria.lean`: theorems 2, 4 and 5.
- `TuringTask/Knopp.lean`: theorem 1, with the Moebius function.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
