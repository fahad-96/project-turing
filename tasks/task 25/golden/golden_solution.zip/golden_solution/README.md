# Project Turing - Task 25 golden answer

Lean 4 project with complete proofs of five results on Fibonacci and Lucas numbers next to a
square or twice a square: `F_n + 1` is a square exactly for `n` in `{0, 4, 6}`,
`F_n = x^2 + 1` exactly for `n` in `{1, 2, 3, 5}`, `F_n = 2 x^2 + 1` exactly for `n` in
`{1, 2, 4}`, `L_n = x^2 + 1` exactly for `n` in `{0, 1}`, and `L_n + 1 = 2 x^2` exactly for
`n` in `{1, 4, 11}`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Lucas.lean`: Lucas numbers with integer index and the shift congruences
  modulo `L_k`.
- `TuringTask/Residues.lean`: residues modulo 3, 4 and 8, and the obstruction modulo `L_k`.
- `TuringTask/Equations.lean`: Cohn's results on squares and twice squares among `F_n`, `L_n`.
- `TuringTask/Factor.lean`: `L_n = 2 F_(n+1) - F_n`, the factorizations of `F_n +- 1` and
  `L_n +- 1`, coprimality, splitting of products.
- `TuringTask/FibEq.lean`: `L_n = 3 y^2`, and theorems 1, 2 and 3.
- `TuringTask/LucEq.lean`: theorems 4 and 5.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
