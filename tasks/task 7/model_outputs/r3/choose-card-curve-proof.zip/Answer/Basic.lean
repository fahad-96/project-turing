import Answer.CharacterProof

namespace TuringTask

open scoped BigOperators

noncomputable def csum (p : Nat) [Fact p.Prime] (c : Int) : Int :=
  Finset.sum (Finset.range p) (fun x : Nat => legendreSym p ((x : Int) ^ 3 - c * (x : Int)))

lemma legendre_eq_quadraticChar (p : Nat) [Fact p.Prime] (hp2 : p ≠ 2) (a : Int) :
    legendreSym p a = (quadraticChar (ZMod p)) (a : ZMod p) := by
  have hleg := legendreSym.card_sqrts p hp2 a
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hchar := quadraticChar_card_sqrts (F := ZMod p) hpchar (a : ZMod p)
  omega

lemma natCast_fin_eq_finEquiv (p : Nat) [NeZero p] (x : Fin p) :
    ((x.val : Nat) : ZMod p) = (ZMod.finEquiv p) x := by
  cases p with
  | zero => exact Fin.elim0 x
  | succ n =>
      apply ZMod.val_injective (n + 1)
      change x.val % (n + 1) = x.val
      exact Nat.mod_eq_of_lt x.isLt

lemma csum_eq_curveSum (p : Nat) [Fact p.Prime] (hp2 : p ≠ 2) (a : Int) :
    csum p a = CharacterProof.curveSum (a : ZMod p) := by
  rw [csum, CharacterProof.curveSum, ← Fin.sum_univ_eq_sum_range]
  apply Fintype.sum_equiv (ZMod.finEquiv p)
  intro x
  rw [legendre_eq_quadraticChar p hp2]
  congr 1
  push_cast
  rw [natCast_fin_eq_finEquiv p x]

theorem csum_sq_add_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (c r : Int)
    (hc : legendreSym p c = 1) (hr : legendreSym p r = -1) :
    csum p c ^ 2 + csum p r ^ 2 = 4 * (p : Int) := by
  have hp2 : p ≠ 2 := by omega
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hm1 : (quadraticChar (ZMod p)) (-1) = 1 := by
    have h := legendre_eq_quadraticChar p hp2 (-1)
    rw [legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp] at h
    simpa using h.symm
  have hqc : (quadraticChar (ZMod p)) (c : ZMod p) = 1 := by
    rw [← legendre_eq_quadraticChar p hp2]
    exact hc
  have hqr : (quadraticChar (ZMod p)) (r : ZMod p) = -1 := by
    rw [← legendre_eq_quadraticChar p hp2]
    exact hr
  rw [csum_eq_curveSum p hp2, csum_eq_curveSum p hp2]
  rw [CharacterProof.curveSum_sq_add_sq hpchar hm1 (c : ZMod p) (r : ZMod p) hqc hqr]
  rw [ZMod.card]

lemma cast_factorial_eq_prod {R : Type*} [CommSemiring R] (n : Nat) :
    (n.factorial : R) = ∏ i ∈ Finset.range n, ((i + 1 : Nat) : R) := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Nat.factorial_succ, Nat.cast_mul, ih, Finset.prod_range_succ]
      norm_num [mul_comm]

lemma sum_range_reflect (f : Nat → Int) (n : Nat) :
    (∑ i ∈ Finset.range n, f (n - i)) = ∑ i ∈ Finset.range n, f (i + 1) := by
  apply Finset.sum_bij (fun i _ => n - 1 - i)
  · simp only [Finset.mem_range]
    omega
  · intro i hi j hj hij
    simp only [Finset.mem_range] at hi hj
    omega
  · intro j hj
    simp only [Finset.mem_range] at hj
    refine ⟨n - 1 - j, ?_, ?_⟩
    · simp only [Finset.mem_range]
      omega
    · omega
  · intro i hi
    simp only [Finset.mem_range] at hi
    congr 1
    omega

lemma prod_range_reflect {M : Type*} [CommMonoid M] (f : Nat → M) (n : Nat) :
    (∏ i ∈ Finset.range n, f (n - i)) = ∏ i ∈ Finset.range n, f (i + 1) := by
  apply Finset.prod_bij (fun i _ => n - 1 - i)
  · simp only [Finset.mem_range]
    omega
  · intro i hi j hj hij
    simp only [Finset.mem_range] at hi hj
    omega
  · intro j hj
    simp only [Finset.mem_range] at hj
    refine ⟨n - 1 - j, ?_, ?_⟩
    · simp only [Finset.mem_range]
      omega
    · omega
  · intro i hi
    simp only [Finset.mem_range] at hi
    congr 1
    omega

lemma sum_range_of_neg_eq (f : Nat → Int) (n : Nat) (h0 : f 0 = 0)
    (hneg : ∀ x, 1 ≤ x → x ≤ n → f (2 * n + 1 - x) = f x) :
    (∑ x ∈ Finset.range (2 * n + 1), f x) =
      2 * ∑ i ∈ Finset.range n, f (i + 1) := by
  rw [show 2 * n + 1 = (n + 1) + n by omega, Finset.sum_range_add]
  rw [show (∑ x ∈ Finset.range (n + 1), f x) =
      f 0 + ∑ i ∈ Finset.range n, f (i + 1) by
    rw [Finset.sum_range_succ']
    ac_rfl]
  rw [h0, zero_add]
  have hlast : (∑ i ∈ Finset.range n, f (n + 1 + i)) =
      ∑ i ∈ Finset.range n, f (n - i) := by
    apply Finset.sum_congr rfl
    intro i hi
    simp only [Finset.mem_range] at hi
    rw [← hneg (n - i)]
    · congr 1
      omega
    · omega
    · omega
  rw [hlast, sum_range_reflect]
  ring

lemma sum_emod_four_of_signs (s : Finset Nat) (f : Nat → Int)
    (hsign : ∀ x ∈ s, f x = 1 ∨ f x = -1)
    (hprod : ∏ x ∈ s, f x = 1) :
    (∑ x ∈ s, f x) % 4 = (s.card : Int) % 4 := by
  let t := s.filter (fun x => f x = -1)
  have hinter : s ∩ t = t := by
    ext x
    simp [t]
  have hf (x : Nat) (hx : x ∈ s) :
      f x = 1 - 2 * if x ∈ t then (1 : Int) else 0 := by
    simp only [t, Finset.mem_filter]
    rcases hsign x hx with h | h
    · rw [h]
      simp
    · rw [h]
      simp [hx]
  have hsum : (∑ x ∈ s, f x) = (s.card : Int) - 2 * t.card := by
    calc
      _ = ∑ x ∈ s, (1 - 2 * if x ∈ t then (1 : Int) else 0) := by
        apply Finset.sum_congr rfl
        exact hf
      _ = (∑ _x ∈ s, (1 : Int)) -
          2 * ∑ x ∈ s, if x ∈ t then (1 : Int) else 0 := by
        rw [Finset.sum_sub_distrib, Finset.mul_sum]
      _ = _ := by
        rw [Finset.sum_ite_mem, hinter]
        simp
  have hprod' : (∏ x ∈ s, f x) = (-1 : Int) ^ t.card := by
    calc
      _ = ∏ x ∈ s, if x ∈ t then (-1 : Int) else 1 := by
        apply Finset.prod_congr rfl
        intro x hx
        simp only [t, Finset.mem_filter]
        rcases hsign x hx with h | h <;> simp [hx, h]
      _ = _ := by
        rw [Finset.prod_ite]
        simp only [Finset.prod_const, one_pow, mul_one]
        have hfilter : s.filter (fun x => x ∈ t) = t := by
          ext x
          simp [t]
        rw [hfilter]
  have ht_even : Even t.card := by
    apply (neg_one_pow_eq_one_iff_even (by norm_num : (-1 : Int) ≠ 1)).mp
    rw [← hprod', hprod]
  obtain ⟨k, hk⟩ := ht_even
  rw [hsum, hk]
  omega

lemma half_factorial_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    (((p / 2).factorial : ZMod p) ^ 2) = -1 := by
  let n := p / 2
  have hpform : p = 2 * n + 1 := by
    have hprime := (Fact.out : p.Prime)
    have hp2 : p ≠ 2 := by omega
    have hodd := hprime.odd_of_ne_two hp2
    dsimp [n]
    omega
  have hneven : Even n := by
    use n / 2
    omega
  have hw := ZMod.wilsons_lemma p
  have hall : ((p - 1).factorial : ZMod p) =
      ∏ i ∈ Finset.range (2 * n), ((i + 1 : Nat) : ZMod p) := by
    rw [cast_factorial_eq_prod]
    congr 3
    omega
  rw [hall, show 2 * n = n + n by omega, Finset.prod_range_add] at hw
  have hfirst : (∏ i ∈ Finset.range n, ((i + 1 : Nat) : ZMod p)) =
      (n.factorial : ZMod p) := (cast_factorial_eq_prod n).symm
  have hsecond :
      (∏ i ∈ Finset.range n, ((n + i + 1 : Nat) : ZMod p)) =
        (-1 : ZMod p) ^ n * (n.factorial : ZMod p) := by
    calc
      _ = ∏ i ∈ Finset.range n,
          ((-1 : ZMod p) * ((n - i : Nat) : ZMod p)) := by
        apply Finset.prod_congr rfl
        intro i hi
        simp only [Finset.mem_range] at hi
        have hsum : ((n + i + 1 : Nat) : ZMod p) +
            ((n - i : Nat) : ZMod p) = 0 := by
          rw [← Nat.cast_add, show n + i + 1 + (n - i) = p by omega]
          exact ZMod.natCast_self p
        rw [neg_mul, one_mul]
        exact eq_neg_of_add_eq_zero_left hsum
      _ = (-1 : ZMod p) ^ n *
          ∏ i ∈ Finset.range n, ((n - i : Nat) : ZMod p) := by
        rw [Finset.prod_mul_distrib, Finset.prod_const]
        simp
      _ = _ := by rw [prod_range_reflect, ← cast_factorial_eq_prod]
  rw [hfirst, hsecond, hneven.neg_one_pow] at hw
  simpa [pow_two] using hw

lemma quadraticChar_half_factorial (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    (quadraticChar (ZMod p)) ((p / 2).factorial : ZMod p) =
      (quadraticChar (ZMod p)) (2 : ZMod p) := by
  let n := p / 2
  let z : ZMod p := (n.factorial : ZMod p)
  change (quadraticChar (ZMod p)) z = (quadraticChar (ZMod p)) (2 : ZMod p)
  have hp2 : p ≠ 2 := by omega
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  have hsq : z ^ 2 = -1 := by
    simpa [z, n] using half_factorial_sq p hp
  have hneg : (-1 : ZMod p) ≠ 0 := by
    rw [neg_ne_zero]
    exact one_ne_zero
  have hz : z ≠ 0 := by
    intro hz
    rw [hz, zero_pow (by norm_num)] at hsq
    exact hneg hsq.symm
  have hn : n = 2 * (p / 4) := by
    dsimp [n]
    omega
  have hzpow : z ^ n = (-1 : ZMod p) ^ (p / 4) := by
    rw [hn, pow_mul, hsq]
  have hq2 : (quadraticChar (ZMod p)) (2 : ZMod p) =
      if p % 8 = 1 then 1 else -1 := by
    have hcast : ((2 : Int) : ZMod p) = (2 : ZMod p) := by norm_num
    rw [← hcast, ← legendre_eq_quadraticChar p hp2, legendreSym.at_two hp2]
    rcases hp8 with h | h
    · have hc : (p : ZMod 8) = 1 := by
        apply ZMod.val_injective 8
        change p % 8 = 1
        exact h
      simp [hc, ZMod.χ₈, h]
    · have hc : (p : ZMod 8) = 5 := by
        apply ZMod.val_injective 8
        change p % 8 = 5
        exact h
      simp [hc, ZMod.χ₈, h]
  rcases hp8 with hp8 | hp8
  · have hk : Even (p / 4) := by
      use p / 8
      omega
    have his : IsSquare z := by
      apply (ZMod.euler_criterion p hz).mpr
      rw [hzpow, hk.neg_one_pow]
    rw [hq2, if_pos hp8]
    simp [quadraticChar, quadraticCharFun, hz, his]
  · have hk : Odd (p / 4) := by
      use p / 8
      omega
    have hnis : ¬IsSquare z := by
      intro his
      have he := (ZMod.euler_criterion p hz).mp his
      rw [hzpow, hk.neg_one_pow] at he
      have hm1 : (-1 : ZMod p) ≠ 1 := by
        intro h
        have htwo : (2 : ZMod p) ≠ 0 := by
          intro htwo
          have hm : ((2 : Int) : ZMod p) = ((0 : Int) : ZMod p) := by
            norm_num
            exact htwo
          have hdneg : (p : Int) ∣ -2 := by
            simpa using (ZMod.intCast_eq_intCast_iff_dvd_sub 2 0 p).mp hm
          have hdint : (p : Int) ∣ 2 := dvd_neg.mp hdneg
          have hd : p ∣ 2 := Int.natCast_dvd_natCast.mp hdint
          have hpge : 5 ≤ p := by
            have := (Fact.out : p.Prime).two_le
            omega
          have hple : p ≤ 2 := Nat.le_of_dvd (by norm_num) hd
          omega
        apply htwo
        calc
          (2 : ZMod p) = 1 - (-1) := by ring
          _ = 0 := by rw [h]; ring
      exact hm1 he
    rw [hq2, if_neg (by omega)]
    simp [quadraticChar, quadraticCharFun, hz, hnis]

lemma prod_shift_two {R : Type*} [CommSemiring R] (m : Nat) :
    (∏ i ∈ Finset.range m, ((i + 2 : Nat) : R)) = ((m + 1).factorial : R) := by
  rw [cast_factorial_eq_prod, Finset.prod_range_succ']
  norm_num
  apply Finset.prod_congr rfl
  intro i _
  ring

lemma prod_shift_three_mul_two {R : Type*} [CommSemiring R] (m : Nat) :
    (∏ i ∈ Finset.range m, ((i + 3 : Nat) : R)) * 2 =
      ((m + 2).factorial : R) := by
  rw [cast_factorial_eq_prod,
    show m + 2 = (m + 1) + 1 by omega, Finset.prod_range_succ',
    Finset.prod_range_succ']
  norm_num only [Nat.cast_one, mul_one]

lemma zmod_natCast_ne_zero (p x : Nat) (hx0 : 0 < x) (hxp : x < p) :
    (x : ZMod p) ≠ 0 := by
  intro h
  have hv : (x : ZMod p).val = 0 := (ZMod.val_eq_zero _).mpr h
  simp [ZMod.val_natCast, Nat.mod_eq_of_lt hxp] at hv
  omega

lemma half_curve_sign_prod (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    let n := p / 2
    ∏ i ∈ Finset.range (n - 1),
      (quadraticChar (ZMod p))
        (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) = 1 := by
  let n := p / 2
  let Q := quadraticChar (ZMod p)
  let z : ZMod p := (n.factorial : ZMod p)
  change (∏ i ∈ Finset.range (n - 1),
    Q (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p))) = 1
  have hp2 : p ≠ 2 := by omega
  have hpform : p = 2 * n + 1 := by
    have hodd := (Fact.out : p.Prime).odd_of_ne_two hp2
    dsimp [n]
    omega
  have hn2 : 2 ≤ n := by
    have hpge : 5 ≤ p := by
      have := (Fact.out : p.Prime).two_le
      omega
    omega
  have hm1 : Q (-1) = 1 := by
    have h := legendre_eq_quadraticChar p hp2 (-1)
    rw [legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp] at h
    simpa [Q] using h.symm
  have hprod_field :
      (∏ i ∈ Finset.range (n - 1),
        (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p))) * 2 =
        -z ^ 3 := by
    have hfactor (i : Nat) :
        (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) =
          ((i + 2 : Nat) : ZMod p) * ((i + 1 : Nat) : ZMod p) *
            ((i + 3 : Nat) : ZMod p) := by
      push_cast
      ring
    simp_rw [hfactor, Finset.prod_mul_distrib]
    rw [prod_shift_two, ← cast_factorial_eq_prod]
    have hnsub : n - 1 + 1 = n := by omega
    have hnsub2 : n - 1 + 2 = n + 1 := by omega
    rw [hnsub]
    rw [show (z * ((n - 1).factorial : ZMod p) *
        ∏ x ∈ Finset.range (n - 1), ((x + 3 : Nat) : ZMod p)) * 2 =
        z * ((n - 1).factorial : ZMod p) *
          ((∏ x ∈ Finset.range (n - 1), ((x + 3 : Nat) : ZMod p)) * 2) by ring]
    rw [prod_shift_three_mul_two, hnsub2]
    have hfacn : (n.factorial : ZMod p) =
        (n : ZMod p) * ((n - 1).factorial : ZMod p) := by
      rw [show n = (n - 1) + 1 by omega, Nat.factorial_succ, Nat.cast_mul]
      push_cast
      ring
    have hfacnext : ((n + 1).factorial : ZMod p) =
        (n + 1 : ZMod p) * z := by
      rw [Nat.factorial_succ, Nat.cast_mul]
      simp [z]
    have hnneg : (n : ZMod p) + 1 = -(n : ZMod p) := by
      have hs : ((n + 1 : Nat) : ZMod p) + (n : ZMod p) = 0 := by
        rw [← Nat.cast_add, show n + 1 + n = p by omega]
        exact ZMod.natCast_self p
      push_cast at hs
      linear_combination hs
    rw [hfacnext, hnneg]
    change z * ((n - 1).factorial : ZMod p) * (-((n : Nat) : ZMod p) * z) = -z ^ 3
    have hfacn' : z = (n : ZMod p) * ((n - 1).factorial : ZMod p) := by
      simpa [z] using hfacn
    calc
      _ = -((n : ZMod p) * ((n - 1).factorial : ZMod p)) * z ^ 2 := by ring
      _ = _ := by rw [← hfacn']; ring
  have hQprod : Q
      (∏ i ∈ Finset.range (n - 1),
        (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p))) =
      ∏ i ∈ Finset.range (n - 1),
        Q (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) := by
    exact map_prod Q _ _
  rw [← hQprod]
  have hqeq : Q z = Q (2 : ZMod p) := by
    simpa [Q, z, n] using quadraticChar_half_factorial p hp
  have htwo : (2 : ZMod p) ≠ 0 := zmod_natCast_ne_zero p 2 (by omega) (by omega)
  have hq2sq : Q (2 : ZMod p) * Q (2 : ZMod p) = 1 := by
    rw [← map_mul, ← pow_two]
    exact quadraticChar_sq_one' htwo
  have hchar := congrArg Q hprod_field
  simp only [map_mul] at hchar
  rw [show -z ^ 3 = (-1 : ZMod p) * z ^ 3 by ring, map_mul, map_pow, hm1,
    one_mul] at hchar
  rw [hqeq] at hchar
  calc
    Q (∏ i ∈ Finset.range (n - 1),
        (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p))) =
        Q (∏ i ∈ Finset.range (n - 1),
          (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p))) *
          (Q (2 : ZMod p) * Q (2 : ZMod p)) := by rw [hq2sq, mul_one]
    _ = (Q (2 : ZMod p) ^ 3) * Q (2 : ZMod p) := by rw [← mul_assoc, hchar]
    _ = 1 := by nlinarith [hq2sq]

theorem csum_one_emod (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    csum p 1 % 8 = if p % 8 = 5 then 2 else 6 := by
  let n := p / 2
  let Q := quadraticChar (ZMod p)
  let f : Nat → Int := fun x => Q (((x : Nat) : ZMod p) ^ 3 - ((x : Nat) : ZMod p))
  have hp2 : p ≠ 2 := by omega
  have hpform : p = 2 * n + 1 := by
    have hodd := (Fact.out : p.Prime).odd_of_ne_two hp2
    dsimp [n]
    omega
  have hn2 : 2 ≤ n := by
    have hpge : 5 ≤ p := by
      have := (Fact.out : p.Prime).two_le
      omega
    omega
  have hm1 : Q (-1) = 1 := by
    have h := legendre_eq_quadraticChar p hp2 (-1)
    rw [legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp] at h
    simpa [Q] using h.symm
  have hcsum : csum p 1 = ∑ x ∈ Finset.range p, f x := by
    rw [csum]
    apply Finset.sum_congr rfl
    intro x _
    rw [legendre_eq_quadraticChar p hp2]
    dsimp [f, Q]
    congr 1
    push_cast
    ring
  have hf0 : f 0 = 0 := by simp [f, Q]
  have hpair : ∀ x, 1 ≤ x → x ≤ n → f (2 * n + 1 - x) = f x := by
    intro x hx0 hxn
    have hcast : (((2 * n + 1 - x : Nat) : ZMod p)) = -((x : Nat) : ZMod p) := by
      have hs : (((2 * n + 1 - x : Nat) : ZMod p)) + ((x : Nat) : ZMod p) = 0 := by
        rw [← Nat.cast_add, show 2 * n + 1 - x + x = p by omega]
        exact ZMod.natCast_self p
      exact eq_neg_of_add_eq_zero_left hs
    dsimp [f]
    rw [hcast]
    rw [show (-((x : Nat) : ZMod p)) ^ 3 - (-((x : Nat) : ZMod p)) =
      (-1 : ZMod p) * (((x : Nat) : ZMod p) ^ 3 - ((x : Nat) : ZMod p)) by ring]
    rw [map_mul, hm1, one_mul]
  have hhalf : csum p 1 = 2 * ∑ i ∈ Finset.range n, f (i + 1) := by
    rw [hcsum, hpform]
    exact sum_range_of_neg_eq f n hf0 hpair
  have hf1 : f 1 = 0 := by simp [f, Q]
  have hsplit : (∑ i ∈ Finset.range n, f (i + 1)) =
      ∑ i ∈ Finset.range (n - 1), f (i + 2) := by
    rw [show n = (n - 1) + 1 by omega, Finset.sum_range_succ']
    simp [hf1]
  let s := Finset.range (n - 1)
  let g : Nat → Int := fun i => f (i + 2)
  have hsign : ∀ i ∈ s, g i = 1 ∨ g i = -1 := by
    intro i hi
    simp only [s, Finset.mem_range] at hi
    have hx0 : 0 < i + 2 := by omega
    have hxm : i + 2 < p := by omega
    have hxm1 : 0 < i + 1 := by omega
    have hxm1p : i + 1 < p := by omega
    have hxp1 : 0 < i + 3 := by omega
    have hxp1p : i + 3 < p := by omega
    have h0 : (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) ≠ 0 := by
      rw [show (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) =
        ((i + 2 : Nat) : ZMod p) * ((i + 1 : Nat) : ZMod p) *
          ((i + 3 : Nat) : ZMod p) by push_cast; ring]
      exact mul_ne_zero
        (mul_ne_zero (zmod_natCast_ne_zero p (i + 2) hx0 hxm)
          (zmod_natCast_ne_zero p (i + 1) hxm1 hxm1p))
        (zmod_natCast_ne_zero p (i + 3) hxp1 hxp1p)
    have hsquare : Q (((i + 2 : Nat) : ZMod p) ^ 3 - ((i + 2 : Nat) : ZMod p)) ^ 2 = 1 :=
      quadraticChar_sq_one h0
    change Q _ = 1 ∨ Q _ = -1
    exact sq_eq_one_iff.mp hsquare
  have hprod : ∏ i ∈ s, g i = 1 := by
    simpa [s, g, f, Q, n] using half_curve_sign_prod p hp
  have hmod := sum_emod_four_of_signs s g hsign hprod
  have hcard : s.card = n - 1 := by simp [s]
  rw [hcard] at hmod
  rw [hhalf, hsplit]
  change (2 * ∑ i ∈ s, g i) % 8 = _
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases hp8 with hp8 | hp8
  · rw [if_neg (by omega)]
    omega
  · rw [if_pos hp8]
    omega

lemma prime_odd_coordinate_unique (p : Nat) [Fact p.Prime] (hp : p % 4 = 1)
    (a b A B : Int) (hab : a ^ 2 + b ^ 2 = (p : Int))
    (hAB : A ^ 2 + B ^ 2 = (p : Int)) (ha : a % 2 = 1) (hA : A % 2 = 1) :
    a ^ 2 = A ^ 2 := by
  let P : Int := p
  have hPpos : 0 < P := by
    dsimp [P]
    exact_mod_cast (Fact.out : p.Prime).pos
  obtain ⟨q, hP⟩ : ∃ q : Int, P = 4 * q + 1 := by
    refine ⟨P / 4, ?_⟩
    dsimp [P]
    omega
  obtain ⟨u, hu⟩ : ∃ u : Int, a = 2 * u + 1 := by
    exact ⟨a / 2, by omega⟩
  obtain ⟨v, hv⟩ : ∃ v : Int, b = 2 * v := by
    rcases Int.even_or_odd' b with ⟨v, hv | hv⟩
    · exact ⟨v, hv⟩
    · exfalso
      dsimp [P] at hP
      rw [hu, hv, hP] at hab
      ring_nf at hab
      omega
  obtain ⟨U, hU⟩ : ∃ U : Int, A = 2 * U + 1 := by
    exact ⟨A / 2, by omega⟩
  obtain ⟨V, hV⟩ : ∃ V : Int, B = 2 * V := by
    rcases Int.even_or_odd' B with ⟨V, hV | hV⟩
    · exact ⟨V, hV⟩
    · exfalso
      dsimp [P] at hP
      rw [hU, hV, hP] at hAB
      ring_nf at hAB
      omega
  let z₁ := a * B - b * A
  let z₂ := a * B + b * A
  have hprod : z₁ * z₂ = P * (a ^ 2 - A ^ 2) := by
    dsimp [z₁, z₂, P]
    linear_combination a ^ 2 * hAB - A ^ 2 * hab
  have hPprime : Prime P := by
    dsimp [P]
    exact Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)
  have hdiv : P ∣ z₁ ∨ P ∣ z₂ := by
    apply hPprime.dvd_mul.mp
    rw [hprod]
    exact dvd_mul_right P (a ^ 2 - A ^ 2)
  have hz₁even : ∃ t : Int, z₁ = 2 * t := by
    refine ⟨u * V * 2 + V - v * U * 2 - v, ?_⟩
    simp only [z₁]
    rw [hu, hv, hU, hV]
    ring
  have hz₂even : ∃ t : Int, z₂ = 2 * t := by
    refine ⟨u * V * 2 + V + v * U * 2 + v, ?_⟩
    simp only [z₂]
    rw [hu, hv, hU, hV]
    ring
  have hlag₁ : z₁ ^ 2 + (a * A + b * B) ^ 2 = P ^ 2 := by
    calc
      _ = (a ^ 2 + b ^ 2) * (A ^ 2 + B ^ 2) := by
        dsimp [z₁]
        ring
      _ = _ := by rw [hab, hAB]; simp [P, pow_two]
  have hlag₂ : z₂ ^ 2 + (a * A - b * B) ^ 2 = P ^ 2 := by
    calc
      _ = (a ^ 2 + b ^ 2) * (A ^ 2 + B ^ 2) := by
        dsimp [z₂]
        ring
      _ = _ := by rw [hab, hAB]; simp [P, pow_two]
  have factor_zero (z w : Int) (hzw : z ^ 2 + w ^ 2 = P ^ 2)
      (hzeven : ∃ t : Int, z = 2 * t) (hzdiv : P ∣ z) : z = 0 := by
    obtain ⟨t, ht⟩ := hzeven
    obtain ⟨k, hk⟩ := hzdiv
    have hkeven : ∃ l : Int, k = 2 * l := by
      let m := q * k
      have hpar : 2 * t = 4 * m + k := by
        calc
          2 * t = P * k := by rw [← ht, hk]
          _ = (4 * q + 1) * k := by rw [hP]
          _ = 4 * m + k := by dsimp [m]; ring
      refine ⟨k / 2, ?_⟩
      omega
    have hzsq : z ^ 2 ≤ P ^ 2 := by nlinarith [sq_nonneg w]
    have hzle : z ≤ P := by nlinarith [sq_nonneg (z + P)]
    have hzge : -P ≤ z := by nlinarith [sq_nonneg (z - P)]
    rw [hk] at hzle hzge
    have hiffle : P * k ≤ P * 1 ↔ k ≤ 1 := Int.mul_le_mul_left hPpos
    have hkle : k ≤ 1 := hiffle.mp (by simpa using hzle)
    have hkge : -1 ≤ k := by
      have hiffge : P * (-1) ≤ P * k ↔ -1 ≤ k := Int.mul_le_mul_left hPpos
      apply hiffge.mp
      simpa [mul_comm] using hzge
    obtain ⟨l, hl⟩ := hkeven
    have : k = 0 := by omega
    rw [hk, this, mul_zero]
  rcases hdiv with hz₁ | hz₂
  · have hz := factor_zero z₁ (a * A + b * B) hlag₁ hz₁even hz₁
    have hzero : P * (a ^ 2 - A ^ 2) = 0 := by rw [← hprod, hz, zero_mul]
    nlinarith
  · have hz := factor_zero z₂ (a * A - b * B) hlag₂ hz₂even hz₂
    have hzero : P * (a ^ 2 - A ^ 2) = 0 := by rw [← hprod, hz, mul_zero]
    nlinarith

lemma csum_sq_eq_one_of_residue (p : Nat) [Fact p.Prime] (hp : p % 4 = 1)
    (c : Int) (hc : legendreSym p c = 1) :
    csum p c ^ 2 = csum p 1 ^ 2 := by
  let Q := quadraticChar (ZMod p)
  have hp2 : p ≠ 2 := by omega
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hqc : Q (c : ZMod p) = 1 := by
    dsimp [Q]
    rw [← legendre_eq_quadraticChar p hp2]
    exact hc
  have hc0 : (c : ZMod p) ≠ 0 := by
    intro h
    have hz := quadraticChar_zero (F := ZMod p)
    rw [h, hz] at hqc
    norm_num at hqc
  have hcardInt : ({x : ZMod p | x ^ 2 = (c : ZMod p)}.toFinset.card : Int) = 2 := by
    rw [quadraticChar_card_sqrts hpchar, hqc]
    norm_num
  have hcard : {x : ZMod p | x ^ 2 = (c : ZMod p)}.toFinset.card = 2 := by
    exact_mod_cast hcardInt
  have hnonempty : {x : ZMod p | x ^ 2 = (c : ZMod p)}.toFinset.Nonempty := by
    rw [Finset.nonempty_iff_ne_empty]
    intro he
    rw [he] at hcard
    simp at hcard
  obtain ⟨d, hd⟩ := hnonempty
  have hdroot : d ^ 2 = (c : ZMod p) := by simpa using hd
  have hd0 : d ≠ 0 := by
    intro h
    rw [h, zero_pow (by norm_num)] at hdroot
    exact hc0 hdroot.symm
  have hqd : Q d * Q d = 1 := by
    rw [← map_mul, ← pow_two]
    exact quadraticChar_sq_one' hd0
  have htwist : CharacterProof.curveSum (c : ZMod p) =
      Q d * CharacterProof.curveSum (1 : ZMod p) := by
    let e : ZMod p ≃ ZMod p := Equiv.mulRight₀ d hd0
    rw [CharacterProof.curveSum, CharacterProof.curveSum]
    have hreindex : (∑ x : ZMod p, Q (x ^ 3 - (c : ZMod p) * x)) =
        ∑ x : ZMod p, Q ((e x) ^ 3 - (c : ZMod p) * (e x)) := by
      symm
      exact Fintype.sum_equiv e _ _ (fun _ => rfl)
    rw [hreindex, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    simp only [e, Equiv.mulRight₀_apply]
    rw [show (x * d) ^ 3 - (c : ZMod p) * (x * d) =
      d ^ 3 * (x ^ 3 - 1 * x) by rw [← hdroot]; ring]
    rw [map_mul, map_pow]
    calc
      Q d ^ 3 * Q (x ^ 3 - 1 * x) =
          (Q d * Q d) * (Q d * Q (x ^ 3 - 1 * x)) := by ring
      _ = _ := by rw [hqd, one_mul]
  rw [csum_eq_curveSum p hp2, csum_eq_curveSum p hp2, htwist]
  calc
    (Q d * CharacterProof.curveSum (1 : ZMod p)) ^ 2 =
        (Q d * Q d) * CharacterProof.curveSum (1 : ZMod p) ^ 2 := by ring
    _ = _ := by rw [hqd, one_mul]; norm_num

theorem csum_sq_of_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b c : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 2 = 1) (hc : legendreSym p c = 1) :
    csum p c ^ 2 = 4 * a ^ 2 := by
  have hp2 : p ≠ 2 := by omega
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  let Q := quadraticChar (ZMod p)
  have hex : ∃ r : ZMod p, Q r = -1 := by
    by_contra h
    push Not at h
    have hall (x : ZMod p) (hx : x ≠ 0) : Q x = 1 := by
      have hs : Q x ^ 2 = 1 := quadraticChar_sq_one hx
      rcases sq_eq_one_iff.mp hs with hx1 | hxm1
      · exact hx1
      · exact (h x hxm1).elim
    have hsum : (∑ x : ZMod p, Q x) = (p : Int) - 1 := by
      calc
        _ = ∑ x : ZMod p, Q x ^ 2 := by
          apply Finset.sum_congr rfl
          intro x _
          by_cases hx : x = 0
          · subst x
            simp [Q]
          · rw [hall x hx]
            norm_num
        _ = (Fintype.card (ZMod p) : Int) - 1 := CharacterProof.sum_quadratic_sq
        _ = _ := by rw [ZMod.card]
    have hzero := quadraticChar_sum_zero hpchar
    rw [hzero] at hsum
    have hpge := (Fact.out : p.Prime).two_le
    omega
  obtain ⟨r, hr⟩ := hex
  let rInt : Int := r.val
  have hrleg : legendreSym p rInt = -1 := by
    rw [legendre_eq_quadraticChar p hp2]
    dsimp [rInt, Q]
    norm_num only [Int.cast_natCast]
    rw [ZMod.natCast_zmod_val]
    exact hr
  have hsum := csum_sq_add_sq p hp 1 rInt (by simp) hrleg
  have hone := csum_one_emod p hp
  have honeeven : ∃ A : Int, csum p 1 = 2 * A := by
    have hmod2 : csum p 1 % 2 = 0 := by
      split at hone <;> omega
    have hd : (2 : Int) ∣ csum p 1 := Int.dvd_iff_emod_eq_zero.mpr hmod2
    obtain ⟨A, hA⟩ := hd
    exact ⟨A, by omega⟩
  obtain ⟨A, hA⟩ := honeeven
  have hReven : ∃ B : Int, csum p rInt = 2 * B := by
    rcases Int.even_or_odd' (csum p rInt) with ⟨B, hB | hB⟩
    · exact ⟨B, hB⟩
    · exfalso
      rw [hA, hB] at hsum
      ring_nf at hsum
      omega
  obtain ⟨B, hB⟩ := hReven
  have hAB : A ^ 2 + B ^ 2 = (p : Int) := by
    rw [hA, hB] at hsum
    nlinarith
  have hAodd : A % 2 = 1 := by
    split at hone <;> omega
  have haA := prime_odd_coordinate_unique p hp a b A B hab hAB ha hAodd
  rw [csum_sq_eq_one_of_residue p hp c hc, hA, haA]
  ring

end TuringTask
