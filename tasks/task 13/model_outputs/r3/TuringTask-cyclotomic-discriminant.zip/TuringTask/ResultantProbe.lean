import Mathlib

-- Focused inventory for likely strategies involving polynomial resultants.
#check Polynomial.resultant_eq_zero_iff
#check Polynomial.resultant_ne_zero
#check Polynomial.resultant_comm
#check Polynomial.resultant_mul_left
#check Polynomial.resultant_mul_right
#check Polynomial.resultant_add_mul_left
#check Polynomial.resultant_add_mul_right
#check Polynomial.resultant_X_sub_C_left
#check Polynomial.resultant_X_sub_C_right
#check Polynomial.resultant_eq_prod_eval
#check Polynomial.resultant_eq_prod_roots_sub
#check Polynomial.exists_mul_add_mul_eq_C_resultant
#check Polynomial.isUnit_resultant_iff_isCoprime
