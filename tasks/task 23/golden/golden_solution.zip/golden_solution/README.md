# Project Turing - Task 23 golden answer

Lean 4 project with complete proofs of five results on smooth numbers (Stormer, Lehmer): the
`n` with every prime factor of `n (n + 1)` at most `7`, the `x` with every prime factor of
`x^2 - 1` at most `7`, the `n` with every prime factor of `n (n + 1) (n + 2)` at most `7`, the
`x` with every prime factor of `x^2 + 1` at most `13`, and the solutions of
`x^2 - 2 y^2 = +-1` with every prime factor of `y` at most `13`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/PellSeq.lean`: powers `X_k + Y_k sqrt D = (a + b sqrt D)^k`, divisibility of
  `Y_k`, and the bound on the prime factors of an index with `Y_k` smooth.
- `TuringTask/PellDescent.lean`: every solution of a Pell equation is a power of the unit;
  helpers for indices and for the explicit units.
- `TuringTask/Blocks210a.lean`, `TuringTask/Blocks210b.lean`: `x^2 - D y^2 = 1` for the 15
  squarefree `D > 1` dividing 210.
- `TuringTask/Blocks65.lean`: `x^2 - D y^2 = -1` for the 7 squarefree `D > 1` dividing 130, and
  `x^2 - 2 y^2 = +-1`.
- `TuringTask/Stormer.lean`: the five statements from the squarefree part of `x^2 - 1` and
  `x^2 + 1`.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
