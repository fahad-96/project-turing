# Project Turing - Task 22 golden answer

Lean 4 project with complete proofs of five statements about cubes: the equation
`x^3 + y^3 = 2 z^3` has only the solutions with `x = y` or `x + y = 0` (Euler's descent in the
Eisenstein integers), the rational points of `y^2 = x^3 + 1` and `y^2 = x^3 - 27`, the integer
solutions of `x^3 - 2 y^3 = 1` and `x^3 - 2 y^3 = -1`, and the triangular numbers
`n (n + 1) / 2` that are cubes.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Eisenstein.lean`: the Eisenstein integers as `QuadraticAlgebra Int (-1) (-1)`,
  division with rounding, the Euclidean structure, cubes of coprime factors, the six units.
- `TuringTask/EulerCube.lean`: Euler's lemma on cubes of the form `u^2 + 3 v^2`.
- `TuringTask/Descent.lean`: the descent for `x^3 + y^3 = 2 z^3` (theorem 1).
- `TuringTask/Curves.lean`: the rational points of `y^2 = x^3 - 27` and `y^2 = x^3 + 1`.
- `TuringTask/Apps.lean`: `x^3 - 2 y^3 = +-1` and `n (n + 1) = 2 m^3`.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
