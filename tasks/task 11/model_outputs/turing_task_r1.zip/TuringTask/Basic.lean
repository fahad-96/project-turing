import Mathlib

namespace TuringTask

open Classical

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

/-! ### Part 1: Abstract Lovász Local Lemma -/

variable {Ω I : Type*} [Fintype Ω] [DecidableEq Ω] [Fintype I] [DecidableEq I]

noncomputable def E (A : I → Finset Ω) (J : Finset I) : Finset Ω :=
  Finset.univ.filter (fun ω => ∀ j ∈ J, ω ∉ A j)

lemma mem_E (A : I → Finset Ω) (J : Finset I) (ω : Ω) :
    ω ∈ E A J ↔ ∀ j ∈ J, ω ∉ A j := by
  simp [E]

lemma E_empty (A : I → Finset Ω) : E A ∅ = Finset.univ := by
  ext ω
  simp [E]

lemma E_insert (A : I → Finset Ω) (J : Finset I) (u : I) :
    E A (insert u J) = E A J \ A u := by
  ext ω
  simp [E]
  tauto

lemma card_E_insert (A : I → Finset Ω) (J : Finset I) (u : I) :
    ((E A (insert u J)).card : ℝ) = ((E A J).card : ℝ) - ((A u ∩ E A J).card : ℝ) := by
  rw [E_insert]
  have h := Finset.card_sdiff (s := A u) (t := E A J)
  have h_le : (A u ∩ E A J).card ≤ (E A J).card := Finset.card_le_card Finset.inter_subset_right
  rw [h]
  exact Nat.cast_sub h_le

lemma E_union_prod_le
    (A : I → Finset Ω)
    (x : I → ℝ)
    (hx : ∀ i, 0 ≤ x i ∧ x i < 1)
    (s : ℕ)
    (h_step : ∀ K, K.card ≤ s → ∀ i ∉ K,
      ((A i ∩ E A K).card : ℝ) ≤ x i * ((E A K).card : ℝ))
    (J1 J2 : Finset I)
    (hdisj : Disjoint J1 J2)
    (hcard : (J1 ∪ J2).card ≤ s + 1) :
    ((E A J2).card : ℝ) * (∏ j ∈ J1, (1 - x j)) ≤ ((E A (J1 ∪ J2)).card : ℝ) := by
  induction J1 using Finset.induction_on with
  | empty =>
    simp
  | @insert u J1 hu ih =>
    rw [Finset.disjoint_insert_left] at hdisj
    have hdisj1 : Disjoint J1 J2 := hdisj.2
    have hu_not_union : u ∉ J1 ∪ J2 := by
      intro h
      rw [Finset.mem_union] at h
      cases h with
      | inl h => exact hu h
      | inr h => exact hdisj.1 h
    have hcard1 : (J1 ∪ J2).card ≤ s := by
      have h_ins : (insert u J1 ∪ J2).card = (J1 ∪ J2).card + 1 := by
        rw [Finset.insert_union, Finset.card_insert_of_notMem hu_not_union]
      rw [h_ins] at hcard
      omega
    have ih_res := ih hdisj1 (hcard1.trans (Nat.le_succ s))
    rw [Finset.insert_union]
    rw [card_E_insert A (J1 ∪ J2) u]
    rw [Finset.prod_insert hu]
    have hu_step := h_step (J1 ∪ J2) hcard1 u hu_not_union
    have h_factor : (1 - x u) * ((E A (J1 ∪ J2)).card : ℝ) ≤
        ((E A (J1 ∪ J2)).card : ℝ) - ((A u ∩ E A (J1 ∪ J2)).card : ℝ) := by
      linarith
    have h_x_pos : 0 ≤ 1 - x u := by linarith [(hx u).2]
    have h_mul := mul_le_mul_of_nonneg_left ih_res h_x_pos
    rw [← mul_assoc] at h_mul
    have h_comm : (1 - x u) * ((E A J2).card : ℝ) = ((E A J2).card : ℝ) * (1 - x u) := mul_comm _ _
    rw [h_comm, mul_assoc] at h_mul
    exact h_mul.trans h_factor

lemma prod_one_sub_le_prod_one_sub_subset
    (x : I → ℝ)
    (hx : ∀ i, 0 ≤ x i ∧ x i < 1)
    {S T : Finset I} (hST : S ⊆ T) :
    ∏ j ∈ T, (1 - x j) ≤ ∏ j ∈ S, (1 - x j) := by
  have h_dec : T = S ∪ (T \ S) := (Finset.union_sdiff_of_subset hST).symm
  rw [h_dec, Finset.prod_union Finset.disjoint_sdiff]
  have h_le1 : ∏ j ∈ T \ S, (1 - x j) ≤ 1 := by
    apply Finset.prod_le_one
    · intro j hj; linarith [(hx j).2]
    · intro j hj; linarith [(hx j).1]
  have h_pos : 0 ≤ ∏ j ∈ S, (1 - x j) := by
    apply Finset.prod_nonneg
    intro j hj; linarith [(hx j).2]
  calc
    (∏ j ∈ S, (1 - x j)) * ∏ j ∈ T \ S, (1 - x j)
      ≤ (∏ j ∈ S, (1 - x j)) * 1 := mul_le_mul_of_nonneg_left h_le1 h_pos
    _ = ∏ j ∈ S, (1 - x j) := mul_one _

lemma E_subset_le (A : I → Finset Ω) {J K : Finset I} (h : J ⊆ K) :
    E A K ⊆ E A J := by
  intro ω hω
  rw [E, Finset.mem_filter] at hω ⊢
  refine ⟨hω.1, fun j hj => hω.2 j (h hj)⟩

lemma lovasz_local_lemma_inductive
    (A : I → Finset Ω)
    (D : I → Finset I)
    (x : I → ℝ)
    (hx : ∀ i, 0 ≤ x i ∧ x i < 1)
    (hΩ : 0 < Fintype.card Ω)
    (h_not_mem : ∀ i, i ∉ D i)
    (h_indep : ∀ i J, Disjoint J (insert i (D i)) →
      ((A i ∩ E A J).card : ℝ) * (Fintype.card Ω : ℝ) = ((A i).card : ℝ) * ((E A J).card : ℝ))
    (h_bound : ∀ i, ((A i).card : ℝ) ≤ x i * (∏ j ∈ D i, (1 - x j)) * (Fintype.card Ω : ℝ)) :
    ∀ s (J : Finset I), J.card ≤ s → ∀ i ∉ J,
      ((A i ∩ E A J).card : ℝ) ≤ x i * ((E A J).card : ℝ) := by
  have h_card_pos : (0 : ℝ) < (Fintype.card Ω : ℝ) := Nat.cast_pos.mpr hΩ
  intro s
  induction s with
  | zero =>
    intro J hJ i hi
    have hJ0 : J = ∅ := Finset.card_eq_zero.mp (by omega)
    subst hJ0
    have h_disj : Disjoint (∅ : Finset I) (insert i (D i)) := Finset.disjoint_empty_left _
    have hind := h_indep i ∅ h_disj
    have hind' : ((A i ∩ E A ∅).card : ℝ) = ((A i).card : ℝ) := by
      have h1 : ((A i ∩ E A ∅).card : ℝ) * (Fintype.card Ω : ℝ) = ((A i).card : ℝ) * (Fintype.card Ω : ℝ) := by
        rw [hind, E_empty, Finset.card_univ]
      exact mul_right_cancel₀ (ne_of_gt h_card_pos) h1
    rw [hind', E_empty, Finset.card_univ]
    have hb := h_bound i
    have h_prod_le1 : ∏ j ∈ D i, (1 - x j) ≤ 1 := by
      apply Finset.prod_le_one
      · intro j hj; linarith [(hx j).2]
      · intro j hj; linarith [(hx j).1]
    calc
      ((A i).card : ℝ) ≤ x i * (∏ j ∈ D i, (1 - x j)) * (Fintype.card Ω : ℝ) := hb
      _ ≤ x i * 1 * (Fintype.card Ω : ℝ) := by
        have : x i * (∏ j ∈ D i, (1 - x j)) ≤ x i * 1 :=
          mul_le_mul_of_nonneg_left h_prod_le1 (hx i).1
        exact mul_le_mul_of_nonneg_right this (by positivity)
      _ = x i * (Fintype.card Ω : ℝ) := by ring
  | succ s ih =>
    intro J hJ i hi
    by_cases hJ_le : J.card ≤ s
    · exact ih J hJ_le i hi
    have hJ_eq : J.card = s + 1 := by omega
    set J1 := J ∩ D i with hJ1_def
    set J2 := J \ D i with hJ2_def
    have hdisj12 : Disjoint J1 J2 := Disjoint.symm (Finset.disjoint_sdiff_inter J (D i))
    have hunion12 : J1 ∪ J2 = J := by
      ext k
      simp [J1, J2]
      tauto
    have hdisj_indep : Disjoint J2 (insert i (D i)) := by
      rw [Finset.disjoint_insert_right]
      refine ⟨?_, ?_⟩
      · intro hiJ2
        rw [hJ2_def, Finset.mem_sdiff] at hiJ2
        exact hi hiJ2.1
      · rw [hJ2_def]
        exact Finset.sdiff_disjoint
    have hind := h_indep i J2 hdisj_indep
    have hind' : ((A i ∩ E A J2).card : ℝ) =
        (((A i).card : ℝ) / (Fintype.card Ω : ℝ)) * ((E A J2).card : ℝ) := by
      rw [← mul_div_right_comm, ← hind]
      rw [mul_div_cancel_right₀ _ (ne_of_gt h_card_pos)]
    have h_sub : A i ∩ E A J ⊆ A i ∩ E A J2 := by
      apply Finset.inter_subset_inter (fun ⦃a⦄ ha => ha)
      apply E_subset_le
      intro j hj
      rw [hJ2_def, Finset.mem_sdiff] at hj
      exact hj.1
    have h_sub_card : ((A i ∩ E A J).card : ℝ) ≤ ((A i ∩ E A J2).card : ℝ) := by
      exact Nat.cast_le.mpr (Finset.card_le_card h_sub)
    have hb := h_bound i
    have hb_div : ((A i).card : ℝ) / (Fintype.card Ω : ℝ) ≤ x i * ∏ j ∈ D i, (1 - x j) := by
      rw [div_le_iff₀ h_card_pos]
      exact hb
    have h_prod_le := prod_one_sub_le_prod_one_sub_subset x hx (show J1 ⊆ D i from Finset.inter_subset_right)
    have h_bound2 : ((A i).card : ℝ) / (Fintype.card Ω : ℝ) ≤ x i * ∏ j ∈ J1, (1 - x j) := by
      calc
        ((A i).card : ℝ) / (Fintype.card Ω : ℝ) ≤ x i * ∏ j ∈ D i, (1 - x j) := hb_div
        _ ≤ x i * ∏ j ∈ J1, (1 - x j) := mul_le_mul_of_nonneg_left h_prod_le (hx i).1
    have h_J1_card : (J1 ∪ J2).card ≤ s + 1 := by rw [hunion12, hJ_eq]
    have h_prod_E := E_union_prod_le A x hx s ih J1 J2 hdisj12 h_J1_card
    rw [hunion12] at h_prod_E
    calc
      ((A i ∩ E A J).card : ℝ) ≤ ((A i ∩ E A J2).card : ℝ) := h_sub_card
      _ = (((A i).card : ℝ) / (Fintype.card Ω : ℝ)) * ((E A J2).card : ℝ) := hind'
      _ ≤ (x i * ∏ j ∈ J1, (1 - x j)) * ((E A J2).card : ℝ) := by
        exact mul_le_mul_of_nonneg_right h_bound2 (by positivity)
      _ = x i * (((E A J2).card : ℝ) * ∏ j ∈ J1, (1 - x j)) := by ring
      _ ≤ x i * ((E A J).card : ℝ) := mul_le_mul_of_nonneg_left h_prod_E (hx i).1

theorem lovasz_local_lemma
    (A : I → Finset Ω)
    (D : I → Finset I)
    (x : I → ℝ)
    (hx : ∀ i, 0 ≤ x i ∧ x i < 1)
    (hΩ : 0 < Fintype.card Ω)
    (h_not_mem : ∀ i, i ∉ D i)
    (h_indep : ∀ i J, Disjoint J (insert i (D i)) →
      ((A i ∩ E A J).card : ℝ) * (Fintype.card Ω : ℝ) = ((A i).card : ℝ) * ((E A J).card : ℝ))
    (h_bound : ∀ i, ((A i).card : ℝ) ≤ x i * (∏ j ∈ D i, (1 - x j)) * (Fintype.card Ω : ℝ)) :
    ∃ ω : Ω, ∀ i, ω ∉ A i := by
  have hind := lovasz_local_lemma_inductive A D x hx hΩ h_not_mem h_indep h_bound (Fintype.card I)
  have h_prod := E_union_prod_le A x hx (Fintype.card I) hind Finset.univ ∅ (Finset.disjoint_empty_right _) (by simp)
  rw [Finset.union_empty, E_empty, Finset.card_univ] at h_prod
  have h_pos : 0 < (Fintype.card Ω : ℝ) * ∏ j ∈ Finset.univ, (1 - x j) := by
    apply mul_pos
    · exact Nat.cast_pos.mpr hΩ
    · apply Finset.prod_pos
      intro j hj; linarith [(hx j).2]
  have h_E_pos : 0 < ((E A Finset.univ).card : ℝ) := lt_of_lt_of_le h_pos h_prod
  have h_card_pos : 0 < (E A Finset.univ).card := Nat.cast_pos.mp h_E_pos
  obtain ⟨ω, hω⟩ := Finset.card_pos.mp h_card_pos
  rw [E, Finset.mem_filter] at hω
  refine ⟨ω, fun i => hω.2 i (Finset.mem_univ i)⟩

/-! ### Part 2: Variable-based SAT / Clause LLL -/

variable {V : Type*} [Fintype V] [DecidableEq V]

noncomputable def overrideOnSub (c : V → Bool) (S : Finset V) (w : S → Bool) : V → Bool :=
  fun v => if h : v ∈ S then w ⟨v, h⟩ else c v

lemma overrideOnSub_mem (c : V → Bool) (S : Finset V) (w : S → Bool)
    (v : V) (hv : v ∈ S) :
    overrideOnSub c S w v = w ⟨v, hv⟩ := by
  simp [overrideOnSub, hv]

lemma overrideOnSub_not_mem (c : V → Bool) (S : Finset V) (w : S → Bool)
    (v : V) (hv : v ∉ S) :
    overrideOnSub c S w v = c v := by
  simp [overrideOnSub, hv]

lemma card_prod_eq_card_of_indep
    (S : Finset V)
    (bad : S → Bool)
    (A : Finset (V → Bool))
    (hA : A = Finset.univ.filter (fun c => ∀ (v : S), c v.1 = bad v))
    (E : Finset (V → Bool))
    (hE : ∀ (c : V → Bool) (w : S → Bool), c ∈ E → overrideOnSub c S w ∈ E) :
    2 ^ S.card * (A ∩ E).card = E.card := by
  have h_equiv : (S → Bool) × { c // c ∈ A ∩ E } ≃ { c // c ∈ E } := {
    toFun := fun p => ⟨overrideOnSub p.2.1 S p.1, by
      have hp2 := p.2.2
      rw [Finset.mem_inter] at hp2
      exact hE p.2.1 p.1 hp2.2⟩
    invFun := fun c => (
      fun (v : S) => c.1 v.1,
      ⟨overrideOnSub c.1 S bad, by
        rw [Finset.mem_inter, hA, Finset.mem_filter]
        refine ⟨⟨Finset.mem_univ _, fun v => ?_⟩, ?_⟩
        · rw [overrideOnSub_mem _ _ _ v.1 v.2]
        · exact hE c.1 bad c.2⟩
    )
    left_inv := by
      rintro ⟨w, ⟨c, hc⟩⟩
      rw [Finset.mem_inter, hA, Finset.mem_filter] at hc
      have hcA := hc.1.2
      apply Prod.ext
      · funext ⟨v, hv⟩
        dsimp
        rw [overrideOnSub_mem _ _ _ v hv]
      · apply Subtype.ext
        dsimp
        ext v
        by_cases hv : v ∈ S
        · rw [overrideOnSub_mem _ _ _ v hv]
          have := hcA ⟨v, hv⟩
          rw [this]
        · rw [overrideOnSub_not_mem _ _ _ v hv, overrideOnSub_not_mem _ _ _ v hv]
    right_inv := by
      rintro ⟨c, hc⟩
      apply Subtype.ext
      dsimp
      ext v
      by_cases hv : v ∈ S
      · rw [overrideOnSub_mem _ _ _ v hv]
      · rw [overrideOnSub_not_mem _ _ _ v hv, overrideOnSub_not_mem _ _ _ v hv]
  }
  have h_card := Fintype.card_congr h_equiv
  rw [Fintype.card_prod, Fintype.card_coe, Fintype.card_coe, Fintype.card_fun, Fintype.card_bool, Fintype.card_coe] at h_card
  exact h_card

lemma one_sub_div_pow_ge_exp_neg_one (d : ℕ) (hd : 1 ≤ d) :
    Real.exp (-1) ≤ (1 - 1 / ((d : ℝ) + 1)) ^ d := by
  have hd_pos : 0 < (d : ℝ) := by positivity
  have hd1_pos : 0 < (d : ℝ) + 1 := by positivity
  have h1 : 1 + 1 / (d : ℝ) ≤ Real.exp (1 / (d : ℝ)) := by
    have := Real.add_one_le_exp (1 / (d : ℝ))
    linarith
  have h2 : (1 + 1 / (d : ℝ)) ^ d ≤ (Real.exp (1 / (d : ℝ))) ^ d := by
    gcongr
  have h_exp : (Real.exp (1 / (d : ℝ))) ^ d = Real.exp 1 := by
    rw [← Real.exp_nat_mul]
    congr 1
    field_simp
  rw [h_exp] at h2
  have h_eq : 1 + 1 / (d : ℝ) = (((d : ℝ) + 1) / (d : ℝ)) := by
    field_simp
  have h_sub : 1 - 1 / ((d : ℝ) + 1) = (d : ℝ) / ((d : ℝ) + 1) := by
    field_simp; ring
  have h_pos : 0 < (d : ℝ) / ((d : ℝ) + 1) := by positivity
  have h_inv : ((d : ℝ) + 1) / (d : ℝ) = ((d : ℝ) / ((d : ℝ) + 1))⁻¹ := by
    field_simp
  have h3 : (((d : ℝ) / ((d : ℝ) + 1))⁻¹) ^ d ≤ Real.exp 1 := by
    rwa [← h_inv, ← h_eq]
  rw [inv_pow] at h3
  have h4 : (Real.exp 1)⁻¹ ≤ (((d : ℝ) / ((d : ℝ) + 1)) ^ d) := by
    have h_pow_pos : 0 < ((d : ℝ) / ((d : ℝ) + 1)) ^ d := by positivity
    have h_e_pos : 0 < Real.exp 1 := by positivity
    exact (inv_le_comm₀ (by positivity) (by positivity)).mpr h3
  rw [Real.exp_neg 1]
  rw [h_sub]
  exact h4

lemma hk_pos_of_hkd (k d : ℕ) (hkd : Real.exp 1 * ((d : Real) + 1) ≤ 2 ^ k) : 1 ≤ k := by
  by_contra! hk0
  interval_cases k
  simp only [pow_zero] at hkd
  have h_e_gt : 2 ≤ Real.exp 1 := by
    have := Real.add_one_le_exp 1
    linarith
  have h_d1 : 1 ≤ (d : ℝ) + 1 := by linarith [show 0 ≤ (d : ℝ) by positivity]
  have : 2 ≤ Real.exp 1 * ((d : ℝ) + 1) := by
    nlinarith
  linarith

noncomputable def sat_A (vbl : I → Finset V)
    (bad : (i : I) → vbl i → Bool) (i : I) : Finset (V → Bool) :=
  Finset.univ.filter (fun c => ∀ (v : vbl i), c v.1 = bad i v)

lemma mem_sat_A (vbl : I → Finset V) (bad : (i : I) → vbl i → Bool) (i : I) (c : V → Bool) :
    c ∈ sat_A vbl bad i ↔ ∀ (v : vbl i), c v.1 = bad i v := by
  simp [sat_A]

noncomputable def sat_D (vbl : I → Finset V) (i : I) : Finset I :=
  Finset.univ.filter (fun j => j ≠ i ∧ (vbl i ∩ vbl j).Nonempty)

lemma sat_D_not_mem (vbl : I → Finset V) (i : I) :
    i ∉ sat_D vbl i := by
  simp [sat_D]

lemma sat_indep
    (k : ℕ) (vbl : I → Finset V) (bad : (i : I) → vbl i → Bool)
    (hk : ∀ i, (vbl i).card = k)
    (i : I) (J : Finset I)
    (hdisj : Disjoint J (insert i (sat_D vbl i))) :
    ((sat_A vbl bad i ∩ E (sat_A vbl bad) J).card : ℝ) * (Fintype.card (V → Bool) : ℝ) =
      ((sat_A vbl bad i).card : ℝ) * ((E (sat_A vbl bad) J).card : ℝ) := by
  have h_disj_vbl : ∀ j ∈ J, Disjoint (vbl i) (vbl j) := by
    intro j hj
    rw [Finset.disjoint_insert_right] at hdisj
    have hj_not_D : j ∉ sat_D vbl i := by
      intro hjD
      exact (Finset.disjoint_right.mp hdisj.2 hjD) hj
    have hj_ne : j ≠ i := by
      rintro rfl
      exact hdisj.1 hj
    rw [Finset.disjoint_iff_inter_eq_empty]
    rw [sat_D, Finset.mem_filter] at hj_not_D
    push Not at hj_not_D
    exact hj_not_D (Finset.mem_univ j) hj_ne
  have hE_inv : ∀ (c : V → Bool) (w : vbl i → Bool),
      c ∈ E (sat_A vbl bad) J → overrideOnSub c (vbl i) w ∈ E (sat_A vbl bad) J := by
    intro c w hc
    rw [mem_E] at hc ⊢
    intro j hj hjA
    apply hc j hj
    rw [mem_sat_A] at hjA ⊢
    intro v
    have hv := hjA v
    have hdisj_ij := h_disj_vbl j hj
    have hv_not_i : v.1 ∉ vbl i := by
      intro hvi
      have h_inter : v.1 ∈ vbl i ∩ vbl j := Finset.mem_inter.mpr ⟨hvi, v.2⟩
      have h_emp : vbl i ∩ vbl j = ∅ := Finset.disjoint_iff_inter_eq_empty.mp hdisj_ij
      rw [h_emp] at h_inter
      exact Finset.notMem_empty _ h_inter
    rw [overrideOnSub_not_mem _ _ _ _ hv_not_i] at hv
    exact hv
  have h_prod1 := card_prod_eq_card_of_indep (vbl i) (bad i) (sat_A vbl bad i) rfl (E (sat_A vbl bad) J) hE_inv
  have h_prod2 := card_prod_eq_card_of_indep (vbl i) (bad i) (sat_A vbl bad i) rfl Finset.univ (fun _ _ _ => Finset.mem_univ _)
  rw [hk i] at h_prod1 h_prod2
  rw [Finset.inter_univ] at h_prod2
  rw [Finset.card_univ] at h_prod2
  have h_card_A : (2 ^ k : ℝ) * ((sat_A vbl bad i).card : ℝ) = (Fintype.card (V → Bool) : ℝ) := by
    exact_mod_cast h_prod2
  have h_card_AE : (2 ^ k : ℝ) * ((sat_A vbl bad i ∩ E (sat_A vbl bad) J).card : ℝ) =
      ((E (sat_A vbl bad) J).card : ℝ) := by
    exact_mod_cast h_prod1
  calc
    ((sat_A vbl bad i ∩ E (sat_A vbl bad) J).card : ℝ) * (Fintype.card (V → Bool) : ℝ)
      = ((sat_A vbl bad i ∩ E (sat_A vbl bad) J).card : ℝ) * ((2 ^ k : ℝ) * ((sat_A vbl bad i).card : ℝ)) := by rw [h_card_A]
    _ = ((2 ^ k : ℝ) * ((sat_A vbl bad i ∩ E (sat_A vbl bad) J).card : ℝ)) * ((sat_A vbl bad i).card : ℝ) := by ring
    _ = ((E (sat_A vbl bad) J).card : ℝ) * ((sat_A vbl bad i).card : ℝ) := by rw [h_card_AE]
    _ = ((sat_A vbl bad i).card : ℝ) * ((E (sat_A vbl bad) J).card : ℝ) := mul_comm _ _

lemma sat_bound
    (k d : ℕ) (vbl : I → Finset V) (bad : (i : I) → vbl i → Bool)
    (hk : ∀ i, (vbl i).card = k)
    (hd : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧ (vbl i ∩ vbl j).Nonempty)).card ≤ d)
    (hkd : Real.exp 1 * ((d : Real) + 1) ≤ 2 ^ k)
    (x : I → ℝ)
    (hx_val : ∀ i, x i = if d = 0 then (1 : ℝ) / 2 else 1 / ((d : ℝ) + 1))
    (i : I) :
    ((sat_A vbl bad i).card : ℝ) ≤
      x i * (∏ j ∈ sat_D vbl i, (1 - x j)) * (Fintype.card (V → Bool) : ℝ) := by
  have hk_pos := hk_pos_of_hkd k d hkd
  have hΩ : 0 < Fintype.card (V → Bool) := by
    rw [Fintype.card_fun, Fintype.card_bool]
    positivity
  have h_prod2 := card_prod_eq_card_of_indep (vbl i) (bad i) (sat_A vbl bad i) rfl Finset.univ (fun _ _ _ => Finset.mem_univ _)
  rw [hk i, Finset.inter_univ, Finset.card_univ] at h_prod2
  have h_card_A : ((sat_A vbl bad i).card : ℝ) = (Fintype.card (V → Bool) : ℝ) / (2 ^ k : ℝ) := by
    have : (2 ^ k : ℝ) * ((sat_A vbl bad i).card : ℝ) = (Fintype.card (V → Bool) : ℝ) := by exact_mod_cast h_prod2
    rw [← this]
    have : (2 ^ k : ℝ) ≠ 0 := by positivity
    rw [mul_div_cancel_left₀ _ this]
  rw [h_card_A]
  have hΩ_pos : (0 : ℝ) < (Fintype.card (V → Bool) : ℝ) := Nat.cast_pos.mpr hΩ
  rw [div_le_iff₀ (by positivity)]
  rw [mul_comm, ← mul_assoc]
  rw [le_mul_iff_one_le_left hΩ_pos]
  by_cases hd0 : d = 0
  · subst hd0
    have hD_card : (sat_D vbl i).card ≤ 0 := hd i
    have hD_empty : sat_D vbl i = ∅ := Finset.card_eq_zero.mp (by omega)
    rw [hD_empty, Finset.prod_empty]
    rw [hx_val i, if_pos rfl]
    have h_pow2 : (2 : ℝ) ≤ 2 ^ k := by
      have : 2 ≤ 2 ^ k := by
        calc
          2 = 2 ^ 1 := by ring
          _ ≤ 2 ^ k := Nat.pow_le_pow_right (by omega) hk_pos
      exact_mod_cast this
    linarith
  · have hd_ge : 1 ≤ d := by omega
    have hd_pos : 0 < (d : ℝ) + 1 := by positivity
    have hx_val' : ∀ j, x j = 1 / ((d : ℝ) + 1) := by
      intro j; rw [hx_val j, if_neg hd0]
    have h_prod_eq : ∏ j ∈ sat_D vbl i, (1 - x j) = (1 - 1 / ((d : ℝ) + 1)) ^ (sat_D vbl i).card := by
      rw [Finset.prod_congr rfl (fun j hj => by rw [hx_val' j])]
      rw [Finset.prod_const]
    have h_sub_pos : 0 ≤ 1 - 1 / ((d : ℝ) + 1) := by
      have : 1 / ((d : ℝ) + 1) ≤ 1 := by
        rw [div_le_one hd_pos]
        linarith [show 0 ≤ (d : ℝ) by positivity]
      linarith
    have h_sub_le1 : 1 - 1 / ((d : ℝ) + 1) ≤ 1 := by
      have : 0 ≤ 1 / ((d : ℝ) + 1) := by positivity
      linarith
    have h_pow_le : (1 - 1 / ((d : ℝ) + 1)) ^ d ≤ (1 - 1 / ((d : ℝ) + 1)) ^ (sat_D vbl i).card := by
      apply pow_le_pow_of_le_one h_sub_pos h_sub_le1 (hd i)
    have h_exp_neg := one_sub_div_pow_ge_exp_neg_one d hd_ge
    have h_exp_le : Real.exp (-1) ≤ ∏ j ∈ sat_D vbl i, (1 - x j) := by
      rw [h_prod_eq]
      exact h_exp_neg.trans h_pow_le
    rw [hx_val i, if_neg hd0]
    have h_e_pos : 0 < Real.exp 1 := by positivity
    have h_exp_neg_eq : Real.exp (-1) = (Real.exp 1)⁻¹ := Real.exp_neg 1
    have h_bound_prod : (1 / ((d : ℝ) + 1)) * (Real.exp 1)⁻¹ ≤ (1 / ((d : ℝ) + 1)) * ∏ j ∈ sat_D vbl i, (1 - x j) := by
      apply mul_le_mul_of_nonneg_left
      · rwa [h_exp_neg_eq] at h_exp_le
      · positivity
    have h_exp_mul : (1 / ((d : ℝ) + 1)) * (Real.exp 1)⁻¹ = (Real.exp 1 * ((d : ℝ) + 1))⁻¹ := by
      rw [mul_inv, mul_comm (Real.exp 1)⁻¹]
      congr 1
      rw [one_div]
    rw [h_exp_mul] at h_bound_prod
    have h_inv_le : (2 ^ k : ℝ)⁻¹ ≤ (Real.exp 1 * ((d : ℝ) + 1))⁻¹ := by
      have h1 : 0 < Real.exp 1 * ((d : ℝ) + 1) := by positivity
      have h2 : 0 < (2 ^ k : ℝ) := by positivity
      exact (inv_le_inv₀ h2 h1).mpr hkd
    have h_final : (2 ^ k : ℝ)⁻¹ ≤ (1 / ((d : ℝ) + 1)) * ∏ j ∈ sat_D vbl i, (1 - x j) :=
      h_inv_le.trans h_bound_prod
    have h_pos_2k : 0 < (2 ^ k : ℝ) := by positivity
    rw [mul_comm]
    exact (inv_le_iff_one_le_mul₀ h_pos_2k).mp h_final

theorem lll_sat (k d : ℕ)
    (vbl : I → Finset V)
    (bad : (i : I) → vbl i → Bool)
    (hk : ∀ i, (vbl i).card = k)
    (hd : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧ (vbl i ∩ vbl j).Nonempty)).card ≤ d)
    (hkd : Real.exp 1 * ((d : Real) + 1) ≤ 2 ^ k) :
    ∃ c : V → Bool, ∀ i, ∃ (v : vbl i), c v.1 ≠ bad i v := by
  have hΩ : 0 < Fintype.card (V → Bool) := by
    rw [Fintype.card_fun, Fintype.card_bool]
    positivity
  let x : I → ℝ := fun _ => if d = 0 then (1 : ℝ) / 2 else 1 / ((d : ℝ) + 1)
  have hx : ∀ i, 0 ≤ x i ∧ x i < 1 := by
    intro i
    dsimp [x]
    split_ifs with hd0
    · norm_num
    · have hd_pos : 0 < (d : ℝ) + 1 := by positivity
      refine ⟨by positivity, ?_⟩
      rw [div_lt_one hd_pos]
      have hd1 : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast (Nat.one_le_iff_ne_zero.mpr hd0)
      linarith
  have h_indep := sat_indep k vbl bad hk
  have h_bound := sat_bound k d vbl bad hk hd hkd x (fun _ => rfl)
  have h_lll := lovasz_local_lemma
    (sat_A vbl bad) (sat_D vbl) x hx hΩ
    (sat_D_not_mem vbl) h_indep h_bound
  obtain ⟨c, hc⟩ := h_lll
  refine ⟨c, ?_⟩
  intro i
  have hci := hc i
  rw [mem_sat_A] at hci
  push Not at hci
  obtain ⟨v, hv⟩ := hci
  exact ⟨v, hv⟩

/-! ### Part 3: General Helpers for the 5 Theorems -/

lemma two_le_card_of_mem_both (s : Finset Bool) (ht : true ∈ s) (hf : false ∈ s) :
    2 ≤ s.card := by
  have h_sub : {true, false} ⊆ s := by
    intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    cases hx <;> (subst_vars; assumption)
  have h_card : ({true, false} : Finset Bool).card = 2 := rfl
  rw [← h_card]
  exact Finset.card_le_card h_sub

lemma hk_ge_one_of_exp_le {d k : ℕ} (h : Real.exp 1 * ((d : Real) + 1) ≤ 2 ^ (k - 1)) :
    1 ≤ k := by
  by_contra! hk0
  have hk0' : k = 0 := by omega
  subst hk0'
  simp only [Nat.zero_sub] at h
  have : (0 : ℝ) ≤ d := by positivity
  have : 2 ≤ Real.exp 1 := by
    have := Real.add_one_le_exp 1
    linarith
  have : 2 ≤ Real.exp 1 * ((d : Real) + 1) := by nlinarith
  have : Real.exp 1 * ((d : Real) + 1) ≤ 1 := by linarith [show (2 : ℝ) ^ 0 = 1 by ring]
  linarith

lemma hk_ge_two_of_exp_le {N k : ℕ} (h : Real.exp 1 * (((k ^ 2 * N : Nat) : Real) + 1) ≤ 2 ^ (k - 1)) :
    2 ≤ k := by
  by_contra! hk
  interval_cases k
  · simp only [Nat.zero_sub, pow_zero] at h
    have : (0 : ℝ) ≤ (0 ^ 2 * N : ℕ) := by positivity
    have : 2 ≤ Real.exp 1 := by linarith [Real.add_one_le_exp 1]
    have : 2 ≤ Real.exp 1 * (((0 ^ 2 * N : ℕ) : ℝ) + 1) := by nlinarith
    linarith
  · simp only [Nat.sub_self, pow_zero] at h
    have : (0 : ℝ) ≤ (1 ^ 2 * N : ℕ) := by positivity
    have : 2 ≤ Real.exp 1 := by linarith [Real.add_one_le_exp 1]
    have : 2 ≤ Real.exp 1 * (((1 ^ 2 * N : ℕ) : ℝ) + 1) := by nlinarith
    linarith

lemma meet_card_le {n m : ℕ} (d : ℕ) (I : Fin m → Fin n → Bool)
    (hd : ∀ i, (Finset.univ.filter (fun j => ¬ (j = i) ∧ ∃ v, I i v = true ∧ I j v = true)).card ≤ d)
    (i : Fin m) (b : Bool) :
    (Finset.univ.filter (fun (p : Fin m × Bool) =>
      p ≠ (i, b) ∧ ((Finset.univ.filter (fun v => I i v = true)) ∩
        (Finset.univ.filter (fun v => I p.1 v = true))).Nonempty)).card ≤ 2 * d + 1 := by
  let meet_i := Finset.univ.filter (fun j => ¬(j = i) ∧ ∃ v, I i v = true ∧ I j v = true)
  let S := Finset.univ.filter (fun (p : Fin m × Bool) =>
      p ≠ (i, b) ∧ ((Finset.univ.filter (fun v => I i v = true)) ∩
        (Finset.univ.filter (fun v => I p.1 v = true))).Nonempty)
  have h_sub : S ⊆ insert (i, !b) (meet_i ×ˢ Finset.univ) := by
    intro ⟨j, b'⟩ hj
    simp only [S, Finset.mem_filter, Finset.mem_univ, true_and] at hj
    by_cases hj_eq : j = i
    · subst hj_eq
      have hb_ne : b' ≠ b := by
        intro hb_eq
        subst hb_eq
        exact hj.1 rfl
      have hb_not : b' = !b := by
        revert hb_ne
        cases b <;> cases b' <;> decide
      subst hb_not
      exact Finset.mem_insert_self _ _
    · apply Finset.mem_insert_of_mem
      rw [Finset.mem_product]
      refine ⟨?_, Finset.mem_univ _⟩
      simp only [meet_i, Finset.mem_filter, Finset.mem_univ, true_and]
      refine ⟨hj_eq, ?_⟩
      obtain ⟨v, hv⟩ := hj.2
      simp only [Finset.mem_inter, Finset.mem_filter, Finset.mem_univ, true_and] at hv
      exact ⟨v, hv.1, hv.2⟩
  have h_card := Finset.card_le_card h_sub
  have h_card_insert := Finset.card_insert_le (i, !b) (meet_i ×ˢ Finset.univ)
  have h_card_prod : (meet_i ×ˢ (Finset.univ : Finset Bool)).card = meet_i.card * 2 := by
    rw [Finset.card_product]
    rfl
  have h_meet : meet_i.card ≤ d := hd i
  linarith

lemma poly_le_pow2_shift (j : ℕ) (hj : 8 ≤ j) : 3 * (j ^ 2 + j + 1) ≤ 2 ^ j := by
  induction j, hj using Nat.le_induction with
  | base => decide
  | succ n hn ih =>
    calc
      3 * ((n + 1) ^ 2 + (n + 1) + 1) = 3 * (n ^ 2 + 3 * n + 3) := by ring
      _ ≤ 2 * (3 * (n ^ 2 + n + 1)) := by
        have : 3 * (n ^ 2 + 3 * n + 3) + 3 ≤ 2 * (3 * (n ^ 2 + n + 1)) := by nlinarith
        omega
      _ ≤ 2 * 2 ^ n := by gcongr
      _ = 2 ^ (n + 1) := by rw [pow_succ, mul_comm]

lemma exp_mul_deg_le_pow (k : ℕ) (hk : 9 ≤ k) :
    Real.exp 1 * (((k * (k - 1) : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1) := by
  have h_exp_lt : Real.exp 1 ≤ 3 := by
    have := Real.exp_one_lt_d9
    linarith
  have hj : 8 ≤ k - 1 := by omega
  have h_nat := poly_le_pow2_shift (k - 1) hj
  have h_poly_eq : k * (k - 1) + 1 = (k - 1) ^ 2 + (k - 1) + 1 := by
    have : k = (k - 1) + 1 := by omega
    nth_rw 1 [this]
    ring
  rw [← h_poly_eq] at h_nat
  have h_nat_cast : ((3 * (k * (k - 1) + 1) : ℕ) : ℝ) ≤ ((2 ^ (k - 1) : ℕ) : ℝ) := by
    exact Nat.mono_cast h_nat
  have h_lhs : Real.exp 1 * (((k * (k - 1) : ℕ) : ℝ) + 1) ≤ 3 * (((k * (k - 1) : ℕ) : ℝ) + 1) := by
    apply mul_le_mul_of_nonneg_right h_exp_lt
    positivity
  have h_eq : (3 : ℝ) * (((k * (k - 1) : ℕ) : ℝ) + 1) = ((3 * (k * (k - 1) + 1) : ℕ) : ℝ) := by
    push_cast; ring
  calc
    Real.exp 1 * (((k * (k - 1) : ℕ) : ℝ) + 1)
      ≤ 3 * (((k * (k - 1) : ℕ) : ℝ) + 1) := h_lhs
    _ = ((3 * (k * (k - 1) + 1) : ℕ) : ℝ) := h_eq
    _ ≤ ((2 ^ (k - 1) : ℕ) : ℝ) := h_nat_cast
    _ = 2 ^ (k - 1) := by push_cast; rfl

lemma deg_meet_le {n m k : ℕ} (I : Fin m → Fin n → Bool)
    (hk : ∀ i, (Finset.univ.filter (fun v => I i v = true)).card = k)
    (hdeg : ∀ v, (Finset.univ.filter (fun i => I i v = true)).card ≤ k)
    (i : Fin m) :
    (Finset.univ.filter (fun j => ¬ (j = i) ∧ ∃ v, I i v = true ∧ I j v = true)).card ≤ k * (k - 1) := by
  let Ei := Finset.univ.filter (fun v => I i v = true)
  let meet_i := Finset.univ.filter (fun j => ¬ (j = i) ∧ ∃ v, I i v = true ∧ I j v = true)
  have h_sub : meet_i ⊆ Ei.biUnion (fun v => (Finset.univ.filter (fun j => I j v = true)).erase i) := by
    intro j hj
    simp only [meet_i, Finset.mem_filter, Finset.mem_univ, true_and] at hj
    obtain ⟨hj_ne, v, hvi, hvj⟩ := hj
    rw [Finset.mem_biUnion]
    refine ⟨v, ?_, ?_⟩
    · simp only [Ei, Finset.mem_filter, Finset.mem_univ, true_and, hvi]
    · rw [Finset.mem_erase]
      refine ⟨hj_ne, ?_⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, hvj]
  have h_le := (Finset.card_le_card h_sub).trans (Finset.card_biUnion_le)
  have h_each : ∀ v ∈ Ei, ((Finset.univ.filter (fun j => I j v = true)).erase i).card ≤ k - 1 := by
    intro v hv
    simp only [Ei, Finset.mem_filter, Finset.mem_univ, true_and] at hv
    have hi_mem : i ∈ Finset.univ.filter (fun j => I j v = true) := by
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, hv]
    rw [Finset.card_erase_of_mem hi_mem]
    have := hdeg v
    omega
  have h_sum := Finset.sum_le_card_nsmul Ei (fun v => ((Finset.univ.filter (fun j => I j v = true)).erase i).card) (k - 1) h_each
  rw [hk i, nsmul_eq_mul] at h_sum
  linarith

lemma Sym2_toFinset_injective {α : Type*} [DecidableEq α] (x y : Sym2 α) (h : x.toFinset = y.toFinset) : x = y := by
  induction x using Sym2.inductionOn with
  | hf a b =>
    induction y using Sym2.inductionOn with
    | hf c d =>
      rw [Sym2.toFinset_mk_eq, Sym2.toFinset_mk_eq] at h
      rw [Sym2.eq_iff]
      have h1 : a ∈ ({c, d} : Finset α) := by rw [← h]; simp
      have h2 : b ∈ ({c, d} : Finset α) := by rw [← h]; simp
      have h3 : c ∈ ({a, b} : Finset α) := by rw [h]; simp
      have h4 : d ∈ ({a, b} : Finset α) := by rw [h]; simp
      simp only [Finset.mem_insert, Finset.mem_singleton] at h1 h2 h3 h4
      tauto

lemma card_offDiag_image_sym2 {α : Type*} [DecidableEq α] (s : Finset α) :
    (s.offDiag.image (fun q => Sym2.mk q.1 q.2)).card = Nat.choose s.card 2 := by
  let E_s := s.offDiag.image (fun q => Sym2.mk q.1 q.2)
  have h_img_sub : E_s.image Sym2.toFinset ⊆ s.powersetCard 2 := by
    intro t ht
    rw [Finset.mem_image] at ht
    obtain ⟨e, he, rfl⟩ := ht
    simp only [E_s, Finset.mem_image, Finset.mem_offDiag, Prod.exists] at he
    obtain ⟨u, v, ⟨hu, hv, huv⟩, rfl⟩ := he
    rw [Finset.mem_powersetCard]
    refine ⟨?_, ?_⟩
    · rw [Sym2.toFinset_mk_eq]
      intro x hx
      simp only [Finset.mem_insert, Finset.mem_singleton] at hx
      cases hx <;> (subst_vars; assumption)
    · rw [Sym2.toFinset_mk_eq]
      exact Finset.card_pair huv
  have h_sub_img : s.powersetCard 2 ⊆ E_s.image Sym2.toFinset := by
    intro t ht
    rw [Finset.mem_powersetCard] at ht
    have h2 := ht.2
    obtain ⟨u, v, huv, rfl⟩ := Finset.card_eq_two.mp h2
    have hsub := ht.1
    have hu : u ∈ s := hsub (Finset.mem_insert_self u {v})
    have hv : v ∈ s := hsub (Finset.mem_insert_of_mem (Finset.mem_singleton_self v))
    rw [Finset.mem_image]
    refine ⟨Sym2.mk u v, ?_, ?_⟩
    · simp only [E_s, Finset.mem_image, Finset.mem_offDiag, Prod.exists]
      exact ⟨u, v, ⟨hu, hv, huv⟩, rfl⟩
    · rw [Sym2.toFinset_mk_eq]
  have h_inj : ∀ x ∈ E_s, ∀ y ∈ E_s, Sym2.toFinset x = Sym2.toFinset y → x = y :=
    fun x _ y _ => Sym2_toFinset_injective x y
  have h_card1 : (E_s.image Sym2.toFinset).card = E_s.card :=
    Finset.card_image_of_injOn h_inj
  have h_card_le1 : E_s.card ≤ (s.powersetCard 2).card := by
    rw [← h_card1]
    exact Finset.card_le_card h_img_sub
  have h_card_le2 : (s.powersetCard 2).card ≤ E_s.card := by
    rw [← h_card1]
    exact Finset.card_le_card h_sub_img
  have h_card_eq : E_s.card = (s.powersetCard 2).card := by omega
  rw [h_card_eq, Finset.card_powersetCard]

lemma card_subsets_containing_t {n : ℕ} (t : Finset (Fin n)) (ht : t.card = 2) (k : ℕ) :
    (Finset.univ.filter (fun (s : Finset (Fin n)) => s.card = k ∧ t ⊆ s)).card ≤ Nat.choose n (k - 2) := by
  let S := Finset.univ.filter (fun (s : Finset (Fin n)) => s.card = k ∧ t ⊆ s)
  let T := (Finset.univ : Finset (Fin n)).powersetCard (k - 2)
  have h_inj : ∀ s1 ∈ S, ∀ s2 ∈ S, s1 \ t = s2 \ t → s1 = s2 := by
    intro s1 hs1 s2 hs2 h_diff
    simp only [S, Finset.mem_filter, Finset.mem_univ, true_and] at hs1 hs2
    have h1 : s1 = t ∪ (s1 \ t) := (Finset.union_sdiff_of_subset hs1.2).symm
    have h2 : s2 = t ∪ (s2 \ t) := (Finset.union_sdiff_of_subset hs2.2).symm
    rw [h1, h2, h_diff]
  have h_img : S.image (fun s => s \ t) ⊆ T := by
    intro r hr
    rw [Finset.mem_image] at hr
    obtain ⟨s, hs, rfl⟩ := hr
    simp only [S, Finset.mem_filter, Finset.mem_univ, true_and] at hs
    dsimp [T]
    rw [Finset.mem_powersetCard]
    refine ⟨Finset.subset_univ _, ?_⟩
    rw [Finset.card_sdiff_of_subset hs.2, hs.1, ht]
  have h_card : S.card ≤ T.card := by
    rw [← Finset.card_image_of_injOn h_inj]
    exact Finset.card_le_card h_img
  have h_T_card : T.card = Nat.choose n (k - 2) := by
    dsimp [T]
    rw [Finset.card_powersetCard, Finset.card_univ, Fintype.card_fin]
  exact h_card.trans (le_of_eq h_T_card)

lemma ramsey_degree_le {n k : ℕ} (s : Finset (Fin n)) (hs : s.card = k) (b : Bool) :
    let S_k := { s' : Finset (Fin n) // s'.card = k }
    let vbl : (S_k × Bool) → Finset (Sym2 (Fin n)) :=
      fun p => p.1.1.offDiag.image (fun q => Sym2.mk q.1 q.2)
    (Finset.univ.filter (fun (p : S_k × Bool) =>
      p ≠ (⟨s, hs⟩, b) ∧ (vbl (⟨s, hs⟩, b) ∩ vbl p).Nonempty)).card ≤
        2 * (Nat.choose k 2 * Nat.choose n (k - 2)) + 1 := by
  intro S_k vbl
  let meet_s := Finset.univ.filter (fun (s' : S_k) =>
    s' ≠ ⟨s, hs⟩ ∧ (vbl (⟨s, hs⟩, b) ∩ vbl (s', false)).Nonempty)
  have h_vbl_b : ∀ s' b1 b2, vbl (s', b1) = vbl (s', b2) := fun _ _ _ => rfl
  have h_sub : (Finset.univ.filter (fun (p : S_k × Bool) =>
      p ≠ (⟨s, hs⟩, b) ∧ (vbl (⟨s, hs⟩, b) ∩ vbl p).Nonempty)) ⊆
        insert (⟨s, hs⟩, !b) (meet_s ×ˢ Finset.univ) := by
    intro ⟨s', b'⟩ hp
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hp
    by_cases hs' : s' = ⟨s, hs⟩
    · subst hs'
      have hb' : b' ≠ b := by
        intro hb_eq
        subst hb_eq
        exact hp.1 rfl
      have hb_not : b' = !b := by
        revert hb'
        cases b <;> cases b' <;> decide
      subst hb_not
      exact Finset.mem_insert_self _ _
    · apply Finset.mem_insert_of_mem
      rw [Finset.mem_product]
      refine ⟨?_, Finset.mem_univ _⟩
      simp only [meet_s, Finset.mem_filter, Finset.mem_univ, true_and]
      refine ⟨hs', ?_⟩
      rw [h_vbl_b s' b' false] at hp
      exact hp.2
  have h_card_prod : (meet_s ×ˢ (Finset.univ : Finset Bool)).card = meet_s.card * 2 := by
    rw [Finset.card_product]
    rfl
  have h_card_ins := (Finset.card_le_card h_sub).trans (Finset.card_insert_le _ _)
  have h_meet_sub : meet_s.image (fun s' => s'.1) ⊆
      (s.powersetCard 2).biUnion (fun t => Finset.univ.filter (fun s' : Finset (Fin n) => s'.card = k ∧ t ⊆ s')) := by
    intro s' hs'
    rw [Finset.mem_image] at hs'
    obtain ⟨⟨s'_val, hs'_card⟩, hs'_mem, rfl⟩ := hs'
    rw [Finset.mem_filter] at hs'_mem
    obtain ⟨e, he_inter⟩ := hs'_mem.2.2
    rw [Finset.mem_inter] at he_inter
    obtain ⟨he1, he2⟩ := he_inter
    dsimp [vbl] at he1 he2
    obtain ⟨⟨u1, v1⟩, hu1v1, rfl⟩ := Finset.mem_image.mp he1
    obtain ⟨⟨u2, v2⟩, hu2v2, he2_eq⟩ := Finset.mem_image.mp he2
    rw [Finset.mem_offDiag] at hu1v1 hu2v2
    dsimp at hu1v1 hu2v2
    rw [Sym2.eq_iff] at he2_eq
    dsimp at he2_eq
    rw [Finset.mem_biUnion]
    let t : Finset (Fin n) := {u1, v1}
    have ht_card : t.card = 2 := Finset.card_pair hu1v1.2.2
    have ht_sub : t ⊆ s := by
      intro x hx
      simp only [t, Finset.mem_insert, Finset.mem_singleton] at hx
      cases hx with
      | inl hx => subst hx; exact hu1v1.1
      | inr hx => subst hx; exact hu1v1.2.1
    refine ⟨t, ?_, ?_⟩
    · rw [Finset.mem_powersetCard]
      exact ⟨ht_sub, ht_card⟩
    · simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      refine ⟨hs'_card, ?_⟩
      intro x hx
      simp only [t, Finset.mem_insert, Finset.mem_singleton] at hx
      cases he2_eq with
      | inl h =>
        cases hx with
        | inl hx => subst hx; rw [← h.1]; exact hu2v2.1
        | inr hx => subst hx; rw [← h.2]; exact hu2v2.2.1
      | inr h =>
        cases hx with
        | inl hx => subst hx; rw [← h.2]; exact hu2v2.2.1
        | inr hx => subst hx; rw [← h.1]; exact hu2v2.1
  have h_inj : ∀ (x y : S_k), x.1 = y.1 → x = y := fun x y h => Subtype.ext h
  have h_meet_card : meet_s.card = (meet_s.image (fun s' => s'.1)).card := by
    exact (Finset.card_image_of_injective meet_s h_inj).symm
  have h_biUnion_le := Finset.card_biUnion_le (s := s.powersetCard 2)
    (t := fun t => Finset.univ.filter (fun s' : Finset (Fin n) => s'.card = k ∧ t ⊆ s'))
  have h_each : ∀ t ∈ s.powersetCard 2,
      (Finset.univ.filter (fun s' : Finset (Fin n) => s'.card = k ∧ t ⊆ s')).card ≤ Nat.choose n (k - 2) := by
    intro t ht
    rw [Finset.mem_powersetCard] at ht
    exact card_subsets_containing_t t ht.2 k
  have h_sum := Finset.sum_le_card_nsmul (s.powersetCard 2)
    (fun t => (Finset.univ.filter (fun s' : Finset (Fin n) => s'.card = k ∧ t ⊆ s')).card)
    (Nat.choose n (k - 2)) h_each
  rw [Finset.card_powersetCard, hs] at h_sum
  have h_meet_le : meet_s.card ≤ Nat.choose k 2 * Nat.choose n (k - 2) := by
    rw [h_meet_card]
    have h1 := Finset.card_le_card h_meet_sub
    have h2 : ∑ a ∈ s.powersetCard 2, (Finset.univ.filter (fun s' : Finset (Fin n) => s'.card = k ∧ a ⊆ s')).card ≤
        Nat.choose k 2 * Nat.choose n (k - 2) := by
      rwa [nsmul_eq_mul] at h_sum
    exact h1.trans (h_biUnion_le.trans h2)
  linarith

lemma card_ap_containing_v_at_j (N k : ℕ) (v : Fin N) (j : ℕ) :
    let AP := { p : Fin N × Fin N // 1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N }
    (Finset.univ.filter (fun (p : AP) => p.1.1.1 + j * p.1.2.1 = v.1)).card ≤ N := by
  intro AP
  let S := Finset.univ.filter (fun (p : AP) => p.1.1.1 + j * p.1.2.1 = v.1)
  have h_inj : ∀ p1 ∈ S, ∀ p2 ∈ S, p1.1.2 = p2.1.2 → p1 = p2 := by
    intro p1 hp1 p2 hp2 hr
    simp only [S, Finset.mem_filter, Finset.mem_univ, true_and] at hp1 hp2
    have hr_val : p1.1.2.1 = p2.1.2.1 := congrArg Fin.val hr
    have ha : p1.1.1.1 = p2.1.1.1 := by
      rw [hr_val] at hp1
      omega
    have ha_fin : p1.1.1 = p2.1.1 := Fin.ext ha
    have h_pair : p1.1 = p2.1 := Prod.ext ha_fin hr
    exact Subtype.ext h_pair
  have h_card : S.card ≤ Fintype.card (Fin N) := by
    rw [← Finset.card_image_of_injOn h_inj]
    exact Finset.card_le_univ _
  rw [Fintype.card_fin] at h_card
  exact h_card

lemma ap_degree_le (N k : ℕ)
    (a r : ℕ) (hr : 1 ≤ r) (ha : a + (k - 1) * r < N)
    (ha_lt : a < N) (hr_lt : r < N) (b : Bool) :
    let AP := { p : Fin N × Fin N // 1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N }
    let vbl : (AP × Bool) → Finset (Fin N) := fun p =>
      (Finset.range k).attach.image (fun ⟨j, hj⟩ =>
        ⟨p.1.1.1.1 + j * p.1.1.2.1, by
          rw [Finset.mem_range] at hj
          have : j ≤ k - 1 := Nat.le_pred_of_lt hj
          have : p.1.1.1.1 + j * p.1.1.2.1 ≤ p.1.1.1.1 + (k - 1) * p.1.1.2.1 := by gcongr
          exact this.trans_lt p.1.2.2⟩)
    let p0 : AP := ⟨(⟨a, ha_lt⟩, ⟨r, hr_lt⟩), ⟨hr, ha⟩⟩
    (Finset.univ.filter (fun (p : AP × Bool) =>
      p ≠ (p0, b) ∧ (vbl (p0, b) ∩ vbl p).Nonempty)).card ≤ 2 * (k ^ 2 * N) + 1 := by
  intro AP vbl p0
  let meet_p0 := Finset.univ.filter (fun (p : AP) =>
    p ≠ p0 ∧ (vbl (p0, b) ∩ vbl (p, false)).Nonempty)
  have h_vbl_b : ∀ p b1 b2, vbl (p, b1) = vbl (p, b2) := fun _ _ _ => rfl
  have h_sub : (Finset.univ.filter (fun (p : AP × Bool) =>
      p ≠ (p0, b) ∧ (vbl (p0, b) ∩ vbl p).Nonempty)) ⊆
        insert (p0, !b) (meet_p0 ×ˢ Finset.univ) := by
    intro ⟨p', b'⟩ hp
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hp
    by_cases hp' : p' = p0
    · subst hp'
      have hb' : b' ≠ b := by
        intro hb_eq
        subst hb_eq
        exact hp.1 rfl
      have hb_not : b' = !b := by
        revert hb'
        cases b <;> cases b' <;> decide
      subst hb_not
      exact Finset.mem_insert_self _ _
    · apply Finset.mem_insert_of_mem
      rw [Finset.mem_product]
      refine ⟨?_, Finset.mem_univ _⟩
      simp only [meet_p0, Finset.mem_filter, Finset.mem_univ, true_and]
      refine ⟨hp', ?_⟩
      rw [h_vbl_b p' b' false] at hp
      exact hp.2
  have h_card_prod : (meet_p0 ×ˢ (Finset.univ : Finset Bool)).card = meet_p0.card * 2 := by
    rw [Finset.card_product]
    rfl
  have h_card_ins := (Finset.card_le_card h_sub).trans (Finset.card_insert_le _ _)
  have h_meet_sub : meet_p0 ⊆
      (Finset.range k).biUnion (fun j1 =>
        (Finset.range k).biUnion (fun j2 =>
          Finset.univ.filter (fun p' : AP =>
            p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r))) := by
    intro p' hp'
    simp only [meet_p0, Finset.mem_filter, Finset.mem_univ, true_and] at hp'
    obtain ⟨e, he_inter⟩ := hp'.2
    rw [Finset.mem_inter] at he_inter
    obtain ⟨he1, he2⟩ := he_inter
    dsimp [vbl] at he1 he2
    rw [Finset.mem_image] at he1 he2
    obtain ⟨⟨j1, hj1⟩, _, rfl⟩ := he1
    obtain ⟨⟨j2, hj2⟩, _, he2_eq⟩ := he2
    have he2_val : p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r := congrArg Fin.val he2_eq
    rw [Finset.mem_range] at hj1 hj2
    rw [Finset.mem_biUnion]
    refine ⟨j1, Finset.mem_range.mpr hj1, ?_⟩
    rw [Finset.mem_biUnion]
    refine ⟨j2, Finset.mem_range.mpr hj2, ?_⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact he2_val
  have h_step2 : ∀ j1 ∈ Finset.range k,
      ((Finset.range k).biUnion (fun j2 =>
        Finset.univ.filter (fun p' : AP =>
          p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r))).card ≤ k * N := by
    intro j1 hj1
    have h_biUnion_le := Finset.card_biUnion_le (s := Finset.range k)
      (t := fun j2 => Finset.univ.filter (fun p' : AP => p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r))
    have h_each : ∀ j2 ∈ Finset.range k,
        (Finset.univ.filter (fun p' : AP => p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r)).card ≤ N := by
      intro j2 hj2
      rw [Finset.mem_range] at hj1
      have hj1_le : j1 ≤ k - 1 := Nat.le_pred_of_lt hj1
      have : a + j1 * r ≤ a + (k - 1) * r := by gcongr
      have h_val_lt : a + j1 * r < N := this.trans_lt ha
      let v : Fin N := ⟨a + j1 * r, h_val_lt⟩
      exact card_ap_containing_v_at_j N k v j2
    have h_sum := Finset.sum_le_card_nsmul (Finset.range k)
      (fun j2 => (Finset.univ.filter (fun p' : AP => p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r)).card)
      N h_each
    rw [Finset.card_range, nsmul_eq_mul] at h_sum
    exact h_biUnion_le.trans h_sum
  have h_biUnion_le1 := Finset.card_biUnion_le (s := Finset.range k)
    (t := fun j1 => (Finset.range k).biUnion (fun j2 =>
      Finset.univ.filter (fun p' : AP => p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r)))
  have h_sum1 := Finset.sum_le_card_nsmul (Finset.range k)
    (fun j1 => ((Finset.range k).biUnion (fun j2 =>
      Finset.univ.filter (fun p' : AP => p'.1.1.1 + j2 * p'.1.2.1 = a + j1 * r))).card)
    (k * N) h_step2
  rw [Finset.card_range, nsmul_eq_mul] at h_sum1
  have h_meet_le : meet_p0.card ≤ k ^ 2 * N := by
    have h1 := (Finset.card_le_card h_meet_sub).trans h_biUnion_le1
    have h2 : k * (k * N) = k ^ 2 * N := by ring
    exact h1.trans (h_sum1.trans (le_of_eq h2))
  linarith

lemma card_ap_vbl (N k : ℕ) (p : { p : Fin N × Fin N // 1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N }) :
    let vbl : Finset (Fin N) :=
      (Finset.range k).attach.image (fun ⟨j, hj⟩ =>
        ⟨p.1.1.1 + j * p.1.2.1, by
          rw [Finset.mem_range] at hj
          have : j ≤ k - 1 := Nat.le_pred_of_lt hj
          have : p.1.1.1 + j * p.1.2.1 ≤ p.1.1.1 + (k - 1) * p.1.2.1 := by gcongr
          exact this.trans_lt p.2.2⟩)
    vbl.card = k := by
  intro vbl
  have h_inj : ∀ (x y : { x // x ∈ Finset.range k }),
      (⟨p.1.1.1 + x.1 * p.1.2.1, by
        have hj := x.2
        rw [Finset.mem_range] at hj
        have : x.1 ≤ k - 1 := Nat.le_pred_of_lt hj
        have : p.1.1.1 + x.1 * p.1.2.1 ≤ p.1.1.1 + (k - 1) * p.1.2.1 := by gcongr
        exact this.trans_lt p.2.2⟩ : Fin N) =
      (⟨p.1.1.1 + y.1 * p.1.2.1, by
        have hj := y.2
        rw [Finset.mem_range] at hj
        have : y.1 ≤ k - 1 := Nat.le_pred_of_lt hj
        have : p.1.1.1 + y.1 * p.1.2.1 ≤ p.1.1.1 + (k - 1) * p.1.2.1 := by gcongr
        exact this.trans_lt p.2.2⟩ : Fin N) → x = y := by
    rintro ⟨j1, hj1⟩ ⟨j2, hj2⟩ h
    have h_val : p.1.1.1 + j1 * p.1.2.1 = p.1.1.1 + j2 * p.1.2.1 := congrArg Fin.val h
    have hr : 1 ≤ p.1.2.1 := p.2.1
    have hj_eq : j1 = j2 := by nlinarith
    exact Subtype.ext hj_eq
  have h_card := Finset.card_image_of_injective (Finset.range k).attach h_inj
  rw [Finset.card_attach, Finset.card_range] at h_card
  exact h_card

/-! ### Part 4: The Five Required Theorems -/

theorem color_meet (n m k d : Nat) (I : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => I i v = true)).card = k)
    (hd : forall i, (Finset.univ.filter (fun j => Not (j = i) /\
      exists v, I i v = true /\ I j v = true)).card <= d)
    (hkd : Real.exp 1 * ((d : Real) + 1) <= 2 ^ (k - 1)) :
    exists c : Fin n -> Bool, forall i,
      (exists v, I i v = true /\ c v = true) /\ (exists v, I i v = true /\ c v = false) := by
  have hk1 : 1 ≤ k := hk_ge_one_of_exp_le hkd
  let vbl : (Fin m × Bool) → Finset (Fin n) := fun p => Finset.univ.filter (fun v => I p.1 v = true)
  let bad : (p : Fin m × Bool) → vbl p → Bool := fun p _ => p.2
  have hk' : ∀ p, (vbl p).card = k := fun p => hk p.1
  have hd' : ∀ p, (Finset.univ.filter (fun q => q ≠ p ∧ (vbl p ∩ vbl q).Nonempty)).card ≤ 2 * d + 1 := by
    intro ⟨i, b⟩
    exact meet_card_le d I hd i b
  have hkd' : Real.exp 1 * (((2 * d + 1 : ℕ) : Real) + 1) ≤ 2 ^ k := by
    have h_cast : (((2 * d + 1 : ℕ) : Real) + 1) = 2 * ((d : Real) + 1) := by push_cast; ring
    rw [h_cast, ← mul_assoc, mul_comm (Real.exp 1) 2, mul_assoc]
    have h_pow : (2 : ℝ) ^ k = 2 * 2 ^ (k - 1) := by
      have : k = (k - 1) + 1 := by omega
      conv_lhs => rw [this]
      rw [pow_succ, mul_comm]
    rw [h_pow]
    gcongr
  obtain ⟨c, hc⟩ := lll_sat k (2 * d + 1) vbl bad hk' hd' hkd'
  refine ⟨c, ?_⟩
  intro i
  have hc_false := hc (i, false)
  have hc_true := hc (i, true)
  obtain ⟨⟨v1, hv1⟩, hv1_bad⟩ := hc_false
  obtain ⟨⟨v2, hv2⟩, hv2_bad⟩ := hc_true
  simp only [vbl, Finset.mem_filter, Finset.mem_univ, true_and] at hv1 hv2
  dsimp [bad] at hv1_bad hv2_bad
  refine ⟨⟨v1, hv1, ?_⟩, ⟨v2, hv2, ?_⟩⟩
  · cases h : c v1
    · contradiction
    · rfl
  · cases h : c v2
    · rfl
    · contradiction

theorem color_deg (n m k : Nat) (hk9 : 9 <= k) (I : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => I i v = true)).card = k)
    (hdeg : forall v, (Finset.univ.filter (fun i => I i v = true)).card <= k) :
    exists c : Fin n -> Bool, forall i,
      (exists v, I i v = true /\ c v = true) /\ (exists v, I i v = true /\ c v = false) := by
  have hd : ∀ i, (Finset.univ.filter (fun j => ¬ (j = i) ∧ ∃ v, I i v = true ∧ I j v = true)).card ≤ k * (k - 1) :=
    deg_meet_le I hk hdeg
  have hkd : Real.exp 1 * (((k * (k - 1) : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1) :=
    exp_mul_deg_le_pow k hk9
  exact color_meet n m k (k * (k - 1)) I hk hd hkd

theorem sat_exists (n m k d : Nat) (V s : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => V i v = true)).card = k)
    (hd : forall i, (Finset.univ.filter (fun j => Not (j = i) /\
      exists v, V i v = true /\ V j v = true)).card <= d)
    (hkd : Real.exp 1 * ((d : Real) + 1) <= 2 ^ k) :
    exists x : Fin n -> Bool, forall i, exists v, V i v = true /\ x v = s i v := by
  let vbl : Fin m → Finset (Fin n) := fun i => Finset.univ.filter (fun v => V i v = true)
  let bad : (i : Fin m) → vbl i → Bool := fun i v => !(s i v.1)
  have hd' : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧ (vbl i ∩ vbl j).Nonempty)).card ≤ d := by
    intro i
    have h_eq : (Finset.univ.filter (fun j => j ≠ i ∧ (vbl i ∩ vbl j).Nonempty)) =
        (Finset.univ.filter (fun j => ¬(j = i) ∧ ∃ v, V i v = true ∧ V j v = true)) := by
      ext j
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      simp only [vbl, Finset.Nonempty, Finset.mem_inter, Finset.mem_filter, Finset.mem_univ, true_and]
    rw [h_eq]
    exact hd i
  obtain ⟨x, hx⟩ := lll_sat k d vbl bad hk hd' hkd
  refine ⟨x, ?_⟩
  intro i
  obtain ⟨⟨v, hv⟩, hxv⟩ := hx i
  dsimp [bad] at hxv
  rw [Finset.mem_filter] at hv
  refine ⟨v, hv.2, ?_⟩
  cases h : s i v
  · simp [h] at hxv
    exact hxv
  · simp [h] at hxv
    exact hxv

theorem ramsey_color (n k : Nat)
    (h : Real.exp 1 * (((Nat.choose k 2 * Nat.choose n (k - 2) : Nat) : Real) + 1)
      <= 2 ^ (Nat.choose k 2 - 1)) :
    exists c : Sym2 (Fin n) -> Bool, forall s : Finset (Fin n), s.card = k ->
      2 <= (s.offDiag.image (fun q => c (Sym2.mk q.1 q.2))).card := by
  let K := Nat.choose k 2
  let d := Nat.choose k 2 * Nat.choose n (k - 2)
  have hK1 : 1 ≤ K := hk_ge_one_of_exp_le h
  let S_k := { s' : Finset (Fin n) // s'.card = k }
  let vbl : (S_k × Bool) → Finset (Sym2 (Fin n)) :=
    fun p => p.1.1.offDiag.image (fun q => Sym2.mk q.1 q.2)
  let bad : (p : S_k × Bool) → vbl p → Bool := fun p _ => p.2
  have hk' : ∀ p, (vbl p).card = K := by
    intro ⟨⟨s', hs'⟩, b'⟩
    dsimp [vbl, K]
    rw [card_offDiag_image_sym2, hs']
  have hd' : ∀ p, (Finset.univ.filter (fun q => q ≠ p ∧ (vbl p ∩ vbl q).Nonempty)).card ≤ 2 * d + 1 := by
    rintro ⟨⟨s', hs'⟩, b'⟩
    exact ramsey_degree_le s' hs' b'
  have hkd' : Real.exp 1 * (((2 * d + 1 : ℕ) : Real) + 1) ≤ 2 ^ K := by
    have h_cast : (((2 * d + 1 : ℕ) : Real) + 1) = 2 * ((d : Real) + 1) := by push_cast; ring
    rw [h_cast, ← mul_assoc, mul_comm (Real.exp 1) 2, mul_assoc]
    have h_pow : (2 : ℝ) ^ K = 2 * 2 ^ (K - 1) := by
      have : K = (K - 1) + 1 := by omega
      conv_lhs => rw [this]
      rw [pow_succ, mul_comm]
    rw [h_pow]
    gcongr
  obtain ⟨c, hc⟩ := lll_sat K (2 * d + 1) vbl bad hk' hd' hkd'
  refine ⟨c, ?_⟩
  intro s hs
  let s_sub : S_k := ⟨s, hs⟩
  have hc_false := hc (s_sub, false)
  have hc_true := hc (s_sub, true)
  obtain ⟨⟨e1, he1⟩, he1_bad⟩ := hc_false
  obtain ⟨⟨e2, he2⟩, he2_bad⟩ := hc_true
  simp only [vbl, Finset.mem_image, Finset.mem_offDiag, Prod.exists] at he1 he2
  dsimp [bad] at he1_bad he2_bad
  have hc_e1 : c e1 = true := by cases h1 : c e1 <;> simp_all
  have hc_e2 : c e2 = false := by cases h2 : c e2 <;> simp_all
  let img := s.offDiag.image (fun q => c (Sym2.mk q.1 q.2))
  have h_true_mem : true ∈ img := by
    obtain ⟨u1, v1, hq1, rfl⟩ := he1
    rw [Finset.mem_image]
    exact ⟨(u1, v1), Finset.mem_offDiag.mpr hq1, hc_e1⟩
  have h_false_mem : false ∈ img := by
    obtain ⟨u2, v2, hq2, rfl⟩ := he2
    rw [Finset.mem_image]
    exact ⟨(u2, v2), Finset.mem_offDiag.mpr hq2, hc_e2⟩
  exact two_le_card_of_mem_both img h_true_mem h_false_mem

theorem ap_color (N k : Nat) (h : Real.exp 1 * (((k ^ 2 * N : Nat) : Real) + 1) <= 2 ^ (k - 1)) :
    exists c : Nat -> Bool, forall a r : Nat, 1 <= r -> a + (k - 1) * r < N ->
      2 <= ((Finset.range k).image (fun j => c (a + j * r))).card := by
  have hk2 : 2 ≤ k := hk_ge_two_of_exp_le h
  let AP := { p : Fin N × Fin N // 1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N }
  let vbl : (AP × Bool) → Finset (Fin N) := fun p =>
    (Finset.range k).attach.image (fun ⟨j, hj⟩ =>
      ⟨p.1.1.1.1 + j * p.1.1.2.1, by
        rw [Finset.mem_range] at hj
        have : j ≤ k - 1 := Nat.le_pred_of_lt hj
        have : p.1.1.1.1 + j * p.1.1.2.1 ≤ p.1.1.1.1 + (k - 1) * p.1.1.2.1 := by gcongr
        exact this.trans_lt p.1.2.2⟩)
  let bad : (p : AP × Bool) → vbl p → Bool := fun p _ => p.2
  have hk' : ∀ p, (vbl p).card = k := by
    rintro ⟨p, b⟩
    exact card_ap_vbl N k p
  have hd' : ∀ p, (Finset.univ.filter (fun q => q ≠ p ∧ (vbl p ∩ vbl q).Nonempty)).card ≤ 2 * (k ^ 2 * N) + 1 := by
    rintro ⟨⟨⟨⟨a', ha'⟩, ⟨r', hr'⟩⟩, ⟨hr'_ge, ha'_lt⟩⟩, b'⟩
    exact ap_degree_le N k a' r' hr'_ge ha'_lt ha' hr' b'
  have hkd' : Real.exp 1 * (((2 * (k ^ 2 * N) + 1 : ℕ) : Real) + 1) ≤ 2 ^ k := by
    have h_cast : (((2 * (k ^ 2 * N) + 1 : ℕ) : Real) + 1) = 2 * (((k ^ 2 * N : ℕ) : Real) + 1) := by push_cast; ring
    rw [h_cast, ← mul_assoc, mul_comm (Real.exp 1) 2, mul_assoc]
    have h_pow : (2 : ℝ) ^ k = 2 * 2 ^ (k - 1) := by
      have : k = (k - 1) + 1 := by omega
      conv_lhs => rw [this]
      rw [pow_succ, mul_comm]
    rw [h_pow]
    gcongr
  obtain ⟨c_fin, hc⟩ := lll_sat k (2 * (k ^ 2 * N) + 1) vbl bad hk' hd' hkd'
  let c : ℕ → Bool := fun x => if hx : x < N then c_fin ⟨x, hx⟩ else false
  refine ⟨c, ?_⟩
  intro a r hr ha
  have ha_lt : a < N := by omega
  have hr_lt : r < N := by
    have : 1 * r ≤ (k - 1) * r := by
      have : 1 ≤ k - 1 := by omega
      gcongr
    linarith
  let p0 : AP := ⟨(⟨a, ha_lt⟩, ⟨r, hr_lt⟩), ⟨hr, ha⟩⟩
  have hc_false := hc (p0, false)
  have hc_true := hc (p0, true)
  obtain ⟨⟨v1, hv1⟩, hv1_bad⟩ := hc_false
  obtain ⟨⟨v2, hv2⟩, hv2_bad⟩ := hc_true
  simp only [vbl, Finset.mem_image, Finset.mem_attach, true_and, Subtype.exists] at hv1 hv2
  dsimp [bad] at hv1_bad hv2_bad
  have hc_v1 : c_fin v1 = true := by cases h1 : c_fin v1 <;> simp_all
  have hc_v2 : c_fin v2 = false := by cases h2 : c_fin v2 <;> simp_all
  let img := (Finset.range k).image (fun j => c (a + j * r))
  have h_true_mem : true ∈ img := by
    obtain ⟨j1, hj1, hv1_eq⟩ := hv1
    rw [Finset.mem_image]
    refine ⟨j1, hj1, ?_⟩
    have hv1_val : a + j1 * r = v1.1 := by
      have h := congrArg Fin.val hv1_eq
      dsimp [p0] at h
      exact h
    dsimp [c]
    rw [hv1_val, dif_pos v1.2]
    exact hc_v1
  have h_false_mem : false ∈ img := by
    obtain ⟨j2, hj2, hv2_eq⟩ := hv2
    rw [Finset.mem_image]
    refine ⟨j2, hj2, ?_⟩
    have hv2_val : a + j2 * r = v2.1 := by
      have h := congrArg Fin.val hv2_eq
      dsimp [p0] at h
      exact h
    dsimp [c]
    rw [hv2_val, dif_pos v2.2]
    exact hc_v2
  exact two_le_card_of_mem_both img h_true_mem h_false_mem

end TuringTask
