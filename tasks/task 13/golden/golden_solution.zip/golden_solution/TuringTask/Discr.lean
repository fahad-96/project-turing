import Mathlib
import TuringTask.Resultants

/-!
# The discriminant of a cyclotomic polynomial

Write `Psi_n = prod_{d | n, d < n} Phi_d`, so that `Phi_n * Psi_n = X^n - 1`.

* `Res(Phi_n, Psi_n)` obeys the recursion `Res(Phi_{n p}, Psi_{n p}) = Res(Phi_n, Psi_n)^(p-1) *
  Res(Phi_{n p}, Phi_n)` for `p` not dividing `n`, and `Res(Phi_{n p^v}, Psi_{n p^v}) =
  Res(Phi_{n p}, Psi_{n p})^(p^(v-1))`; both come from the fibre lemma.  This gives
  `Res(Phi_n, Psi_n)^2 = (prod_{p | n} p^(phi(n)/(p-1)))^2`, and for `n >= 3` the resultant is
  non-negative, so `Res(Phi_n, Psi_n) = prod_{p | n} p^(phi(n)/(p-1))`.
* Differentiating `Phi_n * Psi_n = X^n - 1` and evaluating at the primitive roots gives
  `Res(Phi_n, Phi_n') * Res(Phi_n, Psi_n) = n^phi(n)` (for `n >= 3`), and Mathlib's
  `resultant_deriv` converts `Res(Phi_n, Phi_n')` into the discriminant.
-/

namespace TuringTask

open Polynomial

/-! ### The cofactor `Psi_n` -/

theorem cyclotomic_mul_prod_properDivisors (n : ℕ) (hn : 0 < n) :
    cyclotomic n ℤ * ∏ d ∈ n.properDivisors, cyclotomic d ℤ = X ^ n - 1 := by
  rw [← prod_cyclotomic_eq_X_pow_sub_one hn ℤ, ← Nat.insert_self_properDivisors hn.ne',
    Finset.prod_insert Nat.self_notMem_properDivisors]

theorem expand_X_pow_sub_one (p n : ℕ) : expand ℤ p (X ^ n - 1) = X ^ (n * p) - 1 := by
  rw [map_sub, map_pow, expand_X, map_one, ← pow_mul, mul_comm]

theorem prod_properDivisors_cyclotomic_ne_zero (n : ℕ) :
    ∏ d ∈ n.properDivisors, cyclotomic d ℤ ≠ 0 :=
  Finset.prod_ne_zero_iff.mpr fun d _ => cyclotomic_ne_zero d ℤ

/-- `Psi_{n p} = (expand p Psi_n) * Phi_n` for `p` prime not dividing `n`. -/
theorem prod_properDivisors_cyclotomic_mul_prime (n p : ℕ) (hn : 0 < n) (hp : p.Prime)
    (hpn : ¬ p ∣ n) :
    ∏ d ∈ (n * p).properDivisors, cyclotomic d ℤ =
      expand ℤ p (∏ d ∈ n.properDivisors, cyclotomic d ℤ) * cyclotomic n ℤ := by
  have hnp : 0 < n * p := Nat.mul_pos hn hp.pos
  apply mul_left_cancel₀ (cyclotomic_ne_zero (n * p) ℤ)
  rw [cyclotomic_mul_prod_properDivisors _ hnp, ← expand_X_pow_sub_one,
    ← cyclotomic_mul_prod_properDivisors n hn, map_mul,
    cyclotomic_expand_eq_cyclotomic_mul hp hpn ℤ]
  ring

/-- `Psi_{n p} = expand p Psi_n` for `p` prime dividing `n`. -/
theorem prod_properDivisors_cyclotomic_mul_prime_dvd (n p : ℕ) (hn : 0 < n) (hp : p.Prime)
    (hpn : p ∣ n) :
    ∏ d ∈ (n * p).properDivisors, cyclotomic d ℤ =
      expand ℤ p (∏ d ∈ n.properDivisors, cyclotomic d ℤ) := by
  have hnp : 0 < n * p := Nat.mul_pos hn hp.pos
  apply mul_left_cancel₀ (cyclotomic_ne_zero (n * p) ℤ)
  rw [cyclotomic_mul_prod_properDivisors _ hnp, ← expand_X_pow_sub_one,
    ← cyclotomic_mul_prod_properDivisors n hn, map_mul,
    cyclotomic_expand_eq_cyclotomic hp hpn ℤ]

theorem prod_properDivisors_cyclotomic_mul_prime_pow (n p : ℕ) (hn : 0 < n) (hp : p.Prime)
    (hpn : p ∣ n) : ∀ j : ℕ,
    ∏ d ∈ (n * p ^ j).properDivisors, cyclotomic d ℤ =
      expand ℤ (p ^ j) (∏ d ∈ n.properDivisors, cyclotomic d ℤ) := by
  intro j
  induction j generalizing n with
  | zero => simp [expand_one]
  | succ j ih =>
    rw [pow_succ, expand_mul, ← prod_properDivisors_cyclotomic_mul_prime_dvd n p hn hp hpn,
      ← ih (n * p) (Nat.mul_pos hn hp.pos) (Dvd.intro_left n rfl)]
    congr 2
    ring

/-! ### The recursion for `Res(Phi_n, Psi_n)` -/

/-- `Res(Phi_{n p^v}, Psi_{n p^v}) = Res(Phi_{n p}, Psi_{n p})^(p^(v-1))` for `p` not dividing
`n`, `v >= 1`. -/
theorem resultant_cyclotomic_prod_properDivisors_prime_pow (n p v : ℕ) (hn : 0 < n)
    (hp : p.Prime) (hpn : ¬ p ∣ n) (hv : 0 < v) :
    resultant (cyclotomic (n * p ^ v) ℤ) (∏ d ∈ (n * p ^ v).properDivisors, cyclotomic d ℤ) =
      (resultant (cyclotomic (n * p) ℤ) (∏ d ∈ (n * p).properDivisors, cyclotomic d ℤ)) ^
        (p ^ (v - 1)) := by
  obtain ⟨w, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hv.ne'
  have hp0 := hp.pos
  have hnp : 0 < n * p := Nat.mul_pos hn hp0
  have e : n * p ^ (w + 1) = n * p * p ^ w := by ring
  rw [e, prod_properDivisors_cyclotomic_mul_prime_pow (n * p) p hnp hp (Dvd.intro_left n rfl) w,
    resultant_cyclotomic_expand _ _ (by positivity) (pow_pos hp0 w)]
  have hg : Nat.gcd (n * p * p ^ w) (p ^ w) = p ^ w := Nat.gcd_eq_right (Dvd.intro_left _ rfl)
  have hq : n * p * p ^ w / p ^ w = n * p := Nat.mul_div_cancel _ (pow_pos hp0 w)
  have ht : Nat.totient (n * p * p ^ w) / Nat.totient (n * p) = p ^ w := by
    rw [show n * p * p ^ w = n * p ^ (w + 1) by ring, show n * p = n * p ^ 1 by ring,
      totient_mul_prime_pow_eq hp hpn _ (by omega), totient_mul_prime_pow_eq hp hpn 1 (by omega),
      Nat.add_sub_cancel, Nat.sub_self, pow_zero, one_mul]
    have hden : 0 < Nat.totient n * (p - 1) :=
      Nat.mul_pos (Nat.totient_pos.mpr hn) (Nat.sub_pos_of_lt hp.one_lt)
    rw [show Nat.totient n * (p ^ w * (p - 1)) = Nat.totient n * (p - 1) * p ^ w by ring]
    exact Nat.mul_div_cancel_left _ hden
  rw [hg, hq, ht, Nat.succ_sub_one]

/-- `Res(Phi_{n p}, Psi_{n p}) = Res(Phi_n, Psi_n)^(p-1) * Res(Phi_{n p}, Phi_n)` for `p` not
dividing `n`. -/
theorem resultant_cyclotomic_prod_properDivisors_prime (n p : ℕ) (hn : 0 < n) (hp : p.Prime)
    (hpn : ¬ p ∣ n) :
    resultant (cyclotomic (n * p) ℤ) (∏ d ∈ (n * p).properDivisors, cyclotomic d ℤ) =
      (resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ)) ^ (p - 1) *
        resultant (cyclotomic (n * p) ℤ) (cyclotomic n ℤ) := by
  have hp0 := hp.pos
  have hnp : 0 < n * p := Nat.mul_pos hn hp0
  rw [prod_properDivisors_cyclotomic_mul_prime n p hn hp hpn,
    natDegree_mul ((expand_eq_zero hp0).not.mpr (prod_properDivisors_cyclotomic_ne_zero n))
      (cyclotomic_ne_zero n ℤ),
    resultant_mul_right _ _ _ _ le_rfl, resultant_cyclotomic_expand _ _ hnp hp0]
  have hg : Nat.gcd (n * p) p = p := Nat.gcd_eq_right (Dvd.intro_left _ rfl)
  have hq : n * p / p = n := Nat.mul_div_cancel _ hp0
  have ht : Nat.totient (n * p) / Nat.totient n = p - 1 := by
    rw [Nat.totient_mul (hp.coprime_iff_not_dvd.mpr hpn).symm, Nat.totient_prime hp]
    exact Nat.mul_div_cancel_left _ (Nat.totient_pos.mpr hn)
  rw [hg, hq, ht]

/-- The squared closed form of `Res(Phi_n, Psi_n)`. -/
theorem resultant_cyclotomic_prod_properDivisors_sq (n : ℕ) (hn : 0 < n) :
    (resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ)) ^ 2 =
      (∏ q ∈ n.primeFactors, (q : ℤ) ^ (Nat.totient n / (q - 1))) ^ 2 := by
  induction n using Nat.recOnPrimePow with
  | zero => exact absurd hn (lt_irrefl 0)
  | one =>
    rw [Nat.properDivisors_one, Finset.prod_empty, natDegree_one, resultant_one_right, pow_zero,
      Nat.primeFactors_one, Finset.prod_empty]
  | prime_pow_mul a p v hp hpa hv ih =>
    have ha : 0 < a := by
      rcases Nat.eq_zero_or_pos a with h0 | h0
      · rw [h0, mul_zero] at hn
        exact absurd hn (lt_irrefl 0)
      · exact h0
    have hp0 := hp.pos
    have hap : 0 < a * p := Nat.mul_pos ha hp0
    have hcomm : p ^ v * a = a * p ^ v := mul_comm _ _
    rw [hcomm, resultant_cyclotomic_prod_properDivisors_prime_pow a p v ha hp hpa hv,
      resultant_cyclotomic_prod_properDivisors_prime a p ha hp hpa,
      show a * p = a * p ^ 1 by ring,
      resultant_cyclotomic_mul_prime_pow_coprime_signed a p 1 ha hp le_rfl hpa]
    -- arithmetic on the right-hand side
    have hpf : (a * p ^ v).primeFactors = a.primeFactors ∪ {p} := by
      rw [Nat.primeFactors_mul ha.ne' (pow_pos hp0 v).ne', Nat.primeFactors_prime_pow hv.ne' hp]
    have hdisj : Disjoint a.primeFactors {p} := by
      rw [Finset.disjoint_singleton_right, Nat.mem_primeFactors]
      intro h
      exact hpa h.2.1
    have htot : Nat.totient (a * p ^ v) = Nat.totient a * (p ^ (v - 1) * (p - 1)) :=
      totient_mul_prime_pow_eq hp hpa v hv
    have hpm1 : 0 < p - 1 := Nat.sub_pos_of_lt hp.one_lt
    have hexp_p : Nat.totient (a * p ^ v) / (p - 1) = Nat.totient a * p ^ (v - 1) := by
      rw [htot, show Nat.totient a * (p ^ (v - 1) * (p - 1)) =
        Nat.totient a * p ^ (v - 1) * (p - 1) by ring]
      exact Nat.mul_div_cancel _ hpm1
    have hexp_q : ∀ q ∈ a.primeFactors,
        (q : ℤ) ^ (Nat.totient (a * p ^ v) / (q - 1)) =
          ((q : ℤ) ^ (Nat.totient a / (q - 1))) ^ (p ^ (v - 1) * (p - 1)) := by
      intro q hq
      rw [Nat.mem_primeFactors] at hq
      have hdvd : q - 1 ∣ Nat.totient a := by
        rw [← Nat.totient_prime hq.1]
        exact Nat.totient_dvd_of_dvd hq.2.1
      rw [htot, mul_comm (Nat.totient a), Nat.mul_div_assoc _ hdvd, mul_comm, pow_mul]
    rw [hpf, Finset.prod_union hdisj, Finset.prod_singleton, hexp_p,
      Finset.prod_congr rfl hexp_q, Finset.prod_pow]
    -- now pure algebra: use the induction hypothesis on `Res(Phi_a, Psi_a)^2`
    set X := resultant (cyclotomic a ℤ) (∏ d ∈ a.properDivisors, cyclotomic d ℤ) with hX
    set Y := ∏ q ∈ a.primeFactors, (q : ℤ) ^ (Nat.totient a / (q - 1)) with hY
    set s : ℤ := (-1) ^ (Nat.totient (p ^ 1) * Nat.totient a) with hs
    have hs2 : s ^ 2 = 1 := by
      rw [hs, ← pow_mul, mul_comm, pow_mul]
      simp
    have hIH : X ^ 2 = Y ^ 2 := ih ha
    calc ((X ^ (p - 1) * (s * (p : ℤ) ^ Nat.totient a)) ^ p ^ (v - 1)) ^ 2
        = (X ^ 2) ^ ((p - 1) * p ^ (v - 1)) * (s ^ 2) ^ (p ^ (v - 1)) *
            ((p : ℤ) ^ Nat.totient a) ^ (2 * p ^ (v - 1)) := by ring
      _ = (Y ^ 2) ^ ((p - 1) * p ^ (v - 1)) * 1 ^ (p ^ (v - 1)) *
            ((p : ℤ) ^ Nat.totient a) ^ (2 * p ^ (v - 1)) := by rw [hIH, hs2]
      _ = (Y ^ (p ^ (v - 1) * (p - 1)) * (p : ℤ) ^ (Nat.totient a * p ^ (v - 1))) ^ 2 := by ring

/-- The closed form of `Res(Phi_n, Psi_n)` for `n >= 3`. -/
theorem resultant_cyclotomic_prod_properDivisors_eq (n : ℕ) (hn : 3 ≤ n) :
    resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ) =
      ∏ q ∈ n.primeFactors, (q : ℤ) ^ (Nat.totient n / (q - 1)) := by
  have h1 : 0 ≤ resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ) :=
    resultant_cyclotomic_nonneg n hn _
  have h2 : 0 ≤ ∏ q ∈ n.primeFactors, (q : ℤ) ^ (Nat.totient n / (q - 1)) :=
    Finset.prod_nonneg fun q _ => pow_nonneg (Int.natCast_nonneg q) _
  exact (sq_eq_sq₀ h1 h2).mp (resultant_cyclotomic_prod_properDivisors_sq n (by omega))

/-! ### The derivative identity -/

/-- The product of the primitive `n`-th roots of unity is `1` for `n >= 3`. -/
theorem prod_primitiveRoots_eq_one_of_three_le (n : ℕ) (hn : 3 ≤ n) :
    ∏ α ∈ primitiveRoots n ℂ, α = 1 := by
  have hn0 : n ≠ 0 := by omega
  have h := cyclotomic_eq_prod_X_sub_primitiveRoots (Complex.isPrimitiveRoot_exp n hn0)
  have h0 := cyclotomic_coeff_zero ℂ (show 1 < n by omega)
  rw [coeff_zero_eq_eval_zero, h, eval_prod] at h0
  simp only [eval_sub, eval_X, eval_C, zero_sub] at h0
  rw [Finset.prod_neg, Complex.card_primitiveRoots, (Nat.totient_even hn).neg_one_pow,
    one_mul] at h0
  exact h0

/-- `Res(Phi_n, Phi_n') * Res(Phi_n, Psi_n) = n ^ phi(n)` for `n >= 3`. -/
theorem resultant_derivative_mul_resultant_prod_properDivisors (n : ℕ) (hn : 3 ≤ n) :
    resultant (cyclotomic n ℤ) (derivative (cyclotomic n ℤ)) *
        resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ) =
      (n : ℤ) ^ Nat.totient n := by
  have hn0 : 0 < n := by omega
  haveI : NeZero (n : ℂ) := ⟨by exact_mod_cast hn0.ne'⟩
  apply Int.cast_injective (α := ℂ)
  rw [Int.cast_mul, Int.cast_pow, Int.cast_natCast, resultant_cyclotomic_eq_prod n hn0,
    resultant_cyclotomic_eq_prod n hn0, ← Finset.prod_mul_distrib]
  -- the derivative identity over `C`
  have hprod : cyclotomic n ℂ * (∏ d ∈ n.properDivisors, cyclotomic d ℤ).map (Int.castRingHom ℂ) =
      X ^ n - 1 := by
    have := congrArg (Polynomial.map (Int.castRingHom ℂ)) (cyclotomic_mul_prod_properDivisors n hn0)
    rwa [Polynomial.map_mul, map_cyclotomic_int, Polynomial.map_sub, Polynomial.map_pow,
      Polynomial.map_X, Polynomial.map_one] at this
  have hder := congrArg derivative hprod
  rw [derivative_mul, derivative_sub, derivative_X_pow, derivative_one, sub_zero] at hder
  have key : ∀ α ∈ primitiveRoots n ℂ,
      ((derivative (cyclotomic n ℤ)).map (Int.castRingHom ℂ)).eval α *
        ((∏ d ∈ n.properDivisors, cyclotomic d ℤ).map (Int.castRingHom ℂ)).eval α =
          (n : ℂ) * α ^ (n - 1) := by
    intro α hα
    have hroot : eval α (cyclotomic n ℂ) = 0 := by
      rw [mem_primitiveRoots hn0] at hα
      exact (isRoot_cyclotomic_iff.mpr hα).eq_zero
    have := congrArg (eval α) hder
    rw [eval_add, eval_mul, eval_mul, hroot, zero_mul, add_zero, eval_mul, eval_C, eval_pow,
      eval_X] at this
    rw [← derivative_map, map_cyclotomic_int]
    exact this
  rw [Finset.prod_congr rfl key, Finset.prod_mul_distrib, Finset.prod_const,
    Complex.card_primitiveRoots, Finset.prod_pow, prod_primitiveRoots_eq_one_of_three_le n hn,
    one_pow, mul_one]

/-- Theorem 3 in its working form. -/
theorem discr_cyclotomic' (n : ℕ) (hn : 1 ≤ n) :
    discr (cyclotomic n ℤ) * n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1))) =
      (-1) ^ (n.totient / 2) * (n : ℤ) ^ n.totient := by
  rcases lt_or_ge n 3 with hlt | hge
  · interval_cases n
    · have hdeg : (X - 1 : ℤ[X]).degree = 1 := by rw [← C_1]; exact degree_X_sub_C 1
      rw [cyclotomic_one, discr_of_degree_eq_one hdeg]
      simp
    · have hdeg : (X + 1 : ℤ[X]).degree = 1 := by rw [← C_1]; exact degree_X_add_C 1
      rw [cyclotomic_two, discr_of_degree_eq_one hdeg, Nat.Prime.primeFactors Nat.prime_two,
        Nat.totient_two]
      simp
  · have hkey := resultant_derivative_mul_resultant_prod_properDivisors n hge
    rw [resultant_cyclotomic_prod_properDivisors_eq n hge] at hkey
    have hdeg : 0 < (cyclotomic n ℤ).degree := degree_cyclotomic_pos n ℤ (by omega)
    have hres := resultant_deriv hdeg
    rw [(cyclotomic.monic n ℤ).leadingCoeff, mul_one, natDegree_cyclotomic] at hres
    rw [natDegree_derivative, natDegree_cyclotomic] at hkey
    rw [hres] at hkey
    -- hkey : (-1) ^ e * discr * prod = n ^ phi n, with e = phi n * (phi n - 1) / 2
    have heven := Nat.totient_even (show 2 < n by omega)
    obtain ⟨t, ht⟩ := heven
    have ht1 : 1 ≤ t := by
      have : 2 ≤ Nat.totient n := by
        have := Nat.totient_pos.mpr (show 0 < n by omega)
        omega
      omega
    have hsign : ((-1 : ℤ) ^ (Nat.totient n * (Nat.totient n - 1) / 2)) =
        (-1) ^ (Nat.totient n / 2) := by
      rw [ht, show t + t = 2 * t by ring, Nat.mul_div_cancel_left t two_pos,
        show 2 * t * (2 * t - 1) = 2 * (t * (2 * t - 1)) by ring, Nat.mul_div_cancel_left _ two_pos,
        pow_mul', Odd.neg_one_pow]
      exact ⟨t - 1, by omega⟩
    rw [hsign] at hkey
    have hsq : ((-1 : ℤ) ^ (Nat.totient n / 2)) * (-1) ^ (Nat.totient n / 2) = 1 := by
      rw [← pow_add, ← two_mul, pow_mul]
      simp
    calc discr (cyclotomic n ℤ) * n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1)))
        = (-1) ^ (Nat.totient n / 2) * ((-1) ^ (Nat.totient n / 2) * discr (cyclotomic n ℤ) *
            n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1)))) := by
          rw [← mul_assoc, ← mul_assoc, hsq, one_mul]
      _ = (-1) ^ (Nat.totient n / 2) * (n : ℤ) ^ Nat.totient n := by rw [hkey]

end TuringTask
