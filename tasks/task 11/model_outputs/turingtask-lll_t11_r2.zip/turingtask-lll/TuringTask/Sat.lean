import TuringTask.Deg

/-!
# The k-SAT application of the symmetric LLL
-/

namespace TuringTask

open Finset

section Sat

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- `Unsat D sgn i` : the event that clause `i` (variables `D i`, signs `sgn i`) is unsatisfied,
i.e. `ω v ≠ sgn i v` for every variable `v` of the clause. -/
def Unsat (D : ι → Finset V) (sgn : ι → V → Bool) (i : ι) : Finset (V → Bool) :=
  univ.filter (fun ω => ¬ ∃ v ∈ D i, ω v = sgn i v)

lemma Meas_Unsat (D : ι → Finset V) (sgn : ι → V → Bool) (i : ι) :
    Meas (D i) (Unsat D sgn i) := by
  intro ω ω' hvv hω
  simp only [Unsat, Finset.mem_filter, Finset.mem_univ, true_and] at hω ⊢
  rintro ⟨v, hv, hval⟩
  exact hω ⟨v, hv, by rw [hvv v hv]; exact hval⟩

/-- The unsatisfying assignments of clause `i` form a single pattern on `D i`. -/
lemma Unsat_subset (D : ι → Finset V) (sgn : ι → V → Bool) (i : ι) :
    Unsat D sgn i ⊆ agree (D i) (fun v => ! (sgn i v)) := by
  intro ω hω
  simp only [Unsat, Finset.mem_filter, Finset.mem_univ, true_and] at hω
  push_neg at hω
  rw [mem_agree]
  intro v hv
  have := hω v hv
  cases hs : sgn i v <;> cases ho : ω v <;> simp_all

/-- Generic k-SAT theorem. -/
theorem sat_generic (D : ι → Finset V) (sgn : ι → V → Bool) (k d : ℕ)
    (hk : ∀ i, k ≤ (D i).card)
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hcond : Real.exp 1 * ((d : ℝ) + 1) ≤ 2 ^ k) :
    ∃ ω : V → Bool, ∀ i, ∃ v ∈ D i, ω v = sgn i v := by
  have hmain : ∃ ω : V → Bool, ∀ i, ω ∉ Unsat D sgn i := by
    refine LLL_sym (Unsat D sgn) D d (1 / 2 ^ k) (Meas_Unsat D sgn) hdeg ?_ ?_
    · intro i
      exact pr_le_pattern1 (Unsat_subset D sgn i) (hk i)
    · rw [mul_one_div, div_mul_eq_mul_div, div_le_one (by positivity)]
      linarith [hcond]
  obtain ⟨ω, hω⟩ := hmain
  refine ⟨ω, fun i => ?_⟩
  have := hω i
  simp only [Unsat, Finset.mem_filter, Finset.mem_univ, true_and, not_not] at this
  exact this

end Sat

end TuringTask
