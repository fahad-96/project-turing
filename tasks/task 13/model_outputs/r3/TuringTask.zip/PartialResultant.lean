import Mathlib

open Polynomial

namespace TuringTask

lemma resultant_cyclotomic_ne_zero {m n : Nat} (hmn : m ≠ n) :
    Polynomial.resultant (cyclotomic m Int) (cyclotomic n Int) ≠ 0 := by
  intro hzero
  have hcop : IsCoprime (cyclotomic m Rat) (cyclotomic n Rat) :=
    cyclotomic.isCoprime_rat hmn
  have hne : Polynomial.resultant (cyclotomic m Rat) (cyclotomic n Rat) ≠ 0 :=
    resultant_ne_zero _ _ hcop
  have hmap := resultant_map_map (cyclotomic m Int) (cyclotomic n Int)
    m.totient n.totient (Int.castRingHom Rat)
  change (cyclotomic m Int).resultant (cyclotomic n Int)
    (cyclotomic m Int).natDegree (cyclotomic n Int).natDegree = 0 at hzero
  rw [natDegree_cyclotomic, natDegree_cyclotomic] at hzero
  rw [map_cyclotomic_int, map_cyclotomic_int, hzero, map_zero] at hmap
  apply hne
  simpa only [natDegree_cyclotomic] using hmap

lemma resultant_C_mul_X_pow_cyclotomic
    (n a : Nat) (z : Int) (hz : z ≠ 0) :
    Polynomial.resultant (C z * X ^ a) (cyclotomic n Int) =
      z ^ n.totient * ((cyclotomic n Int).constantCoeff ^ a) := by
  change (C z * X ^ a).resultant (cyclotomic n Int)
    (C z * X ^ a).natDegree (cyclotomic n Int).natDegree = _
  have hdeg : ((C z : Int[X]) * X ^ a).natDegree =
      (C z : Int[X]).natDegree + ((X : Int[X]) ^ a).natDegree := by
    rw [natDegree_mul]
    · exact C_ne_zero.mpr hz
    · exact pow_ne_zero _ X_ne_zero
  have hC : (C z : Int[X]).resultant (cyclotomic n Int) 0 n.totient = z ^ n.totient := by
    rw [resultant_C_left]
    simp
  have hX : (X : Int[X]).resultant (cyclotomic n Int) 1 n.totient =
      (cyclotomic n Int).constantCoeff := by
    have ht := resultant_X_sub_C_left (cyclotomic n Int) n.totient (0 : Int) (by
      rw [natDegree_cyclotomic])
    rw [show (X : Int[X]) - C 0 = X by simp] at ht
    rw [constantCoeff_apply, coeff_zero_eq_eval_zero]
    exact ht
  rw [hdeg, resultant_mul_left]
  · rw [show (C z : Int[X]).natDegree = 0 by simp,
      show (cyclotomic n Int).natDegree = n.totient by rw [natDegree_cyclotomic], hC]
    rw [resultant_pow_left]
    · rw [show (X : Int[X]).natDegree = 1 by simp, hX]
    · simp
    · rw [natDegree_cyclotomic]
  · exact le_rfl

lemma resultant_C_mul_X_pow_cyclotomic_padded
    (n a t : Nat) (z : Int) (hz : z ≠ 0) :
    (C z * X ^ a : Int[X]).resultant (cyclotomic n Int) (a + t) n.totient =
      (-1 : Int) ^ (t * n.totient) *
        (z ^ n.totient * ((cyclotomic n Int).constantCoeff ^ a)) := by
  have hnat : (C z * X ^ a : Int[X]).natDegree = a := by
    rw [natDegree_mul (C_ne_zero.mpr hz) (pow_ne_zero _ X_ne_zero)]
    simp
  induction t with
  | zero =>
      rw [Nat.add_zero]
      have hb := resultant_C_mul_X_pow_cyclotomic n a z hz
      change (C z * X ^ a : Int[X]).resultant (cyclotomic n Int)
        (C z * X ^ a : Int[X]).natDegree (cyclotomic n Int).natDegree = _ at hb
      rw [hnat, natDegree_cyclotomic] at hb
      simpa using hb
  | succ t ih =>
      rw [Nat.add_succ, resultant_succ_left_deg]
      · rw [show (cyclotomic n Int).coeff n.totient = 1 by
          rw [← natDegree_cyclotomic n Int]
          exact (cyclotomic.monic n Int).coeff_natDegree]
        rw [ih]
        simp only [mul_one, Nat.succ_mul, pow_add]
        ring
      · omega

lemma resultant_eq_of_monomial_mod_cyclotomic
    (n a t : Nat) (z : Int) (q f : Int[X]) (hz : z ≠ 0)
    (hfdeg : f.natDegree = a + t)
    (hqdeg : q.natDegree + n.totient ≤ a + t)
    (heq : f = C z * X ^ a + cyclotomic n Int * q) :
    f.resultant (cyclotomic n Int) =
      (-1 : Int) ^ (t * n.totient) *
        (z ^ n.totient * ((cyclotomic n Int).constantCoeff ^ a)) := by
  change f.resultant (cyclotomic n Int) f.natDegree
    (cyclotomic n Int).natDegree = _
  rw [hfdeg, natDegree_cyclotomic, heq]
  rw [resultant_add_mul_left]
  · exact resultant_C_mul_X_pow_cyclotomic_padded n a t z hz
  · exact hqdeg
  · rw [natDegree_cyclotomic]

end TuringTask
