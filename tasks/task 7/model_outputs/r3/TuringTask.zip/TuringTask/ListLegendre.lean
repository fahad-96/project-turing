import Mathlib

open Lean Elab Command

elab "list_decls " needle:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if (toString name).contains needle.getString then
      logInfo name

list_decls "legendreSym."
list_decls "legendreSym_"
list_decls "isSquare_iff"
list_decls "IsQuadratic."
