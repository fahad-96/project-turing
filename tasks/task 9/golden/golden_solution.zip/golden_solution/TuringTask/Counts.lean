import Mathlib
import TuringTask.Jacobi3

/-!
# Point counts and the cubic Gauss sum in terms of the cubic Jacobi sum

Throughout, `χ` is a character of order 3 on `ZMod p` and `T = J(χ, χ) + J(χ⁻¹, χ⁻¹)`.

* `count_fermat_cubic`: `#{(x, y) | x ^ 3 + y ^ 3 = 1} = p - 2 + T`;
* `count_both_cubes`: `9 * #{x | x ≠ 0, x + 1 ≠ 0, x and x + 1 cubes} = p - 8 + T`;
* `count_noncube_pairs`: `9 * #{x | x, x + 1 not cubes, x (x + 1) a cube} = 2 (p + 1 + T)`;
* `two_cube_iff_even`: `2` is a cube iff the integer `L = p - 2 + ...` is even;
* `cubic_gauss_core`: `G ^ 3 = 3 p G + p T` for `G = ∑ x, e(a x ^ 3 / p)`.
-/

open Finset

namespace TuringTask

variable {p : ℕ} [Fact p.Prime] {χ : MulChar (ZMod p) ℂ} (hχ : orderOf χ = 3)
include hχ

/-! ### Character sums -/

/-- Expanding the product of two cube-root counts. -/
theorem sum_nine : ∑ x : ZMod p, (1 + χ x + χ⁻¹ x) * (1 + χ (1 - x) + χ⁻¹ (1 - x)) =
    (p : ℂ) - 2 + (jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹) := by
  have e : ∀ x : ZMod p, (1 + χ x + χ⁻¹ x) * (1 + χ (1 - x) + χ⁻¹ (1 - x)) =
      1 + χ x + χ⁻¹ x + χ (1 - x) + χ⁻¹ (1 - x) + χ x * χ (1 - x) + χ⁻¹ x * χ⁻¹ (1 - x) +
        χ x * χ⁻¹ (1 - x) + χ⁻¹ x * χ (1 - x) := fun x => by ring
  simp only [e, Finset.sum_add_distrib]
  have r1 : ∑ x : ZMod p, χ (1 - x) = 0 :=
    (Fintype.sum_equiv (Equiv.subLeft (1 : ZMod p)) (fun x => χ (1 - x)) (fun x => χ x)
      (fun x => rfl)).trans (MulChar.sum_eq_zero_of_ne_one (o3_ne_one hχ))
  have r2 : ∑ x : ZMod p, χ⁻¹ (1 - x) = 0 :=
    (Fintype.sum_equiv (Equiv.subLeft (1 : ZMod p)) (fun x => χ⁻¹ (1 - x)) (fun x => χ⁻¹ x)
      (fun x => rfl)).trans (MulChar.sum_eq_zero_of_ne_one (o3_inv_ne_one hχ))
  have r3 : ∑ x : ZMod p, χ x * χ⁻¹ (1 - x) = -1 := by
    have h := jacobiSum_nontrivial_inv (o3_ne_one hχ)
    rw [o3_apply_neg_one hχ] at h
    exact h
  have r4 : ∑ x : ZMod p, χ⁻¹ x * χ (1 - x) = -1 := by
    have h := jacobiSum_nontrivial_inv (o3_inv_ne_one hχ)
    rw [inv_inv, o3_apply_neg_one (o3_orderOf_inv hχ)] at h
    exact h
  rw [r1, r2, r3, r4, MulChar.sum_eq_zero_of_ne_one (o3_ne_one hχ),
    MulChar.sum_eq_zero_of_ne_one (o3_inv_ne_one hχ)]
  simp only [Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul, mul_one]
  unfold jacobiSum
  ring

/-- The same sum with `x + 1` in place of `1 - x` (substitute `x = -y`). -/
theorem sum_nine_shift :
    ∑ x : ZMod p, (1 + χ x + χ⁻¹ x) * (1 + χ (x + 1) + χ⁻¹ (x + 1)) =
      (p : ℂ) - 2 + (jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹) := by
  rw [← sum_nine hχ]
  refine Fintype.sum_equiv (Equiv.neg (ZMod p)) _ _ (fun x => ?_)
  simp only [Equiv.neg_apply, o3_apply_neg hχ, o3_apply_neg (o3_orderOf_inv hχ), sub_neg_eq_add,
    add_comm (1 : ZMod p) x]

/-- `∑ x, (1 + χ(x) χ(x + 1) + χ⁻¹(x) χ⁻¹(x + 1)) = p + T`. -/
theorem sum_pair_shift :
    ∑ x : ZMod p, (1 + χ x * χ (x + 1) + χ⁻¹ x * χ⁻¹ (x + 1)) =
      (p : ℂ) + (jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹) := by
  have h : ∑ x : ZMod p, (1 + χ x * χ (x + 1) + χ⁻¹ x * χ⁻¹ (x + 1)) =
      ∑ y : ZMod p, (1 + χ y * χ (1 - y) + χ⁻¹ y * χ⁻¹ (1 - y)) := by
    refine Fintype.sum_equiv (Equiv.neg (ZMod p)) _ _ (fun x => ?_)
    simp only [Equiv.neg_apply, o3_apply_neg hχ, o3_apply_neg (o3_orderOf_inv hχ),
      sub_neg_eq_add, add_comm (1 : ZMod p) x]
  rw [h, Finset.sum_add_distrib, Finset.sum_add_distrib]
  simp only [Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul, mul_one]
  unfold jacobiSum
  ring

/-- `∑ x, (1 - χ(x) χ⁻¹(x)) = 1` (only `x = 0` contributes). -/
theorem sum_one_sub_mul_inv : ∑ x : ZMod p, (1 - χ x * χ⁻¹ x) = 1 := by
  have h : ∀ x : ZMod p, (1 - χ x * χ⁻¹ x) = if x = 0 then 1 else 0 := by
    intro x
    by_cases hx : x = 0
    · rw [if_pos hx, hx, MulChar.map_zero χ, zero_mul, sub_zero]
    · rw [if_neg hx, o3_inv_apply hχ x]
      linear_combination (-1 : ℂ) * o3_apply_pow_three hχ hx
  rw [Finset.sum_congr rfl (fun x _ => h x), Finset.sum_ite_eq']
  simp

theorem sum_one_sub_mul_inv_shift : ∑ x : ZMod p, (1 - χ (x + 1) * χ⁻¹ (x + 1)) = 1 := by
  exact (Fintype.sum_equiv (Equiv.addRight (1 : ZMod p))
    (fun x => 1 - χ (x + 1) * χ⁻¹ (x + 1)) (fun y => 1 - χ y * χ⁻¹ y) (fun x => rfl)).trans
    (sum_one_sub_mul_inv hχ)

/-! ### The three point counts -/

/-- Number of solutions of `x ^ 3 + y ^ 3 = 1`. -/
theorem count_fermat_cubic (L : ℂ) (htr : jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = L) :
    ((#{q : ZMod p × ZMod p | q.1 ^ 3 + q.2 ^ 3 = 1} : ℕ) : ℂ) = p - 2 + L := by
  rw [Finset.natCast_card_filter]
  simp only [Fintype.sum_prod_type]
  have inner : ∀ x : ZMod p, (∑ y : ZMod p, if x ^ 3 + y ^ 3 = 1 then (1 : ℂ) else 0) =
      1 + χ (1 - x ^ 3) + χ⁻¹ (1 - x ^ 3) := by
    intro x
    refine (sum_over_cubes hχ (fun b => if x ^ 3 + b = 1 then (1 : ℂ) else 0)).trans ?_
    have e : ∀ b : ZMod p, (1 + χ b + χ⁻¹ b) * (if x ^ 3 + b = 1 then (1 : ℂ) else 0) =
        if b = 1 - x ^ 3 then 1 + χ b + χ⁻¹ b else 0 := by
      intro b
      by_cases h : b = 1 - x ^ 3
      · rw [if_pos h, if_pos (show x ^ 3 + b = 1 by rw [h]; ring), mul_one]
      · rw [if_neg h, if_neg (show ¬(x ^ 3 + b = 1) from fun h' => h (by linear_combination h')),
          mul_zero]
    rw [Finset.sum_congr rfl (fun b _ => e b), Finset.sum_ite_eq']
    simp
  rw [Finset.sum_congr rfl (fun x _ => inner x)]
  refine (sum_over_cubes hχ (fun a => 1 + χ (1 - a) + χ⁻¹ (1 - a))).trans ?_
  rw [sum_nine hχ, htr]

/-- `9` times the number of `x` with `x ≠ 0`, `x + 1 ≠ 0`, `x` and `x + 1` cubes. -/
theorem count_both_cubes (L : ℂ) (htr : jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = L) :
    9 * ((#{x : ZMod p | ¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u : ZMod p, u ^ 3 = x) ∧
      (∃ v : ZMod p, v ^ 3 = x + 1)} : ℕ) : ℂ) = p - 8 + L := by
  rw [Finset.natCast_card_filter, Finset.mul_sum]
  have hpt : ∀ x : ZMod p, (9 : ℂ) * (if ¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u : ZMod p, u ^ 3 = x) ∧
      (∃ v : ZMod p, v ^ 3 = x + 1) then 1 else 0) =
      (1 + χ x + χ⁻¹ x) * (1 + χ (x + 1) + χ⁻¹ (x + 1)) - 3 * (1 - χ x * χ⁻¹ x) -
        3 * (1 - χ (x + 1) * χ⁻¹ (x + 1)) := by
    intro x
    have ca := isCube_iff hχ x
    have cb := isCube_iff hχ (x + 1)
    rw [o3_inv_apply hχ x, o3_inv_apply hχ (x + 1)]
    split_ifs with hP
    · obtain ⟨h0, h1, hu, hv⟩ := hP
      have ha : χ x = 1 := (ca.mp hu).resolve_left h0
      have hb : χ (x + 1) = 1 := (cb.mp hv).resolve_left h1
      rw [ha, hb]
      norm_num
    · by_cases h0 : x = 0
      · rw [h0, zero_add, MulChar.map_zero, MulChar.map_one]
        norm_num
      by_cases h1 : x + 1 = 0
      · have hx : x = -1 := eq_neg_of_add_eq_zero_left h1
        rw [h1, hx, MulChar.map_zero, o3_apply_neg_one hχ]
        norm_num
      have ha3 := o3_apply_pow_three hχ h0
      have hb3 := o3_apply_pow_three hχ h1
      by_cases ha : χ x = 1
      · have hb : χ (x + 1) ≠ 1 := fun hb =>
          hP ⟨h0, h1, ca.mpr (Or.inr ha), cb.mpr (Or.inr hb)⟩
        have hb0 := one_add_add_sq_eq_zero hb3 hb
        linear_combination (-(1 + χ x + χ x ^ 2)) * hb0 - 3 * ha3 - 3 * hb3
      · have ha0 := one_add_add_sq_eq_zero ha3 ha
        linear_combination (-(1 + χ (x + 1) + χ (x + 1) ^ 2)) * ha0 - 3 * ha3 - 3 * hb3
  refine (Finset.sum_congr rfl (fun x _ => hpt x)).trans ?_
  rw [Finset.sum_sub_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, ← Finset.mul_sum,
    sum_nine_shift hχ, sum_one_sub_mul_inv hχ, sum_one_sub_mul_inv_shift hχ, htr]
  ring

/-- `9` times the number of `x` with `x`, `x + 1` not cubes and `x (x + 1)` a cube. -/
theorem count_noncube_pairs (L : ℂ) (htr : jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = L) :
    9 * ((#{x : ZMod p | ¬(∃ u : ZMod p, u ^ 3 = x) ∧ ¬(∃ v : ZMod p, v ^ 3 = x + 1) ∧
      (∃ w : ZMod p, w ^ 3 = x * (x + 1))} : ℕ) : ℂ) = 2 * (p + 1 + L) := by
  rw [Finset.natCast_card_filter, Finset.mul_sum]
  have hpt : ∀ x : ZMod p, (9 : ℂ) * (if ¬(∃ u : ZMod p, u ^ 3 = x) ∧
      ¬(∃ v : ZMod p, v ^ 3 = x + 1) ∧ (∃ w : ZMod p, w ^ 3 = x * (x + 1)) then 1 else 0) =
      3 * (1 + χ x * χ (x + 1) + χ⁻¹ x * χ⁻¹ (x + 1)) -
        (1 + χ x + χ⁻¹ x) * (1 + χ (x + 1) + χ⁻¹ (x + 1)) := by
    intro x
    have ca := isCube_iff hχ x
    have cb := isCube_iff hχ (x + 1)
    have cc := isCube_iff hχ (x * (x + 1))
    rw [o3_inv_apply hχ x, o3_inv_apply hχ (x + 1)]
    split_ifs with hQ
    · obtain ⟨hnu, hnv, hw⟩ := hQ
      have h0 : x ≠ 0 := fun h => hnu (ca.mpr (Or.inl h))
      have h1 : x + 1 ≠ 0 := fun h => hnv (cb.mpr (Or.inl h))
      have ha : χ x ≠ 1 := fun h => hnu (ca.mpr (Or.inr h))
      have hab : χ x * χ (x + 1) = 1 := by
        rw [← map_mul]
        exact (cc.mp hw).resolve_left (mul_ne_zero h0 h1)
      have ha0 := one_add_add_sq_eq_zero (o3_apply_pow_three hχ h0) ha
      linear_combination (-3 - 3 * (χ x * χ (x + 1) + 1)) * hab +
        (1 + χ (x + 1) + χ (x + 1) ^ 2) * ha0
    · by_cases h0 : x = 0
      · rw [h0, zero_add, MulChar.map_zero, MulChar.map_one]
        norm_num
      by_cases h1 : x + 1 = 0
      · have hx : x = -1 := eq_neg_of_add_eq_zero_left h1
        rw [h1, hx, MulChar.map_zero, o3_apply_neg_one hχ]
        norm_num
      have ha3 := o3_apply_pow_three hχ h0
      have hb3 := o3_apply_pow_three hχ h1
      by_cases ha : χ x = 1
      · rw [ha]
        ring
      by_cases hb : χ (x + 1) = 1
      · rw [hb]
        ring
      have hab : χ x * χ (x + 1) ≠ 1 := by
        intro hab
        apply hQ
        refine ⟨fun h => ?_, fun h => ?_, cc.mpr (Or.inr (by rw [map_mul]; exact hab))⟩
        · rcases ca.mp h with h | h
          · exact h0 h
          · exact ha h
        · rcases cb.mp h with h | h
          · exact h1 h
          · exact hb h
      have hab3 : (χ x * χ (x + 1)) ^ 3 = 1 := by rw [mul_pow, ha3, hb3, one_mul]
      have hab0 := one_add_add_sq_eq_zero hab3 hab
      have ha0 := one_add_add_sq_eq_zero ha3 ha
      linear_combination (-3 : ℂ) * hab0 + (1 + χ (x + 1) + χ (x + 1) ^ 2) * ha0
  refine (Finset.sum_congr rfl (fun x _ => hpt x)).trans ?_
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum, sum_pair_shift hχ, sum_nine_shift hχ, htr]
  ring

/-! ### Two is a cube iff `L` is even -/

omit hχ in
/-- A finite set of pairs that is closed under swapping has `#S = #diagonal + 2 * k`. -/
theorem card_swap_parity (S : Finset (ZMod p × ZMod p)) (hS : ∀ q, q ∈ S ↔ q.swap ∈ S) :
    #S = #{q ∈ S | q.1 = q.2} + 2 * #{q ∈ S | q.1.val < q.2.val} := by
  have h1 := Finset.card_filter_add_card_filter_not (s := S)
    (fun q : ZMod p × ZMod p => q.1 = q.2)
  have h2 := Finset.card_filter_add_card_filter_not (s := {q ∈ S | ¬q.1 = q.2})
    (fun q : ZMod p × ZMod p => q.1.val < q.2.val)
  beta_reduce at h1 h2
  have e1 : {q ∈ {q ∈ S | ¬q.1 = q.2} | q.1.val < q.2.val} = {q ∈ S | q.1.val < q.2.val} := by
    ext q
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨⟨hq, -⟩, hlt⟩
      exact ⟨hq, hlt⟩
    · rintro ⟨hq, hlt⟩
      refine ⟨⟨hq, fun h => ?_⟩, hlt⟩
      rw [h] at hlt
      exact lt_irrefl _ hlt
  have e2 : #{q ∈ {q ∈ S | ¬q.1 = q.2} | ¬q.1.val < q.2.val} = #{q ∈ S | q.1.val < q.2.val} := by
    apply Finset.card_bij (fun q _ => q.swap)
    · intro q hq
      simp only [Finset.mem_filter] at hq ⊢
      obtain ⟨⟨hqS, hne⟩, hnlt⟩ := hq
      refine ⟨(hS q).mp hqS, ?_⟩
      simp only [Prod.fst_swap, Prod.snd_swap]
      have : q.1.val ≠ q.2.val := fun h => hne (ZMod.val_injective p h)
      omega
    · intro a _ b _ h
      exact Prod.swap_injective h
    · intro b hb
      simp only [Finset.mem_filter] at hb
      obtain ⟨hbS, hlt⟩ := hb
      refine ⟨b.swap, ?_, Prod.swap_swap b⟩
      simp only [Finset.mem_filter, Prod.fst_swap, Prod.snd_swap]
      refine ⟨⟨(hS b).mp hbS, fun h => ?_⟩, by omega⟩
      rw [h] at hlt
      exact lt_irrefl _ hlt
  rw [e1] at h2
  rw [← h1, ← h2, e2]
  ring

omit hχ in
/-- The diagonal solutions of `x ^ 3 + y ^ 3 = 1` are the cube roots of `1 / 2`. -/
theorem card_diag (h2 : (2 : ZMod p) ≠ 0) :
    #{q ∈ ({q : ZMod p × ZMod p | q.1 ^ 3 + q.2 ^ 3 = 1} : Finset (ZMod p × ZMod p)) |
      q.1 = q.2} = cubeCount (2⁻¹ : ZMod p) := by
  symm
  unfold cubeCount
  apply Finset.card_bij (fun x _ => (x, x))
  · intro x hx
    have hx' : x ^ 3 = 2⁻¹ := (Finset.mem_filter.mp hx).2
    refine Finset.mem_filter.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, rfl⟩
    show x ^ 3 + x ^ 3 = 1
    rw [hx', ← two_mul, mul_inv_cancel₀ h2]
  · intro a _ b _ h
    exact congrArg Prod.fst h
  · intro q hq
    obtain ⟨hq1, hq2⟩ := Finset.mem_filter.mp hq
    have hq1' : q.1 ^ 3 + q.2 ^ 3 = 1 := (Finset.mem_filter.mp hq1).2
    rw [← hq2] at hq1'
    refine ⟨q.1, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, Prod.ext rfl hq2⟩
    exact eq_inv_of_mul_eq_one_right (by rw [two_mul]; exact hq1')

/-- `2` is a cube modulo `p` iff `L` is even, where `#{x ^ 3 + y ^ 3 = 1} = p - 2 + L`. -/
theorem two_cube_iff_even (L : ℤ)
    (hcount : ((#{q : ZMod p × ZMod p | q.1 ^ 3 + q.2 ^ 3 = 1} : ℕ) : ℤ) = p - 2 + L) :
    (∃ z : ZMod p, z ^ 3 = 2) ↔ Even L := by
  have hpr : p.Prime := Fact.out
  have h2 : (2 : ZMod p) ≠ 0 := by
    intro h
    have h' : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast h
    rw [ZMod.natCast_eq_zero_iff] at h'
    have h3 : p ≤ 2 := Nat.le_of_dvd (by norm_num) h'
    have h4 : p = 2 := le_antisymm h3 hpr.two_le
    -- a character of order 3 needs `3 ∣ p - 1`
    have h5 := MulChar.orderOf_dvd_card_sub_one (ZMod p) χ
    rw [hχ, ZMod.card, h4] at h5
    omega
  have hodd : p % 2 = 1 := by
    rcases hpr.eq_two_or_odd with h | h
    · exfalso
      apply h2
      have : ((2 : ℕ) : ZMod p) = 0 := by rw [← h]; exact ZMod.natCast_self p
      exact_mod_cast this
    · exact h
  have hsym : ∀ q, q ∈ ({q : ZMod p × ZMod p | q.1 ^ 3 + q.2 ^ 3 = 1} :
      Finset (ZMod p × ZMod p)) ↔ q.swap ∈ ({q : ZMod p × ZMod p | q.1 ^ 3 + q.2 ^ 3 = 1} :
      Finset (ZMod p × ZMod p)) := by
    intro q
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Prod.fst_swap, Prod.snd_swap]
    rw [add_comm]
  have hpar := card_swap_parity _ hsym
  rw [card_diag h2] at hpar
  have hcube : (∃ z : ZMod p, z ^ 3 = 2) ↔ χ (2⁻¹) = 1 := by
    constructor
    · rintro ⟨z, hz⟩
      have h' : ∃ u : ZMod p, u ^ 3 = 2⁻¹ := ⟨z⁻¹, by rw [inv_pow, hz]⟩
      exact ((isCube_iff hχ _).mp h').resolve_left (inv_ne_zero h2)
    · intro h
      obtain ⟨u, hu⟩ := (isCube_iff hχ _).mpr (Or.inr h)
      exact ⟨u⁻¹, by rw [inv_pow, hu, inv_inv]⟩
  rw [hcube, Int.even_iff]
  have hguess := cubeCount_eq_guess hχ (2⁻¹ : ZMod p)
  unfold cubeGuess at hguess
  rw [if_neg (inv_ne_zero h2)] at hguess
  by_cases hc : χ (2⁻¹) = 1
  · rw [if_pos hc] at hguess
    rw [hguess] at hpar
    rw [hpar] at hcount
    push_cast at hcount
    exact iff_of_true hc (by omega)
  · rw [if_neg hc] at hguess
    rw [hguess] at hpar
    rw [hpar] at hcount
    push_cast at hcount
    exact iff_of_false hc (by omega)

/-! ### The cubic Gauss sum -/

/-- `G ^ 3 = 3 p G + p T` for `G = ∑ x, ψ (a x ^ 3)` with the standard additive character. -/
theorem cubic_gauss_core (L : ℂ) (htr : jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = L) (a : ZMod p)
    (ha : a ≠ 0) :
    (∑ x : ZMod p, ZMod.stdAddChar (a * x ^ 3)) ^ 3 =
      3 * (p : ℂ) * (∑ x : ZMod p, ZMod.stdAddChar (a * x ^ 3)) + (p : ℂ) * L := by
  have hψ : (ZMod.stdAddChar (N := p)).IsPrimitive := ZMod.isPrimitive_stdAddChar p
  set ψ : AddChar (ZMod p) ℂ := ZMod.stdAddChar with hψdef
  have s0 : ∑ c : ZMod p, ψ (a * c) = 0 := by
    have h := AddChar.sum_mulShift (ψ := ψ) a hψ
    rw [if_neg ha] at h
    calc ∑ c : ZMod p, ψ (a * c) = ∑ c : ZMod p, ψ (c * a) :=
          Finset.sum_congr rfl (fun c _ => by rw [mul_comm])
      _ = 0 := by rw [h, Nat.cast_zero]
  have s1 : ∑ c : ZMod p, χ c * ψ (a * c) = χ⁻¹ a * gaussSum χ ψ := by
    have h := gaussSum_mulShift_eq χ ψ (Units.mk0 a ha)
    rw [Units.val_mk0] at h
    rw [← h]
    simp only [gaussSum, AddChar.mulShift_apply]
  have s2 : ∑ c : ZMod p, χ⁻¹ c * ψ (a * c) = χ a * gaussSum χ⁻¹ ψ := by
    have h := gaussSum_mulShift_eq χ⁻¹ ψ (Units.mk0 a ha)
    rw [inv_inv, Units.val_mk0] at h
    rw [← h]
    simp only [gaussSum, AddChar.mulShift_apply]
  have hsum : ∑ x : ZMod p, ψ (a * x ^ 3) = χ⁻¹ a * gaussSum χ ψ + χ a * gaussSum χ⁻¹ ψ := by
    refine (sum_over_cubes hχ (fun t => ψ (a * t))).trans ?_
    have e : ∀ c : ZMod p, (1 + χ c + χ⁻¹ c) * ψ (a * c) =
        ψ (a * c) + χ c * ψ (a * c) + χ⁻¹ c * ψ (a * c) := fun c => by ring
    rw [Finset.sum_congr rfl (fun c _ => e c), Finset.sum_add_distrib, Finset.sum_add_distrib,
      s0, s1, s2, zero_add]
  have g1 : gaussSum χ ψ ^ 3 = (p : ℂ) * jacobiSum χ χ := by
    have h := gaussSum_pow_eq_prod_jacobiSum (χ := χ) (ψ := ψ) (by omega) hψ
    rw [hχ, o3_apply_neg_one hχ, ZMod.card, show Finset.Ico 1 (3 - 1) = {1} by decide,
      Finset.prod_singleton, pow_one, one_mul] at h
    exact h
  have g2 : gaussSum χ⁻¹ ψ ^ 3 = (p : ℂ) * jacobiSum χ⁻¹ χ⁻¹ := by
    have h := gaussSum_pow_eq_prod_jacobiSum (χ := χ⁻¹) (ψ := ψ)
      (by rw [o3_orderOf_inv hχ]; omega) hψ
    rw [o3_orderOf_inv hχ, o3_apply_neg_one (o3_orderOf_inv hχ), ZMod.card,
      show Finset.Ico 1 (3 - 1) = {1} by decide, Finset.prod_singleton, pow_one, one_mul] at h
    exact h
  have g12 : gaussSum χ ψ * gaussSum χ⁻¹ ψ = (p : ℂ) := by
    have h := gaussSum_mul_gaussSum_pow_orderOf_sub_one (o3_ne_one hχ) hψ
    rw [hχ, show 3 - 1 = 2 from rfl, ← o3_inv_eq_sq hχ, o3_apply_neg_one hχ, one_mul,
      ZMod.card] at h
    exact h
  have hu3 : χ a ^ 3 = 1 := o3_apply_pow_three hχ ha
  rw [hsum, o3_inv_apply hχ a]
  linear_combination
    ((χ a ^ 3 + 1) * gaussSum χ ψ ^ 3 + gaussSum χ⁻¹ ψ ^ 3 +
      3 * gaussSum χ ψ * gaussSum χ⁻¹ ψ *
        (χ a ^ 2 * gaussSum χ ψ + χ a * gaussSum χ⁻¹ ψ)) * hu3 +
    g1 + g2 + 3 * (χ a ^ 2 * gaussSum χ ψ + χ a * gaussSum χ⁻¹ ψ) * g12 + (p : ℂ) * htr

end TuringTask
