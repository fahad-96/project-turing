import TuringTask.Basic

#print axioms TuringTask.fib_eq_sq
#print axioms TuringTask.lucas_eq_sq
#print axioms TuringTask.fib_eq_two_mul_sq
#print axioms TuringTask.lucas_eq_two_mul_sq
#print axioms TuringTask.fib_eq_two_pow
