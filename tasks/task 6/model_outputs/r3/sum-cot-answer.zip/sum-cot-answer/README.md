# Cotangent sums

This project contains kernel-checked proofs of two standard candidates for a
theorem named `sum_cot`:

* `Research.sum_cot`: the unweighted cancellation
  `sum k in Ico 1 n, cot (pi*k/n) = 0` for `0 < n`.
* `Research.sum_cot_sin`: the finite Fourier identity
  `sum k in Ico 1 n, sin (2*pi*m*k/n) * cot (pi*k/n) = n - 2*m`
  for `0 < m < n`.

`Fourier.lean` proves the needed root-of-unity cosine sum from
`geom_sum_mul` and `Complex.exp_eq_one_iff`. `CotPointwise.lean` proves the
Dirichlet-kernel identity by induction. `CotMain.lean` combines them and also
contains the direct involution proof of the unweighted sum.

The supplied prompt did not include a separate exact Lean declaration, so both
precise forms are exposed. No theorem statement is replaced by an axiom or
admitted proof.

## Offline build

This archive intentionally depends on the supplied local Mathlib at
`/opt/mathlib4`; it is not self-contained on an arbitrary machine.

```text
lean-offline-init
lake build
```

No network access is needed or permitted.
