# Project Turing - Task 16 golden answer

Lean 4 project with complete proofs of the classification of square, twice-square and
power-of-two Fibonacci and Lucas numbers: `F(n)` is a square only for `n = 0, 1, 2, 12`,
`L(n)` (`n >= 1`) only for `n = 1, 3`; `F(n)` is twice a square only for `n = 0, 3, 6`,
`L(n)` only for `n = 6`; `F(n)` is a power of 2 only for `n = 1, 2, 3, 6`. The required file is
`TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The four source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Lucas.lean`: Lucas numbers with integer index and the shift congruences
  `F(m + 2 k t) = -F(m)`, `L(m + 2 k t) = -L(m)` modulo `L(k)` (`k` even, `t` odd)
- `TuringTask/Residues.lean`: residues of `F` and `L` modulo 2, 3, 4 and 8,
  `gcd(F(m), L(m)) | 2`, the prime factor `= 3 (mod 4)` of `L(k)`, and the splitting
  `N = 2 k t` with `t` a power of 3
- `TuringTask/Equations.lean`: the five classifications (Lucas statements first)
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof
