# Project Turing - compact memory (read this first, then TURING_HANDOFF_2026-10-06.md)

Last updated: 9 Oct 2026, about 17:50 IST (task 10 submitted; handover to a new Claude account).

NEW ACCOUNT (9 Oct): read `TURING_PLAYBOOK.md` first (complete method and templates). The tracker is now
the file `TURING_TRACKER_EXPORT.md` (the artifact below belongs to the old account).

OLD TRACKER (old account only): the artifact "Turing Task Tracker"
(https://claude.ai/artifact/J1dRbUWM7fSRbdhS73YVhM). Its rows (all tasks on both laptops), reviews and
rules are exported to `TURING_TRACKER_EXPORT.md`. Reserve the next free task number in the export
before creating files and update the row after every step. Task 7 exists on both laptops; the Honor
laptop's task 7 is listed as 7.5.

## The job
Handshake AI, Project Turing: Lean 4 proof-writing tasks. Per task: prompt -> platform runs 3 models
-> at least one genuine failure -> own golden zip + step-by-step explanation -> rubric CSV
(5-20 binary items, weight +1). Targets: golden >= 90 percent, at least 1 of 3 outputs < 40 percent.
Pinned: Lean `leanprover/lean4:v4.33.0-rc1`, Mathlib `9944fe2973b8dc0b86949101ed98232c07cd54a0`.

## The fellow's standing rules
- Do things yourself; keep his manual steps minimal, but ask for a manual step when it saves a
  long wait (for example starting `lean_worker.bat`).
- No long silent waits. Say what is running; hand over each file as soon as it is usable.
- Everything for a submission field is pure ASCII.
- Prompts short, neutral names, no hints about the proof method.
- Be brief; say plainly what is verified and what is not. Aim at 5/5 from the reviewer.
- Never promise a model failure or a reviewer score.
- The golden is written only after a failure is confirmed and never copies a model output.

## Reviewer rules (task 5 feedback, 8 Oct) - apply to every golden and rubric
1. Golden zip: `lakefile.toml` requires mathlib with `path = "/opt/mathlib4"`; `lake-manifest.json`
   in model-output format (copy a model output's manifest, change only "name").
2. Extract the FINAL zip into a fresh folder and run `lake build` and
   `lake env lean StatementAndAxiomsCheck.lean` offline (script `verify_golden_offline_t6.bat`:
   change ZIP and LOG paths; junction `C:\opt\mathlib4` already exists).
3. Rubric: one +1 build item (pinned versions, build includes `TuringTask/Basic.lean`).
4. Definition items and proof items are separate; each says what it does NOT judge.
5. Rerun grading for golden and all evaluated responses after any rubric change.
6. Arithmetic: 1 build + k definitions + 5 theorems. A sorry-only output scores (1+k)/(6+k).
   With k = 0: proving one theorem gives 33 percent; with k = 1 it gives 43 percent (too high).
   Prefer prompts without definitions, or one definition at most.
Rubric CSV: header `"ID","Criterion","Weight"`, all fields quoted, LF, no trailing newline.

## Machines
- Laptop "fahad" (Honor): folder `D:\HandShake\project turing\Project Turing`; Lean in
  `D:\lean\TuringTask` since 8 Oct 22:40 (moved from C:, which was full; `finish_move.bat` links
  C:\lean\TuringTask, C:\opt\mathlib4 and D:\opt\mathlib4 to it). Fresh-copy check of a golden zip:
  `verify_golden_offline.bat <task number>` (works on D:, uses D:\opt\mathlib4).
  Worker `lean_worker.bat` watches `D:\lean\TuringTask\_jobs\<job>\`
  (src\TuringTask\*.lean, optional src\TuringTask.lean, check.lean, READY written LAST in a separate
  commit; result log.txt + DONE). Warm build about 25 s per file, cold first build 500-730 s.
  NEVER build several Mathlib-importing files in parallel here (memory error, stale check output):
  one import chain, or one job per file with a stub TuringTask.lean.
- The PC shell (device_bash) does not start on this laptop: use stage/commit only.
- Warm worker: about 25 s per Mathlib-importing file, so golden iteration through worker jobs is
  2-3 min per round. If a build fails, the check part of the log shows STALE results.
- Before writing a golden, scan for shared lines with the model outputs (decl names, long lines)
  and never build on an earlier draft that shares names or lines with a model output.
- Drive C: was nearly full on 8 Oct (that broke jobs 009, 009b, 010); keep Lean data on D:.
- Cloud workspace (per chat, lost later): pinned Lean in /home/claude/lean, partial Mathlib build in
  /home/claude/work/mathlib, benchmark clones in /home/claude/work/bench. pip is blocked.

## Generators
One self-checking Python generator per task (`tasks\task N\turing_tN_generator.py`) writes the
prompt, `TuringTask\Basic.lean`, `StatementAndAxiomsCheck.lean`, `check_outputs.bat`, asserts ASCII
and Lean lines <= 100 chars. Use `_explicit_args` (top-level binders only) in check_source; the old
regex picked up `(p : Int)` inside binder types (task 7 bug, fixed).

## Novelty hazards (check every topic)
Mathlib at the pinned commit; PutnamBench, miniF2F, ProofNet, compfiles, formal-conjectures;
`TauCetiProject/TauCeti` (11,600 AI-written files, grows daily); `tomdif/RamanujanLean` (q-series,
sums of two and four squares - this whole family is off limits); `AxiomMath/RogersRamanujan`;
`riccardobrasca/KummerCriterion` (Kummer congruences, Voronoi, quadratic Gauss sum sign, h^-, L-values -
Bernoulli congruences are off limits); `leanprover-community/flt-regular`.
Mathlib already has: von Staudt-Clausen, Jacobi sums with `J = -1 + z (mu - 1)^2`,
degrees of irreducible factors of cyclotomic polynomials mod p, Burnside, Dirichlet's theorem.

## What fails the models
Elementary or glue work (tasks 1-3: determinants, Farey) was solved by all three models.
Failures came when every theorem needs one missing classical core (task 4 Jacobi identity: 2 of 3
failed; task 6 sign of the quadratic Gauss sum: 1 failed, 1 passed with 2,868 lines).
Choose a single hard core that all five statements need; avoid statements a model can prove
independently of the core.
Task 11 (local lemma + 5 applications) was solved by all three models (836-1,217 lines): a
self-contained probabilistic/counting core is not hard enough.
Task 10 (Zsigmondy) is the best result: two genuine failures, third rollout died. Its core mixes
cyclotomic algebra, p-adic valuations, real estimates and exceptional cases.

## Task status (8 Oct 2026, 18:00 IST)
- 1, 2, 3: rejected (no failure).
- 4: submitted (golden 100, responses 29/29).
- 5: returned by reviewer (minor issue), the fellow is fixing it.
- 6: golden and 8-item rubric fixed to the reviewer rules, offline fresh-copy check passed; waiting
  for the fellow's platform rerun verdicts; response 2 not received.
- 7 (cubic character sum mod p, Jacobsthal): prompt compiled officially (jobs 006 and 006b, check
  file exit 0); outputs pending. Golden plan in handoff section 21.
- 8 (equidistribution, Weyl) and 9 (cubes mod p, Gauss/Jacobi): prompts compiled officially (jobs
  007 and 008), handed over 8 Oct about 18:30 IST; outputs pending. Plans in handoff section 22.
- 9 (cubes mod p): 9 Oct - R3 genuine failure (all five theorems absent), R1 and R2 pass. Golden
  (5 files, 899 lines) built officially (job 012g) and passed the fresh-copy offline check;
  6-item rubric; expected golden 100, R3 17 percent. Ready for the platform. Handoff section 25.
- 11 (local lemma): 9 Oct - all three models passed (official jobs 013a-c), REJECTED, no golden.
  Handoff section 26.
- 10 (Zsigmondy): 9 Oct - R1 FAIL (sorry, job 014a), R2 rollout failed, R3 FAIL (theorems absent,
  job 014b). Golden (7 files, 1,017 lines) built by job 016c, no warnings; 6-item rubric; expected
  golden 100, R1 and R3 17 percent. SUBMITTED 9 Oct about 17:40 IST WITHOUT the fresh-copy offline
  check (run `verify_golden_offline.bat 10` if the review asks). Handoff section 27.
- Next free task number: 12. Handoff section 28 = handover to the new account.
- 10 (primitive prime divisors, Zsigmondy) and 11 (local lemma applications: hypergraph colouring,
  k-SAT, Ramsey and van der Waerden lower bounds): prompts made 8 Oct about 19:00 IST, worker jobs
  009 and 010. Plans in handoff section 23.
- Task 6 novelty note: KummerCriterion proves the quadratic Gauss sum sign for primes (overlaps
  theorem 3 only); add a disclosure sentence if not yet submitted.
