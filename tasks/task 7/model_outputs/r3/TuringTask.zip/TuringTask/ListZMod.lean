import Mathlib

open Lean Elab Command

elab "list_decls " needle:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if (toString name).contains needle.getString then logInfo name

list_decls "ringChar_zmod"
list_decls "ZMod.ringChar"
list_decls "natCast_zmod_val"
list_decls "equivFin"
list_decls "finEquiv"
list_decls "ZMod.card"
