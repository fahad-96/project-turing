import TuringTask.Apps

/-!
# Auxiliary facts for the bounded-degree colouring theorem
-/

namespace TuringTask

open Finset

/-- `e < 2.7182818286`. -/
lemma exp_one_lt : Real.exp 1 < 2.7182818286 := Real.exp_one_lt_d9

/-- The numeric inequality `e * (k*(k-1) + 1) ≤ 2 ^ (k-1)` for `k ≥ 9`, in shifted form. -/
lemma exp_bound_shift : ∀ j : ℕ,
    Real.exp 1 * ((((j + 9) * (j + 8) : ℕ) : ℝ) + 1) ≤ 2 ^ (j + 8) := by
  intro j
  induction j with
  | zero =>
      have h : ((((0 + 9) * (0 + 8) : ℕ) : ℝ) + 1) = 73 := by norm_num
      rw [h]
      have : (2:ℝ) ^ (0 + 8) = 256 := by norm_num
      rw [this]
      nlinarith [exp_one_lt]
  | succ j ih =>
      have hcast : ((((j + 1 + 9) * (j + 1 + 8) : ℕ) : ℝ) + 1)
          ≤ 2 * ((((j + 9) * (j + 8) : ℕ) : ℝ) + 1) := by
        push_cast
        nlinarith [Nat.cast_nonneg (α := ℝ) j]
      have he : (0:ℝ) < Real.exp 1 := Real.exp_pos 1
      have h2 : Real.exp 1 * ((((j + 1 + 9) * (j + 1 + 8) : ℕ) : ℝ) + 1)
          ≤ 2 * (Real.exp 1 * ((((j + 9) * (j + 8) : ℕ) : ℝ) + 1)) := by
        nlinarith [hcast, he]
      have h3 : (2:ℝ) ^ (j + 1 + 8) = 2 * 2 ^ (j + 8) := by ring
      rw [h3]
      linarith [h2, ih]

/-- The numeric inequality in the form needed. -/
lemma exp_bound (k : ℕ) (hk : 9 ≤ k) :
    Real.exp 1 * (((k * (k - 1) : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1) := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 9 := ⟨k - 9, by omega⟩
  have h1 : (j + 9) * (j + 9 - 1) = (j + 9) * (j + 8) := by congr 1
  have h2 : j + 9 - 1 = j + 8 := by omega
  rw [h1, h2]
  exact exp_bound_shift j

section DegBound

variable {n m : ℕ}

/-- If every vertex has degree at most `k` and `|D i| ≤ k`,
then `i` meets at most `k * (k - 1)` other edges. -/
lemma nbr_card_le (I : Fin m → Fin n → Bool) (k : ℕ)
    (hk : ∀ i, (supp I i).card = k)
    (hdeg : ∀ v, (univ.filter (fun i => I i v = true)).card ≤ k) (i : Fin m) :
    (nbr (supp I) i).card ≤ k * (k - 1) := by
  classical
  set B : Finset (Fin m) :=
    (supp I i).biUnion (fun v => (univ.filter (fun j => I j v = true)).erase i) with hB
  have hsub : nbr (supp I) i ⊆ B := by
    intro j hj
    simp only [nbr, Finset.mem_filter, Finset.mem_univ, true_and, ne_eq] at hj
    obtain ⟨hne, v, hv⟩ := hj
    rw [Finset.mem_inter] at hv
    rw [hB, Finset.mem_biUnion]
    exact ⟨v, hv.1, Finset.mem_erase.2 ⟨hne, Finset.mem_filter.2
      ⟨Finset.mem_univ _, mem_supp.1 hv.2⟩⟩⟩
  refine le_trans (Finset.card_le_card hsub) ?_
  refine le_trans (Finset.card_biUnion_le) ?_
  have hterm : ∀ v ∈ supp I i,
      ((univ.filter (fun j => I j v = true)).erase i).card ≤ k - 1 := by
    intro v hv
    have hmem : i ∈ univ.filter (fun j => I j v = true) :=
      Finset.mem_filter.2 ⟨Finset.mem_univ _, mem_supp.1 hv⟩
    rw [Finset.card_erase_of_mem hmem]
    exact Nat.sub_le_sub_right (hdeg v) 1
  refine le_trans (Finset.sum_le_sum hterm) ?_
  rw [Finset.sum_const, smul_eq_mul, hk i]

end DegBound

end TuringTask
