import Mathlib
open Finset

namespace TuringTask

noncomputable def csum (p : Nat) [Fact p.Prime] (c : Int) : Int :=
  Finset.sum (Finset.range p) (fun x : Nat => legendreSym p ((x : Int) ^ 3 - c * (x : Int)))

variable {p : ℕ} [Fact p.Prime]

local notation "χ" => quadraticChar (ZMod p)

theorem rc (hp : p % 4 = 1) : ringChar (ZMod p) ≠ 2 := by
  rw [ZMod.ringChar_zmod_n]
  intro h; rw [h] at hp; norm_num at hp

theorem Lsum (hp : p % 4 = 1) (d : ZMod p) :
    ∑ u : ZMod p, χ (u * (u + d)) = if d = 0 then (p : ℤ) - 1 else -1 := by
  haveI := Fact.out (p := p.Prime)
  split_ifs with hd
  · subst hd
    have h1 : ∀ x : ZMod p, χ (x * (x + 0)) = (if x = 0 then 0 else 1 : ℤ) := by
      intro x
      by_cases hx : x = 0
      · simp [hx]
      · rw [add_zero, ← sq, quadraticChar_sq_one' hx, if_neg hx]
    rw [Finset.sum_congr rfl (fun x _ => h1 x)]
    rw [Finset.sum_ite, Finset.sum_const, Finset.sum_const]
    rw [smul_zero, zero_add, nsmul_eq_mul, mul_one]
    rw [Finset.filter_ne' univ (0 : ZMod p), Finset.card_erase_of_mem (Finset.mem_univ _)]
    rw [Finset.card_univ, ZMod.card]
    have h5 : 1 ≤ p := this.pos
    push_cast [Nat.cast_sub h5]
    ring
  · -- d ≠ 0
    have key : ∀ u ∈ (univ.erase (0 : ZMod p)), χ (u * (u + d)) = χ (1 + d * u⁻¹) := by
      intro u hu
      have hu0 : u ≠ 0 := (Finset.mem_erase.1 hu).1
      have h2 : u * (u + d) = u^2 * (1 + d * u⁻¹) := by field_simp
      rw [h2, map_mul, quadraticChar_sq_one' hu0, one_mul]
    have hzero : χ ((0:ZMod p) * (0 + d)) = 0 := by simp
    rw [← Finset.sum_erase univ (f := fun u : ZMod p => χ (u * (u + d))) hzero]
    rw [Finset.sum_congr rfl key]
    have hbij : ∑ u ∈ univ.erase (0 : ZMod p), χ (1 + d * u⁻¹)
        = ∑ v ∈ univ.erase (1 : ZMod p), χ v := by
      apply Finset.sum_nbij' (i := fun u : ZMod p => 1 + d * u⁻¹)
        (j := fun v : ZMod p => d * (v - 1)⁻¹)
      · intro u hu
        have hu0 : u ≠ 0 := (Finset.mem_erase.1 hu).1
        simp only [Finset.mem_erase, Finset.mem_univ, and_true]
        intro h
        have h3 : d * u⁻¹ = 0 := by linear_combination h
        rcases mul_eq_zero.1 h3 with h' | h'
        · exact hd h'
        · exact hu0 (inv_eq_zero.1 h')
      · intro v hv
        have hv1 : v ≠ 1 := (Finset.mem_erase.1 hv).1
        simp only [Finset.mem_erase, Finset.mem_univ, and_true]
        intro h
        rcases mul_eq_zero.1 h with h' | h'
        · exact hd h'
        · exact hv1 (by have h4 := inv_eq_zero.1 h'; exact sub_eq_zero.1 h4)
      · intro u hu
        have hu0 : u ≠ 0 := (Finset.mem_erase.1 hu).1
        show d * (1 + d * u⁻¹ - 1)⁻¹ = u
        rw [add_sub_cancel_left, mul_inv, inv_inv]
        field_simp
      · intro v hv
        have hv1 : v ≠ 1 := (Finset.mem_erase.1 hv).1
        have hv0 : v - 1 ≠ 0 := sub_ne_zero.2 hv1
        show 1 + d * (d * (v - 1)⁻¹)⁻¹ = v
        rw [mul_inv, inv_inv, ← mul_assoc, mul_inv_cancel₀ hd, one_mul]
        ring
      · intros; rfl
    rw [hbij]
    have hs := quadraticChar_sum_zero (F := ZMod p) (rc hp)
    have h1 : χ (1 : ZMod p) = 1 := by simp
    rw [← Finset.sum_erase_add univ _ (Finset.mem_univ (1 : ZMod p)), h1] at hs
    linarith

theorem chi_neg_one (hp : p % 4 = 1) : χ (-1 : ZMod p) = 1 := by
  haveI := Fact.out (p := p.Prime)
  rw [quadraticChar_neg_one (rc hp), ZMod.card, ZMod.χ₄_nat_eq_if_mod_four]
  have h2 : p % 2 = 1 := by omega
  simp [h2, hp]

noncomputable def Sz (q : ℕ) [Fact q.Prime] (c : ZMod q) : ℤ :=
  ∑ x : ZMod q, quadraticChar (ZMod q) (x ^ 3 - c * x)

theorem Sz_scale (hp : p % 4 = 1) (c s : ZMod p) (hs : s ≠ 0) :
    Sz p (c * s ^ 2) = χ s * Sz p c := by
  haveI := Fact.out (p := p.Prime)
  unfold Sz
  rw [Finset.mul_sum]
  symm
  apply Fintype.sum_bijective (fun u => s * u) (mulLeft_bijective₀ s hs)
  intro u
  have h : (s * u) ^ 3 - c * s^2 * (s * u) = s^2 * (s * (u^3 - c*u)) := by ring
  rw [h, map_mul, quadraticChar_sq_one' hs, one_mul, map_mul]

-- inner sum over c
theorem inner_c (hp : p % 4 = 1) (x y : ZMod p) :
    ∑ c : ZMod p, χ ((x ^ 3 - c * x) * (y ^ 3 - c * y))
      = χ (x * y) * (if y ^ 2 - x ^ 2 = 0 then (p : ℤ) - 1 else -1) := by
  haveI := Fact.out (p := p.Prime)
  by_cases hx : x = 0
  · subst hx; simp
  by_cases hy : y = 0
  · subst hy; simp
  rw [← Lsum hp (y ^ 2 - x ^ 2)]
  rw [Finset.mul_sum]
  symm
  -- bijection u = x^2 - c
  apply Fintype.sum_bijective (fun c : ZMod p => x ^ 2 - c)
  · exact ⟨fun a b h => by linear_combination -h, fun u => ⟨x ^ 2 - u, by ring⟩⟩
  intro c
  have h : (x ^ 3 - (x ^ 2 - c) * x) * (y ^ 3 - (x ^ 2 - c) * y)
      = (x * y) * (c * (c + (y ^ 2 - x ^ 2))) := by ring
  rw [h]
  simp only [map_mul]

theorem ne_neg_self (hp : p % 4 = 1) (x : ZMod p) (hx : x ≠ 0) : x ≠ -x := by
  haveI := Fact.out (p := p.Prime)
  intro h
  have h2 : (2 : ZMod p) * x = 0 := by linear_combination h
  rcases mul_eq_zero.1 h2 with h' | h'
  · have : ((2:ℕ) : ZMod p) = 0 := by push_cast; exact h'
    rw [ZMod.natCast_eq_zero_iff] at this
    have := (Nat.prime_dvd_prime_iff_eq (Fact.out (p := p.Prime)) Nat.prime_two).1 this
    omega
  · exact hx h'

theorem filter_sq_eq (hp : p % 4 = 1) (x : ZMod p) (hx : x ≠ 0) :
    (univ.filter (fun y : ZMod p => y ^ 2 - x ^ 2 = 0)) = {x, -x} := by
  haveI := Fact.out (p := p.Prime)
  ext y
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert,
    Finset.mem_singleton]
  constructor
  · intro h
    have : (y - x) * (y + x) = 0 := by linear_combination h
    rcases mul_eq_zero.1 this with h' | h'
    · left; linear_combination h'
    · right; linear_combination h'
  · rintro (rfl | rfl) <;> ring

theorem inner_x (hp : p % 4 = 1) (x : ZMod p) :
    ∑ y : ZMod p, χ (x * y) * (if y ^ 2 - x ^ 2 = 0 then (p:ℤ) else 0)
      = if x = 0 then 0 else 2 * (p : ℤ) := by
  haveI := Fact.out (p := p.Prime)
  by_cases hx : x = 0
  · subst hx; simp
  rw [if_neg hx]
  have step : ∀ y : ZMod p, χ (x*y) * (if y ^ 2 - x ^ 2 = 0 then (p:ℤ) else 0)
      = if y ^ 2 - x ^ 2 = 0 then χ (x*y) * (p:ℤ) else 0 := by
    intro y; rw [mul_ite, mul_zero]
  rw [Finset.sum_congr rfl (fun y _ => step y), Finset.sum_ite, Finset.sum_const_zero, add_zero]
  rw [filter_sq_eq hp x hx]
  rw [Finset.sum_pair (ne_neg_self hp x hx)]
  have h1 : χ (x * x) = 1 := by rw [← sq]; exact quadraticChar_sq_one' hx
  have h2 : χ (x * -x) = 1 := by
    rw [show x * -x = (-1) * x^2 by ring, map_mul, quadraticChar_sq_one' hx, mul_one,
      chi_neg_one hp]
  rw [h1, h2]; ring

theorem total_sum (hp : p % 4 = 1) :
    ∑ c : ZMod p, Sz p c ^ 2 = 2 * (p : ℤ) * ((p : ℤ) - 1) := by
  haveI := Fact.out (p := p.Prime)
  have expand : ∀ c : ZMod p, Sz p c ^ 2
      = ∑ x : ZMod p, ∑ y : ZMod p, χ ((x ^ 3 - c * x) * (y ^ 3 - c * y)) := by
    intro c
    unfold Sz
    rw [sq, Finset.sum_mul_sum]
    exact Finset.sum_congr rfl (fun x _ => Finset.sum_congr rfl (fun y _ => (map_mul _ _ _).symm))
  calc ∑ c : ZMod p, Sz p c ^ 2
      = ∑ c : ZMod p, ∑ x : ZMod p, ∑ y : ZMod p, χ ((x ^ 3 - c * x) * (y ^ 3 - c * y)) :=
        Finset.sum_congr rfl (fun c _ => expand c)
    _ = ∑ x : ZMod p, ∑ y : ZMod p, ∑ c : ZMod p, χ ((x ^ 3 - c * x) * (y ^ 3 - c * y)) := by
        rw [Finset.sum_comm]
        exact Finset.sum_congr rfl (fun x _ => Finset.sum_comm)
    _ = ∑ x : ZMod p, ∑ y : ZMod p,
          χ (x * y) * (if y ^ 2 - x ^ 2 = 0 then (p : ℤ) - 1 else -1) :=
        Finset.sum_congr rfl (fun x _ => Finset.sum_congr rfl (fun y _ => inner_c hp x y))
    _ = ∑ x : ZMod p, ∑ y : ZMod p,
          (χ (x * y) * (if y ^ 2 - x ^ 2 = 0 then (p : ℤ) else 0) + χ (x*y) * (-1)) := by
        refine Finset.sum_congr rfl (fun x _ => Finset.sum_congr rfl (fun y _ => ?_))
        by_cases h : y ^ 2 - x ^ 2 = 0
        · simp [h]; ring
        · simp [h]
    _ = 2 * (p : ℤ) * ((p : ℤ) - 1) := by
        rw [Finset.sum_congr rfl (fun x _ => Finset.sum_add_distrib)]
        rw [Finset.sum_add_distrib]
        have hA : ∑ x : ZMod p, ∑ y : ZMod p,
            χ (x * y) * (if y ^ 2 - x ^ 2 = 0 then (p:ℤ) else 0)
            = 2 * (p:ℤ) * ((p:ℤ) - 1) := by
          rw [Finset.sum_congr rfl (fun x _ => inner_x hp x)]
          rw [Finset.sum_ite, Finset.sum_const_zero, zero_add, Finset.sum_const]
          rw [Finset.filter_ne' univ (0 : ZMod p), Finset.card_erase_of_mem (Finset.mem_univ _)]
          rw [Finset.card_univ, ZMod.card, nsmul_eq_mul]
          have h5 : 1 ≤ p := this.pos
          push_cast [Nat.cast_sub h5]
          ring
        have hB : ∑ x : ZMod p, ∑ y : ZMod p, χ (x*y) * (-1 : ℤ) = 0 := by
          have : ∀ x : ZMod p, ∑ y : ZMod p, χ (x*y) * (-1 : ℤ)
              = (-1 : ℤ) * ∑ y : ZMod p, χ (x*y) := by
            intro x; rw [Finset.mul_sum]
            exact Finset.sum_congr rfl (fun y _ => by ring)
          rw [Finset.sum_congr rfl (fun x _ => this x)]
          have hz : ∀ x : ZMod p, ∑ y : ZMod p, χ (x*y) = 0 := by
            intro x
            by_cases hx : x = 0
            · subst hx; simp
            · rw [← quadraticChar_sum_zero (F := ZMod p) (rc hp)]
              exact Fintype.sum_bijective (fun y => x * y) (mulLeft_bijective₀ x hx) _ _
                (fun _ => rfl)
          rw [Finset.sum_congr rfl (fun x _ => by rw [hz x, mul_zero])]
          simp
        rw [hA, hB, add_zero]

-- Sz c ^ 2 depends only on χ c, for c ≠ 0
theorem Sz_sq_eq (hp : p % 4 = 1) (c d : ZMod p) (hc : c ≠ 0) (hd : d ≠ 0)
    (h : χ c = χ d) : Sz p c ^ 2 = Sz p d ^ 2 := by
  haveI := Fact.out (p := p.Prime)
  -- c = d * s^2 for some s ≠ 0  since χ (c/d) = 1
  have hcd : χ (c * d⁻¹) = 1 := by
    rw [map_mul]
    have hdi : χ (d⁻¹) = χ d := by
      have : d⁻¹ = d * (d⁻¹)^2 := by field_simp
      rw [this, map_mul, quadraticChar_sq_one' (inv_ne_zero hd), mul_one]
    rw [hdi, h]
    rw [← sq]; exact quadraticChar_sq_one hd
  have hne : c * d⁻¹ ≠ 0 := mul_ne_zero hc (inv_ne_zero hd)
  obtain ⟨s, hs⟩ := (quadraticChar_one_iff_isSquare hne).1 hcd
  have hs0 : s ≠ 0 := by
    intro h0; rw [h0, mul_zero] at hs; exact hne hs
  have hcs : c = d * s ^ 2 := by
    have : c * d⁻¹ * d = s * s * d := by rw [hs]
    field_simp at this
    rw [sq]
    linear_combination this
  rw [hcs, Sz_scale hp d s hs0, mul_pow, quadraticChar_sq_one hs0, one_mul]

-- counts of residues / nonresidues
theorem card_res (hp : p % 4 = 1) :
    ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d = 1)).card : ℤ) * 1
      + ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d ≠ 1)).card : ℤ) * (-1) = 0 := by
  haveI := Fact.out (p := p.Prime)
  have hs := quadraticChar_sum_zero (F := ZMod p) (rc hp)
  have : ∑ d : ZMod p, χ d
      = ∑ d ∈ univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d = 1), (1:ℤ)
      + ∑ d ∈ univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d ≠ 1), (-1:ℤ) := by
    rw [← Finset.sum_filter_add_sum_filter_not univ (fun d : ZMod p => d = 0)]
    rw [Finset.filter_eq' univ (0 : ZMod p)]
    simp only [Finset.mem_univ, if_true, Finset.sum_singleton, quadraticChar_zero, zero_add]
    rw [← Finset.sum_filter_add_sum_filter_not (univ.filter (fun d : ZMod p => ¬ d = 0))
        (fun d => χ d = 1)]
    congr 1
    · rw [Finset.filter_filter]
      exact Finset.sum_congr rfl (fun d hd => (Finset.mem_filter.1 hd).2.2)
    · rw [Finset.filter_filter]
      refine Finset.sum_congr rfl (fun d hd => ?_)
      obtain ⟨hd0, hd1⟩ := (Finset.mem_filter.1 hd).2
      rcases quadraticChar_dichotomy hd0 with h | h
      · exact absurd h hd1
      · exact h
  rw [this] at hs
  simpa using hs

theorem thm1_core (hp : p % 4 = 1) (c r : ZMod p) (hc : χ c = 1) (hr : χ r = -1) :
    Sz p c ^ 2 + Sz p r ^ 2 = 4 * (p : ℤ) := by
  haveI := Fact.out (p := p.Prime)
  have hc0 : c ≠ 0 := by intro h; rw [h, quadraticChar_zero] at hc; norm_num at hc
  have hr0 : r ≠ 0 := by intro h; rw [h, quadraticChar_zero] at hr; norm_num at hr
  -- split the sum over c by value of χ
  have key : ∀ d : ZMod p, Sz p d ^ 2
      = (if d = 0 then (0:ℤ) else if χ d = 1 then Sz p c ^ 2 else Sz p r ^ 2) := by
    intro d
    by_cases hd : d = 0
    · subst hd
      rw [if_pos rfl]
      -- Sz p 0 = sum χ (x^3) = sum χ x  = 0
      have : Sz p 0 = 0 := by
        unfold Sz
        simp only [zero_mul, sub_zero]
        rw [← quadraticChar_sum_zero (F := ZMod p) (rc hp)]
        apply Finset.sum_congr rfl
        intro x _
        by_cases hx : x = 0
        · simp [hx]
        · rw [show x^3 = x * x^2 by ring, map_mul, quadraticChar_sq_one' hx, mul_one]
      rw [this]; ring
    · rw [if_neg hd]
      rcases quadraticChar_dichotomy hd with h | h
      · rw [if_pos h]; exact Sz_sq_eq hp d c hd hc0 (by rw [h, hc])
      · rw [if_neg (by rw [h]; norm_num)]; exact Sz_sq_eq hp d r hd hr0 (by rw [h, hr])
  have hts := total_sum hp
  rw [Finset.sum_congr rfl (fun d _ => key d)] at hts
  -- split the sum
  have hsplit : ∑ d : ZMod p, (if d = 0 then (0:ℤ) else if χ d = 1 then Sz p c ^ 2 else Sz p r ^ 2)
      = ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d = 1)).card : ℤ) * Sz p c ^ 2
      + ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d ≠ 1)).card : ℤ) * Sz p r ^ 2 := by
    rw [← Finset.sum_filter_add_sum_filter_not univ (fun d : ZMod p => d = 0)]
    rw [Finset.filter_eq' univ (0 : ZMod p)]
    simp only [Finset.mem_univ, if_true, Finset.sum_singleton, if_pos rfl, zero_add]
    rw [← Finset.sum_filter_add_sum_filter_not (univ.filter (fun d : ZMod p => ¬ d = 0))
        (fun d => χ d = 1)]
    rw [Finset.filter_filter, Finset.filter_filter]
    congr 1
    · rw [Finset.sum_congr rfl (fun d hd => by
        obtain ⟨h0, h1⟩ := (Finset.mem_filter.1 hd).2
        rw [if_neg h0, if_pos h1])]
      rw [Finset.sum_const, nsmul_eq_mul]
    · rw [Finset.sum_congr rfl (fun d hd => by
        obtain ⟨h0, h1⟩ := (Finset.mem_filter.1 hd).2
        rw [if_neg h0, if_neg h1])]
      rw [Finset.sum_const, nsmul_eq_mul]
  rw [hsplit] at hts
  -- cardinalities are equal
  have hcard := card_res hp
  set A := ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d = 1)).card : ℤ) with hA
  set B := ((univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d ≠ 1)).card : ℤ) with hB
  have hAB : A = B := by linarith
  -- A + B = p - 1
  have hsum : A + B = (p : ℤ) - 1 := by
    have : (univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d = 1)).card
        + (univ.filter (fun d : ZMod p => d ≠ 0 ∧ χ d ≠ 1)).card
        = (univ.filter (fun d : ZMod p => d ≠ 0)).card := by
      rw [← Finset.filter_filter, ← Finset.filter_filter]
      exact Finset.card_filter_add_card_filter_not _
    have h2 : (univ.filter (fun d : ZMod p => d ≠ 0)).card = p - 1 := by
      rw [Finset.filter_ne' univ (0 : ZMod p), Finset.card_erase_of_mem (Finset.mem_univ _),
        Finset.card_univ, ZMod.card]
    rw [hA, hB, ← Nat.cast_add, this, h2]
    have h5 : 1 ≤ p := Fact.out (p := p.Prime) |>.pos
    push_cast [Nat.cast_sub h5]
    ring
  have h2A : 2 * A = (p:ℤ) - 1 := by linarith
  -- A * (Sc^2 + Sr^2) = 2p(p-1) = 4p * A
  have : A * (Sz p c ^ 2 + Sz p r ^ 2) = A * (4 * (p:ℤ)) := by
    rw [mul_add]
    nlinarith [hts, hAB, h2A]
  have hAne : A ≠ 0 := by
    intro h0
    rw [h0] at h2A
    have : (p:ℤ) = 1 := by linarith
    have := Fact.out (p := p.Prime)
    exact absurd (by exact_mod_cast ‹(p:ℤ) = 1›) this.one_lt.ne'
  exact mul_left_cancel₀ hAne this

section Thm3
variable (hp : p % 4 = 1)

-- the "bad" set
noncomputable def M (p : ℕ) [Fact p.Prime] : Finset (ZMod p) :=
  univ.filter (fun x => quadraticChar (ZMod p) (x ^ 3 - x) = -1)

-- Z: the zero set {0, 1, -1}
theorem zeroset (hp : p % 4 = 1) :
    (univ.filter (fun x : ZMod p => x ^ 3 - x = 0)) = {0, 1, -1} := by
  haveI := Fact.out (p := p.Prime)
  ext x
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert,
    Finset.mem_singleton]
  constructor
  · intro h
    have : x * ((x - 1) * (x + 1)) = 0 := by linear_combination h
    rcases mul_eq_zero.1 this with h' | h'
    · exact Or.inl h'
    · rcases mul_eq_zero.1 h' with h'' | h''
      · exact Or.inr (Or.inl (by linear_combination h''))
      · exact Or.inr (Or.inr (by linear_combination h''))
  · rintro (rfl | rfl | rfl) <;> ring

theorem card_zeroset (hp : p % 4 = 1) (hp5 : 5 ≤ p) :
    (univ.filter (fun x : ZMod p => x ^ 3 - x = 0)).card = 3 := by
  haveI := Fact.out (p := p.Prime)
  rw [zeroset hp]
  have h1 : (1 : ZMod p) ≠ -1 := by
    intro h
    have : (2 : ZMod p) = 0 := by linear_combination h
    have h2 : ((2:ℕ) : ZMod p) = 0 := by push_cast; exact this
    rw [ZMod.natCast_eq_zero_iff] at h2
    have := Nat.le_of_dvd (by norm_num) h2
    omega
  have h0a : (0 : ZMod p) ≠ 1 := by
    intro h; exact one_ne_zero h.symm
  have h0b : (0 : ZMod p) ≠ -1 := by
    intro h
    exact h0a (by linear_combination -h)
  rw [Finset.card_insert_of_notMem (by simp [h0a, h0b]),
    Finset.card_insert_of_notMem (by simp [h1]), Finset.card_singleton]

theorem Sz_one_eq (hp : p % 4 = 1) (hp5 : 5 ≤ p) :
    Sz p 1 = ((p : ℤ) - 3) - 2 * (M p).card := by
  haveI := Fact.out (p := p.Prime)
  unfold Sz M
  simp only [one_mul]
  -- split univ into zeros, M, and the rest
  have hval : ∀ x : ZMod p, χ (x^3 - x)
      = (if x^3 - x = 0 then (0:ℤ) else if χ (x^3 - x) = -1 then -1 else 1) := by
    intro x
    by_cases h0 : x^3 - x = 0
    · rw [if_pos h0, h0, quadraticChar_zero]
    · rw [if_neg h0]
      by_cases h1 : χ (x^3 - x) = -1
      · rw [if_pos h1, h1]
      · rw [if_neg h1]
        rcases quadraticChar_dichotomy (show x^3 - x ≠ 0 from h0) with h | h
        · exact h
        · exact absurd h h1
  rw [Finset.sum_congr rfl (fun x _ => hval x)]
  rw [← Finset.sum_filter_add_sum_filter_not univ (fun x : ZMod p => x^3 - x = 0)]
  have hz : ∑ x ∈ univ.filter (fun x : ZMod p => x^3 - x = 0),
      (if x^3 - x = 0 then (0:ℤ) else if χ (x^3 - x) = -1 then -1 else 1) = 0 := by
    apply Finset.sum_eq_zero
    intro x hx
    rw [if_pos (Finset.mem_filter.1 hx).2]
  rw [hz, zero_add]
  -- now split the nonzero part by membership in M
  rw [← Finset.sum_filter_add_sum_filter_not
      (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0))) (fun x => χ (x^3 - x) = -1)]
  rw [Finset.filter_filter, Finset.filter_filter]
  have e1 : ∑ x ∈ univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ χ (x^3-x) = -1),
      (if x^3 - x = 0 then (0:ℤ) else if χ (x^3 - x) = -1 then -1 else 1)
      = -((univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ χ (x^3-x) = -1)).card : ℤ) := by
    rw [Finset.sum_congr rfl (fun x hx => by
      obtain ⟨h0, h1⟩ := (Finset.mem_filter.1 hx).2
      rw [if_neg h0, if_pos h1])]
    rw [Finset.sum_const, nsmul_eq_mul, mul_neg_one]
  have e2 : ∑ x ∈ univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ ¬ (χ (x^3-x) = -1)),
      (if x^3 - x = 0 then (0:ℤ) else if χ (x^3 - x) = -1 then -1 else 1)
      = ((univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ ¬ (χ (x^3-x) = -1))).card : ℤ) := by
    rw [Finset.sum_congr rfl (fun x hx => by
      obtain ⟨h0, h1⟩ := (Finset.mem_filter.1 hx).2
      rw [if_neg h0, if_neg h1])]
    rw [Finset.sum_const, nsmul_eq_mul, mul_one]
  rw [e1, e2]
  -- M = filter (nonzero ∧ χ = -1):  χ = -1 already implies nonzero
  have hM : (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ χ (x^3-x) = -1))
      = univ.filter (fun x : ZMod p => χ (x^3 - x) = -1) := by
    apply Finset.filter_congr
    intro x _
    constructor
    · exact fun h => h.2
    · intro h
      refine ⟨fun h0 => ?_, h⟩
      rw [h0, quadraticChar_zero] at h; norm_num at h
  rw [hM]
  -- cardinality bookkeeping
  have hcards : (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ χ (x^3-x) = -1)).card
      + (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ ¬ (χ (x^3-x) = -1))).card
      = (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0))).card := by
    rw [← Finset.filter_filter, ← Finset.filter_filter]
    exact Finset.card_filter_add_card_filter_not _
  have hnz : (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0))).card = p - 3 := by
    have := Finset.card_filter_add_card_filter_not (s := (univ : Finset (ZMod p)))
      (p := fun x : ZMod p => x^3 - x = 0)
    rw [card_zeroset hp hp5, Finset.card_univ, ZMod.card] at this
    omega
  rw [hM] at hcards
  have h3p : 3 ≤ p := by omega
  rw [hnz] at hcards
  have hcast : ((univ.filter (fun x : ZMod p => χ (x^3 - x) = -1)).card : ℤ)
      + ((univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ ¬ (χ (x^3-x) = -1))).card : ℤ)
      = (p : ℤ) - 3 := by
    have : (((univ.filter (fun x : ZMod p => χ (x^3 - x) = -1)).card
        + (univ.filter (fun x : ZMod p => ¬ (x^3 - x = 0) ∧ ¬ (χ (x^3-x) = -1))).card : ℕ) : ℤ)
        = ((p - 3 : ℕ) : ℤ) := by rw [hcards]
    push_cast [Nat.cast_sub h3p] at this
    linarith
  linarith

theorem two_ne_zero' (hp : p % 4 = 1) : (2 : ZMod p) ≠ 0 := by
  haveI := Fact.out (p := p.Prime)
  intro h
  have h2 : ((2:ℕ) : ZMod p) = 0 := by push_cast; exact h
  rw [ZMod.natCast_eq_zero_iff] at h2
  have := Nat.le_of_dvd (by norm_num) h2
  have h4 := (Nat.prime_dvd_prime_iff_eq (Fact.out (p := p.Prime)) Nat.prime_two).1 h2
  omega

-- membership facts about M
theorem mem_M_ne_zero (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) : x ≠ 0 := by
  haveI := Fact.out (p := p.Prime)
  unfold M at hx
  intro h
  rw [Finset.mem_filter] at hx
  rw [h] at hx
  simp at hx

theorem mem_M_ne_sq_neg_one (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) : x ^ 2 ≠ -1 := by
  haveI := Fact.out (p := p.Prime)
  intro h
  unfold M at hx
  rw [Finset.mem_filter] at hx
  have hx0 : x ≠ 0 := by
    intro h0; rw [h0] at h; norm_num at h
  -- x^3 - x = x(x^2-1) = x(-1-1) = -2x ; and (1+x)^2 = 1+2x+x^2 = 2x
  have key : x ^ 3 - x = (-1) * (1 + x)^2 := by linear_combination (x + 1) * h
  have h1x : (1 : ZMod p) + x ≠ 0 := by
    intro h0
    have : x = -1 := by linear_combination h0
    rw [this] at h
    exact two_ne_zero' hp (by linear_combination h)
  rw [key, map_mul, quadraticChar_sq_one' h1x, mul_one, chi_neg_one hp] at hx
  norm_num at hx

theorem mem_M_sq_ne_one (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) : x ^ 2 ≠ 1 := by
  haveI := Fact.out (p := p.Prime)
  intro h
  unfold M at hx
  rw [Finset.mem_filter] at hx
  have : x ^ 3 - x = 0 := by linear_combination x * h
  rw [this, quadraticChar_zero] at hx
  have := hx.2
  norm_num at this

theorem M_closed_neg (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) : -x ∈ M p := by
  haveI := Fact.out (p := p.Prime)
  unfold M at hx ⊢
  rw [Finset.mem_filter] at hx ⊢
  refine ⟨Finset.mem_univ _, ?_⟩
  have : (-x) ^ 3 - (-x) = (-1) * (x ^ 3 - x) := by ring
  rw [this, map_mul, chi_neg_one hp, one_mul]
  exact hx.2

theorem M_closed_inv (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) : x⁻¹ ∈ M p := by
  haveI := Fact.out (p := p.Prime)
  have hx0 : x ≠ 0 := mem_M_ne_zero hp hx
  unfold M at hx ⊢
  rw [Finset.mem_filter] at hx ⊢
  refine ⟨Finset.mem_univ _, ?_⟩
  have hi : x⁻¹ ≠ 0 := inv_ne_zero hx0
  have key : (x⁻¹) ^ 3 - x⁻¹ = (-1) * (x⁻¹ ^ 2) ^ 2 * (x ^ 3 - x) := by
    field_simp
    ring
  rw [key, map_mul, map_mul, chi_neg_one hp, one_mul,
    quadraticChar_sq_one' (pow_ne_zero 2 hi), one_mul]
  exact hx.2

-- the four elements x, -x, x⁻¹, -x⁻¹ are distinct for x ∈ M
theorem four_distinct (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) :
    ({x, -x, x⁻¹, -x⁻¹} : Finset (ZMod p)).card = 4 := by
  haveI := Fact.out (p := p.Prime)
  have hx0 : x ≠ 0 := mem_M_ne_zero hp hx
  have hsq1 : x ^ 2 ≠ 1 := mem_M_sq_ne_one hp hx
  have hsqm1 : x ^ 2 ≠ -1 := mem_M_ne_sq_neg_one hp hx
  have h2 : (2 : ZMod p) ≠ 0 := two_ne_zero' hp
  have hxi : x ≠ x⁻¹ := by
    intro h
    apply hsq1
    field_simp at h
    linear_combination h
  have hxni : x ≠ -x⁻¹ := by
    intro h
    apply hsqm1
    field_simp at h
    linear_combination h
  have hxnx : x ≠ -x := ne_neg_self hp x hx0
  have hi0 : x⁻¹ ≠ 0 := inv_ne_zero hx0
  have hini : x⁻¹ ≠ -x⁻¹ := ne_neg_self hp x⁻¹ hi0
  have hnxi : -x ≠ x⁻¹ := by
    intro h; exact hxni (by linear_combination -h)
  have hnxni : -x ≠ -x⁻¹ := by
    intro h; exact hxi (by linear_combination -h)
  rw [Finset.card_insert_of_notMem (by simp [hxnx, hxi, hxni]),
    Finset.card_insert_of_notMem (by simp [hnxi, hnxni]),
    Finset.card_insert_of_notMem (by simp [hini]), Finset.card_singleton]

-- the orbit map
noncomputable def gmap (p : ℕ) [Fact p.Prime] (x : ZMod p) : ZMod p := (x - x⁻¹) ^ 2

theorem fiber_eq (hp : p % 4 = 1) {x : ZMod p} (hx : x ∈ M p) :
    (M p).filter (fun y => gmap p y = gmap p x) = {x, -x, x⁻¹, -x⁻¹} := by
  haveI := Fact.out (p := p.Prime)
  have hx0 : x ≠ 0 := mem_M_ne_zero hp hx
  ext y
  simp only [Finset.mem_filter, Finset.mem_insert, Finset.mem_singleton]
  constructor
  · rintro ⟨hyM, hg⟩
    have hy0 : y ≠ 0 := mem_M_ne_zero hp hyM
    unfold gmap at hg
    -- (y - 1/y)^2 = (x - 1/x)^2  =>  (y-1/y - (x-1/x))(y-1/y + (x-1/x)) = 0
    have hfac : ((y - y⁻¹) - (x - x⁻¹)) * ((y - y⁻¹) + (x - x⁻¹)) = 0 := by
      linear_combination hg
    rcases mul_eq_zero.1 hfac with h | h
    · -- y - 1/y = x - 1/x  =>  (y-x)(1 + 1/(xy)) = 0 => y = x or y = -1/x
      have h2 : (y - x) * (x * y + 1) = 0 := by
        field_simp at h
        linear_combination h
      rcases mul_eq_zero.1 h2 with h' | h'
      · exact Or.inl (by linear_combination h')
      · refine Or.inr (Or.inr (Or.inr ?_))
        field_simp
        linear_combination h'
    · -- y - 1/y = -(x - 1/x) => (y+x)(xy - 1) = 0 => y = -x or y = 1/x
      have h2 : (y + x) * (x * y - 1) = 0 := by
        field_simp at h
        linear_combination h
      rcases mul_eq_zero.1 h2 with h' | h'
      · exact Or.inr (Or.inl (by linear_combination h'))
      · refine Or.inr (Or.inr (Or.inl ?_))
        field_simp
        linear_combination h'
  · intro h
    have hi0 : x⁻¹ ≠ 0 := inv_ne_zero hx0
    rcases h with rfl | rfl | rfl | rfl
    · exact ⟨hx, rfl⟩
    · refine ⟨M_closed_neg hp hx, ?_⟩
      unfold gmap
      rw [inv_neg]
      ring
    · refine ⟨M_closed_inv hp hx, ?_⟩
      unfold gmap
      rw [inv_inv]
      ring
    · refine ⟨M_closed_neg hp (M_closed_inv hp hx), ?_⟩
      unfold gmap
      rw [inv_neg, inv_inv]
      ring

theorem four_dvd_M (hp : p % 4 = 1) : 4 ∣ (M p).card := by
  haveI := Fact.out (p := p.Prime)
  classical
  rw [Finset.card_eq_sum_card_fiberwise (f := gmap p) (t := (M p).image (gmap p))
    (fun x hx => Finset.mem_image_of_mem _ hx)]
  apply Finset.dvd_sum
  intro b hb
  obtain ⟨x, hxM, rfl⟩ := Finset.mem_image.1 hb
  rw [fiber_eq hp hxM, four_distinct hp hxM]

theorem Sz_one_mod_eight (hp : p % 4 = 1) (hp5 : 5 ≤ p) :
    Sz p 1 % 8 = if p % 8 = 5 then 2 else 6 := by
  haveI := Fact.out (p := p.Prime)
  obtain ⟨t, ht⟩ := four_dvd_M hp
  rw [Sz_one_eq hp hp5, ht]
  push_cast
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  obtain ⟨q, hq⟩ : ∃ q, p = 8 * q + p % 8 := ⟨p / 8, by omega⟩
  rcases hp8 with h8 | h8
  · rw [if_neg (by omega)]
    rw [hq, h8]
    push_cast
    omega
  · rw [if_pos h8]
    rw [hq, h8]
    push_cast
    omega

theorem p_ge_five (hp : p % 4 = 1) : 5 ≤ p := by
  haveI := Fact.out (p := p.Prime)
  have h2 := this.two_le
  rcases Nat.lt_or_ge p 5 with h | h
  · interval_cases p <;> simp_all (config := {decide := true})
  · exact h

end Thm3

section TwoSquares

theorem sq_mod_two (x : ℤ) : x ^ 2 % 2 = x % 2 := by
  have h : x % 2 = 0 ∨ x % 2 = 1 := by omega
  obtain ⟨t, ht⟩ : ∃ t, x = 2 * t + x % 2 := ⟨x / 2, by omega⟩
  rcases h with h | h <;> rw [ht, h] <;> ring_nf <;> omega

theorem two_sq_uniq (q : ℕ) (hq : q.Prime) (a b u v : ℤ)
    (h1 : a ^ 2 + b ^ 2 = (q : ℤ)) (h2 : u ^ 2 + v ^ 2 = (q : ℤ))
    (ha : a % 2 = 1) (hu : u % 2 = 1) : u ^ 2 = a ^ 2 := by
  have hqp : Prime ((q : ℤ)) := Nat.prime_iff_prime_int.mp hq
  -- key: (av - bu)(av + bu) = a^2 v^2 - b^2 u^2 = q(v^2 - b^2)
  have hkey : (a * v - b * u) * (a * v + b * u) = (q : ℤ) * (v ^ 2 - b ^ 2) := by
    have : a ^ 2 = (q:ℤ) - b ^ 2 := by linarith
    have hv : v ^ 2 = (q:ℤ) - u ^ 2 := by linarith
    nlinarith [h1, h2]
  -- q divides one of the factors
  have hdvd : (q : ℤ) ∣ (a * v - b * u) * (a * v + b * u) := ⟨_, hkey⟩
  rcases hqp.dvd_mul.1 hdvd with hd | hd
  · -- q ∣ av - bu ; then (au+bv)^2 + (av-bu)^2 = q^2
    obtain ⟨k, hk⟩ := hd
    have hid : (a * u + b * v) ^ 2 + (a * v - b * u) ^ 2 = (q:ℤ) * (q:ℤ) := by
      linear_combination (u ^ 2 + v ^ 2) * h1 + (q:ℤ) * h2
    rw [hk] at hid
    -- q ∣ au + bv
    have hdv2 : (q:ℤ) ∣ (a * u + b * v) ^ 2 := ⟨(q:ℤ) - (q:ℤ) * k ^ 2, by linear_combination hid⟩
    have hdv3 : (q:ℤ) ∣ (a * u + b * v) := hqp.dvd_of_dvd_pow hdv2
    obtain ⟨m, hm⟩ := hdv3
    rw [hm] at hid
    have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
    have hmk : m ^ 2 + k ^ 2 = 1 := by
      have : (q:ℤ) * (q:ℤ) * (m ^ 2 + k ^ 2) = (q:ℤ) * (q:ℤ) * 1 := by linear_combination hid
      exact mul_left_cancel₀ (mul_ne_zero hq0 hq0) this
    -- m^2 + k^2 = 1 : either (m,k) = (±1, 0) or (0, ±1)
    have hk2 : k ^ 2 = 0 ∨ k ^ 2 = 1 := by
      have hkn := sq_nonneg k
      have hmn := sq_nonneg m
      omega
    rcases hk2 with hk0 | hk1
    · -- k = 0 so a*v = b*u, and m^2 = 1 so (au+bv)^2 = q^2
      have hk00 : k = 0 := by nlinarith
      rw [hk00] at hk
      have hav : a * v = b * u := by linarith [hk]
      -- then q * u^2 = (a^2+b^2) u^2 = (au)^2 + (bu)^2 = (au)^2 + (av)^2 = a^2 q
      have : (q:ℤ) * u ^ 2 = a ^ 2 * (q:ℤ) := by
        have e1 : (a^2 + b^2) * u^2 = (a*u)^2 + (b*u)^2 := by ring
        have e2 : (b*u)^2 = (a*v)^2 := by rw [← hav]
        rw [h1] at e1
        have e3 : (a*u)^2 + (a*v)^2 = a^2 * (u^2 + v^2) := by ring
        rw [e2, e3, h2] at e1
        linarith
      have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
      have h6 : (q:ℤ) * (u ^ 2 - a ^ 2) = 0 := by linarith
      rcases mul_eq_zero.1 h6 with h | h
      · exact absurd h hq0
      · linarith
    · -- k^2 = 1 so m = 0, au + bv = 0, giving u^2 = b^2 - contradiction with parity
      have hm0 : m = 0 := by nlinarith
      rw [hm0, mul_zero] at hm
      have hau : a * u = -(b * v) := by linarith
      -- q * u^2 = (a^2+b^2)u^2 = (au)^2 + (bu)^2 = (bv)^2 + (bu)^2 = b^2 q
      have hqu : (q:ℤ) * u ^ 2 = b ^ 2 * (q:ℤ) := by
        have e1 : (a^2 + b^2) * u^2 = (a*u)^2 + (b*u)^2 := by ring
        have e2 : (a*u)^2 = (b*v)^2 := by rw [hau]; ring
        rw [h1] at e1
        have e3 : (b*v)^2 + (b*u)^2 = b^2 * (u^2 + v^2) := by ring
        rw [e2, e3, h2] at e1
        linarith
      have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
      have hub : u ^ 2 = b ^ 2 := by
        have : (q:ℤ) * (u^2 - b^2) = 0 := by linarith
        rcases mul_eq_zero.1 this with h | h
        · exact absurd h hq0
        · linarith
      -- parity: u odd => u^2 odd => b^2 odd => b odd; but a odd and a^2+b^2 = q
      have hbodd : b % 2 = 1 := by
        have h7 : (u ^ 2) % 2 = 1 := by rw [sq_mod_two]; exact hu
        rw [hub, sq_mod_two] at h7
        exact h7
      -- a odd, b odd => q = a^2 + b^2 ≡ 2 mod 4, so q = 2, but then u^2+v^2=2 and u odd...
      have h2q : (q:ℤ) % 2 = 0 := by
        rw [← h1]
        have e1 : a ^ 2 % 2 = 1 := by rw [sq_mod_two]; exact ha
        have e2 : b ^ 2 % 2 = 1 := by rw [sq_mod_two]; exact hbodd
        omega
      have : q % 2 = 0 := by omega
      have hq2 : q = 2 := ((Nat.Prime.eq_one_or_self_of_dvd hq 2 (by omega)).resolve_left (by norm_num)).symm
      -- q = 2: a^2 + b^2 = 2 with a,b odd is fine (1+1), u^2+v^2=2, u odd, so u^2=1=a^2
      subst hq2
      have hb2 : (1:ℤ) ≤ b ^ 2 := by
        rcases eq_or_ne b 0 with rfl | hbne
        · omega
        · exact (by positivity : (0:ℤ) < b ^ 2)
      have ha2' : (1:ℤ) ≤ a ^ 2 := by
        rcases eq_or_ne a 0 with rfl | hane
        · omega
        · exact (by positivity : (0:ℤ) < a ^ 2)
      have hq2v : ((2:ℕ):ℤ) = 2 := by norm_num
      rw [hq2v] at h1
      omega
  · -- q ∣ av + bu ; symmetric, use (au - bv)^2 + (av + bu)^2 = q^2
    obtain ⟨k, hk⟩ := hd
    have hid : (a * u - b * v) ^ 2 + (a * v + b * u) ^ 2 = (q:ℤ) * (q:ℤ) := by
      linear_combination (u ^ 2 + v ^ 2) * h1 + (q:ℤ) * h2
    rw [hk] at hid
    have hdv2 : (q:ℤ) ∣ (a * u - b * v) ^ 2 := ⟨(q:ℤ) - (q:ℤ) * k ^ 2, by linear_combination hid⟩
    have hdv3 : (q:ℤ) ∣ (a * u - b * v) := hqp.dvd_of_dvd_pow hdv2
    obtain ⟨m, hm⟩ := hdv3
    rw [hm] at hid
    have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
    have hmk : m ^ 2 + k ^ 2 = 1 := by
      have : (q:ℤ) * (q:ℤ) * (m ^ 2 + k ^ 2) = (q:ℤ) * (q:ℤ) * 1 := by linear_combination hid
      exact mul_left_cancel₀ (mul_ne_zero hq0 hq0) this
    have hk2 : k ^ 2 = 0 ∨ k ^ 2 = 1 := by
      have hkn := sq_nonneg k
      have hmn := sq_nonneg m
      omega
    rcases hk2 with hk0 | hk1
    · have hk00 : k = 0 := by nlinarith
      rw [hk00] at hk
      have hav : a * v = -(b * u) := by linarith [hk]
      have : (q:ℤ) * u ^ 2 = a ^ 2 * (q:ℤ) := by
        have e1 : (a^2 + b^2) * u^2 = (a*u)^2 + (b*u)^2 := by ring
        have e2 : (b*u)^2 = (a*v)^2 := by rw [hav]; ring
        rw [h1] at e1
        have e3 : (a*u)^2 + (a*v)^2 = a^2 * (u^2 + v^2) := by ring
        rw [e2, e3, h2] at e1
        linarith
      have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
      have : (q:ℤ) * (u^2 - a^2) = 0 := by linarith
      rcases mul_eq_zero.1 this with h | h
      · exact absurd h hq0
      · linarith
    · have hm0 : m = 0 := by nlinarith
      rw [hm0, mul_zero] at hm
      have hau : a * u = b * v := by linarith
      have hqu : (q:ℤ) * u ^ 2 = b ^ 2 * (q:ℤ) := by
        have e1 : (a^2 + b^2) * u^2 = (a*u)^2 + (b*u)^2 := by ring
        have e2 : (a*u)^2 = (b*v)^2 := by rw [hau]
        rw [h1] at e1
        have e3 : (b*v)^2 + (b*u)^2 = b^2 * (u^2 + v^2) := by ring
        rw [e2, e3, h2] at e1
        linarith
      have hq0 : (q:ℤ) ≠ 0 := by exact_mod_cast hq.ne_zero
      have hub : u ^ 2 = b ^ 2 := by
        have : (q:ℤ) * (u^2 - b^2) = 0 := by linarith
        rcases mul_eq_zero.1 this with h | h
        · exact absurd h hq0
        · linarith
      have hbodd : b % 2 = 1 := by
        have h7 : (u ^ 2) % 2 = 1 := by rw [sq_mod_two]; exact hu
        rw [hub, sq_mod_two] at h7
        exact h7
      have h2q : (q:ℤ) % 2 = 0 := by
        rw [← h1]
        have e1 : a ^ 2 % 2 = 1 := by rw [sq_mod_two]; exact ha
        have e2 : b ^ 2 % 2 = 1 := by rw [sq_mod_two]; exact hbodd
        omega
      have : q % 2 = 0 := by omega
      have hq2 : q = 2 := ((Nat.Prime.eq_one_or_self_of_dvd hq 2 (by omega)).resolve_left (by norm_num)).symm
      subst hq2
      have hb2 : (1:ℤ) ≤ b ^ 2 := by
        rcases eq_or_ne b 0 with rfl | hbne
        · omega
        · exact (by positivity : (0:ℤ) < b ^ 2)
      have ha2' : (1:ℤ) ≤ a ^ 2 := by
        rcases eq_or_ne a 0 with rfl | hane
        · omega
        · exact (by positivity : (0:ℤ) < a ^ 2)
      have hq2v : ((2:ℕ):ℤ) = 2 := by norm_num
      rw [hq2v] at h1
      omega

end TwoSquares

section Thm2

-- Sz p 1 = 2 * (odd number)
theorem Sz_one_half (hp : p % 4 = 1) : ∃ w : ℤ, Sz p 1 = 2 * w ∧ w % 2 = 1 := by
  haveI := Fact.out (p := p.Prime)
  have h8 := Sz_one_mod_eight hp (p_ge_five hp)
  refine ⟨Sz p 1 / 2, ?_, ?_⟩ <;> split_ifs at h8 <;> omega

theorem thm2_core (hp : p % 4 = 1) (a b : ℤ) (hab : a ^ 2 + b ^ 2 = (p:ℤ))
    (ha : a % 2 = 1) (c : ZMod p) (hc : χ c = 1) : Sz p c ^ 2 = 4 * a ^ 2 := by
  haveI := Fact.out (p := p.Prime)
  obtain ⟨r, hr⟩ := quadraticChar_exists_neg_one (F := ZMod p) (rc hp)
  have h1 := thm1_core hp c r hc hr
  -- Sz p c ^ 2 = Sz p 1 ^ 2
  have hc0 : c ≠ 0 := by intro h; rw [h, quadraticChar_zero] at hc; norm_num at hc
  have hone : (1 : ZMod p) ≠ 0 := one_ne_zero
  have hcs : Sz p c ^ 2 = Sz p 1 ^ 2 :=
    Sz_sq_eq hp c 1 hc0 hone (by rw [hc]; simp)
  obtain ⟨w, hw, hwodd⟩ := Sz_one_half hp
  -- Sz p r is even
  have hre : ∃ z : ℤ, Sz p r = 2 * z := by
    have : Sz p r ^ 2 = 4 * (p:ℤ) - Sz p c ^ 2 := by linarith
    rw [hcs, hw] at this
    have h4 : (4:ℤ) ∣ Sz p r ^ 2 := ⟨(p:ℤ) - w ^ 2, by linarith⟩
    have h2 : (2:ℤ) ∣ Sz p r := by
      rcases Int.even_or_odd (Sz p r) with ⟨t, ht⟩ | ⟨t, ht⟩
      · exact ⟨t, by omega⟩
      · exfalso
        rw [ht] at h4
        obtain ⟨s, hs⟩ := h4
        have : 4 * s = 4 * (t * t + t) + 1 := by linear_combination -hs
        omega
    obtain ⟨z, hz⟩ := h2
    exact ⟨z, hz⟩
  obtain ⟨z, hz⟩ := hre
  have hpz : w ^ 2 + z ^ 2 = (p:ℤ) := by
    rw [hcs, hw, hz] at h1
    linarith
  have := two_sq_uniq p (Fact.out) a b w z hab hpz ha hwodd
  rw [hcs, hw]
  linarith [this]

end Thm2

section Sign

theorem Sz_one_sign (hp : p % 4 = 1) (a b : ℤ) (hab : a ^ 2 + b ^ 2 = (p:ℤ))
    (ha : a % 4 = 1) : Sz p 1 = -2 * (-1) ^ (p / 4) * a := by
  haveI := Fact.out (p := p.Prime)
  have ha2 : a % 2 = 1 := by omega
  have hone : χ (1 : ZMod p) = 1 := by simp
  have hsq := thm2_core hp a b hab ha2 1 hone
  obtain ⟨w, hw, hwodd⟩ := Sz_one_half hp
  -- (2w)^2 = 4a^2 => w^2 = a^2 => w = ±a
  have hwa : w = a ∨ w = -a := by
    have : w ^ 2 = a ^ 2 := by rw [hw] at hsq; linarith
    exact sq_eq_sq_iff_eq_or_eq_neg.1 this
  have h8 := Sz_one_mod_eight hp (p_ge_five hp)
  -- k = p/4 parity linked to p mod 8
  by_cases hk : p % 8 = 5
  · -- k odd, (-1)^k = -1, want Sz 1 = 2a
    have hkodd : (p / 4) % 2 = 1 := by omega
    rw [Odd.neg_one_pow ⟨p / 4 / 2, by omega⟩]
    rw [if_pos hk] at h8
    rcases hwa with rfl | rfl
    · rw [hw]; ring
    · exfalso; rw [hw] at h8; omega
  · have hk1 : p % 8 = 1 := by omega
    have hkeven : (p / 4) % 2 = 0 := by omega
    rw [Even.neg_one_pow ⟨p / 4 / 2, by omega⟩]
    rw [if_neg hk] at h8
    rcases hwa with rfl | rfl
    · exfalso; rw [hw] at h8; omega
    · rw [hw]; ring

end Sign

section Curve

theorem card_sqrt_eq (hp : p % 4 = 1) (c : ZMod p) :
    ((univ.filter (fun y : ZMod p => y ^ 2 = c)).card : ℤ) = χ c + 1 := by
  haveI := Fact.out (p := p.Prime)
  have := quadraticChar_card_sqrts (F := ZMod p) (rc hp) c
  rw [← this]
  congr 2
  ext y
  simp [Set.mem_toFinset]

theorem curve_count (hp : p % 4 = 1) :
    ((univ.filter (fun q : (ZMod p) × (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card : ℤ)
      = (p : ℤ) + Sz p 1 := by
  haveI := Fact.out (p := p.Prime)
  rw [Finset.card_filter]
  push_cast
  rw [Fintype.sum_prod_type]
  have step : ∀ x : ZMod p, (∑ y : ZMod p, if y ^ 2 = x ^ 3 - x then (1:ℤ) else 0)
      = χ (x ^ 3 - x) + 1 := by
    intro x
    rw [← card_sqrt_eq hp (x ^ 3 - x), Finset.card_filter]
    push_cast
    rfl
  rw [Finset.sum_congr rfl (fun x _ => step x)]
  rw [Finset.sum_add_distrib]
  unfold Sz
  simp only [one_mul]
  rw [Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul, mul_one]
  ring

end Curve

section Thm4

theorem powsum (p : ℕ) [Fact p.Prime] (n : ℕ) (hn : n ≠ 0) :
    ∑ x : ZMod p, x ^ n = if (p - 1) ∣ n then -1 else 0 := by
  haveI := Fact.out (p := p.Prime)
  classical
  have hzero : ∑ x : ZMod p, x ^ n = ∑ x : (ZMod p)ˣ, ((x : ZMod p) ^ n) := by
    rw [← Finset.sum_subset (Finset.subset_univ (univ.erase (0 : ZMod p)))]
    · symm
      apply Finset.sum_nbij' (i := fun u : (ZMod p)ˣ => (u : ZMod p))
        (j := fun x : ZMod p => if h : x = 0 then 1 else Units.mk0 x h)
      · intro u _
        exact Finset.mem_erase.2 ⟨u.ne_zero, Finset.mem_univ _⟩
      · intros; exact Finset.mem_univ _
      · intro u _
        have : (u : ZMod p) ≠ 0 := u.ne_zero
        simp only [dif_neg this]
        ext; rfl
      · intro x hx
        have hx0 : x ≠ 0 := (Finset.mem_erase.1 hx).1
        simp only [dif_neg hx0]
        rfl
      · intros; rfl
    · intro x _ hx
      simp only [Finset.mem_erase, Finset.mem_univ, and_true, not_not] at hx
      rw [hx, zero_pow hn]
  rw [hzero]
  have := FiniteField.sum_pow_units (ZMod p) n
  rw [ZMod.card] at this
  exact this

-- main expansion
theorem Sz_pow_expand (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (hp5 : 5 ≤ p) :
    ∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2)
      = -((-1) ^ (p / 4) * (Nat.choose (p/2) (p/4) : ZMod p)) := by
  haveI := Fact.out (p := p.Prime)
  set m := p / 2 with hm
  set k := p / 4 with hk
  have hmk : m = 2 * k := by omega
  have hpm : p - 1 = 2 * m := by omega
  -- (x^3 - x)^m = x^m * (x^2-1)^m = sum_j C(m,j) (-1)^(m-j) x^(m+2j)
  have hexp : ∀ x : ZMod p, (x ^ 3 - x) ^ m
      = ∑ j ∈ range (m+1), (Nat.choose m j : ZMod p) * (-1) ^ (m - j) * x ^ (m + 2*j) := by
    intro x
    have h1 : (x ^ 3 - x) ^ m = x ^ m * (x^2 + (-1)) ^ m := by
      rw [← mul_pow]; ring_nf
    rw [h1, add_pow]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    have hjm : j ≤ m := Nat.lt_succ_iff.1 (Finset.mem_range.1 hj)
    rw [← pow_mul]
    ring_nf
  rw [Finset.sum_congr rfl (fun x _ => hexp x)]
  rw [Finset.sum_comm]
  -- inner sum over x
  have hinner : ∀ j ∈ range (m+1),
      (∑ x : ZMod p, (Nat.choose m j : ZMod p) * (-1) ^ (m - j) * x ^ (m + 2*j))
      = if j = k then -((-1) ^ k * (Nat.choose m k : ZMod p)) else 0 := by
    intro j hj
    have hjm : j ≤ m := Nat.lt_succ_iff.1 (Finset.mem_range.1 hj)
    rw [← Finset.mul_sum]
    have hne : m + 2*j ≠ 0 := by omega
    rw [powsum p (m + 2*j) hne]
    by_cases hjk : j = k
    · subst hjk
      rw [if_pos rfl, if_pos (show (p-1) ∣ (m + 2*k) by rw [hpm, hmk]; exact ⟨1, by omega⟩)]
      have hmj : m - k = k := by omega
      rw [hmj]
      ring
    · rw [if_neg hjk, if_neg ?_, mul_zero]
      intro hdvd
      have h1 : m + 2*j ≤ 3*m := by omega
      have h2 : 2*m ∣ m + 2*j := by rwa [hpm] at hdvd
      obtain ⟨t, ht⟩ := h2
      have hmpos : 0 < m := by omega
      have ht1 : t = 1 := by nlinarith [ht, hmpos, hjm]
      rw [ht1, mul_one] at ht
      omega
  rw [Finset.sum_congr rfl hinner]
  rw [Finset.sum_ite_eq' (range (m+1)) k (fun _ => -((-1) ^ k * (Nat.choose m k : ZMod p)))]
  rw [if_pos (Finset.mem_range.2 (by omega))]

theorem Sz_cast (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) :
    ((Sz p 1 : ℤ) : ZMod p) = ∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2) := by
  haveI := Fact.out (p := p.Prime)
  unfold Sz
  push_cast
  apply Finset.sum_congr rfl
  intro x _
  have h := quadraticChar_eq_pow_of_char_ne_two' (F := ZMod p) (rc hp) (x ^ 3 - 1 * x)
  rw [ZMod.card] at h
  rw [one_mul] at h ⊢
  exact h

theorem choose_core (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (a b : ℤ)
    (hab : a ^ 2 + b ^ 2 = (p:ℤ)) (ha : a % 4 = 1) :
    (((Nat.choose (p/2) (p/4) : ℕ) : ℤ) : ZMod p) = ((2 * a : ℤ) : ZMod p) := by
  haveI := Fact.out (p := p.Prime)
  have h5 := p_ge_five (p := p) hp
  have hsign := Sz_one_sign (p := p) hp a b hab ha
  have hc := Sz_cast p hp
  rw [Sz_pow_expand p hp h5] at hc
  rw [hsign] at hc
  push_cast at hc
  -- hc : -2 * (-1)^(p/4) * a = -((-1)^(p/4) * C)
  have hu : ((-1 : ZMod p)) ^ (p/4) * ((-1 : ZMod p)) ^ (p/4) = 1 := by
    rw [← pow_add]
    exact Even.neg_one_pow ⟨p/4, rfl⟩
  push_cast
  calc ((Nat.choose (p/2) (p/4) : ℕ) : ZMod p)
      = 1 * ((Nat.choose (p/2) (p/4) : ℕ) : ZMod p) := (one_mul _).symm
    _ = (((-1 : ZMod p)) ^ (p/4) * ((-1 : ZMod p)) ^ (p/4)) * ((Nat.choose (p/2) (p/4) : ℕ) : ZMod p) := by
        rw [hu]
    _ = ((-1 : ZMod p)) ^ (p/4) * (((-1 : ZMod p)) ^ (p/4) * ((Nat.choose (p/2) (p/4) : ℕ) : ZMod p)) := by
        ring
    _ = 2 * (a : ZMod p) := by
        rw [← neg_neg (((-1 : ZMod p)) ^ (p/4) * ((Nat.choose (p/2) (p/4) : ℕ) : ZMod p)), ← hc]
        ring_nf
        rw [mul_comm (p/4) 2, pow_mul, show ((-1 : ZMod p)) ^ 2 = 1 by ring, one_pow]
        ring

end Thm4

section Final

variable {p : ℕ} [Fact p.Prime]

-- bridge: csum equals Sz
theorem csum_eq_Sz (p : ℕ) [Fact p.Prime] (c : ℤ) : csum p c = Sz p (c : ZMod p) := by
  haveI := Fact.out (p := p.Prime)
  haveI : NeZero p := ⟨this.pos.ne'⟩
  unfold csum Sz
  symm
  apply Finset.sum_nbij' (i := fun t : ZMod p => t.val) (j := fun x : ℕ => ((x : ℕ) : ZMod p))
  · intro a _; exact Finset.mem_range.2 (ZMod.val_lt a)
  · intros; exact Finset.mem_univ _
  · intro a _; exact ZMod.natCast_rightInverse a
  · intro a ha; exact ZMod.val_natCast_of_lt (Finset.mem_range.1 ha)
  · intro t _
    unfold legendreSym
    congr 1
    push_cast [ZMod.natCast_val, ZMod.cast_id]
    ring

-- legendreSym p c = 1 means χ (c : ZMod p) = 1
theorem leg_to_chi (p : ℕ) [Fact p.Prime] (c : ℤ) :
    legendreSym p c = quadraticChar (ZMod p) (c : ZMod p) := rfl

theorem csum_sq_add_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (c r : Int)
    (hc : legendreSym p c = 1) (hr : legendreSym p r = -1) :
    csum p c ^ 2 + csum p r ^ 2 = 4 * (p : Int) := by
  rw [csum_eq_Sz, csum_eq_Sz]
  exact thm1_core hp _ _ hc hr

theorem csum_sq_of_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b c : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 2 = 1) (hc : legendreSym p c = 1) :
    csum p c ^ 2 = 4 * a ^ 2 := by
  rw [csum_eq_Sz]
  exact thm2_core hp a b hab ha _ hc

theorem csum_one_emod (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    csum p 1 % 8 = if p % 8 = 5 then 2 else 6 := by
  rw [csum_eq_Sz]
  push_cast
  exact Sz_one_mod_eight hp (p_ge_five hp)

theorem choose_modEq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    Int.ModEq (p : Int) ((Nat.choose (p / 2) (p / 4) : Nat) : Int) (2 * a) := by
  rw [← ZMod.intCast_eq_intCast_iff]
  exact choose_core p hp a b hab ha

theorem card_curve (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card : Int) =
      (p : Int) - 2 * (-1) ^ (p / 4) * a := by
  rw [curve_count hp, Sz_one_sign hp a b hab ha]
  ring

end Final

end TuringTask
