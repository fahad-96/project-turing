# TuringTask: Asymptotics of the Divisor Function in Lean 4

This Lean 4 project contains complete, sorry-free proofs of the five theorems on the divisor function $d(n)$ and its asymptotic behavior in `TuringTask/Basic.lean`:

1. `sum_card_divisors_sub_le`: Dirichlet divisor problem bound $\left| D(N) - N \log N - (2\gamma - 1) N \right| \le 4 \sqrt{N}$.
2. `sum_card_divisors_div_sub_le`: Bound on the logarithmic sum $\left| \sum_{n=1}^{N} \frac{d(n)}{n} - \frac{1}{2} (\log N)^2 - 2\gamma \log N \right| \le 4$.
3. `tendsto_sum_card_divisors`: Asymptotic limit $\frac{D(N) - N \log N}{N} \to 2\gamma - 1$.
4. `tendsto_sum_card_divisors_sub_log`: Asymptotic limit $\frac{1}{N} \sum_{n=1}^{N} (d(n) - \log n) \to 2\gamma$.
5. `tendsto_sum_sum_card_divisors`: Asymptotic limit $\frac{1}{N^2} \left( \sum_{n=1}^{N} D(n) - \frac{1}{2} N^2 \log N \right) \to \gamma - \frac{3}{4}$.

All proofs use only standard Lean 4 axioms (`propext`, `Classical.choice`, `Quot.sound`).

## Offline Build Instructions

Note: This project is configured for the supplied offline environment with pinned Lean toolchain `leanprover/lean4:v4.33.0-rc1` and local precompiled Mathlib at `/opt/mathlib4`. Links to `/opt` mean this archive relies on the supplied Lean/Mathlib environment and is not self-contained on arbitrary external machines without Mathlib.

To build offline using the supplied environment:
```bash
lean-offline-init
lake build
```

Or verify `TuringTask/Basic.lean` directly:
```bash
lean TuringTask/Basic.lean
```
