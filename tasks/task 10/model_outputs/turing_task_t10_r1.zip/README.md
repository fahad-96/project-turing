# TuringTask: Formalization of Zsigmondy's Theorem and Applications in Lean 4

This project provides a Lean 4 formalization of Zsigmondy's Theorem and four of its major arithmetic consequences in `TuringTask/Basic.lean`.

## Environment Requirements

This project is configured for offline build in the supplied environment:
- Lean toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib commit: `9944fe2973b8dc0b86949101ed98232c07cd54a0` located locally at `/opt/mathlib4`

Note: The supplied Lean and Mathlib environment (at `/opt/mathlib4`) is required to build this project; links to `/opt` do not make the archive self-contained on an arbitrary machine.

## Build Instructions (Offline)

From the project root directory:

```bash
# Initialize local offline dependencies (seeds .lake/packages from /opt/mathlib4)
lean-offline-init

# Build the library
lake build
```

The build completes successfully with no errors.

## Content Overview

The file `TuringTask/Basic.lean` contains:
1. `exists_prime_sub`: Zsigmondy's theorem for differences $a^n - b^n$. Proved using homogenized cyclotomic polynomials $\Phi_n(a, b)$, derivative vanishing for multiple roots, and order analysis.
2. `exists_prime_add`: Zsigmondy's theorem for sums $a^n + b^n$, completely proved by applying `exists_prime_sub` to $2n$.
3. `card_divisors_le`: $d(n) \le \omega(a^n - 1) + 2$, completely proved by constructing an injective map from non-exceptional divisors of $n$ to primitive prime factors of $a^d - 1 \mid a^n - 1$.
4. `eq_prime_pow`: Catalan's conjecture special case $a^n - 1 = q^m \implies (a, n, q, m) = (3, 2, 2, 3)$, completely proved using the primitive divisor properties.
5. `primeFactors_eq`: Equality of prime factors $\omega(a^m - 1) = \omega(a^n - 1)$ for $m < n \implies m = 1, n = 2, a + 1 = 2^t$, completely proved via primitive prime factors.
