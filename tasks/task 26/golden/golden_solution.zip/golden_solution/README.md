# Project Turing - Task 26 golden answer

Lean 4 project with complete proofs of five results on primes of the form `x^2 + n y^2` for
discriminants with one class in each genus: `p = x^2 + 5 y^2` exactly for `p = 5` and
`p = 1, 9 mod 20`, Euler's product theorem for primes `p, q = 3, 7 mod 20`,
`p = x^2 + 6 y^2` exactly for `p = 1, 7 mod 24`, `p = x^2 + 13 y^2` exactly for `p = 13` and
six classes mod 52, and `p = x^2 + 21 y^2` exactly for `p = 1, 25, 37 mod 84`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Forms.lean`: binary quadratic forms, the moves of Lagrange reduction, reduced
  forms, and the form of Lagrange's representation step.
- `TuringTask/Values.lean`: square roots of `-n` modulo `p` from the Jacobi symbol, and values
  of a form modulo `4 n`.
- `TuringTask/Classes.lean`: reduced forms and genus tables for `n = 5, 6, 13, 21`, and both
  directions of theorems 1, 3, 4, 5.
- `TuringTask/Main.lean`: Euler's product theorem and the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
