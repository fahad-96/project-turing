# TuringTask — Fibonacci and Lucas Diophantine equations in Lean 4

Complete, `sorry`-free formalisations of the five classical results of J. H. E. Cohn
(*On square Fibonacci numbers*, 1964) and its companions:

1. `fib_eq_sq` — if `F n` is a perfect square then `n ∈ {0, 1, 2, 12}`.
2. `lucas_eq_sq` — if `n ≥ 1` and `L n` is a perfect square then `n ∈ {1, 3}`.
3. `fib_eq_two_mul_sq` — if `F n = 2 x²` then `n ∈ {0, 3, 6}`.
4. `lucas_eq_two_mul_sq` — if `n ≥ 1` and `L n = 2 x²` then `n = 6`.
5. `fib_eq_two_pow` — if `F n` is a power of `2` then `n ∈ {1, 2, 3, 6}`.

Here `L n` is written in the task's form `Nat.fib (n - 1) + Nat.fib (n + 1)`.

## Layout

| file | contents |
| --- | --- |
| `TuringTask/Basic.lean` | the five required theorems, stated verbatim |
| `TuringTask/Lemmas.lean` | the supporting development (see below) |
| `TuringTask.lean` | library root |
| `Axioms.lean` | `#print axioms` for the five theorems |

`TuringTask/Basic.lean` proves the theorems in dependency order
(`lucas_eq_sq`, `lucas_eq_two_mul_sq`, `fib_eq_sq`, `fib_eq_two_mul_sq`, `fib_eq_two_pow`);
all five are present with the exact names and statements required.

## Proof outline

The development follows Cohn's method.

**Lucas numbers.** `luc` is defined by the usual recurrence and tied to `Nat.fib`
by `luc_succ_eq : luc (n+1) = fib n + fib (n+2)`, so the task's
`Nat.fib (n-1) + Nat.fib (n+1)` is `luc n` for `n ≥ 1` (`fib_pred_add_fib_succ`).

**Identities.** Cassini (`cassini`), `luc_sq : L n² = 5 F n² + 4(-1)ⁿ`,
the doubling rules `fib_two_mul'`, `luc_two_mul`, and the addition formulas
`fib_add_two_mul`, `luc_add_two_mul`:
`F(m + 2k) + (-1)^k F m = F(m+k) · L k`.

**Ladders.** For even `k`, iterating the addition formula gives
`fib_ladder`/`luc_ladder`: `F(m + 2ks) ≡ (-1)^s F m (mod L k)`.
Combined with the reflection formulas `fib_reflect'` (`F(2k-i) ≡ (-1)^i F i`)
and `luc_reflect'` (`L(2k-i) ≡ (-1)^(i+1) L i`), this yields the four master tools
`fib_toolA`, `luc_toolA`, `fib_toolB`, `luc_toolB`. Writing `n = c + 2·2^j·t`
with `t` odd (resp. `n + c = 2·2^j·t`), they compute `F n` and `L n` modulo
`N = L(2^j)`.

**Arithmetic of the moduli.** `luc_two_pow_mod_four` (`N ≡ 3 mod 4` for `j ≥ 1`),
`luc_two_pow_mod_eight` (`N ≡ 7 mod 8` for `j ≥ 2`) and `luc_two_pow_mod_three`
(`3 ∤ N` for `j ≥ 2`), all by induction via `L(2m) = L(m)² - 2(-1)^m`.

**Contradictions.** Since `N ≡ 3 mod 4` and `N ≡ 7 mod 8`, Mathlib's Jacobi symbol
gives `J(-1|N) = -1` and `J(2|N) = 1`, hence `J(-2|N) = -1` and `J(-18|N) = -1`.
On the other hand a square (resp. twice a square) has Jacobi symbol in `{0, 1}`
(`jacobiSym_sq_mem`, `jacobiSym_two_sq_mem`). Comparing the two kills every residue
class except the exceptional ones.

**Base cases.** Generic period lemmas (`fib_mod_eq`, `luc_mod_eq`) reduce
`F n % M` and `L n % M` to `n` modulo the Pisano period; a bounded `decide`
then establishes e.g. `luc_sq_mod12`, `luc_two_sq_mod6`, `luc_two_sq_mod16`,
`fib_two_sq_mod16`.

**Descent to the even case.** `F(2m) = F m · L m` with
`gcd (F m, L m) = 2` if `3 ∣ m` and `1` otherwise (`gcd_fib_luc`). Splitting the
coprime factorisation reduces theorems 1 and 3 to theorems 2 and 4.
Theorem 5 uses that `L m` is a power of two only for `m ∈ {0, 1, 3}`
(`luc_eq_two_pow`, via `8 ∤ L m`).

No `sorry`, `admit`, `native_decide`, or new axioms are used. Every `decide` call is
a bounded, kernel-checkable finite computation.

## Building (offline)

This project depends on the **locally installed** Mathlib at `/opt/mathlib4`
(declared as a path dependency in `lakefile.toml`) and the pinned toolchain
`leanprover/lean4:v4.33.0-rc1`. It is *not* self-contained: it must be built inside
the supplied Lean/Mathlib environment, and `/opt/mathlib4` must exist there.

```bash
cd proj
lean-offline-init    # seeds .lake/packages with links to the installed deps
lake build           # no network access required
```

Expected result: `Build completed successfully`, with no errors and no warnings.

To re-check the axiom footprint:

```bash
lake env lean Axioms.lean
```

which prints, for each of the five theorems,

```
depends on axioms: [propext, Classical.choice, Quot.sound]
```
