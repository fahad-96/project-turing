import TuringTask.Second
