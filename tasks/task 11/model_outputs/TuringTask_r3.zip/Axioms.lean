import TuringTask.Basic

#print axioms TuringTask.color_meet
#print axioms TuringTask.color_deg
#print axioms TuringTask.sat_exists
#print axioms TuringTask.ramsey_color
#print axioms TuringTask.ap_color
