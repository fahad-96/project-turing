import Mathlib

namespace TuringTask

open Finset Complex

/-! ### The primitive cube root of unity `om` in `ℂ` -/

/-- A primitive cube root of unity in `ℂ`. -/
noncomputable def om : ℂ := Complex.exp (2 * Real.pi * Complex.I / 3)

lemma om_isPrimitiveRoot : IsPrimitiveRoot om 3 := Complex.isPrimitiveRoot_exp 3 (by norm_num)

lemma om_pow_three : om ^ 3 = 1 := om_isPrimitiveRoot.pow_eq_one

lemma om_ne_one : om ≠ 1 := om_isPrimitiveRoot.ne_one (by norm_num)

lemma om_quad : om ^ 2 + om + 1 = 0 := by
  have h : (om - 1) * (om ^ 2 + om + 1) = 0 := by linear_combination om_pow_three
  rcases mul_eq_zero.mp h with h1 | h1
  · exact absurd (sub_eq_zero.mp h1) om_ne_one
  · exact h1

lemma om_ne_zero : om ≠ 0 := by
  intro h; have := om_pow_three; rw [h] at this; norm_num at this

lemma om_eq : om = Complex.exp ((2 * Real.pi / 3 : ℝ) * Complex.I) := by
  unfold om; congr 1; push_cast; ring

lemma om_im_pos : 0 < om.im := by
  rw [om_eq, Complex.exp_ofReal_mul_I_im]
  apply Real.sin_pos_of_pos_of_lt_pi
  · positivity
  · nlinarith [Real.pi_pos]

/-- `1` and `om` are linearly independent over `ℤ`. -/
lemma om_indep (a b : ℤ) (h : (a : ℂ) + (b : ℂ) * om = 0) : a = 0 ∧ b = 0 := by
  have him : ((a : ℂ) + (b : ℂ) * om).im = 0 := by rw [h]; simp
  simp [Complex.add_im, Complex.mul_im] at him
  have hb0 : b = 0 := by
    rcases him with h1 | h1
    · exact_mod_cast h1
    · exact absurd h1 (ne_of_gt om_im_pos)
  subst hb0
  simp at h
  exact ⟨by exact_mod_cast h, rfl⟩

/-- Every element of `ℤ[om]` has the form `a + b*om` with `a b : ℤ`. -/
lemma adjoin_rep {z : ℂ} (hz : z ∈ Algebra.adjoin ℤ ({om} : Set ℂ)) :
    ∃ a b : ℤ, z = (a : ℂ) + (b : ℂ) * om := by
  induction hz using Algebra.adjoin_induction with
  | mem x hx => exact ⟨0, 1, by simp at hx; simp [hx]⟩
  | algebraMap r => exact ⟨r, 0, by simp⟩
  | add x y hx hy ihx ihy =>
      obtain ⟨a, b, rfl⟩ := ihx; obtain ⟨c, d, rfl⟩ := ihy
      exact ⟨a + c, b + d, by push_cast; ring⟩
  | mul x y hx hy ihx ihy =>
      obtain ⟨a, b, rfl⟩ := ihx; obtain ⟨c, d, rfl⟩ := ihy
      refine ⟨a * c - b * d, a * d + b * c - b * d, ?_⟩
      push_cast
      linear_combination ((b : ℂ) * d) * om_quad

/-- Complex conjugation on `ℤ[om]`: `conj om = om^2 = -1 - om`. -/
lemma om_conj : (starRingEnd ℂ) om = -1 - om := by
  have hnorm : ‖om‖ = 1 := by
    have h3 : ‖om‖ ^ 3 = 1 := by rw [← norm_pow, om_pow_three, norm_one]
    nlinarith [norm_nonneg om, sq_nonneg (‖om‖ - 1), sq_nonneg (‖om‖ + 1)]
  have h1 : om * (starRingEnd ℂ) om = 1 := by
    rw [Complex.mul_conj]; norm_cast
    rw [Complex.normSq_eq_norm_sq, hnorm]; norm_num
  have h2 : om * (-1 - om) = 1 := by linear_combination -om_quad
  exact mul_left_cancel₀ om_ne_zero (h1.trans h2.symm)

/-! ### The cubic character -/

variable (p : ℕ) [Fact p.Prime]

lemma three_dvd (hp : p % 3 = 1) : 3 ∣ Fintype.card (ZMod p) - 1 := by rw [ZMod.card]; omega

noncomputable def chi (hp : p % 3 = 1) : MulChar (ZMod p) ℂ :=
  (MulChar.exists_mulChar_orderOf (ZMod p) (three_dvd p hp) om_isPrimitiveRoot).choose

lemma chi_orderOf (hp : p % 3 = 1) : orderOf (chi p hp) = 3 :=
  (MulChar.exists_mulChar_orderOf (ZMod p) (three_dvd p hp) om_isPrimitiveRoot).choose_spec

lemma chi_pow_three (hp : p % 3 = 1) : (chi p hp) ^ 3 = 1 := by
  rw [← chi_orderOf p hp]; exact pow_orderOf_eq_one _

lemma chi_ne_one (hp : p % 3 = 1) : chi p hp ≠ 1 := by
  intro h; have := chi_orderOf p hp; rw [h, orderOf_one] at this; norm_num at this

/-- The cube of `chi x` is 1 for `x ≠ 0`. -/
lemma chi_cube (hp : p % 3 = 1) {x : ZMod p} (hx : x ≠ 0) : (chi p hp x) ^ 3 = 1 := by
  have := chi_pow_three p hp
  have h2 : ((chi p hp) ^ 3) x = (chi p hp x) ^ 3 := MulChar.pow_apply' _ (by norm_num) x
  rw [this] at h2
  rw [← h2, MulChar.one_apply (isUnit_iff_ne_zero.mpr hx)]



lemma chi_g_ne_one (hp : p % 3 = 1) {g : (ZMod p)ˣ}
    (hg : ∀ x : (ZMod p)ˣ, x ∈ Subgroup.zpowers g) : chi p hp (g : ZMod p) ≠ 1 := by
  intro h
  refine chi_ne_one p hp ?_
  rw [MulChar.eq_iff hg, h, MulChar.one_apply_coe]

lemma chi_g_pow3 (hp : p % 3 = 1) (g : (ZMod p)ˣ) : (chi p hp (g : ZMod p)) ^ 3 = 1 := by
  have h2 : ((chi p hp) ^ 3) (g : ZMod p) = (chi p hp (g : ZMod p)) ^ 3 :=
    MulChar.pow_apply' _ (by norm_num) _
  rw [chi_pow_three p hp] at h2
  rw [← h2, MulChar.one_apply_coe]

lemma chi_g_orderOf (hp : p % 3 = 1) {g : (ZMod p)ˣ}
    (hg : ∀ x : (ZMod p)ˣ, x ∈ Subgroup.zpowers g) : orderOf (chi p hp (g : ZMod p)) = 3 := by
  have hdvd : orderOf (chi p hp (g : ZMod p)) ∣ 3 := orderOf_dvd_of_pow_eq_one (chi_g_pow3 p hp g)
  rcases (Nat.prime_three.eq_one_or_self_of_dvd _ hdvd) with h | h
  · exact absurd (orderOf_eq_one_iff.mp h) (chi_g_ne_one p hp hg)
  · exact h


lemma chi_npow (hp : p % 3 = 1) (g : (ZMod p)ˣ) (k : ℕ) :
    chi p hp ((g ^ k : (ZMod p)ˣ) : ZMod p) = (chi p hp (g : ZMod p)) ^ k := by
  rw [Units.val_pow_eq_pow_val, map_pow]

lemma chi_eq_one_iff_cube (hp : p % 3 = 1) {x : ZMod p} (hx : x ≠ 0) :
    chi p hp x = 1 ↔ ∃ u : ZMod p, u ^ 3 = x := by
  obtain ⟨g, hg⟩ := IsCyclic.exists_generator (α := (ZMod p)ˣ)
  set xu : (ZMod p)ˣ := (isUnit_iff_ne_zero.mpr hx).unit with hxu
  have hxv : (xu : ZMod p) = x := IsUnit.unit_spec _
  obtain ⟨k, hk⟩ : ∃ k : ℕ, g ^ k = xu := by
    have := (mem_powers_iff_mem_zpowers (x := g) (y := xu)).mpr (hg xu)
    exact this
  have hord : orderOf (chi p hp (g : ZMod p)) = 3 := chi_g_orderOf p hp hg
  constructor
  · intro h
    have hmap : (chi p hp (g : ZMod p)) ^ k = 1 := by
      rw [← chi_npow p hp g k, hk, hxv]; exact h
    have h3a : orderOf (chi p hp (g : ZMod p)) ∣ k := orderOf_dvd_of_pow_eq_one hmap
    rw [hord] at h3a
    obtain ⟨m, rfl⟩ := h3a
    refine ⟨((g ^ m : (ZMod p)ˣ) : ZMod p), ?_⟩
    rw [← Units.val_pow_eq_pow_val, ← pow_mul, mul_comm m 3, hk, hxv]
  · rintro ⟨u, rfl⟩
    have hu : u ≠ 0 := by rintro rfl; simp at hx
    rw [map_pow]
    exact chi_cube p hp hu

lemma chi_neg_one (hp : p % 3 = 1) : chi p hp (-1) = 1 := by
  have hne : (-1 : ZMod p) ≠ 0 := by
    intro h
    have : (1 : ZMod p) = 0 := by linear_combination -h
    exact one_ne_zero this
  have h2 : (chi p hp (-1)) ^ 2 = 1 := by
    rw [← map_pow]; norm_num
  have h3 : (chi p hp (-1)) ^ 3 = 1 := chi_cube p hp hne
  -- chi(-1) = chi(-1)^3 / chi(-1)^2
  have hx : chi p hp (-1) * (chi p hp (-1))^2 = 1 * (chi p hp (-1))^2 := by
    rw [one_mul, ← pow_succ']; exact h3.trans h2.symm
  have hne2 : (chi p hp (-1))^2 ≠ 0 := by rw [h2]; norm_num
  exact mul_right_cancel₀ hne2 hx

/-- The Jacobi sum `J(chi,chi)` has absolute value squared `p`, and lies in `ℤ[om]`. -/
lemma jacobi_norm (hp : p % 3 = 1) :
    jacobiSum (chi p hp) (chi p hp) * (starRingEnd ℂ) (jacobiSum (chi p hp) (chi p hp)) = p := by
  have hchar : ringChar ℂ ≠ ringChar (ZMod p) := by
    rw [ZMod.ringChar_zmod_n, ringChar.eq_zero]
    exact fun h => (Fact.out : p.Prime).ne_zero h.symm
  have hsq : (chi p hp) * (chi p hp) ≠ 1 := by
    rw [← sq]
    intro h
    have h3 := chi_orderOf p hp
    have : orderOf (chi p hp) ∣ 2 := orderOf_dvd_of_pow_eq_one h
    rw [h3] at this; norm_num at this
  have key := jacobiSum_mul_jacobiSum_inv (F := ZMod p) (F' := ℂ) hchar
    (chi_ne_one p hp) (chi_ne_one p hp) hsq
  rw [ZMod.card] at key
  rw [← key]
  congr 1
  rw [jacobiSum, jacobiSum, map_sum]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [map_mul, ← MulChar.star_apply' (chi p hp) x, ← MulChar.star_apply' (chi p hp) (1-x)]
  rfl

/-- `J(chi,chi) = a + b*om` with `a ≡ -1 mod 3` ... derived from `J ≡ -1 mod (om-1)^2`. -/
lemma jacobi_congr (hp : p % 3 = 1) :
    ∃ a b : ℤ, jacobiSum (chi p hp) (chi p hp) = (a : ℂ) + (b : ℂ) * om ∧
      a % 3 = 2 ∧ b % 3 = 0 := by
  obtain ⟨z, hz, hJ⟩ := exists_jacobiSum_eq_neg_one_add (F := ZMod p) (R := ℂ) (n := 3)
    (by norm_num) (chi_pow_three p hp) (chi_pow_three p hp)
    (by rw [ZMod.card]; omega) om_isPrimitiveRoot
  obtain ⟨c, d, hcd⟩ := adjoin_rep hz
  rw [hcd] at hJ
  -- (om-1)^2 = om^2 - 2om + 1 = (-1-om) - 2om + 1 = -3om
  have hsq : (om - 1)^2 = -3 * om := by linear_combination om_quad
  rw [hsq] at hJ
  -- J = -1 + (c + d*om) * (-3*om) = -1 - 3c*om - 3d*om^2 = -1 -3c om -3d(-1-om) = (-1+3d) + (-3c+3d) om
  refine ⟨-1 + 3 * d, -3 * c + 3 * d, ?_, by omega, by omega⟩
  rw [hJ]
  push_cast
  linear_combination (-3 * (d:ℂ)) * om_quad

/-- Key structural result: `J(chi,chi) = a + b*om` with `a² - ab + b² = p`,
`a ≡ 2 mod 3`, `b ≡ 0 mod 3`. -/
lemma jacobi_struct (hp : p % 3 = 1) :
    ∃ a b : ℤ, jacobiSum (chi p hp) (chi p hp) = (a : ℂ) + (b : ℂ) * om ∧
      a % 3 = 2 ∧ b % 3 = 0 ∧ a ^ 2 - a * b + b ^ 2 = p := by
  obtain ⟨a, b, hJ, ha, hb⟩ := jacobi_congr p hp
  refine ⟨a, b, hJ, ha, hb, ?_⟩
  have hnorm := jacobi_norm p hp
  rw [hJ] at hnorm
  -- conj (a + b om) = (a - b) - b om
  have hconj : (starRingEnd ℂ) ((a : ℂ) + (b : ℂ) * om) = ((a : ℂ) - b) - (b : ℂ) * om := by
    have hca : (starRingEnd ℂ) ((a:ℤ):ℂ) = ((a:ℤ):ℂ) := by simp
    have hcb : (starRingEnd ℂ) ((b:ℤ):ℂ) = ((b:ℤ):ℂ) := by simp
    rw [map_add, map_mul, om_conj, hca, hcb]
    ring
  rw [hconj] at hnorm
  -- expand
  have hz : ((a ^ 2 - a * b + b ^ 2 - p : ℤ) : ℂ) + ((0 : ℤ) : ℂ) * om = 0 := by
    push_cast
    linear_combination hnorm + ((b:ℂ)^2) * om_quad
  obtain ⟨h1, -⟩ := om_indep _ _ hz
  omega

/-- If `4p = L^2+27M^2 = L'^2+27M'^2` with `L ≡ L' ≡ 1 mod 3`, then `L = L'`. -/
theorem L_unique {p : ℕ} (hp : p.Prime) {L M L' M' : ℤ}
    (h1 : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2) (h2 : 4 * (p : ℤ) = L' ^ 2 + 27 * M' ^ 2)
    (hL : L % 3 = 1) (hL' : L' % 3 = 1) : L = L' := by
  have hpz : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp
  have hp0 : (p : ℤ) ≠ 0 := by
    simpa using hp.ne_zero
  have main : L = L' ∨ L = -L' := by
    have hdvd : (p : ℤ) ∣ (L * M' - L' * M) * (L * M' + L' * M) :=
      ⟨4 * (M' ^ 2 - M ^ 2), by linear_combination (-(M' ^ 2)) * h1 + M ^ 2 * h2⟩
    rcases hpz.dvd_mul.mp hdvd with h | h
    · obtain ⟨k, hk⟩ := h
      have hid : (L * L' + 27 * (M * M')) ^ 2 + 27 * ((p : ℤ) * k) ^ 2 = 16 * (p : ℤ) ^ 2 := by
        rw [← hk]; linear_combination (-(L' ^ 2 + 27 * M' ^ 2)) * h1 - 4 * (p : ℤ) * h2
      have hdvd2 : (p : ℤ) ∣ (L * L' + 27 * (M * M')) := by
        refine hpz.dvd_of_dvd_pow (n := 2) ⟨(p : ℤ) * (16 - 27 * k ^ 2), by linear_combination hid⟩
      obtain ⟨t, ht⟩ := hdvd2
      have h16 : t ^ 2 + 27 * k ^ 2 = 16 := by
        have hpp : (p : ℤ) ^ 2 * (t ^ 2 + 27 * k ^ 2) = (p : ℤ) ^ 2 * 16 := by
          rw [ht] at hid; linear_combination hid
        exact mul_left_cancel₀ (pow_ne_zero 2 hp0) hpp
      have hk0 : k = 0 := by nlinarith [sq_nonneg k, sq_nonneg t]
      have ht4 : t = 4 ∨ t = -4 := by
        rw [hk0] at h16
        have : (t - 4) * (t + 4) = 0 := by linarith
        rcases mul_eq_zero.mp this with h | h
        · left; linarith
        · right; linarith
      rw [hk0, mul_zero] at hk
      have hcross : L * M' = L' * M := by linarith
      -- L * (L*L' + 27*M*M') = L' * (L^2+27M^2) = L' * 4p
      have hmain : L * ((p : ℤ) * t) = L' * (4 * (p : ℤ)) := by
        rw [← ht, h1]
        linear_combination 27 * M * hcross
      rcases ht4 with rfl | rfl
      · left
        have : (p : ℤ) * (4 * L) = (p : ℤ) * (4 * L') := by linarith [hmain]
        have := mul_left_cancel₀ hp0 this
        linarith
      · right
        have : (p : ℤ) * (-4 * L) = (p : ℤ) * (4 * L') := by linarith [hmain]
        have := mul_left_cancel₀ hp0 this
        linarith
    · obtain ⟨k, hk⟩ := h
      have hid : (L * L' - 27 * (M * M')) ^ 2 + 27 * ((p : ℤ) * k) ^ 2 = 16 * (p : ℤ) ^ 2 := by
        rw [← hk]; linear_combination (-(L' ^ 2 + 27 * M' ^ 2)) * h1 - 4 * (p : ℤ) * h2
      have hdvd2 : (p : ℤ) ∣ (L * L' - 27 * (M * M')) := by
        refine hpz.dvd_of_dvd_pow (n := 2) ⟨(p : ℤ) * (16 - 27 * k ^ 2), by linear_combination hid⟩
      obtain ⟨t, ht⟩ := hdvd2
      have h16 : t ^ 2 + 27 * k ^ 2 = 16 := by
        have hpp : (p : ℤ) ^ 2 * (t ^ 2 + 27 * k ^ 2) = (p : ℤ) ^ 2 * 16 := by
          rw [ht] at hid; linear_combination hid
        exact mul_left_cancel₀ (pow_ne_zero 2 hp0) hpp
      have hk0 : k = 0 := by nlinarith [sq_nonneg k, sq_nonneg t]
      have ht4 : t = 4 ∨ t = -4 := by
        rw [hk0] at h16
        have : (t - 4) * (t + 4) = 0 := by linarith
        rcases mul_eq_zero.mp this with h | h
        · left; linarith
        · right; linarith
      rw [hk0, mul_zero] at hk
      have hcross : L * M' = -(L' * M) := by linarith
      have hmain : L * ((p : ℤ) * t) = L' * (4 * (p : ℤ)) := by
        rw [← ht, h1]
        linear_combination (-27 : ℤ) * M * hcross
      rcases ht4 with rfl | rfl
      · left
        have : (p : ℤ) * (4 * L) = (p : ℤ) * (4 * L') := by linarith [hmain]
        have := mul_left_cancel₀ hp0 this
        linarith
      · right
        have : (p : ℤ) * (-4 * L) = (p : ℤ) * (4 * L') := by linarith [hmain]
        have := mul_left_cancel₀ hp0 this
        linarith
  rcases main with h | h
  · exact h
  · exfalso; omega

/-- The Jacobi sum determines `L`. -/
lemma jacobi_L (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) :
    ∃ a b : ℤ, jacobiSum (chi p hp) (chi p hp) = (a : ℂ) + (b : ℂ) * om ∧
      2 * a - b = L := by
  obtain ⟨a, b, hJ, ha, hb, hnorm⟩ := jacobi_struct p hp
  refine ⟨a, b, hJ, ?_⟩
  obtain ⟨m, rfl⟩ : ∃ m, b = 3 * m := ⟨b / 3, by omega⟩
  have h4p : 4 * (p : ℤ) = (2 * a - 3 * m) ^ 2 + 27 * m ^ 2 := by linarith [hnorm]
  have hmod : (2 * a - 3 * m) % 3 = 1 := by omega
  exact L_unique (Fact.out : p.Prime) h4p hLM hmod hL

/-- The trace of the Jacobi sum is `L`: `J + conj J = L`. -/
lemma jacobi_trace (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) :
    jacobiSum (chi p hp) (chi p hp) + (starRingEnd ℂ) (jacobiSum (chi p hp) (chi p hp))
      = (L : ℂ) := by
  obtain ⟨a, b, hJ, hab⟩ := jacobi_L p hp L M hLM hL
  have hca : (starRingEnd ℂ) ((a:ℤ):ℂ) = ((a:ℤ):ℂ) := by simp
  have hcb : (starRingEnd ℂ) ((b:ℤ):ℂ) = ((b:ℤ):ℂ) := by simp
  rw [hJ, map_add, map_mul, om_conj, hca, hcb, ← hab]
  push_cast
  ring

/-! ### Counting cube roots -/

lemma cube_geom {z : ℂ} (h : z ^ 3 = 1) : 1 + z + z ^ 2 = if z = 1 then 3 else 0 := by
  split_ifs with hz
  · subst hz; norm_num
  · have hq : (z - 1) * (1 + z + z ^ 2) = 0 := by linear_combination h
    rcases mul_eq_zero.mp hq with h1 | h1
    · exact absurd (sub_eq_zero.mp h1) hz
    · exact h1

lemma exists_prim3 (hp : p % 3 = 1) : ∃ z : ZMod p, IsPrimitiveRoot z 3 := by
  have hdvd : 3 ∣ Fintype.card (ZMod p)ˣ := by
    rw [ZMod.card_units_eq_totient, Nat.totient_prime (Fact.out)]; omega
  haveI : Fact (Nat.Prime 3) := ⟨by norm_num⟩
  obtain ⟨u, hu⟩ := exists_prime_orderOf_dvd_card (G := (ZMod p)ˣ) 3 hdvd
  refine ⟨(u : ZMod p), ?_⟩
  rw [IsPrimitiveRoot.iff_def]
  refine ⟨?_, fun l hl => ?_⟩
  · have h1 : u ^ 3 = 1 := by rw [← hu]; exact pow_orderOf_eq_one u
    calc ((u : ZMod p)) ^ 3 = ((u ^ 3 : (ZMod p)ˣ) : ZMod p) := by rw [Units.val_pow_eq_pow_val]
      _ = 1 := by rw [h1]; rfl
  · have hul : u ^ l = 1 := by ext; rw [Units.val_pow_eq_pow_val, hl, Units.val_one]
    rw [← hu]; exact orderOf_dvd_of_pow_eq_one hul

/-- Number of cube roots of `c`: 3 if `c` is a nonzero cube, 0 if `c ≠ 0` is not a cube. -/
lemma card_cube_roots (hp : p % 3 = 1) (c : ZMod p) (hc : c ≠ 0) :
    (Finset.univ.filter (fun u : ZMod p => u ^ 3 = c)).card =
      if (∃ v : ZMod p, v ^ 3 = c) then 3 else 0 := by
  classical
  obtain ⟨z, hz⟩ := exists_prim3 p hp
  split_ifs with h
  · obtain ⟨u0, hu0⟩ := h
    have hu0ne : u0 ≠ 0 := by rintro rfl; rw [zero_pow (by norm_num)] at hu0; exact hc hu0.symm
    have heq : (Finset.univ.filter (fun u : ZMod p => u ^ 3 = c)) =
        (Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1)).image (fun w => u0 * w) := by
      ext u
      simp only [mem_filter, mem_univ, true_and, mem_image]
      constructor
      · intro hu
        refine ⟨u / u0, ?_, by field_simp⟩
        rw [div_pow, hu, hu0, div_self hc]
      · rintro ⟨w, hw, rfl⟩
        rw [mul_pow, hw, hu0, mul_one]
    rw [heq, Finset.card_image_of_injective _ (mul_right_injective₀ hu0ne)]
    have h1 : (Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1)) = Polynomial.nthRootsFinset 3 (1 : ZMod p) := by
      ext w; simp only [mem_filter, mem_univ, true_and]
      rw [Polynomial.mem_nthRootsFinset (by norm_num)]
    rw [h1, hz.card_nthRootsFinset]
  · rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    intro u _ hu
    exact h ⟨u, hu⟩

/-- Character-sum formula for the number of cube roots of a nonzero element. -/
lemma nu_eq_sum (hp : p % 3 = 1) (c : ZMod p) (hc : c ≠ 0) :
    (((Finset.univ.filter (fun u : ZMod p => u ^ 3 = c)).card : ℕ) : ℂ) =
      ∑ j ∈ Finset.range 3, ((chi p hp) ^ j) c := by
  classical
  rw [card_cube_roots p hp c hc]
  have hval : ∀ j ∈ Finset.range 3, ((chi p hp) ^ j) c = (chi p hp c) ^ j := by
    intro j hj
    rcases Nat.eq_zero_or_pos j with rfl | hj0
    · simp [MulChar.one_apply (isUnit_iff_ne_zero.mpr hc)]
    · exact MulChar.pow_apply' _ (by omega) c
  rw [Finset.sum_congr rfl hval]
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
  rw [pow_zero, pow_one]
  rw [cube_geom (chi_cube p hp hc)]
  by_cases h : chi p hp c = 1
  · rw [if_pos h, if_pos ((chi_eq_one_iff_cube p hp hc).mp h)]
    norm_num
  · rw [if_neg h, if_neg (fun hcube => h ((chi_eq_one_iff_cube p hp hc).mpr hcube))]
    norm_num

/-! ### Generic counting helpers -/

/-- Fiberwise decomposition of a sum. -/
lemma sum_fiber {α β : Type*} [Fintype α] [Fintype β] [DecidableEq β] (f : α → β) (g : β → ℂ) :
    ∑ a : α, g (f a) = ∑ b : β, ((Finset.univ.filter (fun a => f a = b)).card : ℂ) * g b := by
  classical
  have h := Finset.sum_fiberwise_eq_sum_filter (Finset.univ : Finset α)
    (Finset.univ : Finset β) f (fun a => g (f a))
  simp only [Finset.mem_univ, Finset.filter_true_of_mem, implies_true] at h
  rw [← h]
  refine Finset.sum_congr rfl fun b _ => ?_
  rw [Finset.sum_congr rfl
    (fun a ha => ?_ : ∀ a ∈ Finset.univ.filter (fun a => f a = b), g (f a) = g b),
    Finset.sum_const, nsmul_eq_mul]
  simp only [Finset.mem_filter] at ha
  rw [ha.2]

/-- Card of a filtered product set as a sum over the first coordinate. -/
lemma card_prod_filter {α β : Type*} [Fintype α] [Fintype β] [DecidableEq α] [DecidableEq β]
    (P : α → β → Prop) [∀ a b, Decidable (P a b)] :
    (Finset.univ.filter (fun q : α × β => P q.1 q.2)).card
      = ∑ a : α, (Finset.univ.filter (fun b => P a b)).card := by
  classical
  rw [Finset.card_eq_sum_card_fiberwise (f := Prod.fst) (t := Finset.univ)
    (fun x _ => Finset.mem_univ _)]
  refine Finset.sum_congr rfl fun a _ => ?_
  refine Finset.card_bij' (fun q _ => q.2) (fun b _ => (a, b)) ?_ ?_ ?_ ?_
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq ⊢
    obtain ⟨h1, h2⟩ := hq
    rw [← h2]; exact h1
  · intro b hb
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hb ⊢
    exact ⟨hb, trivial⟩
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq
    exact Prod.ext hq.2.symm rfl
  · intro b _; rfl

/-- The number of pairs `(x,y)` with `x^3+y^3=1` written via cube-root counts. -/
lemma card_cubic_eq_sum (_hp : p % 3 = 1) :
    (((Finset.univ.filter (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℕ) : ℂ)
      = ∑ u : ZMod p, ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = u)).card : ℂ) *
          ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1 - u)).card : ℂ) := by
  classical
  rw [card_prod_filter (fun x y : ZMod p => x ^ 3 + y ^ 3 = 1)]
  push_cast
  -- ∑ x, #{y | x^3+y^3=1} = ∑ x, #{y | y^3 = 1 - x^3}
  have step1 : ∀ x : ZMod p,
      (Finset.univ.filter (fun y : ZMod p => x ^ 3 + y ^ 3 = 1)) =
      (Finset.univ.filter (fun y : ZMod p => y ^ 3 = 1 - x ^ 3)) := by
    intro x; ext y
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    constructor
    · intro h; linear_combination h
    · intro h; linear_combination h
  simp only [step1]
  -- now group by u = x^3
  rw [sum_fiber (fun x : ZMod p => x ^ 3)
    (fun u => ((Finset.univ.filter (fun y : ZMod p => y ^ 3 = 1 - u)).card : ℂ))]

/-- Abbreviation: the character sum `S(c) = Σ_{j<3} chi^j (c)`. -/
noncomputable def charSum (hp : p % 3 = 1) (c : ZMod p) : ℂ :=
  ∑ j ∈ Finset.range 3, ((chi p hp) ^ j) c

lemma charSum_zero (hp : p % 3 = 1) : charSum p hp 0 = 0 := by
  unfold charSum
  refine Finset.sum_eq_zero fun j _ => ?_
  exact MulChar.map_zero _

lemma charSum_eq_nu (hp : p % 3 = 1) {c : ZMod p} (hc : c ≠ 0) :
    charSum p hp c = (((Finset.univ.filter (fun u : ZMod p => u ^ 3 = c)).card : ℕ) : ℂ) :=
  (nu_eq_sum p hp c hc).symm

lemma charSum_one (hp : p % 3 = 1) : charSum p hp 1 = 3 := by
  unfold charSum
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
  simp only [pow_zero, pow_one]
  rw [MulChar.map_one, MulChar.map_one, MulChar.map_one]
  norm_num

/-- `∑_u charSum u * charSum (1-u) = ∑_{i,j<3} J(chi^i, chi^j)`. -/
lemma sum_charSum_prod (hp : p % 3 = 1) :
    ∑ u : ZMod p, charSum p hp u * charSum p hp (1 - u)
      = ∑ i ∈ Finset.range 3, ∑ j ∈ Finset.range 3,
          jacobiSum ((chi p hp) ^ i) ((chi p hp) ^ j) := by
  unfold charSum jacobiSum
  simp only [Finset.sum_mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [Finset.sum_comm]

lemma chi_pow0 (hp : p % 3 = 1) : (chi p hp) ^ 0 = 1 := pow_zero _
lemma chi_pow1 (hp : p % 3 = 1) : (chi p hp) ^ 1 = chi p hp := pow_one _

lemma chi_sq_ne_one' (hp : p % 3 = 1) : (chi p hp) ^ 2 ≠ 1 := by
  intro h
  have h3 := chi_orderOf p hp
  have hd : orderOf (chi p hp) ∣ 2 := orderOf_dvd_of_pow_eq_one h
  rw [h3] at hd; norm_num at hd

lemma chi_sq_inv (hp : p % 3 = 1) : (chi p hp) ^ 2 = (chi p hp)⁻¹ := by
  refine (inv_eq_of_mul_eq_one_right ?_).symm
  rw [← pow_succ']
  exact chi_pow_three p hp

/-- The nine Jacobi sums. -/
lemma jacobi_eval (hp : p % 3 = 1) :
    ∑ i ∈ Finset.range 3, ∑ j ∈ Finset.range 3, jacobiSum ((chi p hp) ^ i) ((chi p hp) ^ j)
      = ((p : ℂ) - 2) - 4 + (jacobiSum (chi p hp) (chi p hp)
          + jacobiSum ((chi p hp)^2) ((chi p hp)^2)) - 2 := by
  have hne := chi_ne_one p hp
  have hne2 := chi_sq_ne_one' p hp
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
  repeat rw [Finset.sum_range_succ]
  simp only [pow_zero, pow_one]
  rw [jacobiSum_one_one (F := ZMod p) (R := ℂ)]
  rw [jacobiSum_one_nontrivial hne, jacobiSum_one_nontrivial hne2]
  rw [jacobiSum_comm (chi p hp) 1, jacobiSum_one_nontrivial hne]
  rw [jacobiSum_comm ((chi p hp)^2) 1, jacobiSum_one_nontrivial hne2]
  -- J(chi, chi^2) = J(chi, chi⁻¹) = -chi(-1) = -1
  rw [chi_sq_inv p hp]
  rw [jacobiSum_nontrivial_inv hne, chi_neg_one p hp]
  -- J(chi⁻¹, chi) = J(chi, chi⁻¹)
  rw [jacobiSum_comm (chi p hp)⁻¹ (chi p hp), jacobiSum_nontrivial_inv hne, chi_neg_one p hp]
  rw [ZMod.card]
  ring

/-- `J(chi^2,chi^2) = conj (J(chi,chi))`. -/
lemma jacobi_sq_conj (hp : p % 3 = 1) :
    jacobiSum ((chi p hp)^2) ((chi p hp)^2)
      = (starRingEnd ℂ) (jacobiSum (chi p hp) (chi p hp)) := by
  rw [chi_sq_inv p hp, jacobiSum, jacobiSum, map_sum]
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [map_mul, ← MulChar.star_apply' (chi p hp) x, ← MulChar.star_apply' (chi p hp) (1 - x)]
  rfl

/-- Replacing `nu` by `charSum` costs the two exceptional points `u = 0` and `u = 1`. -/
lemma nu_vs_charSum (hp : p % 3 = 1) :
    ∑ u : ZMod p, ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = u)).card : ℂ) *
        ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1 - u)).card : ℂ)
      = (∑ u : ZMod p, charSum p hp u * charSum p hp (1 - u)) + 6 := by
  classical
  have hp1 : (1 : ZMod p) ≠ 0 := one_ne_zero
  have h01 : (0 : ZMod p) ≠ 1 := zero_ne_one
  -- define the difference function
  set F : ZMod p → ℂ := fun u =>
    ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = u)).card : ℂ) *
      ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1 - u)).card : ℂ) with hF
  set G : ZMod p → ℂ := fun u => charSum p hp u * charSum p hp (1 - u) with hG
  have hagree : ∀ u : ZMod p, u ≠ 0 → u ≠ 1 → F u = G u := by
    intro u hu0 hu1
    have h1u : (1 : ZMod p) - u ≠ 0 := sub_ne_zero.mpr (Ne.symm hu1)
    rw [hF, hG]
    simp only
    rw [charSum_eq_nu p hp hu0, charSum_eq_nu p hp h1u]
  -- values at 0 and 1
  have hnu0 : ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = (0 : ZMod p))).card : ℂ) = 1 := by
    have : (Finset.univ.filter (fun w : ZMod p => w ^ 3 = (0 : ZMod p))) = {0} := by
      ext w
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
        pow_eq_zero_iff (n := 3) (by norm_num)]
    rw [this]; norm_num
  have hnu1 : ((Finset.univ.filter (fun w : ZMod p => w ^ 3 = (1 : ZMod p))).card : ℂ) = 3 := by
    rw [← charSum_eq_nu p hp hp1, charSum_one p hp]
  have hF0 : F 0 = 3 := by rw [hF]; simp only [sub_zero]; rw [hnu0, hnu1]; ring
  have hF1 : F 1 = 3 := by rw [hF]; simp only [sub_self]; rw [hnu0, hnu1]; ring
  have hG0 : G 0 = 0 := by rw [hG]; simp only [charSum_zero p hp]; ring
  have hG1 : G 1 = 0 := by
    rw [hG]; simp only [sub_self]; rw [charSum_zero p hp]; ring
  have key : ∑ x : ZMod p, (F x - G x) = (F 0 - G 0) + (F 1 - G 1) := by
    rw [← Finset.sum_subset (Finset.subset_univ ({0, 1} : Finset (ZMod p)))]
    · rw [Finset.sum_pair h01]
    · intro x _ hx
      simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at hx
      rw [hagree x hx.1 hx.2, sub_self]
  rw [hF0, hF1, hG0, hG1] at key
  have hsub : ∑ x : ZMod p, (F x - G x) = (∑ x : ZMod p, F x) - ∑ x : ZMod p, G x :=
    Finset.sum_sub_distrib _ _
  rw [hsub] at key
  linear_combination key

/-! ### Theorem 1 -/

theorem card_cubic (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : Int) =
      (p : Int) - 2 + L := by
  classical
  have key : (((Finset.univ.filter
      (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℕ) : ℂ)
      = ((p : ℂ) - 2 + (L : ℂ)) := by
    rw [card_cubic_eq_sum p hp, nu_vs_charSum p hp, sum_charSum_prod p hp, jacobi_eval p hp,
      jacobi_sq_conj p hp, jacobi_trace p hp L M hLM hL]
    ring
  have hcast : (((Finset.univ.filter
      (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℤ) : ℂ)
      = (((p : ℤ) - 2 + L : ℤ) : ℂ) := by push_cast; exact key
  exact_mod_cast hcast

/-! ### Counting via the shifted Jacobi sum -/

/-- `∑_x ψ(x) φ(x+1) = ψ(-1) J(ψ,φ)`. -/
lemma sum_shift (ψ φ : MulChar (ZMod p) ℂ) :
    ∑ x : ZMod p, ψ x * φ (x + 1) = ψ (-1) * jacobiSum ψ φ := by
  rw [jacobiSum, Finset.mul_sum]
  rw [← Equiv.sum_comp (Equiv.neg (ZMod p)) (fun y => ψ (-1) * (ψ y * φ (1 - y)))]
  refine Finset.sum_congr rfl fun x _ => ?_
  simp only [Equiv.neg_apply]
  rw [show (1 : ZMod p) - -x = x + 1 by ring, ← mul_assoc, ← map_mul]
  congr 2
  ring

/-- `chi^i (-1) = 1` for all `i`. -/
lemma chi_pow_neg_one (hp : p % 3 = 1) (i : ℕ) : ((chi p hp) ^ i) (-1) = 1 := by
  rcases Nat.eq_zero_or_pos i with rfl | hi
  · rw [pow_zero]
    exact MulChar.one_apply (isUnit_one.neg)
  · rw [MulChar.pow_apply' _ (by omega), chi_neg_one p hp, one_pow]

/-- The "indicator" identity: for `c ≠ 0`, `(1/3)·Σ_j chi^j(c)` is 1 if `c` is a cube, else 0. -/
lemma charSum_ind (hp : p % 3 = 1) {c : ZMod p} (hc : c ≠ 0) :
    charSum p hp c = if (∃ v : ZMod p, v ^ 3 = c) then 3 else 0 := by
  rw [charSum_eq_nu p hp hc, card_cube_roots p hp c hc]
  split_ifs <;> norm_num

/-- Master sum: `Σ_{i,j<3} chi^i(x) chi^j(x+1)` summed over all `x` equals
`Σ_{i,j} chi^i(-1) J(chi^i, chi^j)`. -/
lemma master_sum (hp : p % 3 = 1) :
    ∑ x : ZMod p, charSum p hp x * charSum p hp (x + 1)
      = ∑ i ∈ Finset.range 3, ∑ j ∈ Finset.range 3,
          ((chi p hp) ^ i) (-1) * jacobiSum ((chi p hp) ^ i) ((chi p hp) ^ j) := by
  unfold charSum
  simp only [Finset.sum_mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun j _ => ?_
  exact sum_shift p _ _

/-- `Σ_x charSum x * charSum (x+1) = p - 8 + L`. -/
lemma master_sum_eval (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) :
    ∑ x : ZMod p, charSum p hp x * charSum p hp (x + 1) = (p : ℂ) - 8 + (L : ℂ) := by
  rw [master_sum p hp]
  simp only [chi_pow_neg_one p hp, one_mul]
  rw [jacobi_eval p hp, jacobi_sq_conj p hp, jacobi_trace p hp L M hLM hL]
  ring

/-! ### Theorem 2 -/

theorem card_cube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : Int) =
      (p : Int) - 8 + L := by
  classical
  set S := Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1)) with hS
  -- the summand is 9 on S and 0 elsewhere
  have hterm : ∀ x : ZMod p, charSum p hp x * charSum p hp (x + 1) = if x ∈ S then 9 else 0 := by
    intro x
    by_cases hx0 : x = 0
    · subst hx0
      rw [charSum_zero p hp, zero_mul, if_neg (by simp [hS])]
    by_cases hx1 : x + 1 = 0
    · rw [hx1, charSum_zero p hp, mul_zero, if_neg (by simp [hS, hx1])]
    rw [charSum_ind p hp hx0, charSum_ind p hp hx1]
    have hmemS : x ∈ S ↔ ((∃ u : ZMod p, u ^ 3 = x) ∧ (∃ v : ZMod p, v ^ 3 = x + 1)) := by
      simp only [hS, Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨fun h => ⟨h.2.2.1, h.2.2.2⟩, fun h => ⟨hx0, hx1, h.1, h.2⟩⟩
    by_cases hc1 : ∃ u : ZMod p, u ^ 3 = x
    · by_cases hc2 : ∃ v : ZMod p, v ^ 3 = x + 1
      · rw [if_pos hc1, if_pos hc2, if_pos (hmemS.mpr ⟨hc1, hc2⟩)]; norm_num
      · rw [if_pos hc1, if_neg hc2, if_neg (fun h => hc2 (hmemS.mp h).2)]; ring
    · rw [if_neg hc1, if_neg (fun h => hc1 (hmemS.mp h).1)]; ring
  have hsum : ∑ x : ZMod p, charSum p hp x * charSum p hp (x + 1) = 9 * (S.card : ℂ) := by
    rw [Finset.sum_congr rfl (fun x _ => hterm x)]
    rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, nsmul_eq_mul]
    ring
  rw [master_sum_eval p hp L M hLM hL] at hsum
  have hfin : ((9 * (S.card : ℤ) : ℤ) : ℂ) = (((p : ℤ) - 8 + L : ℤ) : ℂ) := by
    push_cast
    linear_combination -hsum
  exact_mod_cast hfin

/-! ### Weighted character sums (for Theorem 3) -/

/-- The weighted character sum `D α x = Σ_{i<3} α^i χ^i(x)`. -/
noncomputable def dsum (hp : p % 3 = 1) (α : ℂ) (x : ZMod p) : ℂ :=
  ∑ i ∈ Finset.range 3, α ^ i * ((chi p hp) ^ i) x

lemma dsum_zero (hp : p % 3 = 1) (α : ℂ) : dsum p hp α 0 = 0 := by
  unfold dsum
  refine Finset.sum_eq_zero fun i _ => ?_
  rw [MulChar.map_zero, mul_zero]

/-- For `x ≠ 0`, `D α x = 3` if `α·χ(x) = 1` and `0` otherwise. -/
lemma dsum_eval (hp : p % 3 = 1) {α : ℂ} (hα : α ^ 3 = 1) {x : ZMod p} (hx : x ≠ 0) :
    dsum p hp α x = if α * chi p hp x = 1 then 3 else 0 := by
  unfold dsum
  have hval : ∀ i ∈ Finset.range 3, α ^ i * ((chi p hp) ^ i) x = (α * chi p hp x) ^ i := by
    intro i hi
    rcases Nat.eq_zero_or_pos i with rfl | hi0
    · simp [MulChar.one_apply (isUnit_iff_ne_zero.mpr hx)]
    · rw [MulChar.pow_apply' _ (by omega), mul_pow]
  rw [Finset.sum_congr rfl hval, Finset.sum_range_succ, Finset.sum_range_succ,
    Finset.sum_range_one, pow_zero, pow_one]
  have hcube : (α * chi p hp x) ^ 3 = 1 := by
    rw [mul_pow, hα, chi_cube p hp hx, one_mul]
  exact cube_geom hcube

/-- Master weighted sum: `Σ_x D α x * D β (x+1) = Σ_{i,j} α^i β^j J(χ^i,χ^j)`. -/
lemma master_weighted (hp : p % 3 = 1) (α β : ℂ) :
    ∑ x : ZMod p, dsum p hp α x * dsum p hp β (x + 1)
      = ∑ i ∈ Finset.range 3, ∑ j ∈ Finset.range 3,
          α ^ i * β ^ j * jacobiSum ((chi p hp) ^ i) ((chi p hp) ^ j) := by
  unfold dsum
  simp only [Finset.sum_mul_sum]
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [Finset.sum_comm]
  refine Finset.sum_congr rfl fun j _ => ?_
  have : ∀ x : ZMod p, (α ^ i * ((chi p hp) ^ i) x) * (β ^ j * ((chi p hp) ^ j) (x + 1))
      = (α ^ i * β ^ j) * (((chi p hp) ^ i) x * ((chi p hp) ^ j) (x + 1)) := by
    intro x; ring
  rw [Finset.sum_congr rfl (fun x _ => this x), ← Finset.mul_sum, sum_shift p _ _,
    chi_pow_neg_one p hp i, one_mul, mul_assoc]

/-- Evaluation of the nine Jacobi sums with weights. -/
lemma master_weighted_eval (hp : p % 3 = 1) (α β : ℂ) (_hα : α ^ 3 = 1) (_hβ : β ^ 3 = 1) :
    ∑ x : ZMod p, dsum p hp α x * dsum p hp β (x + 1)
      = ((p : ℂ) - 2) - (β + β ^ 2) - (α + α ^ 2)
        + α * β * jacobiSum (chi p hp) (chi p hp)
        - α * β ^ 2 - α ^ 2 * β
        + α ^ 2 * β ^ 2 * (starRingEnd ℂ) (jacobiSum (chi p hp) (chi p hp)) := by
  rw [master_weighted p hp α β]
  have hne := chi_ne_one p hp
  have hne2 := chi_sq_ne_one' p hp
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
  repeat rw [Finset.sum_range_succ]
  simp only [pow_zero, pow_one]
  rw [jacobiSum_one_one (F := ZMod p) (R := ℂ)]
  rw [jacobiSum_one_nontrivial hne, jacobiSum_one_nontrivial hne2]
  rw [jacobiSum_comm (chi p hp) 1, jacobiSum_one_nontrivial hne]
  rw [jacobiSum_comm ((chi p hp)^2) 1, jacobiSum_one_nontrivial hne2]
  rw [← jacobi_sq_conj p hp]
  -- J(chi, chi^2) and J(chi^2, chi)
  have h12 : jacobiSum (chi p hp) ((chi p hp)^2) = -1 := by
    rw [chi_sq_inv p hp, jacobiSum_nontrivial_inv hne, chi_neg_one p hp]
  have h21 : jacobiSum ((chi p hp)^2) (chi p hp) = -1 := by
    rw [jacobiSum_comm, h12]
  rw [h12, h21, ZMod.card]
  ring

/-- Specialisation: `α β` a pair of conjugate primitive cube roots gives `p + 1 + L`. -/
lemma master_weighted_om (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) (α β : ℂ) (hα : α ^ 3 = 1) (hβ : β ^ 3 = 1) (hαβ : α * β = 1)
    (hα1 : α ≠ 1) :
    ∑ x : ZMod p, dsum p hp α x * dsum p hp β (x + 1) = (p : ℂ) + 1 + (L : ℂ) := by
  rw [master_weighted_eval p hp α β hα hβ]
  have htr := jacobi_trace p hp L M hLM hL
  -- α² + α + 1 = 0 and β = α², so β² = α
  have hquad : α ^ 2 + α + 1 = 0 := by
    have h : (α - 1) * (α ^ 2 + α + 1) = 0 := by linear_combination hα
    rcases mul_eq_zero.mp h with h1 | h1
    · exact absurd (sub_eq_zero.mp h1) hα1
    · exact h1
  have hβα : β = α ^ 2 := by
    have : α * β = α * α ^ 2 := by rw [hαβ]; linear_combination -hα
    have hα0 : α ≠ 0 := by intro h; rw [h] at hα; norm_num at hα
    exact mul_left_cancel₀ hα0 this
  subst hβα
  set J := jacobiSum (chi p hp) (chi p hp) with hJdef
  set K := (starRingEnd ℂ) (jacobiSum (chi p hp) (chi p hp)) with hKdef
  linear_combination htr + (- 2 * α - α ^ 2 + J + K * (α ^ 3 + 1)) * hα - 3 * hquad

/-- Characterisation of the Theorem-3 set in terms of `chi`. -/
lemma thm3_mem (hp : p % 3 = 1) (x : ZMod p) :
    ((¬ ∃ u : ZMod p, u ^ 3 = x) ∧ (¬ ∃ v : ZMod p, v ^ 3 = x + 1) ∧
      (∃ w : ZMod p, w ^ 3 = x * (x + 1)))
    ↔ (x ≠ 0 ∧ x + 1 ≠ 0 ∧ chi p hp x ≠ 1 ∧ chi p hp (x + 1) ≠ 1 ∧
        chi p hp x * chi p hp (x + 1) = 1) := by
  constructor
  · rintro ⟨h1, h2, h3⟩
    have hx0 : x ≠ 0 := by rintro rfl; exact h1 ⟨0, by ring⟩
    have hx1 : x + 1 ≠ 0 := by rintro h; exact h2 ⟨0, by rw [h]; ring⟩
    have hprod : x * (x + 1) ≠ 0 := mul_ne_zero hx0 hx1
    refine ⟨hx0, hx1, fun h => h1 ((chi_eq_one_iff_cube p hp hx0).mp h),
      fun h => h2 ((chi_eq_one_iff_cube p hp hx1).mp h), ?_⟩
    rw [← map_mul]
    exact (chi_eq_one_iff_cube p hp hprod).mpr h3
  · rintro ⟨hx0, hx1, h1, h2, h3⟩
    have hprod : x * (x + 1) ≠ 0 := mul_ne_zero hx0 hx1
    refine ⟨fun h => h1 ((chi_eq_one_iff_cube p hp hx0).mpr h),
      fun h => h2 ((chi_eq_one_iff_cube p hp hx1).mpr h), ?_⟩
    refine (chi_eq_one_iff_cube p hp hprod).mp ?_
    rw [map_mul]; exact h3

/-- A primitive cube root of unity equals `om` or `om^2`. -/
lemma cube_root_cases {z : ℂ} (h3 : z ^ 3 = 1) (h1 : z ≠ 1) : z = om ∨ z = om ^ 2 := by
  -- z^2 + z + 1 = 0 and om^2 + om + 1 = 0, both roots of the same quadratic
  have hz : z ^ 2 + z + 1 = 0 := by
    have h : (z - 1) * (z ^ 2 + z + 1) = 0 := by linear_combination h3
    rcases mul_eq_zero.mp h with hh | hh
    · exact absurd (sub_eq_zero.mp hh) h1
    · exact hh
  have hfac : (z - om) * (z - om ^ 2) = 0 := by
    linear_combination hz + (-z) * om_quad + om_pow_three
  rcases mul_eq_zero.mp hfac with hh | hh
  · exact Or.inl (sub_eq_zero.mp hh)
  · exact Or.inr (sub_eq_zero.mp hh)

/-- Counting via the weighted sums: `Σ_x D α x · D β (x+1) = 9 · #{x : χ(x)=α⁻¹, χ(x+1)=β⁻¹}`. -/
lemma weighted_count (hp : p % 3 = 1) (α β : ℂ) (hα : α ^ 3 = 1) (hβ : β ^ 3 = 1) :
    ∑ x : ZMod p, dsum p hp α x * dsum p hp β (x + 1)
      = 9 * (((Finset.univ.filter (fun x : ZMod p =>
          x ≠ 0 ∧ x + 1 ≠ 0 ∧ α * chi p hp x = 1 ∧ β * chi p hp (x + 1) = 1)).card : ℕ) : ℂ) := by
  classical
  set T := Finset.univ.filter (fun x : ZMod p =>
      x ≠ 0 ∧ x + 1 ≠ 0 ∧ α * chi p hp x = 1 ∧ β * chi p hp (x + 1) = 1) with hT
  have hterm : ∀ x : ZMod p,
      dsum p hp α x * dsum p hp β (x + 1) = if x ∈ T then 9 else 0 := by
    intro x
    by_cases hx0 : x = 0
    · subst hx0
      rw [dsum_zero p hp, zero_mul, if_neg (by simp [hT])]
    by_cases hx1 : x + 1 = 0
    · rw [hx1, dsum_zero p hp, mul_zero, if_neg (by simp [hT, hx1])]
    rw [dsum_eval p hp hα hx0, dsum_eval p hp hβ hx1]
    have hmem : x ∈ T ↔ (α * chi p hp x = 1 ∧ β * chi p hp (x + 1) = 1) := by
      simp only [hT, Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨fun h => ⟨h.2.2.1, h.2.2.2⟩, fun h => ⟨hx0, hx1, h.1, h.2⟩⟩
    by_cases hc1 : α * chi p hp x = 1
    · by_cases hc2 : β * chi p hp (x + 1) = 1
      · rw [if_pos hc1, if_pos hc2, if_pos (hmem.mpr ⟨hc1, hc2⟩)]; norm_num
      · rw [if_pos hc1, if_neg hc2, if_neg (fun h => hc2 (hmem.mp h).2)]; ring
    · rw [if_neg hc1, if_neg (fun h => hc1 (hmem.mp h).1)]; ring
  rw [Finset.sum_congr rfl (fun x _ => hterm x), Finset.sum_ite_mem, Finset.univ_inter,
    Finset.sum_const, nsmul_eq_mul]
  ring

/-! ### `om` arithmetic helpers -/

lemma om_sq_mul_om : om ^ 2 * om = 1 := by linear_combination om_pow_three
lemma om_mul_om_sq : om * om ^ 2 = 1 := by linear_combination om_pow_three
lemma om_sq_ne_one : om ^ 2 ≠ 1 := by
  intro h
  have h3 : om * om ^ 2 = om * 1 := by rw [h]
  rw [om_mul_om_sq, mul_one] at h3
  exact om_ne_one h3.symm
lemma om_sq_pow_three : (om ^ 2) ^ 3 = 1 := by
  rw [← pow_mul, mul_comm, pow_mul, om_pow_three, one_pow]
lemma om_sq_ne_zero : om ^ 2 ≠ 0 := pow_ne_zero 2 om_ne_zero

/-- `om^2 * z = 1 ↔ z = om`. -/
lemma om_sq_mul_eq_one_iff (z : ℂ) : om ^ 2 * z = 1 ↔ z = om := by
  constructor
  · intro h
    refine mul_left_cancel₀ om_sq_ne_zero ?_
    rw [h, om_sq_mul_om]
  · rintro rfl; exact om_sq_mul_om

/-- `om * z = 1 ↔ z = om^2`. -/
lemma om_mul_eq_one_iff (z : ℂ) : om * z = 1 ↔ z = om ^ 2 := by
  constructor
  · intro h
    refine mul_left_cancel₀ om_ne_zero ?_
    rw [h, om_mul_om_sq]
  · rintro rfl; exact om_mul_om_sq

/-- Membership in the Theorem-3 set, in terms of `chi x ∈ {om, om^2}`. -/
lemma thm3_mem' (hp : p % 3 = 1) (x : ZMod p) :
    ((¬ ∃ u : ZMod p, u ^ 3 = x) ∧ (¬ ∃ v : ZMod p, v ^ 3 = x + 1) ∧
      (∃ w : ZMod p, w ^ 3 = x * (x + 1)))
    ↔ ((x ≠ 0 ∧ x + 1 ≠ 0 ∧ chi p hp x = om ∧ chi p hp (x + 1) = om ^ 2) ∨
       (x ≠ 0 ∧ x + 1 ≠ 0 ∧ chi p hp x = om ^ 2 ∧ chi p hp (x + 1) = om)) := by
  rw [thm3_mem p hp x]
  constructor
  · rintro ⟨hx0, hx1, h1, h2, h3⟩
    have hcu : (chi p hp x) ^ 3 = 1 := chi_cube p hp hx0
    rcases cube_root_cases hcu h1 with hcase | hcase
    · left
      refine ⟨hx0, hx1, hcase, ?_⟩
      rw [hcase] at h3
      exact (om_mul_eq_one_iff _).mp h3
    · right
      refine ⟨hx0, hx1, hcase, ?_⟩
      rw [hcase] at h3
      exact (om_sq_mul_eq_one_iff _).mp h3
  · rintro (⟨hx0, hx1, hc1, hc2⟩ | ⟨hx0, hx1, hc1, hc2⟩)
    · exact ⟨hx0, hx1, by rw [hc1]; exact om_ne_one, by rw [hc2]; exact om_sq_ne_one,
        by rw [hc1, hc2]; exact om_mul_om_sq⟩
    · exact ⟨hx0, hx1, by rw [hc1]; exact om_sq_ne_one, by rw [hc2]; exact om_ne_one,
        by rw [hc1, hc2]; exact om_sq_mul_om⟩

/-! ### Theorem 3 -/

theorem card_noncube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
      Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1)))).card : Int) =
      2 * ((p : Int) + 1 + L) := by
  classical
  set A := Finset.univ.filter (fun x : ZMod p =>
      x ≠ 0 ∧ x + 1 ≠ 0 ∧ om ^ 2 * chi p hp x = 1 ∧ om * chi p hp (x + 1) = 1) with hA
  set B := Finset.univ.filter (fun x : ZMod p =>
      x ≠ 0 ∧ x + 1 ≠ 0 ∧ om * chi p hp x = 1 ∧ om ^ 2 * chi p hp (x + 1) = 1) with hB
  set C := Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
      Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1))) with hC
  -- A corresponds to chi x = om, chi (x+1) = om^2 ; B to the swapped case
  have hmemA : ∀ x : ZMod p, x ∈ A ↔
      (x ≠ 0 ∧ x + 1 ≠ 0 ∧ chi p hp x = om ∧ chi p hp (x + 1) = om ^ 2) := by
    intro x
    simp only [hA, Finset.mem_filter, Finset.mem_univ, true_and, om_sq_mul_eq_one_iff,
      om_mul_eq_one_iff]
  have hmemB : ∀ x : ZMod p, x ∈ B ↔
      (x ≠ 0 ∧ x + 1 ≠ 0 ∧ chi p hp x = om ^ 2 ∧ chi p hp (x + 1) = om) := by
    intro x
    simp only [hB, Finset.mem_filter, Finset.mem_univ, true_and, om_sq_mul_eq_one_iff,
      om_mul_eq_one_iff]
  have hdisj : Disjoint A B := by
    rw [Finset.disjoint_left]
    intro x hxA hxB
    rw [hmemA] at hxA; rw [hmemB] at hxB
    -- chi x = om and chi x = om^2 forces om = om^2, hence om = 1
    have heq : om = om ^ 2 := hxA.2.2.1.symm.trans hxB.2.2.1
    refine om_ne_one ?_
    -- from om = om^2 and om^3 = 1: om = om^2 = om^3/om... multiply heq by om
    have h1 : om * om = om * om ^ 2 := by rw [← heq]
    rw [om_mul_om_sq] at h1
    -- h1 : om * om = 1, i.e. om^2 = 1; combined with om^3 = 1 gives om = 1
    have h2 : om * (om * om) = om * 1 := by rw [h1]
    rw [← mul_assoc] at h2
    -- om * om * om = om^3 = 1
    have h3 : om * om * om = 1 := by linear_combination om_pow_three
    rw [h3, mul_one] at h2
    exact h2.symm
  have hCunion : C = A ∪ B := by
    ext x
    simp only [hC, Finset.mem_union, Finset.mem_filter, Finset.mem_univ, true_and]
    rw [show (Not (exists u : ZMod p, u ^ 3 = x) /\ Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1))) ↔ _ from thm3_mem' p hp x, hmemA x, hmemB x]
  have hcard : C.card = A.card + B.card := by
    rw [hCunion, Finset.card_union_of_disjoint hdisj]
  -- evaluate the two weighted sums
  have hsumA := weighted_count p hp (om ^ 2) om om_sq_pow_three om_pow_three
  have hsumB := weighted_count p hp om (om ^ 2) om_pow_three om_sq_pow_three
  rw [← hA] at hsumA
  rw [← hB] at hsumB
  have hevalA := master_weighted_om p hp L M hLM hL (om ^ 2) om om_sq_pow_three om_pow_three
    om_sq_mul_om om_sq_ne_one
  have hevalB := master_weighted_om p hp L M hLM hL om (om ^ 2) om_pow_three om_sq_pow_three
    om_mul_om_sq om_ne_one
  rw [hevalA] at hsumA
  rw [hevalB] at hsumB
  -- combine
  have hfin : ((9 * (C.card : ℤ) : ℤ) : ℂ) = ((2 * ((p : ℤ) + 1 + L) : ℤ) : ℂ) := by
    push_cast
    rw [hcard]
    push_cast
    linear_combination -hsumA - hsumB
  exact_mod_cast hfin

/-! ### Gauss sums (Theorem 5) -/

omit [Fact p.Prime] in
/-- The additive character used in Theorem 5 is `ZMod.stdAddChar`. -/
lemma exp_eq_stdAddChar [NeZero p] (j : ZMod p) :
    Complex.exp (2 * Real.pi * Complex.I * ((j).val : ℂ) / (p : ℂ)) = ZMod.stdAddChar j := by
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]

/-- `G = Σ_x ψ_a (x^3)` where `ψ_a` is the shifted standard additive character. -/
lemma G_eq_sum [NeZero p] (a : ZMod p) :
    (Finset.sum Finset.univ (fun x : ZMod p =>
      Complex.exp (2 * Real.pi * Complex.I * ((a * x ^ 3).val : Complex) / (p : Complex))))
    = ∑ x : ZMod p, (ZMod.stdAddChar.mulShift a) (x ^ 3) := by
  refine Finset.sum_congr rfl fun x _ => ?_
  rw [exp_eq_stdAddChar p (a * x ^ 3), AddChar.mulShift_apply]

/-- Rewriting `Σ_x ψ(x^3)` as a sum over values weighted by the number of cube roots. -/
lemma sum_cube_eq [NeZero p] (hp : p % 3 = 1) (ψ : AddChar (ZMod p) ℂ) :
    ∑ x : ZMod p, ψ (x ^ 3) = ∑ c : ZMod p, charSum p hp c * ψ c + 1 := by
  classical
  have hfib := sum_fiber (fun x : ZMod p => x ^ 3) (fun c => ψ c)
  rw [hfib]
  -- the cube-root count equals charSum except at c = 0
  have hsplit : ∀ c : ZMod p,
      ((Finset.univ.filter (fun x : ZMod p => x ^ 3 = c)).card : ℂ) * ψ c
        = charSum p hp c * ψ c + (if c = 0 then 1 else 0) := by
    intro c
    by_cases hc : c = 0
    · subst hc
      rw [charSum_zero p hp, zero_mul, if_pos rfl]
      have hzero : (Finset.univ.filter (fun x : ZMod p => x ^ 3 = (0 : ZMod p))) = {0} := by
        ext w
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
          pow_eq_zero_iff (n := 3) (by norm_num)]
      rw [hzero]
      simp [ψ.map_zero_eq_one]
    · rw [charSum_eq_nu p hp hc, if_neg hc, add_zero]
  rw [Finset.sum_congr rfl (fun c _ => hsplit c), Finset.sum_add_distrib]
  congr 1
  rw [Finset.sum_ite_eq' Finset.univ (0 : ZMod p) (fun _ => (1 : ℂ))]
  simp

/-- `Σ_c charSum c * ψ c = Σ_{j<3} gaussSum (chi^j) ψ`. -/
lemma charSum_gauss (hp : p % 3 = 1) (ψ : AddChar (ZMod p) ℂ) :
    ∑ c : ZMod p, charSum p hp c * ψ c
      = ∑ j ∈ Finset.range 3, gaussSum ((chi p hp) ^ j) ψ := by
  unfold charSum gaussSum
  rw [Finset.sum_congr rfl (fun c (_ : c ∈ Finset.univ) =>
    Finset.sum_mul (Finset.range 3) (fun j => ((chi p hp) ^ j) c) (ψ c))]
  exact Finset.sum_comm' (by simp)

/-- Gauss sum of the trivial multiplicative character with a nontrivial additive character. -/
lemma gaussSum_triv (ψ : AddChar (ZMod p) ℂ) (hψ : ψ ≠ 1) :
    gaussSum (1 : MulChar (ZMod p) ℂ) ψ = -1 := by
  rw [gaussSum]
  have h1 : ∀ a : ZMod p, (1 : MulChar (ZMod p) ℂ) a * ψ a = ψ a - (if a = 0 then 1 else 0) := by
    intro a
    by_cases ha : a = 0
    · subst ha; rw [MulChar.map_zero, zero_mul, if_pos rfl, ψ.map_zero_eq_one]; ring
    · rw [MulChar.one_apply (isUnit_iff_ne_zero.mpr ha), one_mul, if_neg ha]; ring
  rw [Finset.sum_congr rfl (fun a _ => h1 a), Finset.sum_sub_distrib,
    AddChar.sum_eq_zero_of_ne_one hψ, Finset.sum_ite_eq' Finset.univ (0 : ZMod p)]
  simp

/-- `G` equals the sum of the two nontrivial Gauss sums. -/
lemma G_eq_gauss [NeZero p] (hp : p % 3 = 1) (ψ : AddChar (ZMod p) ℂ) (hψ : ψ ≠ 1) :
    ∑ x : ZMod p, ψ (x ^ 3)
      = gaussSum (chi p hp) ψ + gaussSum ((chi p hp) ^ 2) ψ := by
  rw [sum_cube_eq p hp ψ, charSum_gauss p hp ψ]
  rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one, pow_zero, pow_one,
    gaussSum_triv p ψ hψ]
  ring

/-- `g(chi,ψ)^3 = p * J(chi,chi)`. -/
lemma gauss_cube (hp : p % 3 = 1) {ψ : AddChar (ZMod p) ℂ} (hψ : ψ.IsPrimitive) :
    gaussSum (chi p hp) ψ ^ 3 = (p : ℂ) * jacobiSum (chi p hp) (chi p hp) := by
  have hord : orderOf (chi p hp) = 3 := chi_orderOf p hp
  have h := gaussSum_pow_eq_prod_jacobiSum (χ := chi p hp) (ψ := ψ) (by rw [hord]; norm_num) hψ
  rw [hord] at h
  rw [h, chi_neg_one p hp, ZMod.card]
  norm_num

/-- `orderOf (chi^2) = 3`. -/
lemma chi_sq_orderOf (hp : p % 3 = 1) : orderOf ((chi p hp) ^ 2) = 3 := by
  have hord : orderOf (chi p hp) = 3 := chi_orderOf p hp
  have hd : orderOf ((chi p hp) ^ 2) ∣ 3 := by
    refine orderOf_dvd_of_pow_eq_one ?_
    rw [← pow_mul, mul_comm, pow_mul, chi_pow_three p hp, one_pow]
  rcases (Nat.prime_three.eq_one_or_self_of_dvd _ hd) with h | h
  · exact absurd (orderOf_eq_one_iff.mp h) (chi_sq_ne_one' p hp)
  · exact h

/-- `g(chi^2,ψ)^3 = p * J(chi^2,chi^2)`. -/
lemma gauss_sq_cube (hp : p % 3 = 1) {ψ : AddChar (ZMod p) ℂ} (hψ : ψ.IsPrimitive) :
    gaussSum ((chi p hp) ^ 2) ψ ^ 3 = (p : ℂ) * jacobiSum ((chi p hp) ^ 2) ((chi p hp) ^ 2) := by
  have hord : orderOf ((chi p hp) ^ 2) = 3 := chi_sq_orderOf p hp
  have h := gaussSum_pow_eq_prod_jacobiSum (χ := (chi p hp) ^ 2) (ψ := ψ)
    (by rw [hord]; norm_num) hψ
  rw [hord] at h
  rw [h, chi_pow_neg_one p hp 2, ZMod.card]
  norm_num

/-- `g(chi,ψ) * g(chi^2,ψ) = p`. -/
lemma gauss_mul (hp : p % 3 = 1) {ψ : AddChar (ZMod p) ℂ} (hψ : ψ.IsPrimitive) :
    gaussSum (chi p hp) ψ * gaussSum ((chi p hp) ^ 2) ψ = (p : ℂ) := by
  have hord : orderOf (chi p hp) = 3 := chi_orderOf p hp
  have h := gaussSum_mul_gaussSum_pow_orderOf_sub_one (chi_ne_one p hp) hψ
  rw [hord] at h
  norm_num at h
  rw [h, chi_neg_one p hp, one_mul]

/-! ### Theorem 5 -/

theorem cubic_sum (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1)
    (a : ZMod p) (ha : Not (a = 0)) (G : Complex)
    (hG : G = Finset.sum Finset.univ (fun x : ZMod p =>
      Complex.exp (2 * Real.pi * Complex.I * ((a * x ^ 3).val : Complex) / (p : Complex)))) :
    G ^ 3 = 3 * (p : Complex) * G + (p : Complex) * (L : Complex) := by
  haveI : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  -- the shifted additive character
  set ψ : AddChar (ZMod p) ℂ := ZMod.stdAddChar.mulShift a with hψdef
  have hψne1 : ψ ≠ 1 := by
    intro hone
    have h1 : ψ 1 = (1 : AddChar (ZMod p) ℂ) 1 := by rw [hone]
    rw [hψdef, AddChar.mulShift_apply, mul_one, AddChar.one_apply] at h1
    have h2 : (ZMod.stdAddChar : AddChar (ZMod p) ℂ) a
        = (ZMod.stdAddChar : AddChar (ZMod p) ℂ) 0 := by
      rw [h1, ZMod.stdAddChar.map_zero_eq_one]
    exact ha (ZMod.injective_stdAddChar (N := p) h2)
  have hψprim : ψ.IsPrimitive := AddChar.IsPrimitive.of_ne_one hψne1
  -- rewrite G
  rw [hG, G_eq_sum p a, G_eq_gauss p hp ψ hψne1]
  set g1 := gaussSum (chi p hp) ψ with hg1
  set g2 := gaussSum ((chi p hp) ^ 2) ψ with hg2
  have hc1 : g1 ^ 3 = (p : ℂ) * jacobiSum (chi p hp) (chi p hp) := gauss_cube p hp hψprim
  have hc2 : g2 ^ 3 = (p : ℂ) * jacobiSum ((chi p hp) ^ 2) ((chi p hp) ^ 2) :=
    gauss_sq_cube p hp hψprim
  have hm : g1 * g2 = (p : ℂ) := gauss_mul p hp hψprim
  rw [jacobi_sq_conj p hp] at hc2
  have htr := jacobi_trace p hp L M hLM hL
  -- (g1+g2)^3 = g1^3 + g2^3 + 3 g1 g2 (g1+g2)
  linear_combination hc1 + hc2 + (3 * (g1 + g2)) * hm + (p : ℂ) * htr

/-! ### Theorem 4 -/

/-- Existence of the representation `4p = L^2 + 27 M^2` with `L ≡ 1 mod 3`. -/
lemma rep_exists (hp : p % 3 = 1) :
    ∃ L M : ℤ, 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2 ∧ L % 3 = 1 := by
  obtain ⟨a, b, -, ha, hb, hnorm⟩ := jacobi_struct p hp
  obtain ⟨m, rfl⟩ : ∃ m, b = 3 * m := ⟨b / 3, by omega⟩
  exact ⟨2 * a - 3 * m, m, by linarith [hnorm], by omega⟩

omit [Fact p.Prime] in
lemma p_ne_two (hp : p % 3 = 1) : p ≠ 2 := by
  intro h; rw [h] at hp; norm_num at hp

lemma p_odd (hp : p % 3 = 1) : p % 2 = 1 := by
  rcases (Nat.Prime.eq_two_or_odd (Fact.out : p.Prime)) with h | h
  · exact absurd h (p_ne_two p hp)
  · exact h

lemma two_ne_zero_zmod (hp : p % 3 = 1) : (2 : ZMod p) ≠ 0 := by
  intro h
  have h2 : ((2 : ℕ) : ZMod p) = 0 := by push_cast; exact h
  have hdvd : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp h2
  have := (Nat.prime_dvd_prime_iff_eq (Fact.out : p.Prime) Nat.prime_two).mp hdvd
  exact p_ne_two p hp this

/-- Involution parity: a fixed-point-free involution on a finset forces even cardinality. -/
lemma even_of_involution {α : Type*} [DecidableEq α] (T : Finset α) (g : α → α)
    (hg : ∀ a ∈ T, g a ∈ T) (hinv : ∀ a ∈ T, g (g a) = a) (hnofix : ∀ a ∈ T, g a ≠ a) :
    2 ∣ T.card := by
  have h : ∑ _x ∈ T, (1 : ZMod 2) = 0 := by
    refine Finset.sum_involution (fun a _ => g a) (fun a ha => by decide) ?_ hg
      (fun a ha => hinv a ha)
    intro a ha _
    exact hnofix a ha
  rw [Finset.sum_const, nsmul_eq_mul, mul_one] at h
  exact (ZMod.natCast_eq_zero_iff T.card 2).mp h

/-- `2` is a cube iff `2⁻¹` is a cube. -/
lemma two_cube_iff_inv (hp : p % 3 = 1) :
    (∃ z : ZMod p, z ^ 3 = 2) ↔ (∃ z : ZMod p, z ^ 3 = (2 : ZMod p)⁻¹) := by
  have h2 : (2 : ZMod p) ≠ 0 := two_ne_zero_zmod p hp
  constructor
  · rintro ⟨z, hz⟩
    have hz0 : z ≠ 0 := by rintro rfl; rw [zero_pow (by norm_num)] at hz; exact h2 hz.symm
    exact ⟨z⁻¹, by rw [inv_pow, hz]⟩
  · rintro ⟨z, hz⟩
    have hinv0 : (2 : ZMod p)⁻¹ ≠ 0 := inv_ne_zero h2
    have hz0 : z ≠ 0 := by rintro rfl; rw [zero_pow (by norm_num)] at hz; exact hinv0 hz.symm
    exact ⟨z⁻¹, by rw [inv_pow, hz, inv_inv]⟩

/-- The fixed points of the swap involution on `{(x,y) : x^3+y^3=1}`. -/
lemma swap_fixed_card (hp : p % 3 = 1) :
    ((Finset.univ.filter (fun q : (ZMod p) × (ZMod p) =>
        q.1 ^ 3 + q.2 ^ 3 = 1 ∧ q.1 = q.2)).card)
      = (Finset.univ.filter (fun x : ZMod p => x ^ 3 = (2 : ZMod p)⁻¹)).card := by
  classical
  refine Finset.card_bij' (fun q _ => q.1) (fun x _ => (x, x)) ?_ ?_ ?_ ?_
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq ⊢
    obtain ⟨h1, h2⟩ := hq
    rw [← h2] at h1
    have h2' : (2 : ZMod p) * q.1 ^ 3 = 1 := by linear_combination h1
    exact eq_inv_of_mul_eq_one_left (by linear_combination h2')
  · intro x hx
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hx ⊢
    refine ⟨?_, trivial⟩
    have hne : (2 : ZMod p) ≠ 0 := two_ne_zero_zmod p hp
    have h2' : (2 : ZMod p) * x ^ 3 = 1 := by rw [hx, mul_inv_cancel₀ hne]
    linear_combination h2' 
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq
    exact Prod.ext rfl hq.2
  · intro x _; rfl

/-- Parity: `#T ≡ #Fix(g) mod 2` for an involution `g` on `T`. -/
lemma card_mod_two_eq_fix {α : Type*} [DecidableEq α] (T : Finset α) (g : α → α)
    (hg : ∀ a ∈ T, g a ∈ T) (hinv : ∀ a ∈ T, g (g a) = a) :
    (T.card : ZMod 2) = ((T.filter (fun a => g a = a)).card : ZMod 2) := by
  classical
  set F := T.filter (fun a => g a = a) with hF
  set S := T.filter (fun a => ¬ (g a = a)) with hS
  have hcard : F.card + S.card = T.card := by
    rw [hF, hS]; exact Finset.card_filter_add_card_filter_not _
  have hS2 : 2 ∣ S.card := by
    refine even_of_involution S g (fun a ha => ?_) (fun a ha => ?_) (fun a ha => ?_)
    · simp only [hS, Finset.mem_filter] at ha ⊢
      refine ⟨hg a ha.1, ?_⟩
      intro hcon
      exact ha.2 (by rw [← hinv a ha.1, hcon, hcon])
    · simp only [hS, Finset.mem_filter] at ha
      exact hinv a ha.1
    · simp only [hS, Finset.mem_filter] at ha
      exact ha.2
  obtain ⟨k, hk⟩ := hS2
  rw [← hcard, hk]
  push_cast
  rw [show ((2 : ZMod 2)) = 0 by decide]
  ring

/-- Applying the parity lemma to the swap involution on the Fermat-cubic set. -/
lemma cubic_parity (hp : p % 3 = 1) :
    (((Finset.univ.filter
        (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℕ) : ZMod 2)
      = (((Finset.univ.filter (fun x : ZMod p => x ^ 3 = (2 : ZMod p)⁻¹)).card : ℕ) : ZMod 2) := by
  classical
  set T := Finset.univ.filter (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1) with hT
  have hpar := card_mod_two_eq_fix T Prod.swap ?_ ?_
  · rw [hpar]
    congr 1
    rw [← swap_fixed_card p hp]
    congr 1
    ext q
    simp only [hT, Finset.mem_filter, Finset.mem_univ, true_and, Prod.ext_iff, Prod.swap]
    constructor
    · rintro ⟨h1, h2, h3⟩
      exact ⟨h1, h2.symm⟩
    · rintro ⟨h1, h2⟩
      exact ⟨h1, h2.symm, h2⟩
  · intro q hq
    simp only [hT, Finset.mem_filter, Finset.mem_univ, true_and] at hq ⊢
    rw [Prod.fst_swap, Prod.snd_swap]
    linear_combination hq
  · intro q _
    exact Prod.swap_swap q

/-- `2` is a cube iff `L` is even. -/
lemma two_cube_iff_L_even (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) :
    (∃ z : ZMod p, z ^ 3 = 2) ↔ L % 2 = 0 := by
  classical
  have hinv0 : (2 : ZMod p)⁻¹ ≠ 0 := inv_ne_zero (two_ne_zero_zmod p hp)
  have hfix := card_cube_roots p hp ((2 : ZMod p)⁻¹) hinv0
  have hpar := cubic_parity p hp
  rw [hfix] at hpar
  -- the total count is p - 2 + L
  have htotal := card_cubic p hp L M hLM hL
  -- reduce mod 2
  have hpodd : p % 2 = 1 := p_odd p hp
  rw [two_cube_iff_inv p hp]
  constructor
  · intro h
    rw [if_pos h] at hpar
    -- card ≡ 3 ≡ 1 mod 2
    have hcard2 : (((Finset.univ.filter
        (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℕ) : ZMod 2) = 1 := by
      rw [hpar]; decide
    -- so the card is odd
    have hodd : ¬ (2 ∣ ((Finset.univ.filter
        (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card)) := by
      intro hdvd
      rw [(ZMod.natCast_eq_zero_iff _ 2).mpr hdvd] at hcard2
      exact zero_ne_one hcard2
    -- translate to ℤ
    omega
  · intro hLeven
    by_contra hcon
    rw [if_neg hcon] at hpar
    have hcard2 : (((Finset.univ.filter
        (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : ℕ) : ZMod 2) = 0 := by
      rw [hpar]; decide
    have heven : 2 ∣ ((Finset.univ.filter
        (fun q : (ZMod p) × (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card) :=
      (ZMod.natCast_eq_zero_iff _ 2).mp hcard2
    omega

/-- `L` even iff `p = x^2 + 27 y^2` for some integers. -/
lemma L_even_iff_rep (hp : p % 3 = 1) (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2)
    (hL : L % 3 = 1) :
    L % 2 = 0 ↔ ∃ x y : ℤ, (p : ℤ) = x ^ 2 + 27 * y ^ 2 := by
  constructor
  · intro hLeven
    -- L even forces M even
    have hMeven : M % 2 = 0 := by
      rcases Int.emod_two_eq_zero_or_one M with h | h
      · exact h
      · exfalso
        obtain ⟨k, hk⟩ : ∃ k, L = 2 * k := ⟨L / 2, by omega⟩
        obtain ⟨j, hj⟩ : ∃ j, M = 2 * j + 1 := ⟨M / 2, by omega⟩
        subst hk; subst hj
        -- 4p = 4k² + 108j² + 108j + 27 ; LHS ≡ 0 mod 4 but RHS ≡ 3 mod 4
        have hexp : 4 * (p : ℤ) = 4 * k ^ 2 + 108 * j ^ 2 + 108 * j + 27 := by
          linear_combination hLM
        generalize k ^ 2 = K at hexp
        generalize j ^ 2 = J at hexp
        omega
    obtain ⟨x, hx⟩ : ∃ x, L = 2 * x := ⟨L / 2, by omega⟩
    obtain ⟨y, hy⟩ : ∃ y, M = 2 * y := ⟨M / 2, by omega⟩
    subst hx; subst hy
    exact ⟨x, y, by linarith [hLM]⟩
  · rintro ⟨x, y, hxy⟩
    have hpz3 : (p : ℤ) % 3 = 1 := by
      have : ((p % 3 : ℕ) : ℤ) = ((1 : ℕ) : ℤ) := by rw [hp]
      push_cast at this
      omega
    -- then 4p = (2x)^2 + 27 (2y)^2 ; and L is determined up to the mod-3 normalisation
    have h4 : 4 * (p : ℤ) = (2 * x) ^ 2 + 27 * (2 * y) ^ 2 := by linarith [hxy]
    -- normalise the sign of 2x so that it is ≡ 1 mod 3
    have h3 : (2 * x) % 3 ≠ 0 := by
      intro hdvd
      -- if 3 ∣ 2x then 3 ∣ x, so 9 ∣ x², and 4p = x'^2+27y'^2 forces 3 ∣ p
      obtain ⟨t, ht⟩ : ∃ t, x = 3 * t := ⟨x / 3, by omega⟩
      subst ht
      have hd3 : (3 : ℤ) ∣ 4 * (p : ℤ) := ⟨3 * t ^ 2 * 4 + 36 * y ^ 2, by linear_combination h4⟩
      have hp3 : (3 : ℤ) ∣ (p : ℤ) := by omega
      omega
    rcases Int.emod_two_eq_zero_or_one (2 * x) with hc | hc
    · -- choose the representative L' = ±2x with L' ≡ 1 mod 3
      have hcases : (2 * x) % 3 = 1 ∨ (2 * x) % 3 = 2 := by omega
      rcases hcases with h1 | h1
      · have := L_unique (Fact.out : p.Prime) hLM h4 hL h1
        omega
      · have h4' : 4 * (p : ℤ) = (-(2 * x)) ^ 2 + 27 * (2 * y) ^ 2 := by linarith [h4]
        have hneg : (-(2 * x)) % 3 = 1 := by omega
        have := L_unique (Fact.out : p.Prime) hLM h4' hL hneg
        omega
    · omega

theorem two_cube_iff (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) :
    (exists z : ZMod p, z ^ 3 = 2) <-> exists x y : Int, (p : Int) = x ^ 2 + 27 * y ^ 2 := by
  obtain ⟨L, M, hLM, hL⟩ := rep_exists p hp
  rw [two_cube_iff_L_even p hp L M hLM hL, L_even_iff_rep p hp L M hLM hL]

end TuringTask
