# TuringTask — Dirichlet divisor estimates in Lean 4

This project proves five statements about the divisor-counting function
`d(n) = #(Nat.divisors n)` and its summatory function `D(N) = ∑_{n ≤ N} d(n)`,
with explicit constants and limits involving the Euler–Mascheroni constant `γ`
(`Real.eulerMascheroniConstant`).

## The five theorems

All five live in `TuringTask/Basic.lean`, in namespace `TuringTask`, with
exactly the required statements:

1. `sum_card_divisors_sub_le` — for `N ≥ 1`,
   `|D(N) - N log N - (2γ-1) N| ≤ 4 √N`.
2. `sum_card_divisors_div_sub_le` — for `N ≥ 1`,
   `|∑_{n ≤ N} d(n)/n - (log N)²/2 - 2γ log N| ≤ 4`.
3. `tendsto_sum_card_divisors` — `(D(N) - N log N)/N → 2γ - 1`.
4. `tendsto_sum_card_divisors_sub_log` — `(1/N) ∑_{n ≤ N} (d(n) - log n) → 2γ`.
5. `tendsto_sum_sum_card_divisors` —
   `(1/N²)(∑_{n ≤ N} D(n) - N² log N / 2) → γ - 3/4`.

None of the proofs use `sorry`, `admit`, `native_decide`, or any new axiom.
`#print axioms` reports exactly `[propext, Classical.choice, Quot.sound]` for
each of the five (see `AxCheck.lean`).

## Project layout

| File | Contents |
| --- | --- |
| `TuringTask/Hyperbola.lean` | Lattice points `{(a,b) : a,b ≥ 1, ab ≤ N}`; the sets `hypN`, `hypL`, `hypR`; fibrewise sum formulas and the union/intersection decomposition used by Dirichlet's hyperbola method. |
| `TuringTask/Divisors.lean` | Fibring `hypN N` over the product `a*b` identifies the fibre over `n` with `n.divisorsAntidiagonal`. Gives `D(N) = ∑_{a ≤ N} ⌊N/a⌋` and the Dirichlet hyperbola identity `D(N) + K² = 2 ∑_{a ≤ K} ⌊N/a⌋` with `K = ⌊√N⌋`. |
| `TuringTask/Harmonic.lean` | `H N = ∑_{n ≤ N} 1/n`; two-sided bracketing `0 < H N - log N - γ ≤ 1/N`, derived from Mathlib's `eulerMascheroniSeq`/`eulerMascheroniSeq'`. |
| `TuringTask/Floor.lean` | Floor estimates; `∑_{a ≤ K} ⌊N/a⌋ = N·H K - E` with `0 ≤ E ≤ K - 1` (the sharper `K-1` uses that the `a = 1` term is exact). |
| `TuringTask/Thm1.lean` | Theorem 1. Two elementary real inequalities (`sqrt_ge_aux`, `main_ineq_aux`, proved by exact nonnegative decompositions) plus the hyperbola identity give `|D(N) - N log N - (2γ-1)N| ≤ 4√N`. |
| `TuringTask/LogSum.lean` | `G N = ∑_{a ≤ N} (log a)/a`. Sum–integral comparison against `∫ log x / x = (log x)²/2` on `[3, N]` (where `log x / x` is antitone) yields `|G N - (log N)²/2| ≤ 0.26`. |
| `TuringTask/Thm2.lean` | Theorem 2. The identity `∑_{n≤N} d(n)/n = ∑_{a≤N} (1/a) H(⌊N/a⌋)`, a per-term error bound `|H(⌊N/a⌋) - log(N/a) - γ| ≤ 1/⌊N/a⌋`, and the weighted total `∑_a (1/a)(1/⌊N/a⌋) ≤ 2`. |
| `TuringTask/Stirling.lean` | Elementary bracketing of `∑_{n ≤ N} log n` and `∑_{n ≤ N} n log n` by their integrals (monotone sum–integral comparison). |
| `TuringTask/Limits.lean` | Theorems 3, 4 and 5, each by a squeeze from the corresponding explicit estimate. |
| `TuringTask/Basic.lean` | The five required theorems, stated verbatim. |

## Proof outline

**Theorem 1.** Dirichlet's hyperbola method. Counting lattice points under
`ab ≤ N` in two ways with `K = ⌊√N⌋` gives `D(N) = 2∑_{a≤K}⌊N/a⌋ - K²`.
Substituting `∑_{a≤K}⌊N/a⌋ = N·H K - E` (`0 ≤ E ≤ K-1`) and
`H K = log K + γ + θ` (`0 < θ ≤ 1/K`) turns the target into

```
D(N) - N log N - (2γ-1)N  =  2Nθ - N·L - 2E + r
```

where `L = log N - 2 log K ≥ 0` and `r = N - K² ∈ [0, 2K]`. The upper bound
uses `N·L ≥ r` (from `log t ≥ 1 - 1/t`) and `2N/K ≤ 4√N`; the lower bound uses
`L ≤ r/K²` together with `√N ≥ K + r/(2K+2)`. Both reduce to polynomial
inequalities in `K` and `r` which are closed by explicit nonnegative
decompositions, so no numerical case analysis is needed.

**Theorem 2.** Expanding `d(n) = ∑_{ab=n} 1` gives
`∑_{n≤N} d(n)/n = ∑_{a≤N} (1/a)·H(⌊N/a⌋)`. Writing
`H(⌊N/a⌋) = log(N/a) + γ + e_a` with `|e_a| ≤ 1/⌊N/a⌋` and summing yields
`(log N + γ)·H N - G N + T` with `|T| ≤ 2`. Combining the harmonic bracketing
(`H N = log N + γ + t`, `0 < t ≤ 1/N`) with `|G N - (log N)²/2| ≤ 0.26` leaves
`γ² + (log N + γ)t - c + T`, bounded by `4` using `log N / N ≤ 1/2` and
`1/2 < γ < 2/3`.

**Theorems 3–5.** Each is a squeeze. Theorem 3 divides Theorem 1 by `N`
(error `4/√N → 0`). Theorem 4 additionally needs
`∑_{n≤N} log n = N log N - N + 1 + O(log N)`. Theorem 5 sums Theorem 1 over
`n ≤ N`, uses `∑_{n≤N} n log n = N² log N/2 - N²/4 + 1/4 + O(N log N)` and
`∑_{n≤N} 4√n ≤ 4N√N`, so the total error is `O(N^{3/2})`, which vanishes after
dividing by `N²`.

## Building (offline)

This project is configured for the **supplied offline Lean environment** and is
**not** self-contained on an arbitrary machine. It requires:

* Lean toolchain `leanprover/lean4:v4.33.0-rc1` (pinned in `lean-toolchain`);
* a prebuilt Mathlib at `/opt/mathlib4` (commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0`), referenced as a **local path
  dependency** in `lakefile.toml`.

From the project root:

```sh
lean-offline-init    # seeds .lake/packages with links to the installed deps
lake build           # builds all modules; finishes with no errors
```

`lean-offline-init` only performs local filesystem operations. No network
access, `lake update`, or cache download is required or performed.

To re-check the axioms of the five theorems:

```sh
lake env lean AxCheck.lean
```

which prints, for each theorem,
`depends on axioms: [propext, Classical.choice, Quot.sound]`.
