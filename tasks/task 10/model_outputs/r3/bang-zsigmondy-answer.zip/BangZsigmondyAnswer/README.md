# Bang-Zsigmondy Lean investigation

This project imports `Mathlib` and contains the strongest reduction I could
complete and verify offline without proof placeholders or additional axioms.

## Verified results

`Answer/ExistsPrimeSub.lean` proves:

* `primitive_prime_of_exact_order`: if `q` is prime, `q` does not divide `b`,
  and the order of `a / b` in `ZMod q` is exactly `n`, then `q` divides
  `a^n - b^n` and divides none of `a^k - b^k` for `1 <= k < n`.
* `primitive_prime_of_cyclotomic_root`: if additionally `q` does not divide
  `n` and `a / b` is a root of the `n`th cyclotomic polynomial in `ZMod q`,
  then `q` has exactly the properties required of the witness in
  `exists_prime_sub`.
* `exists_prime_sub_of_cyclotomic_witness`: the requested statement, with all
  of its original hypotheses and one explicit extra hypothesis containing the
  missing cyclotomic-prime witness.

The second theorem uses Mathlib's
`Polynomial.isRoot_cyclotomic_iff` to obtain exact multiplicative order. The
rest of the proof explicitly translates equality in `ZMod q` back to natural
number divisibility, including the truncated natural subtraction in the
question.

## Precise missing lemma

The requested theorem would follow immediately from this existence statement:

> If `b < a`, `1 <= b`, `Nat.Coprime a b`, and `2 <= n`, and neither stated
> exceptional case holds, then there is a prime `q` such that `q ∤ b`,
> `q ∤ n`, and `a / b : ZMod q` is a root of
> `Polynomial.cyclotomic n (ZMod q)`.

This is the substantive Bang-Zsigmondy existence theorem. In the classical
proof, the missing work is the integer-size and prime-divisor classification
for the homogenized cyclotomic value `Phi_n(a,b)`: a non-primitive prime factor
must come from the largest prime factor of `n`, followed by proving that this
cannot account for the whole cyclotomic value except when `n = 2` and `a+b` is
a power of two, or `(a,b,n) = (2,1,6)`. Mathlib supplies the cyclotomic/order
bridge used here, but no theorem implementing that existence and exceptional-
case classification was found in the supplied local Mathlib sources.

The exact requested statement is preserved as a comment at the end of the
Lean source, rather than being asserted without a proof.

## Offline verification

This project deliberately uses the supplied local Mathlib installation:

```toml
[[require]]
name = "mathlib"
path = "/opt/mathlib4"
```

In the supplied environment, verify directly with:

```sh
env -u LEAN_PATH lean Answer/ExistsPrimeSub.lean
env -u LEAN_PATH lean Answer.lean
```

For Lake, first run the local-only `lean-offline-init` helper, then
`lake build`. The `/opt/mathlib4` dependency means this archive is not
self-contained on an arbitrary machine; it requires the supplied Lean/Mathlib
environment or an equivalent local path installation.
