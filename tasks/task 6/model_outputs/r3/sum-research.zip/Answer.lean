import Mathlib

open scoped BigOperators

namespace SumResearch

/-- Sum of squares from `0` through `n`, in the natural numbers. -/
theorem sum_sq (n : ℕ) :
    ∑ k ∈ Finset.range (n + 1), k ^ 2 = n * (n + 1) * (2 * n + 1) / 6 := by
  have h : 6 * ∑ k ∈ Finset.range (n + 1), k ^ 2 =
      n * (n + 1) * (2 * n + 1) := by
    induction n with
    | zero => simp
    | succ n ih =>
        rw [Finset.sum_range_succ]
        nlinarith
  omega

/-- Triangular-number formula: sum of the naturals from `0` through `n`. -/
theorem sum_tri (n : ℕ) :
    ∑ k ∈ Finset.range (n + 1), k = n * (n + 1) / 2 := by
  simpa [Nat.add_sub_cancel, Nat.mul_comm] using Finset.sum_range_id (n + 1)

/-- Division-free sum-of-squares identity. -/
theorem sum_sq_scaled_succ (n : ℕ) :
    6 * ∑ k ∈ Finset.range (n + 1), k ^ 2 =
      n * (n + 1) * (2 * n + 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Finset.sum_range_succ]
      nlinarith

/-- Division-free triangular-number identity. -/
theorem sum_tri_scaled_succ (n : ℕ) :
    2 * ∑ k ∈ Finset.range (n + 1), k = n * (n + 1) := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Finset.sum_range_succ]
      nlinarith

/-- Equivalent formulas for `range n`, whose last index is `n - 1`. -/
theorem sum_sq_range (n : ℕ) :
    ∑ k ∈ Finset.range n, k ^ 2 = n * (n - 1) * (2 * n - 1) / 6 := by
  have h : 6 * ∑ k ∈ Finset.range n, k ^ 2 =
      n * (n - 1) * (2 * n - 1) := by
    cases n with
    | zero => simp
    | succ n =>
        have htwo : (n + 1) * 2 - 1 = n * 2 + 1 := by omega
        simpa [Nat.add_sub_cancel, htwo, Nat.mul_comm, Nat.mul_left_comm,
          Nat.mul_assoc] using sum_sq_scaled_succ n
  omega

theorem sum_tri_range (n : ℕ) :
    ∑ k ∈ Finset.range n, k = n * (n - 1) / 2 := by
  exact Finset.sum_range_id n

/-- If `sum_tri` instead means the sum of the first `n` triangular numbers. -/
theorem sum_of_triangular_numbers (n : ℕ) :
    ∑ k ∈ Finset.range (n + 1), k * (k + 1) / 2 =
      n * (n + 1) * (n + 2) / 6 := by
  have h : 6 * ∑ k ∈ Finset.range (n + 1), k * (k + 1) / 2 =
      n * (n + 1) * (n + 2) := by
    induction n with
    | zero => simp
    | succ n ih =>
        rw [Finset.sum_range_succ]
        have heven : 2 ∣ (n + 1) * (n + 2) := by
          exact Nat.dvd_iff_mod_eq_zero.mpr
            (Nat.even_iff.mp (Nat.even_mul_succ_self (n + 1)))
        have hdiv : (n + 1) * (n + 2) / 2 * 2 = (n + 1) * (n + 2) :=
          Nat.div_mul_cancel heven
        have hterm : 6 * ((n + 1) * (n + 2) / 2) =
            3 * ((n + 1) * (n + 2)) := by
          nlinarith
        rw [Nat.mul_add, ih]
        simp only [show n + 1 + 1 = n + 2 by omega,
          show n + 1 + 2 = n + 3 by omega]
        rw [hterm]
        ring
  omega

/-- The same inclusive sums over `Icc 1 n`. -/
private theorem sum_Icc_one_eq_sum_range_sq (n : ℕ) :
    ∑ k ∈ Finset.Icc 1 n, k ^ 2 = ∑ k ∈ Finset.range (n + 1), k ^ 2 := by
  apply Finset.sum_subset
  · intro k hk
    simp only [Finset.mem_Icc] at hk
    simp only [Finset.mem_range]
    omega
  · intro k hkRange hkIcc
    simp only [Finset.mem_range] at hkRange
    simp only [Finset.mem_Icc, not_and_or, not_le] at hkIcc
    rcases hkIcc with hkZero | hkTooLarge
    · have : k = 0 := by omega
      simp [this]
    · omega

private theorem sum_Icc_one_eq_sum_range_id (n : ℕ) :
    ∑ k ∈ Finset.Icc 1 n, k = ∑ k ∈ Finset.range (n + 1), k := by
  apply Finset.sum_subset
  · intro k hk
    simp only [Finset.mem_Icc] at hk
    simp only [Finset.mem_range]
    omega
  · intro k hkRange hkIcc
    simp only [Finset.mem_range] at hkRange
    simp only [Finset.mem_Icc, not_and_or, not_le] at hkIcc
    omega

theorem sum_sq_Icc (n : ℕ) :
    ∑ k ∈ Finset.Icc 1 n, k ^ 2 = n * (n + 1) * (2 * n + 1) / 6 := by
  rw [sum_Icc_one_eq_sum_range_sq]
  exact sum_sq n

theorem sum_tri_Icc (n : ℕ) :
    ∑ k ∈ Finset.Icc 1 n, k = n * (n + 1) / 2 := by
  rw [sum_Icc_one_eq_sum_range_id]
  exact sum_tri n

/-- Field-valued forms avoid natural-number division. -/
theorem sum_sq_real (n : ℕ) :
    ∑ k ∈ Finset.range (n + 1), (k : ℝ) ^ 2 =
      (n : ℝ) * (n + 1) * (2 * n + 1) / 6 := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Finset.sum_range_succ]
      push_cast
      nlinarith

theorem sum_tri_real (n : ℕ) :
    ∑ k ∈ Finset.range (n + 1), (k : ℝ) = (n : ℝ) * (n + 1) / 2 := by
  induction n with
  | zero => simp
  | succ n ih =>
      rw [Finset.sum_range_succ]
      push_cast
      nlinarith

end SumResearch
