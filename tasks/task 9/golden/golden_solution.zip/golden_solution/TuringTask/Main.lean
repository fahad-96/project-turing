import Mathlib
import TuringTask.Counts

/-!
# The five statements

The statements of the task, proved from the results of `Counts.lean` and `Jacobi3.lean`.
`Basic.lean` restates them under the required names.
-/

namespace TuringTask

theorem points_x3y3 (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : Int) =
      (p : Int) - 2 + L := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  have h := count_fermat_cubic hχ (L : ℂ) (jacobi_trace_eq hp hχ L M hLM hL)
  exact_mod_cast h

theorem nine_cube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : Int) =
      (p : Int) - 8 + L := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  have h := count_both_cubes hχ (L : ℂ) (jacobi_trace_eq hp hχ L M hLM hL)
  exact_mod_cast h

theorem nine_noncube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
      Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1)))).card : Int) =
      2 * ((p : Int) + 1 + L) := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  have h := count_noncube_pairs hχ (L : ℂ) (jacobi_trace_eq hp hχ L M hLM hL)
  exact_mod_cast h

theorem two_is_cube_iff (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) :
    (exists z : ZMod p, z ^ 3 = 2) <-> exists x y : Int, (p : Int) = x ^ 2 + 27 * y ^ 2 := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  obtain ⟨L, M, hL, hLM⟩ := exists_rep hp
  rw [two_cube_iff_even hχ L (points_x3y3 p hp L M hLM hL)]
  constructor
  · rintro ⟨l, rfl⟩
    have hM : Even (27 * M ^ 2) := ⟨2 * p - 2 * l ^ 2, by linear_combination (-1 : ℤ) * hLM⟩
    have h27 : ¬Even (27 : ℤ) := by decide
    obtain ⟨m, rfl⟩ := (Int.even_pow.mp ((Int.even_mul.mp hM).resolve_left h27)).1
    exact ⟨l, m, by linarith⟩
  · rintro ⟨x, y, hxy⟩
    have hx3 : x % 3 ≠ 0 := by
      intro h0
      obtain ⟨k, hk⟩ : (3 : ℤ) ∣ x := Int.dvd_of_emod_eq_zero h0
      have h3 : (3 : ℤ) ∣ (p : ℤ) := ⟨3 * k ^ 2 + 9 * y ^ 2, by rw [hxy, hk]; ring⟩
      omega
    obtain ⟨L', hL'3, hL'sq, hL'ev⟩ :
        ∃ L' : ℤ, L' % 3 = 1 ∧ L' ^ 2 = (2 * x) ^ 2 ∧ Even L' := by
      by_cases h2 : (2 * x) % 3 = 1
      · exact ⟨2 * x, h2, rfl, ⟨x, by ring⟩⟩
      · exact ⟨-(2 * x), by omega, by ring, ⟨-x, by ring⟩⟩
    have h4 : 4 * (p : ℤ) = L' ^ 2 + 27 * (2 * y) ^ 2 := by
      rw [hL'sq, hxy]
      ring
    rw [rep_eq_of_rep Fact.out L M L' (2 * y) hLM h4 hL hL'3]
    exact hL'ev

theorem cubic_gauss_cube (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1)
    (a : ZMod p) (ha : Not (a = 0)) (G : Complex)
    (hG : G = Finset.sum Finset.univ (fun x : ZMod p =>
      Complex.exp (2 * Real.pi * Complex.I * ((a * x ^ 3).val : Complex) / (p : Complex)))) :
    G ^ 3 = 3 * (p : Complex) * G + (p : Complex) * (L : Complex) := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  have hG' : G = ∑ x : ZMod p, ZMod.stdAddChar (a * x ^ 3) := by
    rw [hG]
    exact Finset.sum_congr rfl (fun x _ => (ZMod.toCircle_apply (a * x ^ 3)).symm)
  rw [hG']
  exact cubic_gauss_core hχ (L : ℂ) (jacobi_trace_eq hp hχ L M hLM hL) a ha

end TuringTask
