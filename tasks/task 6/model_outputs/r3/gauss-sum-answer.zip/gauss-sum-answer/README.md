# Quadratic Gauss Sum Identities

`Answer.lean` proves two complex exponential identities for an odd prime `p`:

- `GaussSumAnswer.sum_legendre`: rewrites the quadratic sum as the additive-character sum weighted by `legendreSym`.
- `GaussSumAnswer.sum_sq_mul`: multiplying the square by an integer `a` coprime to `p` multiplies the sum by `legendreSym p a`.

The sums are indexed by `ZMod p`, so every residue occurs exactly once. The displayed theorem statements use `Complex.exp`; the internal helper `quadraticGaussSum` uses Mathlib's equal standard additive character `ZMod.stdAddChar`.

The proof uses these installed Mathlib declarations:

- `quadraticChar_card_sqrts`
- `quadraticChar_sq_one`
- `ZMod.stdAddChar_apply`
- `ZMod.toCircle_apply`
- `ZMod.isPrimitive_stdAddChar`
- `AddChar.sum_mulShift`
- `Finset.sum_fiberwise`
- `Equiv.mulLeft₀`

## Offline verification

This project intentionally uses the supplied local Mathlib path `/opt/mathlib4`. In the provided environment, verify without network access:

```text
lean Answer.lean
```

Or seed Lake's local links and build:

```text
lean-offline-init
lake build
```

The archive is not self-contained on an arbitrary machine; it requires the supplied pinned Lean/Mathlib environment.
