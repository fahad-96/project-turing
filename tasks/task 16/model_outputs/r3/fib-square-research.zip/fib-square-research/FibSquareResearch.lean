import Mathlib

namespace FibSquare

/-- The Lucas number `L n`, represented in `Int` to avoid truncated subtraction. -/
def lucas (n : ℕ) : ℤ := 2 * Int.fib (n + 1) - Int.fib n

/-- `L_n^2 - 5 F_n^2 = 4 (-1)^n`. -/
theorem lucas_pell (n : ℕ) :
    lucas n ^ 2 - 5 * (Nat.fib n : ℤ) ^ 2 = 4 * (-1 : ℤ) ^ n := by
  have hc := Int.fib_add_sq_sub_fib_mul_fib_add_two_mul (n : ℤ) 1
  rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega] at hc
  rw [show (n : ℤ) + 2 * 1 = ((n + 2 : ℕ) : ℤ) by omega] at hc
  simp only [Int.fib_natCast, Int.fib_one, one_pow, Int.natAbs_natCast] at hc
  have hr : (Nat.fib (n + 2) : ℤ) =
      (Nat.fib n : ℤ) + Nat.fib (n + 1) := by
    rw [Nat.fib_add_two]
    omega
  rw [hr] at hc
  have hn : Int.fib (n + 1) = (Nat.fib (n + 1) : ℤ) := by
    rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega,
      Int.fib_natCast]
  have h0 : Int.fib n = (Nat.fib n : ℤ) := Int.fib_natCast n
  unfold lucas
  rw [hn, h0]
  nlinarith [hc]

theorem lucas_nonneg (n : ℕ) : 0 ≤ lucas n := by
  have hf := Nat.fib_le_fib_succ (n := n)
  have hn : Int.fib (n + 1) = (Nat.fib (n + 1) : ℤ) := by
    rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega,
      Int.fib_natCast]
  have h0 : Int.fib n = (Nat.fib n : ℤ) := Int.fib_natCast n
  unfold lucas
  rw [hn, h0]
  have hfz : (Nat.fib n : ℤ) ≤ (Nat.fib (n + 1) : ℤ) := by
    exact_mod_cast hf
  nlinarith [show (0 : ℤ) ≤ Nat.fib (n + 1) by positivity]

/-- The odd-index quartic theorem needed by the reduction. -/
def OddLjunggren : Prop :=
  ∀ (x : ℕ) (y : ℤ), 0 ≤ y → y ^ 2 + 4 = 5 * (x : ℤ) ^ 4 →
    x = 1 ∧ y = 1

/-- The even-index quartic theorem needed by the reduction. -/
def EvenLjunggren : Prop :=
  ∀ (x : ℕ) (y : ℤ), 0 ≤ y → y ^ 2 = 5 * (x : ℤ) ^ 4 + 4 →
    (x = 0 ∧ y = 2) ∨ (x = 1 ∧ y = 3) ∨ (x = 12 ∧ y = 322)

theorem fib_eq_one_index {n : ℕ} (h : Nat.fib n = 1) :
    n = 1 ∨ n = 2 := by
  have hpos : 0 < n := Nat.fib_pos.mp (by omega)
  have hlt : n < 3 := by
    by_contra hnot
    have hm := Nat.fib_mono (show 3 ≤ n by omega)
    norm_num [h] at hm
  omega

theorem fib_eq_144_index {n : ℕ} (h : Nat.fib n = 144) : n = 12 := by
  have hn : 2 ≤ n := by
    by_contra hnot
    have : n = 0 ∨ n = 1 := by omega
    rcases this with rfl | rfl <;> norm_num at h
  apply Nat.fib_strictMonoOn.injOn hn (by norm_num : 12 ∈ Set.Ici 2)
  simpa [h] using (show Nat.fib n = Nat.fib 12 by norm_num [h])

/--
The target Fibonacci classification, with the two exact Ljunggren quartic
classifications exposed as hypotheses. No finiteness assumption is made on
`n` or `x`.
-/
theorem classification_of_ljunggren
    (hodd : OddLjunggren) (heven : EvenLjunggren)
    {n x : ℕ} (h : Nat.fib n = x ^ 2) :
    n = 0 ∨ n = 1 ∨ n = 2 ∨ n = 12 := by
  have hcast : (Nat.fib n : ℤ) = (x : ℤ) ^ 2 := by
    exact_mod_cast h
  rcases Nat.even_or_odd n with hn | hn
  · have hp := lucas_pell n
    rw [hn.neg_one_pow] at hp
    have hq : lucas n ^ 2 = 5 * (x : ℤ) ^ 4 + 4 := by
      rw [hcast] at hp
      nlinarith [sq_nonneg ((x : ℤ) ^ 2)]
    rcases heven x (lucas n) (lucas_nonneg n) hq with hx | hx | hx
    · rcases hx with ⟨rfl, _⟩
      norm_num at h
      exact Or.inl h
    · rcases hx with ⟨rfl, _⟩
      rcases fib_eq_one_index h with rfl | rfl
      · exact Or.inr (Or.inl rfl)
      · exact Or.inr (Or.inr (Or.inl rfl))
    · rcases hx with ⟨rfl, _⟩
      right
      right
      right
      apply fib_eq_144_index
      norm_num at h ⊢
      exact h
  · have hp := lucas_pell n
    rw [hn.neg_one_pow] at hp
    have hq : lucas n ^ 2 + 4 = 5 * (x : ℤ) ^ 4 := by
      rw [hcast] at hp
      nlinarith [sq_nonneg ((x : ℤ) ^ 2)]
    obtain ⟨rfl, _⟩ := hodd x (lucas n) (lucas_nonneg n) hq
    rcases fib_eq_one_index h with rfl | rfl
    · exact Or.inr (Or.inl rfl)
    · exact ((show ¬Odd 2 by norm_num) hn).elim

end FibSquare
