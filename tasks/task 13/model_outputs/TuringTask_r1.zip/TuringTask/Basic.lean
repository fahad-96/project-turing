import Mathlib

open scoped Classical
open Polynomial
open ArithmeticFunction

namespace TuringTask

lemma map_resultant_int_to_complex (n m : ℕ) :
    algebraMap ℤ ℂ (resultant (cyclotomic n ℤ) (X ^ m - 1)) =
      resultant (cyclotomic n ℂ) (X ^ m - 1) := by
  have hinj : Function.Injective (algebraMap ℤ ℂ) := (algebraMap ℤ ℂ).injective_int
  have h1 : (cyclotomic n ℤ).map (algebraMap ℤ ℂ) = cyclotomic n ℂ := map_cyclotomic_int n ℂ
  have h2 : (X ^ m - 1 : ℤ[X]).map (algebraMap ℤ ℂ) = (X ^ m - 1 : ℂ[X]) := by simp
  have hdeg1 : (cyclotomic n ℂ).natDegree = (cyclotomic n ℤ).natDegree := by
    rw [← h1, natDegree_map_eq_of_injective hinj]
  have hdeg2 : (X ^ m - 1 : ℂ[X]).natDegree = (X ^ m - 1 : ℤ[X]).natDegree := by
    rw [← h2, natDegree_map_eq_of_injective hinj]
  have := (resultant_map_map (cyclotomic n ℤ) (X ^ m - 1 : ℤ[X]) (cyclotomic n ℤ).natDegree (X ^ m - 1 : ℤ[X]).natDegree (algebraMap ℤ ℂ)).symm
  rw [h1, h2] at this
  dsimp [resultant]
  rw [hdeg1, hdeg2]
  exact this

lemma resultant_cyclotomic_eval (n : ℕ) (hn : 1 ≤ n) (g : ℂ[X]) :
    resultant (cyclotomic n ℂ) g = ∏ ζ ∈ primitiveRoots n ℂ, g.eval ζ := by
  haveI : NeZero n := ⟨by lia⟩
  have hsplit : (cyclotomic n ℂ).Splits := IsAlgClosed.splits _
  have hmonic : (cyclotomic n ℂ).Monic := cyclotomic.monic n ℂ
  rw [resultant_eq_prod_eval _ _ _ le_rfl hsplit]
  simp [hmonic.leadingCoeff, cyclotomic.roots_eq_primitiveRoots_val]

lemma eval_one_cyclotomic_eq_prod (n : ℕ) (hn : 0 < n) :
    eval (1 : ℂ) (cyclotomic n ℂ) = ∏ μ ∈ primitiveRoots n ℂ, (1 - μ) := by
  haveI : NeZero n := ⟨hn.ne'⟩
  obtain ⟨ζ, hζ⟩ : ∃ ζ : ℂ, IsPrimitiveRoot ζ n := ⟨_, Complex.isPrimitiveRoot_exp n hn.ne'⟩
  rw [cyclotomic_eq_prod_X_sub_primitiveRoots hζ, eval_prod]
  simp

lemma map_eval_one_cyclotomic (k : ℕ) :
    algebraMap ℤ ℂ (eval 1 (cyclotomic k ℤ)) = eval 1 (cyclotomic k ℂ) := by
  have h := (eval₂_at_one (Int.castRingHom ℂ) (p := cyclotomic k ℤ)).symm
  rw [eval₂_eq_eval_map, map_cyclotomic_int] at h
  exact h

lemma prod_sub_one_eq_prod_one_sub (n m : ℕ) (hn : 3 ≤ n) :
    ∏ ζ ∈ primitiveRoots n ℂ, (ζ ^ m - 1) = ∏ ζ ∈ primitiveRoots n ℂ, (1 - ζ ^ m) := by
  haveI : NeZero n := ⟨by lia⟩
  have : (fun ζ : ℂ => ζ ^ m - 1) = fun ζ => -1 * (1 - ζ ^ m) := by ext; ring
  simp_rw [this, Finset.prod_mul_distrib, Finset.prod_const,
    (Complex.isPrimitiveRoot_exp n (by lia)).card_primitiveRoots]
  have heven : Even n.totient := Nat.totient_even (by lia)
  rw [heven.neg_one_pow, one_mul]

lemma prod_fiberwise_const {ι κ M : Type*} [CommMonoid M] [DecidableEq κ]
    (s : Finset ι) (t : Finset κ) (g : ι → κ) (f : κ → M) (C : ℕ)
    (h_maps : ∀ i ∈ s, g i ∈ t)
    (h_card : ∀ j ∈ t, (s.filter (g · = j)).card = C) :
    ∏ i ∈ s, f (g i) = (∏ j ∈ t, f j) ^ C := by
  rw [← Finset.prod_fiberwise_of_maps_to' h_maps]
  have : (fun j => ∏ i ∈ s with g i = j, f j) = fun j => f j ^ (s.filter (g · = j)).card := by
    ext j; rw [Finset.prod_const]
  simp_rw [this]
  have : (∏ j ∈ t, f j ^ (s.filter (g · = j)).card) = ∏ j ∈ t, f j ^ C :=
    Finset.prod_congr rfl (fun j hj => by rw [h_card j hj])
  rw [this, Finset.prod_pow]

lemma unitsMap_fiber_card {k n : ℕ} [NeZero n] [NeZero k] (h : k ∣ n)
    (v : (ZMod k)ˣ) :
    (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = v)).card = n.totient / k.totient := by
  have hsurj := ZMod.unitsMap_surjective h
  have heq : ∀ y : (ZMod k)ˣ, (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = y)).card =
      (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = v)).card := by
    intro y
    exact MonoidHom.card_fiber_eq_of_mem_range (ZMod.unitsMap h) (hsurj y) (hsurj v)
  have hsum : ∑ y : (ZMod k)ˣ, (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = y)).card =
      Fintype.card (ZMod n)ˣ := by
    rw [Fintype.card]
    symm
    exact Finset.card_eq_sum_card_fiberwise (fun _ _ => Finset.mem_univ _)
  have hsum2 : (∑ y : (ZMod k)ˣ, (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = v)).card) =
      k.totient * (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap h u = v)).card := by
    rw [Finset.sum_const, Finset.card_univ, ZMod.card_units_eq_totient]
    rfl
  rw [Finset.sum_congr rfl (fun y _ => heq y)] at hsum
  rw [hsum2, ZMod.card_units_eq_totient] at hsum
  have hk_pos : 0 < k.totient := Nat.totient_pos.2 (NeZero.pos k)
  exact Nat.eq_div_of_mul_eq_right hk_pos.ne' hsum

lemma mem_primitiveRoots_pow_unit {ζ : ℂ} {n : ℕ} [NeZero n]
    (hζ : IsPrimitiveRoot ζ n) (u : (ZMod n)ˣ) :
    ζ ^ (u : ZMod n).val ∈ primitiveRoots n ℂ := by
  rw [mem_primitiveRoots (NeZero.pos n)]
  exact hζ.pow_of_coprime (u : ZMod n).val (ZMod.val_coe_unit_coprime u)

lemma rootEquivUnits_injective {ζ : ℂ} {n : ℕ} [NeZero n]
    (hζ : IsPrimitiveRoot ζ n) :
    Function.Injective (fun u : (ZMod n)ˣ => (⟨ζ ^ (u : ZMod n).val, mem_primitiveRoots_pow_unit hζ u⟩ : primitiveRoots n ℂ)) := by
  intro u v h
  simp only [Subtype.mk.injEq] at h
  have heq := hζ.pow_inj (ZMod.val_lt (u : ZMod n)) (ZMod.val_lt (v : ZMod n)) h
  exact Units.ext ((ZMod.val_injective n) heq)

noncomputable def rootEquivUnits {ζ : ℂ} {n : ℕ} [NeZero n]
    (hζ : IsPrimitiveRoot ζ n) : (ZMod n)ˣ ≃ primitiveRoots n ℂ := by
  let f : (ZMod n)ˣ → primitiveRoots n ℂ := fun u => ⟨ζ ^ (u : ZMod n).val, mem_primitiveRoots_pow_unit hζ u⟩
  refine Equiv.ofBijective f ((Fintype.bijective_iff_injective_and_card f).2 ⟨rootEquivUnits_injective hζ, ?_⟩)
  rw [ZMod.card_units_eq_totient, Fintype.card_coe, hζ.card_primitiveRoots]

lemma isPrimitiveRoot_pow (n m : ℕ) (hn : 0 < n) (hm : 0 < m)
    {ζ : ℂ} (hζ : IsPrimitiveRoot ζ n) :
    IsPrimitiveRoot (ζ ^ m) (n / Nat.gcd n m) := by
  have hu : IsUnit ζ := hζ.isUnit hn.ne'
  lift ζ to ℂˣ using hu
  rw [IsPrimitiveRoot.coe_units_iff] at hζ
  rw [← Units.val_pow_eq_pow_val, IsPrimitiveRoot.coe_units_iff]
  rw [IsPrimitiveRoot.iff_orderOf] at hζ ⊢
  rw [orderOf_pow' ζ hm.ne', hζ]

lemma val_cast_eq {n k : ℕ} [NeZero n] [NeZero k] (a : ZMod n) :
    ((a.cast : ZMod k)).val = a.val % k := by
  rw [ZMod.cast_eq_val, ZMod.val_natCast]

lemma pow_eq_unitsMap {n m k : ℕ} [NeZero n] [NeZero k]
    {ζ : ℂ} (hη : IsPrimitiveRoot (ζ ^ m) k) (hdiv : k ∣ n) (u : (ZMod n)ˣ) :
    (ζ ^ (u : ZMod n).val) ^ m = (ζ ^ m) ^ ((ZMod.unitsMap hdiv u : ZMod k).val) := by
  rw [← pow_mul, mul_comm (u : ZMod n).val, pow_mul]
  have hmod : (u : ZMod n).val = (u : ZMod n).val % k + k * ((u : ZMod n).val / k) :=
    (Nat.mod_add_div (u : ZMod n).val k).symm
  have hpow : (ζ ^ m) ^ (k * ((u : ZMod n).val / k)) = 1 := by
    rw [pow_mul, hη.pow_eq_one, one_pow]
  have h1 : (ζ ^ m) ^ (u : ZMod n).val = (ζ ^ m) ^ ((u : ZMod n).val % k) := by
    conv_lhs => rw [hmod, pow_add, hpow, mul_one]
  have h2 : (ZMod.unitsMap hdiv u : ZMod k).val = (u : ZMod n).val % k := by
    rw [ZMod.unitsMap_val, val_cast_eq]
  rw [h1, h2]

lemma primitiveRoots_fiber_card_bij {n m k : ℕ} [NeZero n] [NeZero k]
    {ζ : ℂ} (hζ : IsPrimitiveRoot ζ n) (hη : IsPrimitiveRoot (ζ ^ m) k)
    (hdiv : k ∣ n) (v : (ZMod k)ˣ)
    (pow_eq : ∀ u : (ZMod n)ˣ, (rootEquivUnits hζ u : ℂ) ^ m = (rootEquivUnits hη (ZMod.unitsMap hdiv u) : ℂ)) :
    ((primitiveRoots n ℂ).filter (fun z => z ^ m = (rootEquivUnits hη v : ℂ))).card =
      (Finset.univ.filter (fun u : (ZMod n)ˣ => ZMod.unitsMap hdiv u = v)).card := by
  symm
  refine Finset.card_bij (fun u _ => (rootEquivUnits hζ u : ℂ)) ?_ ?_ ?_
  · intro u hu
    rw [Finset.mem_filter] at hu ⊢
    refine ⟨(rootEquivUnits hζ u).2, ?_⟩
    rw [pow_eq u, hu.2]
  · intro u1 hu1 u2 hu2 heq
    exact (rootEquivUnits hζ).injective (Subtype.ext heq)
  · intro z hz
    rw [Finset.mem_filter] at hz
    obtain ⟨u, hu⟩ := (rootEquivUnits hζ).surjective ⟨z, hz.1⟩
    refine ⟨u, ?_, ?_⟩
    · rw [Finset.mem_filter]
      refine ⟨Finset.mem_univ _, ?_⟩
      have : (rootEquivUnits hη (ZMod.unitsMap hdiv u) : ℂ) = (rootEquivUnits hη v : ℂ) := by
        rw [← pow_eq u, hu]
        exact hz.2
      exact (rootEquivUnits hη).injective (Subtype.ext this)
    · rw [hu]

lemma resultant_cyclotomic_X_pow_sub_one_aux (n m : ℕ) (hn : 3 ≤ n) (hm : 1 ≤ m)
    (_h : ¬ (m % n = 0)) :
    Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.X ^ m - 1) =
      Polynomial.eval 1 (Polynomial.cyclotomic (n / Nat.gcd n m) Int) ^
        (n.totient / (n / Nat.gcd n m).totient) := by
  apply (algebraMap ℤ ℂ).injective_int
  rw [map_resultant_int_to_complex, resultant_cyclotomic_eval n (by lia)]
  have heval : (fun ζ : ℂ => eval ζ (X ^ m - 1 : ℂ[X])) = fun ζ => ζ ^ m - 1 := by ext; simp
  rw [heval, prod_sub_one_eq_prod_one_sub n m hn]
  set k := n / Nat.gcd n m
  haveI : NeZero n := ⟨by lia⟩
  have hk_pos : 0 < k := by
    apply Nat.div_pos (Nat.gcd_le_left m (by lia)) (Nat.gcd_pos_of_pos_left m (by lia))
  haveI : NeZero k := ⟨hk_pos.ne'⟩
  have hdiv : k ∣ n := Nat.div_dvd_of_dvd (Nat.gcd_dvd_left n m)
  have hζ := Complex.isPrimitiveRoot_exp n (by lia)
  have hη := isPrimitiveRoot_pow n m (by lia) (by lia) hζ
  have hmaps : ∀ ζ ∈ primitiveRoots n ℂ, ζ ^ m ∈ primitiveRoots k ℂ := by
    intro ζ hζ_mem
    have hζ' := isPrimitiveRoot_of_mem_primitiveRoots hζ_mem
    rw [mem_primitiveRoots hk_pos]
    exact isPrimitiveRoot_pow n m (by lia) (by lia) hζ'
  have hcard : ∀ η ∈ primitiveRoots k ℂ, ((primitiveRoots n ℂ).filter (fun z => z ^ m = η)).card = n.totient / k.totient := by
    intro η hη_mem
    obtain ⟨v, hv⟩ := (rootEquivUnits hη).surjective ⟨η, hη_mem⟩
    have hv_eq : (rootEquivUnits hη v : ℂ) = η := by rw [hv]
    rw [← hv_eq]
    have pow_eq : ∀ u : (ZMod n)ˣ, (rootEquivUnits hζ u : ℂ) ^ m = (rootEquivUnits hη (ZMod.unitsMap hdiv u) : ℂ) := by
      intro u
      exact pow_eq_unitsMap hη hdiv u
    rw [primitiveRoots_fiber_card_bij hζ hη hdiv v pow_eq]
    exact unitsMap_fiber_card hdiv v
  rw [prod_fiberwise_const (primitiveRoots n ℂ) (primitiveRoots k ℂ) (fun z => z ^ m) (fun z => 1 - z)
    (n.totient / k.totient) hmaps hcard]
  rw [← eval_one_cyclotomic_eq_prod k hk_pos]
  rw [RingHom.map_pow, map_eval_one_cyclotomic]

lemma resultant_prod_cyclotomic (m : ℕ) (s : Finset ℕ) :
    resultant (cyclotomic m ℤ) (∏ d ∈ s, cyclotomic d ℤ) =
      ∏ d ∈ s, resultant (cyclotomic m ℤ) (cyclotomic d ℤ) := by
  have hlead : ∏ d ∈ s, (cyclotomic d ℤ).leadingCoeff ≠ 0 := by
    have : (∏ d ∈ s, (cyclotomic d ℤ).leadingCoeff) = 1 :=
      Finset.prod_eq_one fun d _ => (cyclotomic.monic d ℤ).leadingCoeff
    rw [this]
    exact one_ne_zero
  exact resultant_prod_right s (cyclotomic m ℤ) (fun d => cyclotomic d ℤ) (cyclotomic m ℤ).natDegree le_rfl hlead

lemma resultant_cyclotomic_X_pow_sub_one_eq_prod (m n : ℕ) (hn : 0 < n) :
    resultant (cyclotomic m ℤ) (X ^ n - 1) =
      ∏ d ∈ n.divisors, resultant (cyclotomic m ℤ) (cyclotomic d ℤ) := by
  rw [← prod_cyclotomic_eq_X_pow_sub_one hn ℤ, resultant_prod_cyclotomic]

lemma eq_of_prod_divisors_eq_lt (m : ℕ) (f g : ℕ → ℤ)
    (hg : ∀ d, 0 < d → d < m → g d ≠ 0)
    (h : ∀ n, 0 < n → n < m → ∏ d ∈ n.divisors, f d = ∏ d ∈ n.divisors, g d) :
    ∀ n, 0 < n → n < m → f n = g n := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    intro hn hnm
    have h1 := h n hn hnm
    rw [← Nat.cons_self_properDivisors hn.ne', Finset.prod_cons, Finset.prod_cons] at h1
    have hprod : ∏ d ∈ n.properDivisors, f d = ∏ d ∈ n.properDivisors, g d := by
      refine Finset.prod_congr rfl (fun d hd => ?_)
      have hd_pos : 0 < d := Nat.pos_of_mem_properDivisors hd
      have hd_lt : d < n := Nat.mem_properDivisors.1 hd |>.2
      exact ih d hd_lt hd_pos (hd_lt.trans hnm)
    rw [hprod] at h1
    have hne : ∏ d ∈ n.properDivisors, g d ≠ 0 := by
      refine Finset.prod_ne_zero_iff.2 (fun d hd => ?_)
      have hd_pos : 0 < d := Nat.pos_of_mem_properDivisors hd
      have hd_lt : d < n := Nat.mem_properDivisors.1 hd |>.2
      exact hg d hd_pos (hd_lt.trans hnm)
    exact mul_right_cancel₀ hne h1

noncomputable def expected_res (m n : ℕ) : ℤ :=
  if (∃ p k : ℕ, p.Prime ∧ 1 ≤ k ∧ m = n * p ^ k) then
    (if n = 1 ∧ m = 2 then -2 else ((m / n).minFac : ℤ) ^ n.totient)
  else 1

lemma expected_res_of_mul_prime_pow (n p k : ℕ) (hn : 1 ≤ n) (hp : p.Prime)
    (hk : 1 ≤ k) (h : ¬ (n = 1 ∧ p = 2 ∧ k = 1)) :
    expected_res (n * p ^ k) n = (p : ℤ) ^ n.totient := by
  dsimp [expected_res]
  have hex : ∃ q j : ℕ, q.Prime ∧ 1 ≤ j ∧ n * p ^ k = n * q ^ j := ⟨p, k, hp, hk, rfl⟩
  rw [if_pos hex]
  have hne : ¬ (n = 1 ∧ n * p ^ k = 2) := by
    rintro ⟨rfl, h2⟩
    rw [one_mul] at h2
    have hp2 : p = 2 := by
      have : p ∣ 2 := by rw [← h2]; exact dvd_pow_self p (by lia)
      exact (Nat.dvd_prime Nat.prime_two).1 this |>.resolve_left hp.ne_one
    subst hp2
    have hk1 : k = 1 := by
      cases k with
      | zero => lia
      | succ k =>
        cases k with
        | zero => rfl
        | succ k =>
          have : 2 ^ (k + 2) ≥ 4 := by
            have : 2 ^ (k + 2) = 2 ^ k * 4 := by ring
            lia
          lia
    exact h ⟨rfl, rfl, hk1⟩
  rw [if_neg hne]
  rw [Nat.mul_div_cancel_left _ (by lia)]
  rw [hp.pow_minFac (by lia)]

lemma expected_res_of_not_mul_prime_pow (m n : ℕ)
    (h : ∀ p k : ℕ, p.Prime → m ≠ n * p ^ k) :
    expected_res m n = 1 := by
  dsimp [expected_res]
  have hnot : ¬ (∃ p k : ℕ, p.Prime ∧ 1 ≤ k ∧ m = n * p ^ k) := by
    rintro ⟨p, k, hp, hk, heq⟩
    exact h p k hp heq
  rw [if_neg hnot]

lemma isCoprime_of_resultant_eq_expected (m n : ℕ) (hn : 1 ≤ n) (hnm : n < m)
    (hres : Polynomial.resultant (Polynomial.cyclotomic m ℤ) (Polynomial.cyclotomic n ℤ) = expected_res m n) :
    IsCoprime (Polynomial.cyclotomic m ℤ) (Polynomial.cyclotomic n ℤ) ↔
      ∀ p k : ℕ, p.Prime → m ≠ n * p ^ k := by
  rw [← Polynomial.isUnit_resultant_iff_isCoprime (Polynomial.cyclotomic.monic m ℤ)]
  rw [hres]
  dsimp [expected_res]
  split_ifs with h1 h2
  · simp only [Int.isUnit_iff]
    constructor
    · rintro (h | h) <;> lia
    · intro h
      obtain ⟨p, k, hp, hk, heq⟩ := h1
      exact False.elim (h p k hp heq)
  · obtain ⟨p, k, hp, hk, heq⟩ := h1
    simp only [Int.isUnit_iff]
    constructor
    · rintro (hu | hu)
      · have hpos : ((m / n).minFac : ℤ) ^ n.totient ≥ 2 := by
          have hdiv : m / n = p ^ k := by rw [heq, Nat.mul_div_cancel_left _ (by lia)]
          have hp_ge : (m / n).minFac = p := by rw [hdiv, hp.pow_minFac (by lia)]
          have hp2 : p ≥ 2 := hp.two_le
          have htot_pos : 1 ≤ n.totient := Nat.totient_pos.2 (by lia)
          have h_nat : p ^ n.totient ≥ 2 := by
            have : p ^ n.totient ≥ p := Nat.le_self_pow (by lia) p
            lia
          rw [hp_ge]
          exact_mod_cast h_nat
        lia
      · have : ((m / n).minFac : ℤ) ^ n.totient ≥ 0 := by positivity
        lia
    · intro h
      exact False.elim (h p k hp heq)
  · simp only [isUnit_one, true_iff]
    intro p k hp heq
    apply h1
    refine ⟨p, k, hp, ?_, heq⟩
    by_contra hk
    have : k = 0 := by lia
    subst this
    simp at heq
    lia

lemma expected_res_eq_one_of_not_prime_pow (m n : ℕ)
    (hnot : ∀ p a : ℕ, p.Prime → m / Nat.gcd m n ≠ p ^ a)
    (d : ℕ) (hd : d ∈ n.divisors) :
    expected_res m d = 1 := by
  dsimp [expected_res]
  have hnot_div : ¬ (∃ p k : ℕ, p.Prime ∧ 1 ≤ k ∧ m = d * p ^ k) := by
    rintro ⟨p, k, hp, hk, heq⟩
    have hd_dvd_m : d ∣ m := ⟨p ^ k, heq⟩
    have hd_dvd_n : d ∣ n := Nat.dvd_of_mem_divisors hd
    have hd_dvd_gcd : d ∣ Nat.gcd m n := Nat.dvd_gcd hd_dvd_m hd_dvd_n
    have hgcd_dvd_m : Nat.gcd m n ∣ m := Nat.gcd_dvd_left m n
    have hdpos : 0 < d := Nat.pos_of_mem_divisors hd
    have h_dvd : m / Nat.gcd m n ∣ p ^ k := by
      obtain ⟨c, hc⟩ := hd_dvd_gcd
      have hm_eq : m = (m / Nat.gcd m n * c) * d := by
        rw [mul_assoc, mul_comm c d, ← hc, Nat.div_mul_cancel hgcd_dvd_m]
      have h_prod : p ^ k * d = (m / Nat.gcd m n * c) * d := by
        rw [← hm_eq, heq, mul_comm]
      have : p ^ k = m / Nat.gcd m n * c := Nat.eq_of_mul_eq_mul_right hdpos h_prod
      exact ⟨c, this⟩
    obtain ⟨a, -, ha⟩ := (Nat.dvd_prime_pow hp).1 h_dvd
    exact hnot p a hp ha
  rw [if_neg hnot_div]

lemma sum_totient_prime_pow_mul (u p e : ℕ) (hp : p.Prime) (hpu : ¬ p ∣ u) :
    (∑ i ∈ Finset.range (e + 1), (p ^ i * u).totient) = p ^ e * u.totient := by
  have hcop : ∀ i, (p ^ i).Coprime u := fun i => (hp.coprime_iff_not_dvd.2 hpu).pow_left i
  have htot : ∀ i, (p ^ i * u).totient = (p ^ i).totient * u.totient :=
    fun i => Nat.totient_mul (hcop i)
  simp_rw [htot, ← Finset.sum_mul]
  have hsum : (∑ i ∈ Finset.range (e + 1), (p ^ i).totient) = p ^ e := by
    have := (Nat.sum_divisors_prime_pow (k := e) (f := Nat.totient) hp).symm
    rw [Nat.sum_totient (p ^ e)] at this
    exact this
  rw [hsum]

lemma totient_mul_prime_pow_div (u p e a : ℕ) (hp : p.Prime) (hpu : ¬ p ∣ u) (ha : 1 ≤ a) :
    (u * p ^ (e + a)).totient / (p ^ a).totient = u.totient * p ^ e := by
  have hcop : u.Coprime (p ^ (e + a)) := ((hp.coprime_iff_not_dvd.2 hpu).pow_left (e + a)).symm
  rw [Nat.totient_mul hcop]
  have hfact : (p ^ (e + a)).totient = (p ^ a).totient * p ^ e := by
    rw [Nat.totient_prime_pow hp (by lia), Nat.totient_prime_pow hp ha]
    have : e + a - 1 = a - 1 + e := by lia
    rw [this, pow_add, mul_assoc, mul_comm (p ^ e), ← mul_assoc]
  rw [hfact, ← mul_assoc, mul_comm u.totient, mul_assoc]
  have hpos : 0 < (p ^ a).totient := Nat.totient_pos.2 (pow_pos hp.pos a)
  exact Nat.mul_div_cancel_left _ hpos

lemma discr_cyclotomic_one :
    Polynomial.discr (Polynomial.cyclotomic 1 ℤ) *
        (1 : ℕ).primeFactors.prod (fun p => (p : ℤ) ^ ((1 : ℕ).totient / (p - 1))) =
      (-1) ^ ((1 : ℕ).totient / 2) * (1 : ℤ) ^ (1 : ℕ).totient := by
  have hd : (Polynomial.cyclotomic 1 ℤ).degree = 1 := by
    rw [Polynomial.cyclotomic_one]
    exact Polynomial.degree_X_sub_C 1
  rw [Polynomial.discr_of_degree_eq_one hd]
  simp

lemma discr_cyclotomic_two :
    Polynomial.discr (Polynomial.cyclotomic 2 ℤ) *
        (2 : ℕ).primeFactors.prod (fun p => (p : ℤ) ^ ((2 : ℕ).totient / (p - 1))) =
      (-1) ^ ((2 : ℕ).totient / 2) * (2 : ℤ) ^ (2 : ℕ).totient := by
  have hd : (Polynomial.cyclotomic 2 ℤ).degree = 1 := by
    rw [Polynomial.cyclotomic_two]
    exact Polynomial.degree_X_add_C 1
  rw [Polynomial.discr_of_degree_eq_one hd]
  have hp : (2 : ℕ).primeFactors = {2} := by
    change (2 : ℕ).factorization.support = {2}
    rw [Nat.Prime.factorization Nat.prime_two]
    exact Finsupp.support_single 2 one_ne_zero
  rw [hp]
  simp

lemma discr_sign_identity (k : ℕ) :
    (-1 : ℤ) ^ (2 * k * (2 * k - 1) / 2) * (-1 : ℤ) ^ k = 1 := by
  have : 2 * k * (2 * k - 1) / 2 = k * (2 * k - 1) := by
    rw [mul_assoc, Nat.mul_div_cancel_left _ (by lia)]
  rw [this, ← pow_add]
  have : k * (2 * k - 1) + k = 2 * k ^ 2 := by
    cases k with
    | zero => rfl
    | succ k => lia
  rw [this]
  have heven : Even (2 * k ^ 2) := even_two_mul (k ^ 2)
  exact heven.neg_one_pow

lemma natDegree_derivative_int {p : ℤ[X]} (hp : p.natDegree ≠ 0) :
    p.derivative.natDegree = p.natDegree - 1 :=
  natDegree_eq_of_degree_eq_some (degree_derivative hp)

lemma discr_deriv_eq (n : ℕ) (hn : 3 ≤ n) :
    resultant (cyclotomic n ℤ) (cyclotomic n ℤ).derivative =
      (-1) ^ (n.totient * (n.totient - 1) / 2) * discr (cyclotomic n ℤ) := by
  have hd : 0 < (cyclotomic n ℤ).degree := by
    rw [degree_eq_natDegree (cyclotomic_ne_zero n ℤ)]
    have : 0 < (cyclotomic n ℤ).natDegree := by
      rw [natDegree_cyclotomic]
      exact Nat.totient_pos.2 (by lia)
    exact WithBot.coe_pos.2 this
  have hmonic : (cyclotomic n ℤ).Monic := cyclotomic.monic n ℤ
  have hdeg : (cyclotomic n ℤ).natDegree = n.totient := natDegree_cyclotomic n ℤ
  have hres := resultant_deriv hd
  rw [hmonic.leadingCoeff, mul_one, hdeg] at hres
  have hdeg_deriv : (cyclotomic n ℤ).derivative.natDegree = (cyclotomic n ℤ).natDegree - 1 := by
    apply natDegree_derivative_int
    rw [hdeg]
    exact (Nat.totient_pos.2 (by lia)).ne'
  dsimp [resultant]
  rw [hdeg_deriv, hdeg]
  exact hres

lemma expected_res_eq_pow (m d p j : ℕ) (hp : p.Prime) (hj : 1 ≤ j) (hm_eq : m = d * p ^ j) (hm3 : 3 ≤ m) :
    expected_res m d = (p : ℤ) ^ d.totient := by
  have hd_pos : 1 ≤ d := by
    by_contra hd0
    have : d = 0 := by lia
    subst this
    rw [zero_mul] at hm_eq
    lia
  have hnot_12 : ¬ (d = 1 ∧ p = 2 ∧ j = 1) := by
    rintro ⟨rfl, rfl, rfl⟩
    rw [one_mul, pow_one] at hm_eq
    lia
  rw [hm_eq]
  exact expected_res_of_mul_prime_pow d p j hd_pos hp hj hnot_12

lemma expected_res_eq_pow_or_one (m d : ℕ) (hm : 3 ≤ m) :
    expected_res m d = 1 ∨
      ∃ p k : ℕ, p.Prime ∧ 1 ≤ k ∧ m = d * p ^ k ∧ expected_res m d = (p : ℤ) ^ d.totient := by
  dsimp [expected_res]
  split_ifs with h1 h2
  · lia
  · obtain ⟨p, k, hp, hk, heq⟩ := h1
    right
    have hd_pos : 0 < d := by
      have : d ≠ 0 := by rintro rfl; rw [zero_mul] at heq; lia
      lia
    refine ⟨p, k, hp, hk, heq, ?_⟩
    rw [heq, Nat.mul_div_cancel_left _ hd_pos, hp.pow_minFac (by lia)]
  · left; rfl

lemma expected_res_ne_zero (m d : ℕ) (hm : 2 ≤ m) : expected_res m d ≠ 0 := by
  rcases eq_or_lt_of_le hm with rfl | hm3
  · dsimp [expected_res]
    split_ifs with h1 h2
    · lia
    · obtain ⟨p, k, hp, hk, heq⟩ := h1
      have hpk : 2 ≤ p ^ k := by
        have : 2 ≤ p := hp.two_le
        have : p ≤ p ^ k := Nat.le_self_pow (by lia) p
        lia
      have hd_pos : 0 < d := by
        have : d ≠ 0 := by rintro rfl; rw [zero_mul] at heq; lia
        lia
      have hd1 : d = 1 := by nlinarith
      exact False.elim (h2 ⟨hd1, rfl⟩)
    · exact one_ne_zero
  · rcases expected_res_eq_pow_or_one m d hm3 with h1 | ⟨p, k, hp, hk, heq, h2⟩
    · rw [h1]; exact one_ne_zero
    · rw [h2]
      have : (p : ℤ) ≠ 0 := by
        have : p ≥ 2 := hp.two_le
        lia
      exact pow_ne_zero _ this

lemma res_two_one :
    resultant (cyclotomic 2 ℤ) (X ^ 1 - 1) = -2 := by
  have h1 : cyclotomic 2 ℤ = X + 1 := cyclotomic_two ℤ
  have h2 : (X ^ 1 - 1 : ℤ[X]) = X - 1 := by ring
  rw [resultant, h1, h2]
  have hd1 : (X + 1 : ℤ[X]).natDegree = 1 := natDegree_X_add_C 1
  have hd2 : (X - 1 : ℤ[X]).natDegree = 1 := natDegree_X_sub_C 1
  rw [hd1, hd2]
  have := resultant_X_add_C_left (X - 1 : ℤ[X]) 1 (1 : ℤ) hd2.le
  rw [map_one, resultant] at this
  rw [this]
  simp

lemma expected_res_two_one : expected_res 2 1 = -2 := by
  dsimp [expected_res]
  have hex : ∃ p k : ℕ, p.Prime ∧ 1 ≤ k ∧ 2 = 1 * p ^ k := ⟨2, 1, Nat.prime_two, by lia, by ring⟩
  rw [if_pos hex]

lemma j_le_add (u p e a j : ℕ) (hp : p.Prime) (hpu : ¬ p ∣ u) (hdiv : p ^ j ∣ u * p ^ (e + a)) :
    j ≤ e + a := by
  have hu_pos : u ≠ 0 := by rintro rfl; exact hpu (dvd_zero p)
  have hcop : (p ^ j).Coprime u := (hp.coprime_iff_not_dvd.2 hpu).pow_left j
  have hdvd : p ^ j ∣ p ^ (e + a) := by
    rw [mul_comm] at hdiv
    exact hcop.dvd_of_dvd_mul_right hdiv
  exact (Nat.pow_dvd_pow_iff_le_right hp.one_lt).1 hdvd

lemma resultant_cyclotomic_eq_expected (m n : ℕ) (hn : 1 ≤ n) (hnm : n < m) :
    Polynomial.resultant (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic n Int) = expected_res m n := by
  have hm : 2 ≤ m := by lia
  apply eq_of_prod_divisors_eq_lt m
    (fun d => Polynomial.resultant (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic d Int))
    (expected_res m) (fun d hd hdm => expected_res_ne_zero m d hm) _ n hn hnm
  intro k hk hkm
  rw [← resultant_cyclotomic_X_pow_sub_one_eq_prod m k hk]
  rcases eq_or_lt_of_le hm with rfl | hm3
  · have : k = 1 := by lia
    subst this
    have : (1 : ℕ).divisors = {1} := rfl
    rw [this, Finset.prod_singleton, res_two_one, expected_res_two_one]
  · have hkm_mod : ¬ (k % m = 0) := by
      rw [Nat.mod_eq_of_lt hkm]
      lia
    rw [resultant_cyclotomic_X_pow_sub_one_aux m k hm3 hk hkm_mod]
    set g := Nat.gcd m k
    set q := m / g
    by_cases hnot : ∀ p a : ℕ, p.Prime → q ≠ p ^ a
    · have h1 : eval 1 (cyclotomic q ℤ) = 1 :=
        eval_one_cyclotomic_not_prime_pow (fun hp r heq => hnot _ _ hp heq.symm)
      rw [h1, one_pow]
      have h2 : ∀ d ∈ k.divisors, expected_res m d = 1 :=
        expected_res_eq_one_of_not_prime_pow m k hnot
      rw [Finset.prod_congr rfl h2, Finset.prod_const_one]
    · push Not at hnot
      obtain ⟨p, a, hp, heq⟩ := hnot
      have ha : 1 ≤ a := by
        by_contra ha0
        have : a = 0 := by lia
        subst this
        simp only [pow_zero] at heq
        have hg_eq : g = m := by
          have hdiv : g ∣ m := Nat.gcd_dvd_left m k
          have : m = g * q := by rw [mul_comm, Nat.div_mul_cancel hdiv]
          rw [this, heq, mul_one]
        have hle : m ≤ k := by rw [← hg_eq]; exact Nat.gcd_le_right m hk
        lia
      have heval : eval 1 (cyclotomic q ℤ) = p := by
        rw [heq]
        have : p ^ a = p ^ (a - 1 + 1) := by
          congr 1; lia
        rw [this]
        have : Fact (Nat.Prime p) := ⟨hp⟩
        exact eval_one_cyclotomic_prime_pow (a - 1)
      rw [heval]
      set e := g.factorization p
      set u := ordCompl[p] g
      have hgpos : 0 < g := Nat.gcd_pos_of_pos_left k (by lia)
      have hpu : ¬ p ∣ u := Nat.not_dvd_ordCompl hp hgpos.ne'
      have hg_eq : g = u * p ^ e := by
        have : ordProj[p] g * ordCompl[p] g = g := Nat.ordProj_mul_ordCompl_eq_self g p
        have hpj : ordProj[p] g = p ^ e := rfl
        rw [← this, hpj, mul_comm]
      have hm_eq : m = u * p ^ (e + a) := by
        have hq_m : m = g * q := by rw [mul_comm, Nat.div_mul_cancel (Nat.gcd_dvd_left m k)]
        rw [hq_m, hg_eq, heq, mul_assoc, ← pow_add]
      have h_tot : m.totient / q.totient = p ^ e * u.totient := by
        rw [heq, hm_eq, totient_mul_prime_pow_div u p e a hp hpu ha, mul_comm]
      rw [h_tot]
      have h_div_subset : ∀ d ∈ k.divisors, expected_res m d ≠ 1 →
          ∃ i ∈ Finset.range (e + 1), d = p ^ i * u := by
        intro d hd hne1
        have hdpos : 0 < d := Nat.pos_of_mem_divisors hd
        rcases expected_res_eq_pow_or_one m d hm3 with h1 | ⟨p', j, hp', hj, heq_m, -⟩
        · exact False.elim (hne1 h1)
        · have hd_dvd_m : d ∣ m := ⟨p' ^ j, heq_m⟩
          have hd_dvd_k : d ∣ k := Nat.dvd_of_mem_divisors hd
          have hd_dvd_g : d ∣ g := Nat.dvd_gcd hd_dvd_m hd_dvd_k
          have h_dvd : q ∣ p' ^ j := by
            obtain ⟨c, hc⟩ := hd_dvd_g
            have hm_g : m = (m / g * c) * d := by
              rw [mul_assoc, mul_comm c d, ← hc, Nat.div_mul_cancel (Nat.gcd_dvd_left m k)]
            have : p' ^ j * d = (m / g * c) * d := by
              rw [← hm_g, heq_m, mul_comm]
            have : m / g * c = p' ^ j := Nat.eq_of_mul_eq_mul_right hdpos (by rw [← this])
            have : q * c = p' ^ j := by
              change m / g * c = p' ^ j
              exact this
            exact ⟨c, this.symm⟩
          rw [heq] at h_dvd
          have hp'_p : p' = p := by
            have : p ∣ p' ^ j := (dvd_pow_self p (by lia)).trans h_dvd
            exact (hp'.dvd_iff_eq hp.ne_one).1 (hp.dvd_of_dvd_pow this)
          rw [hp'_p] at heq_m h_dvd
          have hj_ge : a ≤ j := by
            have h_le := Nat.le_of_dvd (pow_pos hp.pos j) h_dvd
            exact (Nat.pow_le_pow_iff_right hp.one_lt).1 h_le
          have hd_val : d = p ^ (e + a - j) * u := by
            have hm_val : m = d * p ^ j := heq_m
            have hj_le : j ≤ e + a := by
              have hdvd_m : p ^ j ∣ m := ⟨d, by rw [heq_m, mul_comm]⟩
              rw [hm_eq] at hdvd_m
              exact j_le_add u p e a j hp hpu hdvd_m
            have h_calc : (p ^ (e + a - j) * u) * p ^ j = u * p ^ (e + a) := by
              have h_add : e + a - j + j = e + a := Nat.sub_add_cancel hj_le
              have : (p ^ (e + a - j) * u) * p ^ j = u * (p ^ (e + a - j) * p ^ j) := by ring
              rw [this, ← pow_add, h_add]
            have : d * p ^ j = (p ^ (e + a - j) * u) * p ^ j := by
              rw [h_calc, ← hm_eq, heq_m]
            exact Nat.eq_of_mul_eq_mul_right (pow_pos hp.pos j) this
          refine ⟨e + a - j, ?_, hd_val⟩
          rw [Finset.mem_range]
          lia
      let S := (Finset.range (e + 1)).image (fun i => p ^ i * u)
      have hsub : S ⊆ k.divisors := by
        intro d hdS
        rw [Finset.mem_image] at hdS
        obtain ⟨i, hi, rfl⟩ := hdS
        rw [Finset.mem_range] at hi
        have hd_dvd_g : p ^ i * u ∣ g := by
          rw [hg_eq, mul_comm u]
          exact Nat.mul_dvd_mul_right (Nat.pow_dvd_pow p (by lia)) u
        exact Nat.mem_divisors.2 ⟨hd_dvd_g.trans (Nat.gcd_dvd_right m k), hk.ne'⟩
      have hprod : ∏ d ∈ k.divisors, expected_res m d = ∏ d ∈ S, expected_res m d := by
        refine (Finset.prod_subset hsub ?_).symm
        intro d hd hdS
        by_contra hne
        obtain ⟨i, hi, rfl⟩ := h_div_subset d hd hne
        apply hdS
        rw [Finset.mem_image]
        exact ⟨i, hi, rfl⟩
      rw [hprod]
      have hinj : Set.InjOn (fun i => p ^ i * u) (Finset.range (e + 1)) := by
        intro i _ j _ heq_ij
        have hu_pos : 0 < u := by
          have hu_ne : u ≠ 0 := fun hu => hpu (hu ▸ dvd_zero p)
          lia
        have : p ^ i = p ^ j := Nat.eq_of_mul_eq_mul_right hu_pos heq_ij
        exact (Nat.pow_right_inj hp.two_le).1 this
      rw [Finset.prod_image hinj]
      have h_term : ∀ i ∈ Finset.range (e + 1), expected_res m (p ^ i * u) = (p : ℤ) ^ (p ^ i * u).totient := by
        intro i hi
        rw [Finset.mem_range] at hi
        have hm_eq' : m = (p ^ i * u) * p ^ (e + a - i) := by
          rw [hm_eq]
          have : e + a = i + (e + a - i) := (Nat.add_sub_of_le (by lia)).symm
          nth_rw 1 [this]
          rw [pow_add]
          ring
        exact expected_res_eq_pow m (p ^ i * u) p (e + a - i) hp (by lia) hm_eq' hm3
      rw [Finset.prod_congr rfl h_term]
      rw [Finset.prod_pow_eq_pow_sum]
      congr 1
      exact (sum_totient_prime_pow_mul u p e hp hpu).symm

theorem resultant_cyclotomic_eq_one (m n : Nat) (hn : 1 <= n) (hnm : n < m)
    (h : forall p k : Nat, p.Prime -> Not (m = n * p ^ k)) :
    Polynomial.resultant (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic n Int) = 1 := by
  rw [resultant_cyclotomic_eq_expected m n hn hnm]
  exact expected_res_of_not_mul_prime_pow m n h

theorem resultant_cyclotomic_mul_prime_pow (n p k : Nat) (hn : 1 <= n) (hp : p.Prime)
    (hk : 1 <= k) (h : Not (n = 1 /\ p = 2 /\ k = 1)) :
    Polynomial.resultant (Polynomial.cyclotomic (n * p ^ k) Int) (Polynomial.cyclotomic n Int) =
      (p : Int) ^ n.totient := by
  have hnm : n < n * p ^ k := by
    have : 2 ≤ p ^ k := by
      have : 2 ≤ p := hp.two_le
      have : p ≤ p ^ k := Nat.le_self_pow (by lia) p
      lia
    nlinarith
  rw [resultant_cyclotomic_eq_expected (n * p ^ k) n hn hnm]
  exact expected_res_of_mul_prime_pow n p k hn hp hk h

lemma eval_derivative_cyclotomic_mul (n : ℕ) (hn : 0 < n) (P : ℂ[X])
    (hP : cyclotomic n ℂ * P = X ^ n - 1) (ζ : ℂ) (hζ : ζ ∈ primitiveRoots n ℂ) :
    (cyclotomic n ℂ).derivative.eval ζ * P.eval ζ = n * ζ ^ (n - 1) := by
  have hroot : (cyclotomic n ℂ).eval ζ = 0 := by
    rw [mem_primitiveRoots hn] at hζ
    exact hζ.isRoot_cyclotomic hn
  have hderiv : ((cyclotomic n ℂ * P).derivative).eval ζ = ((X ^ n - 1 : ℂ[X]).derivative).eval ζ := by
    rw [hP]
  rw [derivative_mul, eval_add, eval_mul, eval_mul, hroot, zero_mul, add_zero] at hderiv
  rw [derivative_sub, derivative_one, sub_zero, derivative_X_pow] at hderiv
  simp only [eval_mul, eval_C, eval_pow, eval_X] at hderiv
  exact hderiv

lemma prod_primitiveRoots_eq_one (n : ℕ) (hn : 3 ≤ n) :
    ∏ ζ ∈ primitiveRoots n ℂ, ζ = 1 := by
  haveI : NeZero n := ⟨by lia⟩
  have heval : eval (0 : ℂ) (cyclotomic n ℂ) = ∏ ζ ∈ primitiveRoots n ℂ, (-ζ) := by
    obtain ⟨ζ, hζ⟩ : ∃ ζ : ℂ, IsPrimitiveRoot ζ n := ⟨_, Complex.isPrimitiveRoot_exp n (by lia)⟩
    rw [cyclotomic_eq_prod_X_sub_primitiveRoots hζ, eval_prod]
    simp
  have hcoeff : eval (0 : ℂ) (cyclotomic n ℂ) = 1 := by
    rw [← coeff_zero_eq_eval_zero]
    exact cyclotomic_coeff_zero ℂ (by lia)
  rw [hcoeff] at heval
  have hneg : (∏ ζ ∈ primitiveRoots n ℂ, (-ζ)) = (-1) ^ n.totient * ∏ ζ ∈ primitiveRoots n ℂ, ζ := by
    have : (fun ζ : ℂ => -ζ) = fun ζ => -1 * ζ := by ext; ring
    rw [this, Finset.prod_mul_distrib, Finset.prod_const,
      (Complex.isPrimitiveRoot_exp n (by lia)).card_primitiveRoots]
  rw [hneg] at heval
  have heven : Even n.totient := Nat.totient_even (by lia)
  rw [heven.neg_one_pow, one_mul] at heval
  exact heval.symm

lemma prod_deriv_eval (n : ℕ) (hn : 3 ≤ n) :
    ∏ ζ ∈ primitiveRoots n ℂ, ((n : ℂ) * ζ ^ (n - 1)) = (n : ℂ) ^ n.totient := by
  rw [Finset.prod_mul_distrib, Finset.prod_const,
    (Complex.isPrimitiveRoot_exp n (by lia)).card_primitiveRoots,
    Finset.prod_pow, prod_primitiveRoots_eq_one n hn, one_pow, mul_one]

lemma discr_cyclotomic_three_step (n : ℕ) (hn : 3 ≤ n) (D P : ℤ)
    (h_sign : (-1 : ℤ) ^ (n.totient * (n.totient - 1) / 2) * D * P = (n : ℤ) ^ n.totient) :
    D * P = (-1 : ℤ) ^ (n.totient / 2) * (n : ℤ) ^ n.totient := by
  obtain ⟨k, hk⟩ : ∃ k, n.totient = 2 * k := by
    obtain ⟨k, hk⟩ := Nat.totient_even (by lia : 2 < n)
    exact ⟨k, by rw [hk, two_mul]⟩
  have h_div : n.totient / 2 = k := by
    rw [hk, Nat.mul_div_cancel_left _ zero_lt_two]
  have h_sign_id : (-1 : ℤ) ^ (n.totient * (n.totient - 1) / 2) * (-1 : ℤ) ^ (n.totient / 2) = 1 := by
    rw [h_div, hk]
    exact discr_sign_identity k
  calc D * P = 1 * (D * P) := by ring
  _ = ((-1 : ℤ) ^ (n.totient * (n.totient - 1) / 2) * (-1 : ℤ) ^ (n.totient / 2)) * (D * P) := by rw [h_sign_id]
  _ = (-1 : ℤ) ^ (n.totient / 2) * (((-1 : ℤ) ^ (n.totient * (n.totient - 1) / 2) * D * P)) := by ring
  _ = (-1 : ℤ) ^ (n.totient / 2) * (n : ℤ) ^ n.totient := by rw [h_sign]

lemma prime_factors_inj (n : ℕ) (hn : 0 < n)
    (p1 : ℕ) (hp1 : p1.Prime) (k1 : ℕ) (hk1 : 1 ≤ k1) (hdvd1 : p1 ^ k1 ∣ n)
    (p2 : ℕ) (hp2 : p2.Prime) (k2 : ℕ) (_hk2 : 1 ≤ k2) (hdvd2 : p2 ^ k2 ∣ n)
    (heq : n / p1 ^ k1 = n / p2 ^ k2) :
    p1 = p2 ∧ k1 = k2 := by
  have : p1 ^ k1 = p2 ^ k2 := by
    have h1 : n = (n / p1 ^ k1) * p1 ^ k1 := (Nat.div_mul_cancel hdvd1).symm
    have h2 : n = (n / p2 ^ k2) * p2 ^ k2 := (Nat.div_mul_cancel hdvd2).symm
    rw [heq] at h1
    have hdiv_pos : 0 < n / p2 ^ k2 := by
      apply Nat.div_pos (Nat.le_of_dvd hn hdvd2) (pow_pos hp2.pos k2)
    exact Nat.eq_of_mul_eq_mul_left hdiv_pos (h1.symm.trans h2)
  have hp : p1 = p2 := by
    have : p1 ∣ p2 ^ k2 := by rw [← this]; exact dvd_pow_self p1 (by lia)
    exact ((hp2.dvd_iff_eq hp1.ne_one).1 (hp1.dvd_of_dvd_pow this)).symm
  subst hp
  have hk : k1 = k2 := (Nat.pow_right_inj hp1.two_le).1 this
  exact ⟨rfl, hk⟩

lemma sum_totient_div_prime_pow (u p e : ℕ) (hp : p.Prime) (hpu : ¬ p ∣ u) (he : 1 ≤ e) :
    (∑ k ∈ Finset.Ico 1 (e + 1), (u * p ^ (e - k)).totient) = (u * p ^ e).totient / (p - 1) := by
  have hcop : ∀ j, u.Coprime (p ^ j) := fun j => ((hp.coprime_iff_not_dvd.2 hpu).pow_left j).symm
  have htot : ∀ j, (u * p ^ j).totient = u.totient * (p ^ j).totient :=
    fun j => Nat.totient_mul (hcop j)
  have hsum : (∑ k ∈ Finset.Ico 1 (e + 1), (u * p ^ (e - k)).totient) =
      u.totient * ∑ j ∈ Finset.range e, (p ^ j).totient := by
    simp_rw [htot, ← Finset.mul_sum]
    congr 1
    refine Finset.sum_bij (fun k _ => e - k) ?_ ?_ ?_ ?_
    · intro k hk; rw [Finset.mem_Ico] at hk; rw [Finset.mem_range]; lia
    · intro k1 hk1 k2 hk2 heq; rw [Finset.mem_Ico] at hk1 hk2; lia
    · intro j hj; rw [Finset.mem_range] at hj
      refine ⟨e - j, ?_, ?_⟩
      · rw [Finset.mem_Ico]; lia
      · lia
    · intro k hk; rfl
  rw [hsum]
  have hpow_sum : (∑ j ∈ Finset.range e, (p ^ j).totient) = p ^ (e - 1) := by
    cases e with
    | zero => lia
    | succ e =>
      have := (Nat.sum_divisors_prime_pow (k := e) (f := Nat.totient) hp).symm
      rw [Nat.sum_totient (p ^ e)] at this
      exact this
  rw [hpow_sum]
  rw [htot, Nat.totient_prime_pow hp he]
  have hpos : 0 < p - 1 := tsub_pos_of_lt hp.one_lt
  have : u.totient * (p ^ (e - 1) * (p - 1)) = (u.totient * p ^ (e - 1)) * (p - 1) := by ring
  rw [this, Nat.mul_div_cancel _ hpos]

lemma prod_properDivisors_expected_res (n : ℕ) (hn : 3 ≤ n) :
    ∏ d ∈ n.properDivisors, expected_res n d =
      n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1))) := by
  have hn_pos : 0 < n := by lia
  let S_p (p : ℕ) := (Finset.Ico 1 (n.factorization p + 1)).image (fun k => n / p ^ k)
  let S := n.primeFactors.biUnion S_p
  have hsub : S ⊆ n.properDivisors := by
    intro d hd
    rw [Finset.mem_biUnion] at hd
    obtain ⟨p, hp, hdS⟩ := hd
    rw [Nat.mem_primeFactors] at hp
    rw [Finset.mem_image] at hdS
    obtain ⟨k, hk, rfl⟩ := hdS
    rw [Finset.mem_Ico] at hk
    have hpk : p ^ k ∣ n := (hp.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    have hd_dvd : n / p ^ k ∣ n := Nat.div_dvd_of_dvd hpk
    have hd_lt : n / p ^ k < n := by
      apply Nat.div_lt_self hn_pos
      have : 2 ≤ p ^ k := by
        have : p ≥ 2 := hp.1.two_le
        have : p ≤ p ^ k := Nat.le_self_pow (by lia) p
        lia
      lia
    exact Nat.mem_properDivisors.2 ⟨hd_dvd, hd_lt⟩
  have h_rest : ∀ d ∈ n.properDivisors, d ∉ S → expected_res n d = 1 := by
    intro d hd hdS
    dsimp [expected_res]
    split_ifs with h1 h2
    · lia
    · exfalso
      obtain ⟨p, k, hp, hk, heq⟩ := h1
      apply hdS
      rw [Finset.mem_biUnion]
      have hp_dvd : p ∣ n := by
        rw [heq]
        exact dvd_mul_of_dvd_right (dvd_pow_self p (by lia)) d
      have hp_mem : p ∈ n.primeFactors := Nat.mem_primeFactors.2 ⟨hp, hp_dvd, hn_pos.ne'⟩
      refine ⟨p, hp_mem, ?_⟩
      rw [Finset.mem_image]
      have hpk_dvd : p ^ k ∣ n := ⟨d, by rw [heq, mul_comm]⟩
      have hk_le : k ≤ n.factorization p := (hp.pow_dvd_iff_le_factorization hn_pos.ne').1 hpk_dvd
      refine ⟨k, ?_, ?_⟩
      · rw [Finset.mem_Ico]; lia
      · rw [heq, Nat.mul_div_cancel _ (pow_pos hp.pos k)]
    · rfl
  have hprod : ∏ d ∈ n.properDivisors, expected_res n d = ∏ d ∈ S, expected_res n d := by
    refine (Finset.prod_subset hsub ?_).symm
    intro d hd hdS
    exact h_rest d hd hdS
  rw [hprod]
  have hdisj : ∀ p1 ∈ n.primeFactors, ∀ p2 ∈ n.primeFactors, p1 ≠ p2 → Disjoint (S_p p1) (S_p p2) := by
    intro p1 hp1 p2 hp2 hne
    rw [Finset.disjoint_iff_ne]
    intro d1 hd1 d2 hd2
    rw [Finset.mem_image] at hd1 hd2
    obtain ⟨k1, hk1, rfl⟩ := hd1
    obtain ⟨k2, hk2, rfl⟩ := hd2
    rw [Finset.mem_Ico] at hk1 hk2
    rw [Nat.mem_primeFactors] at hp1 hp2
    have hpk1 : p1 ^ k1 ∣ n := (hp1.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    have hpk2 : p2 ^ k2 ∣ n := (hp2.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    intro heq
    have hinj := prime_factors_inj n hn_pos p1 hp1.1 k1 (by lia) hpk1 p2 hp2.1 k2 (by lia) hpk2 heq
    exact hne hinj.1
  rw [Finset.prod_biUnion hdisj]
  refine Finset.prod_congr rfl (fun p hp => ?_)
  rw [Nat.mem_primeFactors] at hp
  have hinj_k : Set.InjOn (fun k => n / p ^ k) (Finset.Ico 1 (n.factorization p + 1)) := by
    intro k1 hk1 k2 hk2 heq
    rw [Finset.mem_coe, Finset.mem_Ico] at hk1 hk2
    have hpk1 : p ^ k1 ∣ n := (hp.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    have hpk2 : p ^ k2 ∣ n := (hp.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    have := prime_factors_inj n hn_pos p hp.1 k1 (by lia) hpk1 p hp.1 k2 (by lia) hpk2 heq
    exact this.2
  rw [Finset.prod_image hinj_k]
  have h_term : ∀ k ∈ Finset.Ico 1 (n.factorization p + 1), expected_res n (n / p ^ k) = (p : ℤ) ^ (n / p ^ k).totient := by
    intro k hk
    rw [Finset.mem_Ico] at hk
    have hpk : p ^ k ∣ n := (hp.1.pow_dvd_iff_le_factorization hn_pos.ne').2 (by lia)
    have heq_n : n = (n / p ^ k) * p ^ k := (Nat.div_mul_cancel hpk).symm
    exact expected_res_eq_pow n (n / p ^ k) p k hp.1 (by lia) heq_n hn
  rw [Finset.prod_congr rfl h_term]
  rw [Finset.prod_pow_eq_pow_sum]
  congr 1
  set e := n.factorization p
  set u := ordCompl[p] n
  have he : 1 ≤ e := (hp.1.dvd_iff_one_le_factorization hn_pos.ne').1 hp.2.1
  have hpu : ¬ p ∣ u := Nat.not_dvd_ordCompl hp.1 hn_pos.ne'
  have hn_eq : n = u * p ^ e := by
    have : ordProj[p] n * ordCompl[p] n = n := Nat.ordProj_mul_ordCompl_eq_self n p
    have hpj : ordProj[p] n = p ^ e := rfl
    rw [← this, hpj, mul_comm]
  have h_div_pow : ∀ k ∈ Finset.Ico 1 (e + 1), n / p ^ k = u * p ^ (e - k) := by
    intro k hk
    rw [Finset.mem_Ico] at hk
    rw [hn_eq]
    have : u * p ^ e = (u * p ^ (e - k)) * p ^ k := by
      rw [mul_assoc, ← pow_add, Nat.sub_add_cancel (by lia)]
    rw [this, Nat.mul_div_cancel _ (pow_pos hp.1.pos k)]
  rw [Finset.sum_congr rfl (fun k hk => by rw [h_div_pow k hk])]
  rw [hn_eq]
  exact sum_totient_div_prime_pow u p e hp.1 hpu he

lemma map_resultant_deriv (n : ℕ) :
    algebraMap ℤ ℂ (Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.cyclotomic n Int).derivative) =
      Polynomial.resultant (Polynomial.cyclotomic n ℂ) (Polynomial.cyclotomic n ℂ).derivative := by
  have hinj : Function.Injective (algebraMap ℤ ℂ) := (algebraMap ℤ ℂ).injective_int
  have h1 : (cyclotomic n ℤ).map (algebraMap ℤ ℂ) = cyclotomic n ℂ := map_cyclotomic_int n ℂ
  have h2 : (derivative (cyclotomic n ℤ)).map (algebraMap ℤ ℂ) = derivative (cyclotomic n ℂ) := by
    rw [← derivative_map, h1]
  have hdeg1 : (cyclotomic n ℂ).natDegree = (cyclotomic n ℤ).natDegree := by
    rw [← h1, natDegree_map_eq_of_injective hinj]
  have hdeg2 : (derivative (cyclotomic n ℂ)).natDegree = (derivative (cyclotomic n ℤ)).natDegree := by
    rw [← h2, natDegree_map_eq_of_injective hinj]
  have hmap := (resultant_map_map (cyclotomic n ℤ) (derivative (cyclotomic n ℤ))
    (cyclotomic n ℤ).natDegree (derivative (cyclotomic n ℤ)).natDegree (algebraMap ℤ ℂ)).symm
  rw [h1, h2] at hmap
  dsimp [resultant]
  rw [hdeg1, hdeg2]
  exact hmap

lemma map_resultant_cyclotomic (n d : ℕ) :
    algebraMap ℤ ℂ (Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.cyclotomic d Int)) =
      Polynomial.resultant (Polynomial.cyclotomic n ℂ) (Polynomial.cyclotomic d ℂ) := by
  have hinj : Function.Injective (algebraMap ℤ ℂ) := (algebraMap ℤ ℂ).injective_int
  have h1 : (cyclotomic n ℤ).map (algebraMap ℤ ℂ) = cyclotomic n ℂ := map_cyclotomic_int n ℂ
  have h2 : (cyclotomic d ℤ).map (algebraMap ℤ ℂ) = cyclotomic d ℂ := map_cyclotomic_int d ℂ
  have hdeg1 : (cyclotomic n ℂ).natDegree = (cyclotomic n ℤ).natDegree := by
    rw [← h1, natDegree_map_eq_of_injective hinj]
  have hdeg2 : (cyclotomic d ℂ).natDegree = (cyclotomic d ℤ).natDegree := by
    rw [← h2, natDegree_map_eq_of_injective hinj]
  have hmap := (resultant_map_map (cyclotomic n ℤ) (cyclotomic d ℤ)
    (cyclotomic n ℤ).natDegree (cyclotomic d ℤ).natDegree (algebraMap ℤ ℂ)).symm
  rw [h1, h2] at hmap
  dsimp [resultant]
  rw [hdeg1, hdeg2]
  exact hmap

theorem discr_cyclotomic (n : Nat) (hn : 1 <= n) :
    Polynomial.discr (Polynomial.cyclotomic n Int) *
        n.primeFactors.prod (fun p => (p : Int) ^ (n.totient / (p - 1))) =
      (-1) ^ (n.totient / 2) * (n : Int) ^ n.totient := by
  rcases eq_or_lt_of_le hn with rfl | hn2
  · exact discr_cyclotomic_one
  · rcases eq_or_lt_of_le (Nat.succ_le_of_lt hn2) with rfl | hn3
    · exact discr_cyclotomic_two
    · apply discr_cyclotomic_three_step n hn3
      have h_deriv_eq : (-1 : ℤ) ^ (n.totient * (n.totient - 1) / 2) *
          Polynomial.discr (Polynomial.cyclotomic n Int) =
        Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.cyclotomic n Int).derivative := by
        rw [discr_deriv_eq n hn3]
      rw [h_deriv_eq]
      apply (algebraMap ℤ ℂ).injective_int
      rw [map_mul, map_resultant_deriv, resultant_cyclotomic_eval n (by lia)]
      have h_prod_res : (algebraMap ℤ ℂ) (n.primeFactors.prod (fun p => (p : Int) ^ (n.totient / (p - 1)))) =
          ∏ ζ ∈ primitiveRoots n ℂ, (∏ d ∈ n.properDivisors, cyclotomic d ℂ).eval ζ := by
        simp_rw [eval_prod]
        rw [Finset.prod_comm]
        have h_inner : ∀ d ∈ n.properDivisors, ∏ ζ ∈ primitiveRoots n ℂ, (cyclotomic d ℂ).eval ζ =
            algebraMap ℤ ℂ (resultant (cyclotomic n ℤ) (cyclotomic d ℤ)) := by
          intro d _hd
          rw [← resultant_cyclotomic_eval n (by lia), map_resultant_cyclotomic]
        rw [Finset.prod_congr rfl h_inner]
        rw [← map_prod]
        congr 1
        have h_exp : ∀ d ∈ n.properDivisors, resultant (cyclotomic n ℤ) (cyclotomic d ℤ) = expected_res n d := by
          intro d hd
          exact resultant_cyclotomic_eq_expected n d (Nat.pos_of_mem_properDivisors hd) (Nat.mem_properDivisors.1 hd |>.2)
        rw [Finset.prod_congr rfl h_exp]
        exact (prod_properDivisors_expected_res n hn3).symm
      rw [h_prod_res, ← Finset.prod_mul_distrib]
      have hP : cyclotomic n ℂ * ∏ d ∈ n.properDivisors, cyclotomic d ℂ = X ^ n - 1 := by
        have : cyclotomic n ℂ * ∏ d ∈ n.properDivisors, cyclotomic d ℂ =
            ∏ d ∈ n.divisors, cyclotomic d ℂ := by
          rw [← Nat.cons_self_properDivisors (by lia), Finset.prod_cons]
        rw [this, prod_cyclotomic_eq_X_pow_sub_one (by lia) ℂ]
      have h_term : ∀ ζ ∈ primitiveRoots n ℂ,
          (cyclotomic n ℂ).derivative.eval ζ * (∏ d ∈ n.properDivisors, cyclotomic d ℂ).eval ζ =
            (n : ℂ) * ζ ^ (n - 1) := fun ζ hζ => eval_derivative_cyclotomic_mul n (by lia) _ hP ζ hζ
      rw [Finset.prod_congr rfl h_term]
      rw [prod_deriv_eval n hn3]
      push_cast
      rfl

theorem isCoprime_cyclotomic_iff (m n : Nat) (hn : 1 <= n) (hnm : n < m) :
    IsCoprime (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic n Int) <->
      forall p k : Nat, p.Prime -> Not (m = n * p ^ k) := by
  exact isCoprime_of_resultant_eq_expected m n hn hnm (resultant_cyclotomic_eq_expected m n hn hnm)

theorem resultant_cyclotomic_X_pow_sub_one (n m : Nat) (hn : 3 <= n) (hm : 1 <= m)
    (h : Not (m % n = 0)) :
    Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.X ^ m - 1) =
      Polynomial.eval 1 (Polynomial.cyclotomic (n / Nat.gcd n m) Int) ^
        (n.totient / (n / Nat.gcd n m).totient) := by
  exact resultant_cyclotomic_X_pow_sub_one_aux n m hn hm h

end TuringTask
