# TuringTask — Pólya–Vinogradov character sum bounds

Lean 4 formalisation of five results on character sums modulo a prime `p`.
All five required theorems are in `TuringTask/Basic.lean`, inside `namespace TuringTask`,
with the statements exactly as specified, and are proved without `sorry`.

## The five theorems

| # | Name | Statement |
|---|------|-----------|
| 1 | `charSum_norm_le` | `‖∑_{n=1}^N χ(n)‖ ≤ √p · log p` for non-principal `χ : MulChar (ZMod p) ℂ` |
| 2 | `legendreSum_le` | `\|∑_{n=1}^N (n/p)\| ≤ √p · log p` for odd `p` |
| 3 | `exists_not_pow_le` | if `2 ≤ k` and `k ∣ p-1`, some `1 ≤ n ≤ √p·log p + 1` is not a `k`-th power mod `p` |
| 4 | `card_residues_sub_le` | for `N < p`, the count `R` of residues in `[1,N]` has `\|2R − N\| ≤ √p · log p` |
| 5 | `exists_prime_nonresidue_le` | some **prime** `q ≤ √p·log p + 1` is a quadratic non-residue mod `p` |

## Proof outline

**Theorem 1** is the classical Pólya–Vinogradov argument.

1. `norm_gaussSum_eq` — for non-principal `χ`, `‖g(χ, ψ)‖ = √p`, from
   `gaussSum_mul_gaussSum_eq_card` together with `star_gaussSum_eq`.
2. `key_identity` — `χ(n)·g(χ⁻¹,ψ) = ∑_t χ⁻¹(t)·ψ(tn)`, via `gaussSum_mulShift_eq`
   (the degenerate case `n = 0` uses `gaussSum_one_right`).
3. Summing over `n ∈ [1,N]` and exchanging the order of summation turns the inner
   sum into a geometric series; `norm_geom_Icc_le` bounds it by `2 / ‖ψ(t) − 1‖`.
4. `norm_stdAddChar_sub_one` evaluates `‖ψ(t) − 1‖ = 2 sin(π t.val / p)`, so each
   term is at most `1 / sin(π t.val / p)`.
5. `sin_inv_sum_le` is the key estimate `∑_{t=1}^{p-1} 1/sin(π t/p) ≤ p · log p`.
   It combines the symmetry `sin(π(p−t)/p) = sin(π t/p)` (`split_Icc`), Jordan's
   inequality `Real.mul_le_sin`, and the harmonic bound
   `harmonicSum_le_log : ∑_{k=1}^m 1/k ≤ log(2m+1)`, which is itself derived from
   Mathlib's `Real.hasSum_log_one_add_inv`.
6. Dividing by `‖g‖ = √p` gives the bound.

**Theorem 2** transports the Legendre symbol to a complex character through
`legChar p = (quadraticChar (ZMod p)).ringHomComp (Int.castRingHom ℂ)`
and applies Theorem 1.

**Theorem 3** picks a character `χ` of order `k` (`MulChar.exists_mulChar_orderOf`,
using `k ∣ p − 1` and a primitive `k`-th root of unity in `ℂ`). Every `k`-th power
satisfies `χ(x^k) = 1`; if all `n ≤ N := ⌊√p·log p⌋ + 1` were `k`-th powers the
character sum would equal `N > √p·log p`, contradicting Theorem 1.
The auxiliary inequality `sqrt_mul_log_lt : √x·log x < x − 1` for `x ≥ 3`
guarantees `N < p`.

**Theorem 4** follows from Theorem 2: for `N < p` no term vanishes, so each
Legendre symbol is `±1` and the sum telescopes to `2R − N`.

**Theorem 5** uses Theorem 4 to produce *some* non-residue `n ≤ √p·log p + 1`,
then takes the least non-residue `q` (`Nat.find`). If `q = a·b` were composite with
`a, b < q`, minimality would force `(a/p) = (b/p) = 1` and hence `(q/p) = 1`,
a contradiction; so `q` is prime.

## Building (offline)

This project requires the Lean/Mathlib environment supplied by the task image:

* Lean toolchain `leanprover/lean4:v4.33.0-rc1`
* Mathlib pre-built at `/opt/mathlib4` (commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`)

`lakefile.toml` refers to Mathlib through a **local path dependency** (`path = "/opt/mathlib4"`),
so no network access is needed or attempted. The archive is therefore *not*
self-contained on an arbitrary machine: it needs that same local Mathlib build.

```bash
cd turing-task
lean-offline-init     # seeds .lake/packages with links to the installed deps (local only)
lake build            # builds TuringTask.Basic; finishes with no errors
```

To check a single file directly with the offline compiler:

```bash
lean TuringTask/Basic.lean
```

## Axiom audit

```bash
lake env lean AxiomCheck.lean
```

reports, for each of the five theorems:

```
depends on axioms: [propext, Classical.choice, Quot.sound]
```

No `sorry`, `admit`, `native_decide`, or added axioms are used anywhere.
