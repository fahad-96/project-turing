import Mathlib
open Lean Elab Command
elab "list_decls " needle:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if (toString name).contains needle.getString then logInfo name
list_decls "Equiv.mul"
list_decls "mulLeft"
list_decls "mulRight"
