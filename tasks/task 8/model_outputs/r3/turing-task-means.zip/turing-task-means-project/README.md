# TuringTask Means

This project uses the pinned Lean and Mathlib installation supplied by the task environment.
Mathlib is referenced locally at `/opt/mathlib4`; the archive is not self-contained on an
arbitrary machine.

Build strictly offline with:

```sh
lean-offline-init
lake build TuringTask.Means
```

To check the requested source directly in the configured project:

```sh
lake env lean TuringTask/Means.lean
```
