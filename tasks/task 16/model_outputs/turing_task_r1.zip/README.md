# TuringTask Lean 4 Project

This project formalizes theorems on Fibonacci and Lucas numbers in Lean 4.

## Prerequisites and Environment
This project is configured for the offline environment provided by the container:
- Lean toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib commit: `9944fe2973b8dc0b86949101ed98232c07cd54a0`
- Local Mathlib path: `/opt/mathlib4`

Note: The supplied Lean and Mathlib environment is required to build this project; the package configuration depends on the local installation at `/opt/mathlib4`.

## Offline Build Instructions
From the project root:
1. Ensure `LEAN_PATH` is unset so the pinned toolchain and baked Mathlib search paths are used.
2. Initialize local dependency links if needed:
   ```bash
   lean-offline-init
   ```
3. Build the project using Lake:
   ```bash
   lake build
   ```
4. Or check individual files directly with the Lean compiler:
   ```bash
   lean TuringTask/Basic.lean
   ```
