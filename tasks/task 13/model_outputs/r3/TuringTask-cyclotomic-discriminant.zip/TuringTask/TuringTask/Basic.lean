import Mathlib

namespace TuringTask

end TuringTask
