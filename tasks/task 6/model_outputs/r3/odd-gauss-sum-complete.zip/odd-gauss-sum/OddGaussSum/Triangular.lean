import OddGaussSum.DoubleSign

open scoped BigOperators

namespace OddGaussSum

noncomputable section

set_option maxHeartbeats 800000

private def e (x : ℝ) : ℂ :=
  Complex.exp (2 * (Real.pi : ℂ) * Complex.I * (x : ℂ))

private theorem even_term_algebra (q r : ℂ) (h : 1 + q * 2 ≠ 0) :
    r * (1 + q * 2)⁻¹ * 2 + r ^ 2 * (1 + q * 2)⁻¹ * 4 =
      -(r * 6) - r * q * 4 + r * q * (1 + q * 2)⁻¹ * 16 +
          r * q ^ 2 * (1 + q * 2)⁻¹ * 8 + r * (1 + q * 2)⁻¹ * 8 -
        r ^ 2 * 4 + r ^ 2 * q * (1 + q * 2)⁻¹ * 8 +
      r ^ 2 * (1 + q * 2)⁻¹ * 8 := by
  field_simp [h]
  ring

private theorem odd_term_algebra (q r : ℂ) (h : 1 + q * 2 ≠ 0) :
    r * (1 + q * 2)⁻¹ * 6 + r ^ 2 * (1 + q * 2)⁻¹ * 4 +
        (1 + q * 2)⁻¹ * 2 =
      -4 - r * 10 - r * q * 4 + r * q * (1 + q * 2)⁻¹ * 24 +
          r * q ^ 2 * (1 + q * 2)⁻¹ * 8 + r * (1 + q * 2)⁻¹ * 16 -
        r ^ 2 * 4 + r ^ 2 * q * (1 + q * 2)⁻¹ * 8 +
          r ^ 2 * (1 + q * 2)⁻¹ * 8 - q * 2 +
        q * (1 + q * 2)⁻¹ * 10 + q ^ 2 * (1 + q * 2)⁻¹ * 4 +
      (1 + q * 2)⁻¹ * 6 := by
  field_simp [h]
  ring

def halfUnit (q : ℕ) : (ZMod (2 * q + 1))ˣ := (doubleUnit q)⁻¹

private theorem halfUnit_coe (q : ℕ) :
    (halfUnit q : ZMod (2 * q + 1)) = (q + 1 : ℕ) := by
  apply (doubleUnit q).isUnit.mul_left_cancel
  rw [show (doubleUnit q : ZMod (2 * q + 1)) * (halfUnit q : ZMod (2 * q + 1)) = 1 by
    simp [halfUnit]]
  symm
  calc
    (2 : ZMod (2 * q + 1)) * (q + 1 : ℕ) =
        ((2 * (q + 1) : ℕ) : ZMod (2 * q + 1)) := by push_cast; rfl
    _ = (((2 * q + 1) + 1 : ℕ) : ZMod (2 * q + 1)) := by congr 1 <;> omega
    _ = 1 := by simp

private theorem sign_halfUnit (q : ℕ) :
    Equiv.Perm.sign (Units.mulLeft (halfUnit q)) =
      (-1 : ℤˣ) ^ (q * (q + 1) / 2) := by
  have hp : Units.mulLeft (halfUnit q) =
      (Units.mulLeft (doubleUnit q))⁻¹ := by
    ext x
    simp [halfUnit]
  rw [hp, Equiv.Perm.sign_inv, sign_doubleUnit]

private theorem e_nat_square_eq_char (q a y : ℕ) :
    e (((a * y ^ 2 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) =
      ZMod.stdAddChar ((a : ZMod (2 * q + 1)) * (y : ZMod (2 * q + 1)) ^ 2) := by
  by_cases hq : q = 0
  · subst q
    have hz : ((a : ZMod 1) * (y : ZMod 1) ^ 2) = 0 := Subsingleton.elim _ _
    have hc : ZMod.stdAddChar
        ((a : ZMod 1) * (y : ZMod 1) ^ 2) = 1 := by rw [hz]; simp
    rw [hc]
    simp only [e]
    norm_num
    convert Complex.exp_nat_mul_two_pi_mul_I (a * y ^ 2) using 1 <;> push_cast <;> ring
  let n := 2 * q + 1
  have hn : 1 < n ∨ n = 1 := by omega
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast (by omega : n ≠ 0)
  have hbase : ZMod.stdAddChar (1 : ZMod n) =
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I / n) := by
    have hn2 : 1 < n := by simp only [n]; omega
    letI : Fact (1 < n) := ⟨hn2⟩
    rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply, ZMod.val_one]
    congr 1
    ring
  change Complex.exp
      (2 * (Real.pi : ℂ) * Complex.I * (((a * y ^ 2 : ℕ) : ℝ) / n : ℝ)) = _
  rw [show ((a : ZMod n) * (y : ZMod n) ^ 2) =
      (a * y ^ 2) • (1 : ZMod n) by
    push_cast
    simp [nsmul_eq_mul]
    ]
  rw [AddChar.map_nsmul_eq_pow, hbase, ← Complex.exp_nat_mul]
  congr 1
  push_cast
  field_simp

private theorem triangular_term (q k : ℕ) :
    e (((k : ℝ) * ((k : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ))) =
      e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        ZMod.stdAddChar
          ((halfUnit q : ZMod (2 * q + 1)) *
            ((k + q + 1 : ℕ) : ZMod (2 * q + 1)) ^ 2) := by
  rw [halfUnit_coe]
  rw [← e_nat_square_eq_char q (q + 1) (k + q + 1)]
  simp only [e]
  rw [← Complex.exp_add]
  apply Complex.exp_eq_exp_iff_exists_int.mpr
  rcases Nat.even_or_odd k with hk | hk
  · obtain ⟨r, rfl⟩ := hk
    refine ⟨-(r * (2 * r + (2 * q + 1) + 2) : ℤ), ?_⟩
    push_cast
    have hn : ((2 * q + 1 : ℕ) : ℂ) ≠ 0 := by
      exact_mod_cast (by omega : 2 * q + 1 ≠ 0)
    have hn' : (1 + (q : ℂ) * 2) ≠ 0 := by
      push_cast at hn
      convert hn using 1 <;> ring
    have hn2 : (2 + (q : ℂ) * 4) ≠ 0 := by
      exact_mod_cast (by omega : 2 + q * 4 ≠ 0)
    have hinv : (2 + (q : ℂ) * 4)⁻¹ = (1 + (q : ℂ) * 2)⁻¹ / 2 := by
      rw [show 2 + (q : ℂ) * 4 = 2 * (1 + q * 2) by ring, mul_inv]
      ring
    ring_nf
    rw [hinv]
    field_simp [hn']
    ring
  · obtain ⟨r, rfl⟩ := hk
    refine ⟨-((2 * r + 1) * (r + q + 2) : ℤ), ?_⟩
    push_cast
    have hn : ((2 * q + 1 : ℕ) : ℂ) ≠ 0 := by
      exact_mod_cast (by omega : 2 * q + 1 ≠ 0)
    have hn' : (1 + (q : ℂ) * 2) ≠ 0 := by
      push_cast at hn
      convert hn using 1 <;> ring
    have hn2 : (2 + (q : ℂ) * 4) ≠ 0 := by
      exact_mod_cast (by omega : 2 + q * 4 ≠ 0)
    have hinv : (2 + (q : ℂ) * 4)⁻¹ = (1 + (q : ℂ) * 2)⁻¹ / 2 := by
      rw [show 2 + (q : ℂ) * 4 = 2 * (1 + q * 2) by ring, mul_inv]
      ring
    ring_nf
    rw [hinv]
    field_simp [hn']
    ring

private theorem shifted_twisted_sum (q : ℕ) :
    twistedQuadraticSumZMod (2 * q + 1) (halfUnit q) =
      ∑ x : ZMod (2 * q + 1),
        ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
          (x + ((q + 1 : ℕ) : ZMod (2 * q + 1))) ^ 2) := by
  let shift : Equiv.Perm (ZMod (2 * q + 1)) := Equiv.addRight (q + 1)
  have hsum := Equiv.sum_comp shift
    (fun x : ZMod (2 * q + 1) =>
      ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) * x ^ 2))
  change (∑ x : ZMod (2 * q + 1),
    ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) * x ^ 2)
    ) = _
  simpa [shift, add_comm, add_assoc] using hsum.symm

private theorem triangular_range_to_fin (q : ℕ) :
    (∑ k ∈ Finset.range (2 * q + 1),
      e (((k : ℝ) * ((k : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ)))) =
      ∑ k : Fin (2 * q + 1),
        e (((k.val : ℝ) * ((k.val : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ))) := by
  simpa using (Fin.sum_univ_eq_sum_range
    (fun k : ℕ => e (((k : ℝ) * ((k : ℝ) + 1)) /
      (2 * (2 * q + 1 : ℝ)))) (2 * q + 1)).symm

private theorem triangular_fin_term (q : ℕ) (k : Fin (2 * q + 1)) :
    e (((k.val : ℝ) * ((k.val : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ))) =
      e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
          ((k.val + q + 1 : ℕ) : ZMod (2 * q + 1)) ^ 2) := by
  exact triangular_term q k.val

private theorem triangular_fin_sum (q : ℕ) :
    (∑ k : Fin (2 * q + 1),
      e (((k.val : ℝ) * ((k.val : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ)))) =
      e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        ∑ x : ZMod (2 * q + 1),
          ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
            (x + ((q + 1 : ℕ) : ZMod (2 * q + 1))) ^ 2) := by
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  change e (((k.val : ℝ) * ((k.val : ℝ) + 1)) /
      (2 * (2 * q + 1 : ℝ))) =
    e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
      ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
        (ZMod.finEquiv (2 * q + 1) k +
          ((q + 1 : ℕ) : ZMod (2 * q + 1))) ^ 2)
  have hk : ZMod.finEquiv (2 * q + 1) k =
      (k.val : ZMod (2 * q + 1)) := by
    have hv : (ZMod.finEquiv (2 * q + 1) k).val = k.val := rfl
    symm
    rw [← hv, ZMod.natCast_zmod_val]
  calc
    _ = e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
          ((k.val + q + 1 : ℕ) : ZMod (2 * q + 1)) ^ 2) :=
      triangular_fin_term q k
    _ = _ := by rw [hk]; push_cast; ring

private theorem triangular_sum_eq_twisted (q : ℕ) :
    (∑ k ∈ Finset.range (2 * q + 1),
      e (((k : ℝ) * ((k : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ)))) =
      e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        twistedQuadraticSumZMod (2 * q + 1) (halfUnit q) := by
  calc
    _ = ∑ k : Fin (2 * q + 1),
        e (((k.val : ℝ) * ((k.val : ℝ) + 1)) /
          (2 * (2 * q + 1 : ℝ))) := triangular_range_to_fin q
    _ = e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        ∑ x : ZMod (2 * q + 1),
          ZMod.stdAddChar ((halfUnit q : ZMod (2 * q + 1)) *
            (x + ((q + 1 : ℕ) : ZMod (2 * q + 1))) ^ 2) := triangular_fin_sum q
    _ = _ := by rw [← shifted_twisted_sum]

private theorem twisted_sum_value (q : ℕ) :
    twistedQuadraticSumZMod (2 * q + 1) (halfUnit q) =
      (Real.sqrt (2 * q + 1) : ℂ) *
        (-1 : ℂ) ^ (q * (q + 1) / 2) *
          (if (2 * q + 1) % 4 = 1 then 1 else Complex.I) := by
  have h := twisted_normalized_trace (2 * q + 1)
    (show Odd (2 * q + 1) from ⟨q, by omega⟩) (halfUnit q)
  rw [twistedNormalizedFourierMatrix, Matrix.trace_smul,
    trace_twistedFourierMatrix, sign_halfUnit] at h
  simp only [smul_eq_mul] at h
  have hs : (Real.sqrt (2 * q + 1) : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.2 (by positivity :
      (0 : ℝ) < (2 * q + 1 : ℕ))))
  have hsign : ((((-1 : ℤˣ) ^ (q * (q + 1) / 2) : ℤˣ) : ℂ)) =
      (-1 : ℂ) ^ (q * (q + 1) / 2) := by
    norm_cast
  rw [hsign] at h
  calc
    twistedQuadraticSumZMod (2 * q + 1) (halfUnit q) =
        (Real.sqrt (2 * q + 1) : ℂ) *
          ((Real.sqrt (2 * q + 1) : ℂ)⁻¹ *
            twistedQuadraticSumZMod (2 * q + 1) (halfUnit q)) := by
      field_simp
    _ = (Real.sqrt (2 * q + 1) : ℂ) *
          (((-1 : ℂ) ^ (q * (q + 1) / 2)) *
            (if (2 * q + 1) % 4 = 1 then 1 else Complex.I)) := by
      have h' := congrArg
        (fun z : ℂ => (Real.sqrt ((2 * q + 1 : ℕ) : ℝ) : ℂ) * z) h
      convert h' using 1 <;> norm_num <;> push_cast <;> ring
    _ = _ := by ring

private theorem e_quarter : e (1 / 4) = Complex.I := by
  rw [e]
  convert Complex.exp_mul_I (Real.pi / 2 : ℂ) using 2 <;>
    simp [Complex.cos_ofReal_re, Complex.sin_ofReal_re] <;> ring

private theorem e_half : e (1 / 2) = -1 := by
  rw [e]
  convert Complex.exp_pi_mul_I using 2 <;> push_cast <;> ring

private theorem e_three_quarters : e (3 / 4) = -Complex.I := by
  change Complex.exp (2 * (Real.pi : ℂ) * Complex.I * ((3 / 4 : ℝ) : ℂ)) = _
  rw [show 2 * (Real.pi : ℂ) * Complex.I * ((3 / 4 : ℝ) : ℂ) =
      2 * (Real.pi : ℂ) * Complex.I * ((1 / 2 : ℝ) : ℂ) +
        2 * (Real.pi : ℂ) * Complex.I * ((1 / 4 : ℝ) : ℂ) by push_cast; ring,
    Complex.exp_add]
  change e (1 / 2) * e (1 / 4) = _
  rw [e_half, e_quarter]
  ring

private theorem e_mul (x y : ℝ) : e x * e y = e (x + y) := by
  simp only [e, ← Complex.exp_add]
  congr 1
  push_cast
  ring

private theorem neg_mul_I_as_e (z : ℂ) : -(z * Complex.I) = z * e (3 / 4) := by
  rw [e_three_quarters]
  ring

private theorem neg_as_e (z : ℂ) : -z = z * e (1 / 2) := by
  rw [e_half]
  ring

private theorem phase_algebra_zero (t : ℂ) (h : 1 + t * 8 ≠ 0) :
    -(t * (1 + t * 8)⁻¹ * 12) - t ^ 2 * (1 + t * 8)⁻¹ * 48 -
        t ^ 3 * (1 + t * 8)⁻¹ * 64 - (1 + t * 8)⁻¹ =
      -1 - t * 5 + t * (1 + t * 8)⁻¹ - t ^ 2 * 8 := by
  field_simp [h]
  ring

private theorem phase_algebra_one (t : ℂ) (h : 3 + t * 8 ≠ 0) :
    3 - t * (3 + t * 8)⁻¹ * 192 - t ^ 2 * (3 + t * 8)⁻¹ * 384 -
        t ^ 3 * (3 + t * 8)⁻¹ * 256 - (3 + t * 8)⁻¹ * 32 =
      -8 - t * 36 + t * (3 + t * 8)⁻¹ * 4 - t ^ 2 * 32 +
        (3 + t * 8)⁻¹ := by
  field_simp [h]
  ring

private theorem phase_algebra_two (t : ℂ) (h : 5 + t * 8 ≠ 0) :
    4 - t * (5 + t * 8)⁻¹ * 864 - t ^ 2 * (5 + t * 8)⁻¹ * 1152 -
        t ^ 3 * (5 + t * 8)⁻¹ * 512 - (5 + t * 8)⁻¹ * 216 =
      -40 - t * 104 + t * (5 + t * 8)⁻¹ * 8 - t ^ 2 * 64 +
        (5 + t * 8)⁻¹ * 4 := by
  field_simp [h]
  ring

private theorem phase_algebra_three (t : ℂ) (h : 7 + t * 8 ≠ 0) :
    1 - t * (7 + t * 8)⁻¹ * 768 - t ^ 2 * (7 + t * 8)⁻¹ * 768 -
        t ^ 3 * (7 + t * 8)⁻¹ * 256 - (7 + t * 8)⁻¹ * 256 =
      -36 - t * 68 + t * (7 + t * 8)⁻¹ * 4 - t ^ 2 * 32 +
        (7 + t * 8)⁻¹ * 3 := by
  field_simp [h]
  ring

private theorem phase_identity (q : ℕ) :
    e (-(((q + 1 : ℕ) ^ 3 : ℕ) : ℝ) / (2 * q + 1 : ℕ)) *
        (-1 : ℂ) ^ (q * (q + 1) / 2) *
      (if (2 * q + 1) % 4 = 1 then 1 else Complex.I) =
    e ((q : ℝ) / (4 * (2 * q + 1 : ℕ))) := by
  obtain ⟨t, ht⟩ : ∃ t, q = 4 * t + q % 4 :=
    ⟨q / 4, (Nat.mod_add_div q 4).symm.trans (by omega)⟩
  have hlt : q % 4 < 4 := Nat.mod_lt _ (by omega)
  interval_cases h : q % 4
  · have hq : q = 4 * t := by omega
    subst q
    have hexp : (4 * t) * (4 * t + 1) / 2 = 2 * t * (4 * t + 1) := by
      rw [show (4 * t) * (4 * t + 1) =
        (2 * t * (4 * t + 1)) * 2 by ring, Nat.mul_div_left _ (by omega)]
    have hpow : (-1 : ℂ) ^ ((4 * t) * (4 * t + 1) / 2) = 1 := by
      rw [hexp, show 2 * t * (4 * t + 1) = 2 * (t * (4 * t + 1)) by ring,
        pow_mul]
      norm_num
    rw [show (4 * t + 0) * (4 * t + 0 + 1) / 2 =
      (4 * t) * (4 * t + 1) / 2 by congr 2 <;> omega, hpow]
    norm_num [show (2 * (4 * t) + 1) % 4 = 1 by omega]
    apply Complex.exp_eq_exp_iff_exists_int.mpr
    refine ⟨-(8 * t ^ 2 + 5 * t + 1 : ℤ), ?_⟩
    push_cast
    have hd : (1 + (t : ℂ) * 8) ≠ 0 := by
      intro hzero
      have hr := congrArg Complex.re hzero
      norm_num at hr
      have hp : (0 : ℝ) < 1 + (t : ℝ) * 8 := by positivity
      linarith
    have halt : (4 + (t : ℂ) * 32)⁻¹ = (1 + (t : ℂ) * 8)⁻¹ / 4 := by
      rw [show 4 + (t : ℂ) * 32 = 4 * (1 + t * 8) by ring, mul_inv]
      ring
    ring_nf
    rw [halt]
    field_simp [hd]
    ring
  · have hq : q = 4 * t + 1 := by omega
    subst q
    have hexp : (4 * t + 1) * (4 * t + 2) / 2 =
        (4 * t + 1) * (2 * t + 1) := by
      rw [show (4 * t + 1) * (4 * t + 2) =
        ((4 * t + 1) * (2 * t + 1)) * 2 by ring,
        Nat.mul_div_left _ (by omega)]
    have hpow : (-1 : ℂ) ^ ((4 * t + 1) * (4 * t + 2) / 2) = -1 := by
      rw [hexp, pow_mul]
      norm_num [pow_add, pow_mul]
    rw [show (4 * t + 1) * (4 * t + 1 + 1) / 2 =
      (4 * t + 1) * (4 * t + 2) / 2 by congr 2 <;> omega,
      hpow, if_neg (by omega : (2 * (4 * t + 1) + 1) % 4 ≠ 1)]
    norm_num
    rw [neg_mul_I_as_e, e_mul]
    apply Complex.exp_eq_exp_iff_exists_int.mpr
    refine ⟨-(8 * t ^ 2 + 9 * t + 2 : ℤ), ?_⟩
    push_cast
    have hd : (3 + (t : ℂ) * 8) ≠ 0 := by
      intro hzero
      have hr := congrArg Complex.re hzero
      norm_num at hr
      have hp : (0 : ℝ) < 3 + (t : ℝ) * 8 := by positivity
      linarith
    have halt : (12 + (t : ℂ) * 32)⁻¹ = (3 + (t : ℂ) * 8)⁻¹ / 4 := by
      rw [show 12 + (t : ℂ) * 32 = 4 * (3 + t * 8) by ring, mul_inv]
      ring
    ring_nf
    rw [halt]
    field_simp [hd]
    ring
  · have hq : q = 4 * t + 2 := by omega
    subst q
    have hexp : (4 * t + 2) * (4 * t + 3) / 2 =
        (2 * t + 1) * (4 * t + 3) := by
      rw [show (4 * t + 2) * (4 * t + 3) =
        ((2 * t + 1) * (4 * t + 3)) * 2 by ring,
        Nat.mul_div_left _ (by omega)]
    have hpow : (-1 : ℂ) ^ ((4 * t + 2) * (4 * t + 3) / 2) = -1 := by
      rw [hexp, pow_mul]
      norm_num [pow_add, pow_mul]
    rw [show (4 * t + 2) * (4 * t + 2 + 1) / 2 =
      (4 * t + 2) * (4 * t + 3) / 2 by congr 2 <;> omega,
      hpow, if_pos (by omega : (2 * (4 * t + 2) + 1) % 4 = 1)]
    norm_num
    rw [neg_as_e, e_mul]
    apply Complex.exp_eq_exp_iff_exists_int.mpr
    refine ⟨-(8 * t ^ 2 + 13 * t + 5 : ℤ), ?_⟩
    push_cast
    have hd : (5 + (t : ℂ) * 8) ≠ 0 := by
      intro hzero
      have hr := congrArg Complex.re hzero
      norm_num at hr
      have hp : (0 : ℝ) < 5 + (t : ℝ) * 8 := by positivity
      linarith
    have halt : (20 + (t : ℂ) * 32)⁻¹ = (5 + (t : ℂ) * 8)⁻¹ / 4 := by
      rw [show 20 + (t : ℂ) * 32 = 4 * (5 + t * 8) by ring, mul_inv]
      ring
    ring_nf
    rw [halt]
    field_simp [hd]
    ring
  · have hq : q = 4 * t + 3 := by omega
    subst q
    have hexp : (4 * t + 3) * (4 * t + 4) / 2 =
        (4 * t + 3) * (2 * t + 2) := by
      rw [show (4 * t + 3) * (4 * t + 4) =
        ((4 * t + 3) * (2 * t + 2)) * 2 by ring,
        Nat.mul_div_left _ (by omega)]
    have hpow : (-1 : ℂ) ^ ((4 * t + 3) * (4 * t + 4) / 2) = 1 := by
      rw [hexp, pow_mul]
      norm_num [pow_add, pow_mul]
    rw [show (4 * t + 3) * (4 * t + 3 + 1) / 2 =
      (4 * t + 3) * (4 * t + 4) / 2 by congr 2 <;> omega,
      hpow, if_neg (by omega : (2 * (4 * t + 3) + 1) % 4 ≠ 1)]
    norm_num
    rw [show Complex.I = e (1 / 4) by rw [e_quarter], e_mul]
    apply Complex.exp_eq_exp_iff_exists_int.mpr
    refine ⟨-(8 * t ^ 2 + 17 * t + 9 : ℤ), ?_⟩
    push_cast
    have hd : (7 + (t : ℂ) * 8) ≠ 0 := by
      intro hzero
      have hr := congrArg Complex.re hzero
      norm_num at hr
      have hp : (0 : ℝ) < 7 + (t : ℝ) * 8 := by positivity
      linarith
    have halt : (28 + (t : ℂ) * 32)⁻¹ = (7 + (t : ℂ) * 8)⁻¹ / 4 := by
      rw [show 28 + (t : ℂ) * 32 = 4 * (7 + t * 8) by ring, mul_inv]
      ring
    ring_nf
    rw [halt]
    field_simp [hd]
    ring

theorem sum_tri_raw (q : ℕ) :
    (∑ k ∈ Finset.range (2 * q + 1),
      e (((k : ℝ) * ((k : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ)))) =
      e (((2 * q + 1 : ℝ) - 1) / (8 * (2 * q + 1 : ℝ))) *
        (Real.sqrt (2 * q + 1) : ℂ) := by
  rw [triangular_sum_eq_twisted, twisted_sum_value]
  have harg : (2 * (q : ℝ) + 1 - 1) / (8 * (2 * (q : ℝ) + 1)) =
      (q : ℝ) / (4 * (2 * q + 1 : ℕ)) := by push_cast; field_simp; ring
  rw [harg]
  rw [mul_assoc, ← phase_identity]
  ring

theorem sum_tri_exp (q : ℕ) :
    (∑ k ∈ Finset.range (2 * q + 1),
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I *
        ((((k : ℝ) * ((k : ℝ) + 1)) / (2 * (2 * q + 1 : ℝ)) : ℝ) : ℂ))) =
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I *
        (((((2 * q + 1 : ℕ) : ℝ) - 1) /
          (8 * ((2 * q + 1 : ℕ) : ℝ)) : ℝ) : ℂ)) *
        (Real.sqrt ((2 * q + 1 : ℕ) : ℝ) : ℂ) := by
  simpa [e] using sum_tri_raw q

end

end OddGaussSum
