import Mathlib

open Lean Elab Command

elab "#findnames" s:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if n.toString.toLower.contains s.getString.toLower then
      logInfo m!"{n}"

#findnames "resultant"
