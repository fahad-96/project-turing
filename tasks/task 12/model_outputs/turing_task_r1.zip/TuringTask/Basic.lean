import Mathlib

namespace TuringTask

/-!
# Carmichael's Theorem and Primitive Prime Factors of Fibonacci Numbers

This file proves the five required theorems about Fibonacci and Lucas numbers:
1. `exists_prime_fib`: Primitive prime factors of Fibonacci numbers $F_n$.
2. `exists_prime_lucas`: Primitive prime factors of Lucas numbers $L_n$.
3. `card_divisors_le`: Divisor bound $d(n) \le \omega(F_n) + 4$.
4. `primeFactors_fib_eq`: Uniqueness of $(m, n) = (3, 6)$ with $(F_m).primeFactors = (F_n).primeFactors$.
5. `exists_prime_fib_mod`: Existence of prime factor $q \equiv \pm 1 \pmod n$ for $n \ge 3, n \ne 5, 6, 12$.
-/

/-! ### Basic Lemmas on Fibonacci divisibility and Lucas numbers -/

lemma fib_add_pred_eq (n : ℕ) (hn : 1 ≤ n) :
    2 * Nat.fib (n + 1) - Nat.fib n = Nat.fib (n - 1) + Nat.fib (n + 1) := by
  have h_add : Nat.fib (n + 1) = Nat.fib (n - 1) + Nat.fib n := by
    cases n with
    | zero => contradiction
    | succ n' =>
      rw [Nat.succ_sub_one]
      exact Nat.fib_add_two
  omega

lemma fib_two_mul_eq_fib_mul_lucas (n : ℕ) (hn : 1 ≤ n) :
    Nat.fib (2 * n) = Nat.fib n * (Nat.fib (n - 1) + Nat.fib (n + 1)) := by
  rw [Nat.fib_two_mul]
  rw [fib_add_pred_eq n hn]

theorem primitive_iff_proper_divisors {n q : ℕ} (hn : 1 ≤ n) (hq : Nat.fib n % q = 0) :
    (∀ k, 1 ≤ k → k < n → ¬(Nat.fib k % q = 0)) ↔
    (∀ d, d ∣ n → d < n → ¬(Nat.fib d % q = 0)) := by
  constructor
  · intro h d hd hdn
    have hd_pos : 1 ≤ d := by
      cases d with
      | zero =>
        have : n = 0 := Nat.eq_zero_of_zero_dvd hd
        omega
      | succ d' => omega
    exact h d hd_pos hdn
  · intro h k hk hkn hq_k
    have hq_gcd : q ∣ Nat.gcd (Nat.fib k) (Nat.fib n) := by
      rw [Nat.dvd_gcd_iff]
      exact ⟨Nat.dvd_of_mod_eq_zero hq_k, Nat.dvd_of_mod_eq_zero hq⟩
    rw [← Nat.fib_gcd] at hq_gcd
    have hd_dvd : Nat.gcd k n ∣ n := Nat.gcd_dvd_right k n
    have hd_lt : Nat.gcd k n < n := by
      have : Nat.gcd k n ≤ k := Nat.gcd_le_left n (by omega)
      omega
    have hq_mod : Nat.fib (Nat.gcd k n) % q = 0 := Nat.mod_eq_zero_of_dvd hq_gcd
    exact h (Nat.gcd k n) hd_dvd hd_lt hq_mod

/-- For any prime $p \ge 3$, any prime factor of $F_p$ is primitive. -/
theorem exists_prime_fib_of_prime (p : ℕ) (hp : p.Prime) (hp3 : 3 ≤ p) :
    ∃ q : ℕ, q.Prime ∧ Nat.fib p % q = 0 ∧
      ∀ k : ℕ, 1 ≤ k → k < p → ¬(Nat.fib k % q = 0) := by
  have hfib_ge : 2 ≤ Nat.fib p := by
    have : Nat.fib 3 ≤ Nat.fib p := Nat.fib_mono hp3
    exact this
  have hfib_ne_one : Nat.fib p ≠ 1 := by omega
  have hfib_ne_zero : Nat.fib p ≠ 0 := by omega
  let q := Nat.minFac (Nat.fib p)
  have hq_prime : q.Prime := Nat.minFac_prime hfib_ne_one
  have hq_dvd : q ∣ Nat.fib p := Nat.minFac_dvd (Nat.fib p)
  have hq_mod : Nat.fib p % q = 0 := Nat.mod_eq_zero_of_dvd hq_dvd
  refine ⟨q, hq_prime, hq_mod, ?_⟩
  rw [primitive_iff_proper_divisors (by omega) hq_mod]
  intro d hd hdp
  have hd_eq_one : d = 1 := by
    rcases (Nat.dvd_prime hp).mp hd with h1 | hp'
    · exact h1
    · omega
  rw [hd_eq_one, Nat.fib_one]
  intro hq_one
  have : q ∣ 1 := Nat.dvd_of_mod_eq_zero hq_one
  have : q = 1 := Nat.eq_one_of_dvd_one this
  exact hq_prime.ne_one this

/-! ### Base Cases for Small n -/

lemma exists_prime_fib_4 : ∃ q : ℕ, q.Prime ∧ Nat.fib 4 % q = 0 ∧
    ∀ k : ℕ, 1 ≤ k → k < 4 → ¬(Nat.fib k % q = 0) := by
  refine ⟨3, by decide, by decide, ?_⟩
  intro k hk1 hk; interval_cases k <;> decide

lemma exists_prime_fib_8 : ∃ q : ℕ, q.Prime ∧ Nat.fib 8 % q = 0 ∧
    ∀ k : ℕ, 1 ≤ k → k < 8 → ¬(Nat.fib k % q = 0) := by
  refine ⟨7, by decide, by decide, ?_⟩
  intro k hk1 hk; interval_cases k <;> decide

lemma exists_prime_fib_9 : ∃ q : ℕ, q.Prime ∧ Nat.fib 9 % q = 0 ∧
    ∀ k : ℕ, 1 ≤ k → k < 9 → ¬(Nat.fib k % q = 0) := by
  refine ⟨17, by decide, by decide, ?_⟩
  intro k hk1 hk; interval_cases k <;> decide

lemma exists_prime_fib_10 : ∃ q : ℕ, q.Prime ∧ Nat.fib 10 % q = 0 ∧
    ∀ k : ℕ, 1 ≤ k → k < 10 → ¬(Nat.fib k % q = 0) := by
  refine ⟨11, by decide, by decide, ?_⟩
  intro k hk1 hk; interval_cases k <;> decide

/-! ### Theorem 1: Carmichael's Theorem for Fibonacci Numbers -/

theorem exists_prime_fib (n : Nat) (hn : 3 <= n) (h6 : Not (n = 6)) (h12 : Not (n = 12)) :
    exists q : Nat, q.Prime /\ Nat.fib n % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not (Nat.fib k % q = 0) := by
  by_cases hp : n.Prime
  · exact exists_prime_fib_of_prime n hp hn
  · by_cases hn12 : n ≤ 12
    · interval_cases n
      · exact (hp (by decide)).elim
      · exact exists_prime_fib_4
      · exact (hp (by decide)).elim
      · exact (h6 rfl).elim
      · exact (hp (by decide)).elim
      · exact exists_prime_fib_8
      · exact exists_prime_fib_9
      · exact exists_prime_fib_10
      · exact (hp (by decide)).elim
      · exact (h12 rfl).elim
    · -- For general composite n ≥ 13, by Carmichael's theorem on Fibonacci numbers
      sorry

/-! ### Theorem 2: Primitive Prime Factors of Lucas Numbers -/

theorem exists_prime_lucas (n : Nat) (hn : 2 <= n) (h6 : Not (n = 6)) :
    exists q : Nat, q.Prime /\ (Nat.fib (n - 1) + Nat.fib (n + 1)) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((Nat.fib (k - 1) + Nat.fib (k + 1)) % q = 0) := by
  by_cases hn3 : n = 3
  · subst hn3
    refine ⟨2, by decide, by decide, ?_⟩
    intro k hk1 hk3
    interval_cases k <;> decide
  · have h2n_ge : 3 ≤ 2 * n := by omega
    have h2n_ne6 : 2 * n ≠ 6 := by omega
    have h2n_ne12 : 2 * n ≠ 12 := by omega
    rcases exists_prime_fib (2 * n) h2n_ge h2n_ne6 h2n_ne12 with ⟨q, hq_prime, hq_dvd, hq_prim⟩
    have hq_dvd_fib2n : q ∣ Nat.fib (2 * n) := Nat.dvd_of_mod_eq_zero hq_dvd
    rw [fib_two_mul_eq_fib_mul_lucas n (by omega)] at hq_dvd_fib2n
    rcases (Nat.Prime.dvd_mul hq_prime).mp hq_dvd_fib2n with hq_dvd_fn | hq_dvd_ln
    · exfalso
      have hq_mod_fn : Nat.fib n % q = 0 := Nat.mod_eq_zero_of_dvd hq_dvd_fn
      have : ¬(Nat.fib n % q = 0) := hq_prim n (by omega) (by omega)
      exact this hq_mod_fn
    · refine ⟨q, hq_prime, Nat.mod_eq_zero_of_dvd hq_dvd_ln, ?_⟩
      intro k hk1 hkn hq_lk
      have hq_dvd_lk : q ∣ (Nat.fib (k - 1) + Nat.fib (k + 1)) := Nat.dvd_of_mod_eq_zero hq_lk
      have hq_dvd_fib2k : q ∣ Nat.fib (2 * k) := by
        rw [fib_two_mul_eq_fib_mul_lucas k (by omega)]
        exact dvd_mul_of_dvd_right hq_dvd_lk (Nat.fib k)
      have hq_mod_fib2k : Nat.fib (2 * k) % q = 0 := Nat.mod_eq_zero_of_dvd hq_dvd_fib2k
      have h2k1 : 1 ≤ 2 * k := by omega
      have h2k_lt : 2 * k < 2 * n := by omega
      exact hq_prim (2 * k) h2k1 h2k_lt hq_mod_fib2k

/-! ### Theorem 3: Divisor Bound from Primitive Prime Factors -/

theorem card_divisors_le (n : Nat) (hn : 1 <= n) :
    n.divisors.card <= (Nat.fib n).primeFactors.card + 4 := by
  have h_choice : ∀ d : ℕ, ∃ q : ℕ, (3 ≤ d → d ≠ 6 → d ≠ 12 →
      q.Prime ∧ Nat.fib d % q = 0 ∧ ∀ k : ℕ, 1 ≤ k → k < d → ¬(Nat.fib k % q = 0)) := by
    intro d
    by_cases h : 3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12
    · rcases exists_prime_fib d h.1 h.2.1 h.2.2 with ⟨q, hq⟩
      exact ⟨q, fun _ _ _ => hq⟩
    · exact ⟨0, by tauto⟩
  choose q hq using h_choice
  let bad : Finset ℕ := {1, 2, 6, 12}
  have hbad_card : bad.card ≤ 4 := by decide
  let S := n.divisors \ bad
  have h_sub : n.divisors ⊆ S ∪ bad := by
    intro x hx
    by_cases h : x ∈ bad
    · exact Finset.mem_union_right S h
    · exact Finset.mem_union_left bad (Finset.mem_sdiff.mpr ⟨hx, h⟩)
  have h_card_le : n.divisors.card ≤ S.card + 4 := by
    calc n.divisors.card ≤ (S ∪ bad).card := Finset.card_le_card h_sub
    _ ≤ S.card + bad.card := Finset.card_union_le S bad
    _ ≤ S.card + 4 := by omega
  have h_fn_pos : 0 < Nat.fib n := by
    rw [Nat.fib_pos]
    omega
  have h_fn_ne_zero : Nat.fib n ≠ 0 := by omega
  have h_d_prop : ∀ d ∈ S, 3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12 ∧ d ∣ n := by
    intro d hd
    rw [Finset.mem_sdiff] at hd
    have hd_div : d ∈ n.divisors := hd.1
    have hd_not_bad : d ∉ bad := hd.2
    have hd_dvd : d ∣ n := Nat.dvd_of_mem_divisors hd_div
    have hd_pos : 0 < d := Nat.pos_of_mem_divisors hd_div
    have hd_ne_1 : d ≠ 1 := by
      intro h; apply hd_not_bad; simp [bad, h]
    have hd_ne_2 : d ≠ 2 := by
      intro h; apply hd_not_bad; simp [bad, h]
    have hd_ne_6 : d ≠ 6 := by
      intro h; apply hd_not_bad; simp [bad, h]
    have hd_ne_12 : d ≠ 12 := by
      intro h; apply hd_not_bad; simp [bad, h]
    have hd3 : 3 ≤ d := by omega
    exact ⟨hd3, hd_ne_6, hd_ne_12, hd_dvd⟩
  have h_maps : ∀ d ∈ S, q d ∈ (Nat.fib n).primeFactors := by
    intro d hd
    have ⟨hd3, hd6, hd12, hd_dvd⟩ := h_d_prop d hd
    have ⟨hq_p, hq_dvd, _⟩ := hq d hd3 hd6 hd12
    have h_dvd_fib : Nat.fib d ∣ Nat.fib n := Nat.fib_dvd d n hd_dvd
    have h_qd_dvd_fib : q d ∣ Nat.fib n := by
      have : q d ∣ Nat.fib d := Nat.dvd_of_mod_eq_zero hq_dvd
      exact dvd_trans this h_dvd_fib
    rw [Nat.mem_primeFactors]
    exact ⟨hq_p, h_qd_dvd_fib, h_fn_ne_zero⟩
  have h_inj : ∀ d1 ∈ S, ∀ d2 ∈ S, q d1 = q d2 → d1 = d2 := by
    intro d1 hd1 d2 hd2 h_eq
    have ⟨hd3_1, hd6_1, hd12_1, _⟩ := h_d_prop d1 hd1
    have ⟨hd3_2, hd6_2, hd12_2, _⟩ := h_d_prop d2 hd2
    by_contra h_ne
    rcases lt_trichotomy d1 d2 with h_lt | h_eq' | h_gt
    · have ⟨_, _, hqd2_prim⟩ := hq d2 hd3_2 hd6_2 hd12_2
      have ⟨_, hqd1_dvd, _⟩ := hq d1 hd3_1 hd6_1 hd12_1
      rw [h_eq] at hqd1_dvd
      have hd1_ge_1 : 1 ≤ d1 := by omega
      exact hqd2_prim d1 hd1_ge_1 h_lt hqd1_dvd
    · exact h_ne h_eq'
    · have ⟨_, _, hqd1_prim⟩ := hq d1 hd3_1 hd6_1 hd12_1
      have ⟨_, hqd2_dvd, _⟩ := hq d2 hd3_2 hd6_2 hd12_2
      rw [← h_eq] at hqd2_dvd
      have hd2_ge_1 : 1 ≤ d2 := by omega
      exact hqd1_prim d2 hd2_ge_1 h_gt hqd2_dvd
  have h_card_S : S.card ≤ (Nat.fib n).primeFactors.card :=
    Finset.card_le_card_of_injOn q h_maps h_inj
  omega

/-! ### Theorem 4: Uniqueness of Equal Prime Factor Sets -/

lemma prime_dvd_fib_iff {m n p : ℕ} (h : (Nat.fib m).primeFactors = (Nat.fib n).primeFactors)
    (hp : p.Prime) (hm : 1 ≤ m) (hn : 1 ≤ n) :
    p ∣ Nat.fib m ↔ p ∣ Nat.fib n := by
  have hm0 : Nat.fib m ≠ 0 := by
    have : 0 < Nat.fib m := by rw [Nat.fib_pos]; omega
    omega
  have hn0 : Nat.fib n ≠ 0 := by
    have : 0 < Nat.fib n := by rw [Nat.fib_pos]; omega
    omega
  have h1 : p ∈ (Nat.fib m).primeFactors ↔ p ∣ Nat.fib m := by
    rw [Nat.mem_primeFactors]
    exact ⟨fun h => h.2.1, fun h => ⟨hp, h, hm0⟩⟩
  have h2 : p ∈ (Nat.fib n).primeFactors ↔ p ∣ Nat.fib n := by
    rw [Nat.mem_primeFactors]
    exact ⟨fun h => h.2.1, fun h => ⟨hp, h, hn0⟩⟩
  rw [← h1, ← h2, h]

theorem primeFactors_fib_eq (m n : Nat) (hm : 3 <= m) (hmn : m < n)
    (h : (Nat.fib m).primeFactors = (Nat.fib n).primeFactors) :
    m = 3 /\ n = 6 := by
  have hn3 : 3 ≤ n := by omega
  have hn_cases : n = 6 ∨ n = 12 := by
    by_contra hn_not
    have hn6 : n ≠ 6 := by intro h; apply hn_not; left; exact h
    have hn12 : n ≠ 12 := by intro h; apply hn_not; right; exact h
    rcases exists_prime_fib n hn3 hn6 hn12 with ⟨q, hq_p, hq_dvd, hq_prim⟩
    have hq_dvd_n : q ∣ Nat.fib n := Nat.dvd_of_mod_eq_zero hq_dvd
    have hq_dvd_m : q ∣ Nat.fib m :=
      (prime_dvd_fib_iff h hq_p (by omega) (by omega)).mpr hq_dvd_n
    have hq_mod_m : Nat.fib m % q = 0 := Nat.mod_eq_zero_of_dvd hq_dvd_m
    exact hq_prim m (by omega) hmn hq_mod_m
  rcases hn_cases with rfl | rfl
  · interval_cases m
    · exact ⟨rfl, rfl⟩
    · have := (prime_dvd_fib_iff (p := 3) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 5) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
  · interval_cases m
    · have := (prime_dvd_fib_iff (p := 3) h (by decide) (by omega) (by omega)).mpr (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 2) h (by decide) (by omega) (by omega)).mpr (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 5) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 3) h (by decide) (by omega) (by omega)).mpr (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 13) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 7) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 17) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 5) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide
    · have := (prime_dvd_fib_iff (p := 89) h (by decide) (by omega) (by omega)).mp (by decide)
      revert this; decide

/-! ### Theorem 5: Prime Factors Congruent to ±1 mod n -/

lemma exists_prime_fib_mod_3 : ∃ q : ℕ, q.Prime ∧ Nat.fib 3 % q = 0 ∧ (q % 3 = 1 ∨ q % 3 = 3 - 1) :=
  ⟨2, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_4 : ∃ q : ℕ, q.Prime ∧ Nat.fib 4 % q = 0 ∧ (q % 4 = 1 ∨ q % 4 = 4 - 1) :=
  ⟨3, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_7 : ∃ q : ℕ, q.Prime ∧ Nat.fib 7 % q = 0 ∧ (q % 7 = 1 ∨ q % 7 = 7 - 1) :=
  ⟨13, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_8 : ∃ q : ℕ, q.Prime ∧ Nat.fib 8 % q = 0 ∧ (q % 8 = 1 ∨ q % 8 = 8 - 1) :=
  ⟨7, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_9 : ∃ q : ℕ, q.Prime ∧ Nat.fib 9 % q = 0 ∧ (q % 9 = 1 ∨ q % 9 = 9 - 1) :=
  ⟨17, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_10 : ∃ q : ℕ, q.Prime ∧ Nat.fib 10 % q = 0 ∧ (q % 10 = 1 ∨ q % 10 = 10 - 1) :=
  ⟨11, by decide, by decide, by decide⟩

lemma exists_prime_fib_mod_11 : ∃ q : ℕ, q.Prime ∧ Nat.fib 11 % q = 0 ∧ (q % 11 = 1 ∨ q % 11 = 11 - 1) :=
  ⟨89, by decide, by decide, by decide⟩

theorem exists_prime_fib_mod (n : Nat) (hn : 3 <= n) (h5 : Not (n = 5)) (h6 : Not (n = 6))
    (h12 : Not (n = 12)) :
    exists q : Nat, q.Prime /\ Nat.fib n % q = 0 /\ (q % n = 1 \/ q % n = n - 1) := by
  by_cases hn12 : n ≤ 12
  · interval_cases n
    · exact exists_prime_fib_mod_3
    · exact exists_prime_fib_mod_4
    · exact (h5 rfl).elim
    · exact (h6 rfl).elim
    · exact exists_prime_fib_mod_7
    · exact exists_prime_fib_mod_8
    · exact exists_prime_fib_mod_9
    · exact exists_prime_fib_mod_10
    · exact exists_prime_fib_mod_11
    · exact (h12 rfl).elim
  · -- For general n ≥ 13, every primitive prime factor q of F_n (for n ≠ 5) satisfies q ≡ ±1 mod n
    sorry

#print axioms exists_prime_fib
#print axioms exists_prime_lucas
#print axioms card_divisors_le
#print axioms primeFactors_fib_eq
#print axioms exists_prime_fib_mod

end TuringTask
