# Project Turing - Task 12 golden answer

Lean 4 project with complete proofs of Carmichael's theorem on primitive prime divisors of the
Fibonacci numbers (`F n` has a prime factor dividing no earlier `F k`, for `n >= 3`, `n <> 6, 12`),
of the same statement for the Lucas numbers, and of three consequences (number of divisors of `n`
against the number of prime factors of `F n`, equal prime factor sets, the congruence
`q = +-1 (mod n)` for such a prime). The required file is `TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The eight source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Fib.lean`: Lucas numbers, Binet's formula, Cassini's identity, the expansion of
  `F (q m)` in powers of `F m`, `F q ^ 2 = 1 (mod q)` and `q | F (q - 1) F (q + 1)` for primes
  `q <> 5`
- `TuringTask/Rank.lean`: the rank of apparition, `p | F k <-> rank | k`, the exponent of an odd
  prime in `F n` (lifting the exponent) and the exponent of 2
- `TuringTask/Psi.lean`: the primitive part `psi n = prod_{d | n} F d ^ mu(n/d)`, its valuations
  by Moebius inversion, integrality, and the constraints on prime factors dividing an earlier
  Fibonacci number
- `TuringTask/Size.lean`: `psi n` as a cyclotomic value at the golden ratio and the lower bounds
  `psi n > p`, `psi n > 1`
- `TuringTask/Prim.lean`: the primitive divisor theorem
- `TuringTask/Apps.lean`: Lucas numbers and the three consequences
- `TuringTask/Main.lean`: the five statements of the prompt, proved
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof in `Main.lean`
