import Mathlib

open scoped BigOperators ComplexConjugate

namespace Research

private theorem exp_root_ne_one (n l : ℕ) (hn : 0 < n) (hl : 0 < l) (hln : l < n) :
    Complex.exp (((2 * Real.pi * l / n : ℝ) : ℂ) * Complex.I) ≠ 1 := by
  rw [ne_eq, Complex.exp_eq_one_iff]
  rintro ⟨m, hm⟩
  have him : 2 * Real.pi * l / n = (m : ℝ) * (2 * Real.pi) := by
    have h := congrArg Complex.im hm
    norm_num [Complex.mul_im] at h ⊢
    exact h
  have hpi : (Real.pi : ℝ) ≠ 0 := Real.pi_ne_zero
  have hn0 : (n : ℝ) ≠ 0 := by positivity
  have heq : (l : ℝ) = (m : ℝ) * n := by
    field_simp at him
    nlinarith
  have heq' : (l : ℤ) = m * n := by exact_mod_cast heq
  have hmpos : 0 < m := by
    by_contra hmnot
    have hmle : m ≤ 0 := le_of_not_gt hmnot
    have hnnonneg : (0 : ℤ) ≤ n := by positivity
    have : (l : ℤ) ≤ 0 := by
      rw [heq']
      exact mul_nonpos_of_nonpos_of_nonneg hmle hnnonneg
    omega
  have : (n : ℤ) ≤ l := by
    rw [heq']
    have : (1 : ℤ) ≤ m := by omega
    nlinarith
  omega

private theorem exp_root_pow (n l : ℕ) (hn : 0 < n) :
    Complex.exp (((2 * Real.pi * l / n : ℝ) : ℂ) * Complex.I) ^ n = 1 := by
  rw [← Complex.exp_nat_mul]
  have hn0 : (n : ℝ) ≠ 0 := by positivity
  have harg : (n : ℂ) * (((2 * Real.pi * l / n : ℝ) : ℂ) * Complex.I) =
      (l : ℤ) * (2 * (Real.pi : ℂ) * Complex.I) := by
    apply Complex.ext
    · norm_num [Complex.mul_re]
    · norm_num [Complex.mul_im]
      field_simp
  rw [harg, Complex.exp_int_mul_two_pi_mul_I]

private theorem sum_exp_root (n l : ℕ) (hn : 0 < n) (hl : 0 < l) (hln : l < n) :
    ∑ k ∈ Finset.range n,
      Complex.exp (((2 * Real.pi * l * k / n : ℝ) : ℂ) * Complex.I) = 0 := by
  let z : ℂ := Complex.exp (((2 * Real.pi * l / n : ℝ) : ℂ) * Complex.I)
  have hzpow : z ^ n = 1 := exp_root_pow n l hn
  have hzne : z ≠ 1 := exp_root_ne_one n l hn hl hln
  have hgeom := geom_sum_mul z n
  rw [hzpow, sub_self] at hgeom
  have hsum : ∑ k ∈ Finset.range n, z ^ k = 0 := by
    rcases mul_eq_zero.mp hgeom with h | h
    · exact h
    · exact (hzne (sub_eq_zero.mp h)).elim
  rw [← hsum]
  apply Finset.sum_congr rfl
  intro k hk
  rw [← Complex.exp_nat_mul]
  congr 1
  push_cast
  have hn0 : (n : ℝ) ≠ 0 := by positivity
  field_simp

theorem sum_cos_root (n l : ℕ) (hn : 0 < n) (hl : 0 < l) (hln : l < n) :
    ∑ k ∈ Finset.range n, Real.cos (2 * Real.pi * l * k / n) = 0 := by
  have h := congrArg Complex.reCLM (sum_exp_root n l hn hl hln)
  simp only [map_sum] at h
  change (∑ k ∈ Finset.range n,
    (Complex.exp (((2 * Real.pi * l * k / n : ℝ) : ℂ) * Complex.I)).re) = 0 at h
  simpa [Complex.exp_re, Complex.mul_re, Complex.mul_im] using h

end Research
