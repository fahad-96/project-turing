import Mathlib

/-!
A checked bridge from a prime divisor of a cyclotomic value to exact
multiplicative order. The hypotheses `p ∤ n` and `p ∣ Φ_n(q)` isolate the
part of Bang-Zsigmondy that existing Mathlib APIs handle concisely.
-/

theorem exact_order_of_prime_dvd_cyclotomic_eval
    {q n p : ℕ} (hp : p.Prime) (hpn : ¬p ∣ n)
    (hdvd : (p : ℤ) ∣ Polynomial.eval (q : ℤ) (Polynomial.cyclotomic n ℤ)) :
    orderOf (q : ZMod p) = n := by
  letI : Fact p.Prime := ⟨hp⟩
  letI : NeZero (n : ZMod p) :=
    ⟨by
      intro h
      exact hpn ((ZMod.natCast_eq_zero_iff n p).mp h)⟩
  have heval :
      ((Polynomial.eval (q : ℤ) (Polynomial.cyclotomic n ℤ) : ℤ) : ZMod p) = 0 :=
    (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).2 hdvd
  have hroot :
      (Polynomial.cyclotomic n (ZMod p)).IsRoot (q : ZMod p) := by
    change Polynomial.eval (q : ZMod p) (Polynomial.cyclotomic n (ZMod p)) = 0
    rw [← Polynomial.map_cyclotomic_int, Polynomial.eval_map]
    have hq : (q : ZMod p) = (Int.castRingHom (ZMod p)) (q : ℤ) := by
      change (q : ZMod p) = ((q : ℤ) : ZMod p)
      exact (Int.cast_natCast q).symm
    rw [hq, Polynomial.eval₂_at_apply]
    exact heval
  exact (Polynomial.isRoot_cyclotomic_iff.mp hroot).eq_orderOf.symm
