import TuringTask

/-!
Axiom audit for the five required theorems.
Each `#print axioms` must report exactly `[propext, Classical.choice, Quot.sound]`.

Check with:  `lake env lean AxiomCheck.lean`
-/

#print axioms TuringTask.color_meet
#print axioms TuringTask.color_deg
#print axioms TuringTask.sat_exists
#print axioms TuringTask.ramsey_color
#print axioms TuringTask.ap_color
