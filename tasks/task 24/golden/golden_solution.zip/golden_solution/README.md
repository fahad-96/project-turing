# Project Turing - Task 24 golden answer

Lean 4 project with complete proofs of five results on the Pisano period `pi(n)` and the entry
point `z(n)` of the Fibonacci numbers modulo `n`: `pi(n) <= 6 n`, `pi(n) = 6 n` exactly for
`n = 2 * 5^j` with `j >= 1`, `pi(n) = n` exactly for `n = 1` and `n = 24 * 5^j`,
`z(n) = 2 n` exactly for `n = 6 * 5^j`, and `z(n) = n` exactly for `n = 5^j` and
`n = 12 * 5^j`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/FibPer.lean`: periods and zeros of `F_k` modulo `m`, least elements divide,
  coprime moduli, the small moduli `2, 3, 4, 5, 8`.
- `TuringTask/FibRing.lean`: `F_k` in `Z[w]` with `w^2 = w + 1`, lifting to prime powers, the
  prime `5`, and the primes `p >= 7` (Frobenius in characteristic `p`).
- `TuringTask/Bounds.lean`: periods and zeros modulo prime powers, and two bounds for odd
  moduli by induction over coprime factors.
- `TuringTask/Large.lean`: if `n` divides all its periods (or zeros), then `n = 2^a 3^b 5^c`.
- `TuringTask/Pisano.lean`: theorems 1, 2 and 3.
- `TuringTask/Entry.lean`: theorems 4 and 5.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
