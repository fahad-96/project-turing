import TuringTask.Basic

#print axioms TuringTask.charSum_norm_le
#print axioms TuringTask.legendreSum_le
#print axioms TuringTask.exists_not_pow_le
#print axioms TuringTask.card_residues_sub_le
#print axioms TuringTask.exists_prime_nonresidue_le
