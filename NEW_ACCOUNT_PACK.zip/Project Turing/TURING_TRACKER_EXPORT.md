# Project Turing - task tracker (export, replaces the old tracker artifact)

Exported 9 Oct 2026, about 17:50 IST, from the artifact "Turing Task Tracker" of the old Claude
account (https://claude.ai/artifact/J1dRbUWM7fSRbdhS73YVhM - a new account cannot open it).
From now on THIS FILE is the tracker: update the row of a task after every step (prompt,
outputs, golden, platform scores, submit, review) and keep the "Updated" line current.

Next free task number: 12 (unless the fellow says another number is taken).
Numbering note: number 7 was used on both laptops; the Honor laptop's task 7 (folder
`tasks\task 7` on the Honor laptop) is listed as 7.5.

## Summary

| No. | Title | Laptop | Status | Models | Next |
| --- | --- | --- | --- | --- | --- |
| 1 | Smith's LCM determinants | waris-pc | rejected | all passed | - |
| 2 | Circulant determinants | waris-pc | rejected | all passed | - |
| 3 | Farey neighbours | waris-pc | rejected | all passed | - |
| 4 | Congruences for coloured partitions | waris-pc chat, Honor laptop platform | submitted | R1 fail, R2 rollout failed, R3 fail | confirm submitted; if returned apply the task 5 v2 fix |
| 5 | Square and triangular sums of partition numbers | waris-pc | submitted | R1 fail, R2 rollout failed, R3 pass | awaiting re-review |
| 6 | Exponential sums over squares (sign of the quadratic Gauss sum) | Honor laptop | golden | R1 fail, R2 not received, R3 pass | platform upload and grading, then submit |
| 7 | Convolution identities for quadratic sequences | waris-pc | golden | R1 fail, R2 no output, R3 fail | platform upload and grading, then submit |
| 7.5 | Cubic character sum x^3 - c x mod p (Honor laptop's task 7) | Honor laptop | prompt | not received | ask the fellow; check outputs if run |
| 8 | Fractional parts of n x and n^2 x (Weyl) | Honor laptop | prompt | not run | ask the fellow; paste prompt if not run |
| 9 | Cubes modulo p (Gauss, Jacobi) | Honor laptop | golden | R1 pass, R2 pass, R3 fail | confirm submitted (cleared 9 Oct) |
| 10 | Primitive prime divisors (Zsigmondy) | Honor laptop | submitted | R1 fail, R2 rollout failed, R3 fail | await review |
| 11 | Colourings that avoid bad events (local lemma applications) | Honor laptop | rejected | all passed | - |

Status values: prompt (prompt written and compiled), outputs (checking outputs), golden (golden
ready, platform pending), submitted, returned (sent back by a reviewer), rejected (no failure).

## Rows (full)

### Task 1 - Smith's LCM determinants

- Status: rejected
- State: All three models passed, no failure
- Laptop: waris-pc
- Topic: Determinants of LCM and GCD matrices, 4 theorems
- Model outputs: M1 pass, M2 pass, M3 pass
- Next: None
- Updated: 6 Oct 2026

### Task 2 - Circulant determinants

- Status: rejected
- State: All three models passed, no failure
- Laptop: waris-pc
- Topic: Closed forms for determinants of circulant matrices, 5 theorems
- Model outputs: M1 pass, M2 pass, M3 pass
- Next: None
- Updated: 7 Oct 2026

### Task 3 - Farey neighbours

- Status: rejected
- State: All three models passed, no failure
- Laptop: waris-pc
- Topic: Farey adjacency, determinant, mediant and next term, 5 theorems
- Model outputs: M1 pass, M2 pass, M3 pass
- Next: None
- Updated: 6 Oct 2026

### Task 4 - Congruences for coloured partitions

- Status: submitted
- State: Cleared to submit on 7 Oct; submission not yet confirmed here
- Laptop: waris-pc chat, Honor laptop platform
- Folder: tasks\task 4\golden
- Topic: Prime divisibility of coloured partition counts and parity of Euler-product powers; needs Jacobi's identity
- Model outputs: M1 fail (sorry), M2 rollout failed, M3 fail (skeleton only)
- Golden: turing_task4_golden.zip (sha256 a4b1a25f...), Jacobi's identity from Gaussian binomials. Old form: lakefile requires Mathlib by git.
- Rubric: 7 items (2 anchors, 5 proof items). Platform: golden 100 percent, both evaluated models 29 percent.
- Notes: May come back with the same review as task 5 (git lakefile, no build item). The fix is the task 5 v2 recipe.
- Next: Confirm it was submitted. If sent back, apply the task 5 v2 fix.
- Updated: 7 Oct 2026

### Task 5 - Square and triangular sums of partition numbers

- Status: submitted
- State: Sent back by Alexey on 8 Oct, fixed as v2, reply drafted
- Laptop: waris-pc
- Folder: tasks\task 5\golden
- Topic: 5 partition identities from Gauss's theta identities (overpartitions, distinct and odd distinct parts)
- Model outputs: M1 fail (sorry), M2 rollout failed, M3 pass
- Golden: v2 turing_task5_golden.zip (sha256 dfc700cf...), /opt/mathlib4 lakefile and environment manifest, offline fresh-extract check passed.
- Rubric: 8 items (anchors sqAlt and halfSum, 5 proof items, build item). Expected: golden 8/8, M1 3/8, M3 8/8.
- Notes: v1 had a git lakefile and definitions inside rubric items 3 and 5.
- Next: Confirm the platform rerun matches the expected scores and the reply was sent; wait for re-review.
- Updated: 8 Oct 2026

### Task 6 - Exponential sums over squares (sign of the quadratic Gauss sum)

- Status: golden
- State: Golden and 8-item rubric brought in line with Alexey's rules; fresh-copy offline check passed 8 Oct
- Laptop: Honor laptop
- Folder: tasks\task 6\golden (Honor laptop)
- Topic: Odd n: sum of e(k^2/n); triangular sum; Legendre-twisted sum; two-prime product; cotangent sum. 5 theorems, defs ex and rt
- Model outputs: M1 fail (sorry), M2 not received, M3 pass (2,868 lines)
- Golden: golden_solution.zip (sha256 b8d15537...), 6 files, /opt/mathlib4 lakefile, offline fresh-extract check passed (8671 jobs, exit 0).
- Rubric: 8 items (build, defs ex and rt, 5 proof-only items). Expected: golden 8/8, M1 3/8, M3 8/8.
- Notes: Novelty note found 8 Oct: the public repo riccardobrasca/KummerCriterion (Sep 2026) fixes the sign of the quadratic Gauss sum for primes (Schur's DFT route). Theorem 3 (sum_legendre) overlaps; theorems 1, 2, 4, 5 go beyond it. Consider one disclosure sentence in the explanation.
- Next: Upload golden_solution.zip and explanation, upload task6_rubric.csv in both rubric sections, rerun grading, compare verdicts, submit.
- Updated: 8 Oct 2026

### Task 7 - Convolution identities for quadratic sequences

- Status: golden
- State: Golden ready on 8 Oct; platform upload and grading pending
- Laptop: waris-pc
- Folder: tasks\task 7\golden
- Topic: 5 convolution identities of theta-type sequences (Jacobi triple product, Gauss, Jacobi's identity)
- Model outputs: M1 fail (sorry), M2 no output, M3 fail (simp, build error)
- Golden: turing_task7_golden.zip (sha256 312d8bb2...), 4 files, 1,465 lines, offline fresh-extract check passed, deep audit clean.
- Rubric: 8 items (anchors conv and quad, 5 proof items, build item). Expected: golden 8/8, M1 3/8, M3 2/8.
- Next: Upload zip and explanation, upload the rubric CSV in both sections, run both evaluations, then submit.
- Updated: 8 Oct 2026

### Task 7.5 - Cubic character sum x^3 - c x mod p (Honor laptop's task 7)

- Status: prompt
- State: Prompt compiled officially (jobs 006 and 006b on the Honor laptop), 8 Oct
- Laptop: Honor laptop
- Folder: tasks\task 7 (Honor laptop)
- Topic: Jacobsthal sums for p = 1 mod 4: S(c)^2 + S(r)^2 = 4p, S(c)^2 = 4a^2, S(1) mod 8, Gauss's binomial congruence, point count of y^2 = x^3 - x. Folder tasks\task 7 on the Honor laptop; a different task from waris-pc's task 7.
- Model outputs: Not received yet
- Rubric: Plan: build + def csum + 5 proofs = 7 items; sorry-only 2/7 = 29 percent.
- Notes: Golden plan in TURING_HANDOFF_2026-10-06.md section 21 (Honor laptop copy).
- Next: Check the three outputs when they arrive; golden only after a genuine failure.
- Updated: 8 Oct 2026

### Task 8 - Fractional parts of n x and n^2 x (Weyl)

- Status: prompt
- State: Prompt compiled officially (job 007), handed over 8 Oct about 18:30 IST
- Laptop: Honor laptop
- Folder: tasks\task 8 (Honor laptop)
- Topic: Equidistribution of n x and n^2 x, uniform version, first digits of 2^n, mean of |sin n|. 5 theorems, no definitions
- Model outputs: Not run yet
- Rubric: Plan: build + 5 proofs = 6 items; sorry-only 1/6 = 17 percent.
- Notes: Checks are finite-N numerics only (limits). Golden plan in handoff section 22.
- Next: Paste task8_prompt.txt on the platform; check the outputs when they arrive.
- Updated: 8 Oct 2026

### Task 9 - Cubes modulo p (Gauss, Jacobi)

- Status: golden
- State: Golden, explanation and 6-item rubric ready and verified 9 Oct 13:45 IST; cleared for the platform
- Laptop: Honor laptop
- Folder: tasks\task 9\golden (Honor laptop)
- Topic: For p = 1 mod 3, 4p = L^2 + 27M^2: count of x^3 + y^3 = 1, two cyclotomic numbers, 2 is a cube iff p = x^2 + 27y^2, cubic exponential sum. 5 theorems, no definitions
- Model outputs: R1 PASS (official job 011d, 9 Oct: build 0, check 0, standard axioms). R2 PASS (job 011b). R3 FAIL (job 011a: build 0, all five theorems absent, check file errors). Expected 6-item rubric: R3 1/6 = 17 percent
- Golden: golden_solution.zip (sha256 fd923c5f...), 5 files, 899 lines, /opt/mathlib4 lakefile, model-format manifest. Worker job 012g and fresh-copy offline check (9 Oct 13:19) both: build exit 0, no warnings, check exit 0, standard axioms.
- Rubric: 6 items: build + 5 proof-only items (task9_rubric.csv). Expected from our Lean runs: golden 6/6, R1 6/6, R2 6/6, R3 1/6 = 17 percent.
- Notes: Novelty re-checked 9 Oct (KummerCriterion, TauCeti 39c285d3, web): nothing on cubic residues or x^2 + 27y^2. Mathlib Jacobi-sum lemmas used and disclosed. Earlier draft 012a discarded (shared names/lines with R2); final golden shares no proof lines with R1/R2. Handoff section 25.
- Next: Platform: upload zip, paste task9_golden_explanation.txt, upload task9_rubric.csv in the model-response section and run, download CSV, upload it in the golden section and run, compare verdicts (golden 6/6, R3 1/6), confirm and submit.
- Updated: 9 Oct 2026, 13:45 IST

### Task 10 - Primitive prime divisors (Zsigmondy)

- Status: submitted
- State: Submitted by the fellow on 9 Oct (about 17:40 IST). Fresh-copy offline check was NOT run before submission (no golden_offline_check_log.txt); worker job 016c passed.
- Laptop: Honor laptop
- Folder: tasks\task 10\golden (Honor laptop)
- Topic: a^n - b^n and a^n + b^n always gain a new prime factor (exceptions listed); divisor bound for the prime factors of a^n - 1; a^n - 1 = q^m only for 3^2 - 1; same prime factors only for m = 1, n = 2. 5 theorems, no definitions
- Model outputs: R1 FAIL (official job 014a: build 0, one sorry at line 1757 in exists_prime_sub, all five theorems depend on sorryAx; README claims completeness). R2 rollout failed (no output). R3 FAIL (job 014b: build 0, none of the five theorems exist, check exit 1). Re-confirmed 9 Oct 16:45 IST; job sources byte-identical to the zips. Expected 6-item rubric: R1 1/6, R3 1/6.
- Golden: golden_solution.zip (sha256 488b63a5...), 7 files (Hcyc, Prim, Size, Zsig, Apps, Main, Basic), 1,017 lines, /opt/mathlib4 lakefile, model-format manifest. Official worker job 016c: build exit 0, no warnings, check exit 0, standard axioms. Fresh-copy offline check not run.
- Rubric: 6 items: build + 5 proof-only items (task10_rubric.csv). Expected: golden 6/6, R1 1/6 = 17 percent, R3 1/6 = 17 percent (R2 rollout failed).
- Notes: Own Zsigmondy proof (homogeneous cyclotomic values, cyclotomic_mul_prime_pow_eq, LTE padicValNat.pow_sub_pow, real bounds sub_one_pow_totient_lt_cyclotomic_eval). Numeric check of every lemma claim (2,223 cases). Overlap scan vs R1/R3: only prompt statement lines. Novelty re-checked 9 Oct: Mathlib, TauCeti 0e01c247 (12,085 files), KummerCriterion, web: no Zsigmondy in Lean.
- Next: Wait for review. Optional: run verify_golden_offline.bat 10 to confirm the fresh-extract build. If sent back, fix per the review and rerun grading.
- Updated: 9 Oct 2026, 17:45 IST

### Task 11 - Colourings that avoid bad events (local lemma applications)

- Status: rejected
- State: All three models passed, no failure (9 Oct 15:05 IST). No golden written.
- Laptop: Honor laptop
- Folder: tasks\task 11 (Honor laptop)
- Topic: Bounded dependence: proper 2-colourings of hypergraphs (two versions), k-SAT, Ramsey and van der Waerden lower bounds. 5 theorems, no definitions
- Model outputs: M1 pass, M2 pass, M3 pass. Official 9 Oct: R1 job 013a, R2 job 013b, R3 job 013c all build exit 0 (lint/deprecation warnings only), check file exit 0, five axiom lists [propext, Classical.choice, Quot.sound]. R1 1,217 lines (own counting LLL), R2 1,121 lines in 8 files (own LLL), R3 836 lines (Mathlib product measure and iIndepFun_pi).
- Rubric: Plan: build + 5 proofs = 6 items; sorry-only 1/6 = 17 percent.
- Notes: Sanity checks only (existence for all parameters). Isabelle AFP has the local lemma (Edmonds 2024): disclose. Golden plan in handoff section 23 (Honor laptop).
- Next: None. Lesson: the symmetric local lemma is within reach of all three models (836 to 1,217 lines).
- Updated: 9 Oct 2026, 15:05 IST

## Reviews

### Task 5 - Alexey, 2026-10-08, "Minor issue"

- Feedback: Golden zip used a git Mathlib require. Use the pinned checkout at /opt/mathlib4 in lakefile.toml and lake-manifest.json, then check a fresh extract offline (lake build and lake env lean StatementAndAxiomsCheck.lean) with no edits. Rubric: add a build item (pinned Lean and Mathlib, build includes TuringTask/Basic.lean); criteria 3 and 5 mixed definition fidelity with completed proofs; rerun grading for the golden and both responses.
- Action: v2 zip with path /opt/mathlib4, environment manifest and README; offline fresh-extract check passed. Rubric now 8 items: 2 anchors, 5 proof-only items, build item. Short reply drafted for Alexey.
- State: Fixed, awaiting re-review (resolved: no)

## Project rules (from the tracker meta document)

- Pinned environment, never change: Lean leanprover/lean4:v4.33.0-rc1, Mathlib 9944fe2973b8dc0b86949101ed98232c07cd54a0.
- One chat per task. Read this tracker first and update it after every step (prompt, outputs, golden, platform scores, submit, review).
- Task numbers: take the next free number from this tracker and reserve the row before creating files. Number 7 was used on both laptops; the Honor laptop's task 7 is listed as 7.5.
- Write the golden only after a model output genuinely fails (an environment failure does not count). The golden is own work, never copied from a model output.
- Golden zip: lakefile.toml requires Mathlib with path = /opt/mathlib4, lake-manifest.json in the environment form, README with lean-offline-init, lake build, lake env lean StatementAndAxiomsCheck.lean. Run the offline fresh-extract check before delivering.
- Rubric: at most 2 definition anchors, one proof-only item per theorem (exact statement; #print axioms only propext, Classical.choice, Quot.sound), one build item. Never put a definition inside a proof item. A sorry-only output must stay below 40 percent. Prompts without definitions give build + 5 proofs = 6 items (sorry-only 17 percent, one proof 33 percent).
- Topics: one hard classical core that all five theorems need. Elementary or glue work (tasks 1-3) was solved by every model.
- Novelty check before every task: Mathlib at the pinned commit, PutnamBench, miniF2F, ProofNet, compfiles, formal-conjectures, TauCeti, RamanujanLean, riccardobrasca/KummerCriterion (Kummer congruences, Gauss sum sign), web search.
- Platform: upload the rubric CSV in the model-response section and run it, download it, upload the same CSV in the golden section and run it. Targets: golden at least 90 percent, at least one model below 40 percent.
- Everything pasted into a submission field is pure ASCII and generated by script. Explanations in Markdown: ### headings, - bullets, math in $...$.
- Be brief. Say plainly what is verified and what is not. Never promise a model failure or a reviewer score.

## Laptops

- waris-pc: folder `C:\Users\bhatw\OneDrive\Desktop\Project Turing`. Tasks 1-5 and 7. Lean in C:\lean\TuringTask (lean_worker.bat). Long details: TURING_HANDOFF_2026-10-06.md, newest sections 17-20.
- Honor laptop (device fahad): folder `D:\HandShake\project turing\Project Turing`. Tasks 6, 7.5 (its folder is tasks\task 7), 8, 9, 10, 11. Lean moved to D:\lean\TuringTask on 8 Oct (C: was full); lean_worker.bat uses it. Give a new chat access to D:\HandShake\project turing and D:\lean. Never build several Mathlib files in parallel here. Golden fresh-copy check: verify_golden_offline.bat <task>. Opening prompt for golden chats: NEW_CHAT_PROMPT_GOLDEN.txt. Details: TURING_MEMORY.md and TURING_HANDOFF_2026-10-06.md sections 17-24.

