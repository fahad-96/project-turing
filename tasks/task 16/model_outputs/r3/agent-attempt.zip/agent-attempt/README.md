# Agent Attempt

This Lean 4 project proves the five theorem statements present in the supplied
Fibonacci quartic research source. The proofs use no `sorry`, `admit`,
`native_decide`, or additional axioms.

## Offline verification

The project depends on the Mathlib installation supplied at `/opt/mathlib4`.
It is therefore intended for the supplied Lean/Mathlib environment and is not
self-contained on an arbitrary machine.

```bash
lean AgentAttempt.lean
lean-offline-init
lake build
```
