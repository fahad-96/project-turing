# TuringTask

`TuringTask/Basic.lean` is the supplied task and is unchanged. Compile-tested
kernel proof of `sum_card_divisors_sub_le` is in `TuringTask/First.lean` with
the exact namespace and statement from the task. Supporting divisor identities
and harmonic estimates are in `TuringTask/Research.lean`.

Check the quantitative theorem directly, offline:

```sh
lean-offline-init
lake build TuringTask.First
```

The proof module contains no `sorry`, `admit`, `native_decide`, or added axioms.
It proves an exact finite Dirichlet hyperbola identity and then derives the
explicit `4 * Real.sqrt N` estimate.

Compile-tested proofs of the last three theorem statements are separately in
`TuringTask/Limits.lean`, in the namespace `TuringTask.Limits`.

The limit proofs use only the first supplied quantitative estimate,
`TuringTask.sum_card_divisors_sub_le`. They do not use the supplied declarations
of any of the three limits. The main additional ingredients are a telescoping
Cesaro argument for the logarithmic average, monotone integral bounds for
`x * log x`, and a summed `O(sqrt n)` error bound.

Check the limit development directly, offline:

```sh
lake env lean TuringTask/Limits.lean
```

Build the project offline in the supplied Lean/Mathlib environment:

```sh
lean-offline-init
lake build
```

The project intentionally uses the supplied local Mathlib at `/opt/mathlib4`.
It therefore requires the supplied Lean/Mathlib environment and is not
self-contained on an arbitrary machine.
