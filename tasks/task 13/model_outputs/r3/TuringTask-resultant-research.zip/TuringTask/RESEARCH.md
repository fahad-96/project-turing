# Offline proof research

`TuringTask/Basic.lean` was not modified.

## Blocker

The supplied project does not contain the referenced "first two exact theorem
statements." `TuringTask/Basic.lean` only imports Mathlib and opens/closes the
`TuringTask` namespace. Consequently, no exact proof term can be tested without
inventing assumptions or conclusions.

## Available probe

`ResultantProbe.lean` checks the principal Mathlib declarations suggested by
the pre-existing `Probe.lean`, which searches for names containing
`resultant`. Compile it with:

```sh
lean ResultantProbe.lean
```

`ResultantStrategies.lean` contains checked proof terms for the common
zero/nonzero-resultant and coprimality directions. These are examples rather
than answers to the missing exact statements.

Once the exact statements are supplied, copy them verbatim into a separate
probe file and test combinations of the checked declarations there. Do not
change `TuringTask/Basic.lean` during research.

## Offline verification

This project uses the supplied Lean/Mathlib environment and its local Mathlib
dependency at `/opt/mathlib4`. It is not self-contained on a machine lacking
that environment. No network access is needed:

```sh
lean TuringTask/Basic.lean
lean Probe.lean
lean ResultantProbe.lean
lean ResultantStrategies.lean
```
