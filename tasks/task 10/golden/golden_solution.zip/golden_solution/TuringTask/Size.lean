import Mathlib
import TuringTask.Prim

/-!
# The size bound

`size_bound`: if `n = q ^ k * m` with `k ≥ 1`, `q ∤ m`, `m ∣ q - 1` and `n ≥ 3`, then
`q < hcyc n a b`, except for `(a, b, n) = (2, 1, 6)`.
-/

open Polynomial Finset

namespace TuringTask

/-! ### The size bound -/

theorem pow_sub_pow_gt (A B : ℤ) (hB : 1 ≤ B) (hAB : B < A) :
    ∀ q : ℕ, 2 ≤ q → (q : ℤ) * (A - B) < A ^ q - B ^ q := by
  intro q hq
  induction q, hq using Nat.le_induction with
  | base =>
    push_cast
    nlinarith [mul_pos (sub_pos.mpr hAB) (show (0 : ℤ) < A + B - 2 by linarith)]
  | succ q hq ih =>
    have hBq : 0 ≤ B ^ q := pow_nonneg (by linarith) q
    have hpos : 0 < A - B := by linarith
    have h1 : A * (A ^ q - B ^ q) ≤ A ^ (q + 1) - B ^ (q + 1) := by
      rw [pow_succ, pow_succ]
      nlinarith [mul_nonneg hBq hpos.le]
    have hq0 : (0 : ℤ) ≤ q := by positivity
    have h3 : 0 ≤ A ^ q - B ^ q := by nlinarith [mul_nonneg hq0 hpos.le]
    have hA2 : 2 ≤ A := by linarith
    have h2 : 2 * (A ^ q - B ^ q) ≤ A * (A ^ q - B ^ q) := mul_le_mul_of_nonneg_right hA2 h3
    have hq1 : (1 : ℤ) ≤ q := by exact_mod_cast (by omega : 1 ≤ q)
    push_cast
    nlinarith [mul_nonneg (sub_nonneg.mpr hq1) hpos.le]

theorem pow_sub_pow_ge_add (A B : ℤ) (hB : 1 ≤ B) (hAB : B < A) :
    ∀ q : ℕ, 4 ≤ q → (q : ℤ) * (A + B) ≤ A ^ q - B ^ q := by
  intro q hq
  induction q, hq using Nat.le_induction with
  | base =>
    push_cast
    have h1 : 4 ≤ A ^ 2 + B ^ 2 := by nlinarith
    have h2 : 0 ≤ A + B := by linarith
    have h3 : 1 ≤ A - B := by linarith
    calc (4 : ℤ) * (A + B) ≤ (A + B) * (A ^ 2 + B ^ 2) := by
          nlinarith [mul_nonneg h2 (sub_nonneg.mpr h1)]
      _ ≤ (A - B) * (A + B) * (A ^ 2 + B ^ 2) := by
          nlinarith [mul_nonneg (mul_nonneg (sub_nonneg.mpr h3) h2)
            (by positivity : (0 : ℤ) ≤ A ^ 2 + B ^ 2)]
      _ = A ^ 4 - B ^ 4 := by ring
  | succ q hq ih =>
    have hBq : 0 ≤ B ^ q := pow_nonneg (by linarith) q
    have hpos : 0 < A - B := by linarith
    have h1 : A * (A ^ q - B ^ q) ≤ A ^ (q + 1) - B ^ (q + 1) := by
      rw [pow_succ, pow_succ]
      nlinarith [mul_nonneg hBq hpos.le]
    have hq0 : (0 : ℤ) ≤ q := by positivity
    have hAB0 : 0 ≤ A + B := by linarith
    have h3 : 0 ≤ A ^ q - B ^ q := by nlinarith [mul_nonneg hq0 hAB0]
    have hA2 : 2 ≤ A := by linarith
    have h2 : 2 * (A ^ q - B ^ q) ≤ A * (A ^ q - B ^ q) := mul_le_mul_of_nonneg_right hA2 h3
    have hq1 : (1 : ℤ) ≤ q := by exact_mod_cast (by omega : 1 ≤ q)
    push_cast
    nlinarith [mul_nonneg (sub_nonneg.mpr hq1) hAB0]

theorem pow_sub_pow_ge_three (A B : ℤ) (hB : 1 ≤ B) (hAB : B < A) (hA : 3 ≤ A) :
    3 * (A + B) ≤ A ^ 3 - B ^ 3 := by
  have hA0 : (0 : ℤ) < A := by linarith
  have hB0 : (0 : ℤ) < B := by linarith
  have hsq : (0 : ℤ) ≤ A ^ 2 + A * B + B ^ 2 := by
    nlinarith [mul_pos hA0 hB0, sq_nonneg A, sq_nonneg B]
  calc 3 * (A + B) ≤ A ^ 2 + A * B + B ^ 2 := by
        nlinarith [mul_nonneg hA0.le (by linarith : (0 : ℤ) ≤ A - 3),
          mul_nonneg hB0.le (by linarith : (0 : ℤ) ≤ A + B - 3)]
    _ ≤ (A - B) * (A ^ 2 + A * B + B ^ 2) := by
        nlinarith [mul_nonneg (by linarith : (0 : ℤ) ≤ A - B - 1) hsq]
    _ = A ^ 3 - B ^ 3 := by ring

theorem pow_sub_pow_ge_mul_add (A B : ℤ) (hB : 1 ≤ B) (hAB : B < A) (q : ℕ) (hq : 3 ≤ q)
    (hexc : ¬ (A = 2 ∧ q = 3)) : (q : ℤ) * (A + B) ≤ A ^ q - B ^ q := by
  rcases Nat.lt_or_ge q 4 with h | h
  · obtain rfl : q = 3 := by omega
    have hA : 3 ≤ A := by
      by_contra hA
      push Not at hA
      exact hexc ⟨by omega, rfl⟩
    push_cast
    exact pow_sub_pow_ge_three A B hB hAB hA
  · exact pow_sub_pow_ge_add A B hB hAB q h

theorem size_core (q m A B : ℕ) (hq : q.Prime) (hB : 0 < B) (hAB : B < A) (hqm : ¬ q ∣ m)
    (hmq : m ∣ q - 1) (hm0 : 0 < m) (hexc : ¬ (A = 2 ∧ q = 3 ∧ m = 2)) :
    (q : ℤ) < hcyc (q * m) A B := by
  have hBZ : (1 : ℤ) ≤ B := by exact_mod_cast hB
  have hABZ : (B : ℤ) < A := by exact_mod_cast hAB
  rcases Nat.lt_or_ge m 2 with hm1 | hm2
  · obtain rfl : m = 1 := by omega
    rw [mul_one]
    have h := hcyc_prime_mul q A B hq hB
    have hlt := pow_sub_pow_gt (A : ℤ) (B : ℤ) hBZ hABZ q hq.two_le
    have hpos : (0 : ℤ) < (A : ℤ) - B := by linarith
    rw [← h] at hlt
    exact lt_of_mul_lt_mul_right hlt hpos.le
  · have hq3 : 3 ≤ q := by
      have h1 : m ≤ q - 1 := Nat.le_of_dvd (by have := hq.two_le; omega) hmq
      omega
    have hexc' : ¬ ((A : ℤ) = 2 ∧ q = 3) := by
      rintro ⟨hA2, hq3'⟩
      apply hexc
      refine ⟨by exact_mod_cast hA2, hq3', ?_⟩
      subst hq3'
      have : m ≤ 2 := Nat.le_of_dvd (by norm_num) hmq
      omega
    have hL := pow_sub_pow_ge_mul_add (A : ℤ) (B : ℤ) hBZ hABZ q hq3 hexc'
    have hrel := hcyc_mul_not_dvd q m A B hq hqm hB
    rw [mul_comm m q] at hrel
    have hlow := hcyc_gt m (A ^ q) (B ^ q) hm2 (pow_pos hB q)
      (Nat.pow_lt_pow_left hAB hq.ne_zero)
    have hup := hcyc_le m A B hB hAB
    have hposm : (0 : ℝ) < ((hcyc m A B : ℤ) : ℝ) := by exact_mod_cast hcyc_pos m A B hB hAB
    have hφ : m.totient ≠ 0 := (Nat.totient_pos.mpr hm0).ne'
    have hLR : (q : ℝ) * ((A : ℝ) + B) ≤ (A : ℝ) ^ q - (B : ℝ) ^ q := by exact_mod_cast hL
    have hq1 : (1 : ℝ) ≤ q := by exact_mod_cast hq.one_lt.le
    push_cast at hlow
    have key : (q : ℝ) * ((hcyc m A B : ℤ) : ℝ) <
        ((hcyc (q * m) A B : ℤ) : ℝ) * ((hcyc m A B : ℤ) : ℝ) := by
      calc (q : ℝ) * ((hcyc m A B : ℤ) : ℝ) ≤ (q : ℝ) * ((A : ℝ) + B) ^ m.totient :=
            mul_le_mul_of_nonneg_left hup (by positivity)
        _ ≤ (q : ℝ) ^ m.totient * ((A : ℝ) + B) ^ m.totient :=
            mul_le_mul_of_nonneg_right (le_self_pow₀ hq1 hφ) (by positivity)
        _ = ((q : ℝ) * ((A : ℝ) + B)) ^ m.totient := (mul_pow _ _ _).symm
        _ ≤ ((A : ℝ) ^ q - (B : ℝ) ^ q) ^ m.totient :=
            pow_le_pow_left₀ (by positivity) hLR _
        _ < ((hcyc m (A ^ q) (B ^ q) : ℤ) : ℝ) := hlow
        _ = ((hcyc (q * m) A B : ℤ) : ℝ) * ((hcyc m A B : ℤ) : ℝ) := by
            rw [← hrel, Int.cast_mul]
    have := lt_of_mul_lt_mul_right key hposm.le
    exact_mod_cast this

/-- The size bound: `q < hcyc n a b` when `n = q ^ k * m`, `m ∣ q - 1`, `n ≥ 3`, outside
`(a, b, n) = (2, 1, 6)`. -/
theorem size_bound {n a b q k m : ℕ} (hq : q.Prime) (hb : 0 < b) (hab : b < a)
    (hk : 0 < k) (hqm : ¬ q ∣ m) (hnkm : n = q ^ k * m) (hmq : m ∣ q - 1) (hn3 : 3 ≤ n)
    (h6 : ¬ (a = 2 ∧ b = 1 ∧ n = 6)) : (q : ℤ) < hcyc n a b := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  have hm0 : 0 < m := by
    rcases Nat.eq_zero_or_pos m with h | h
    · rw [h, mul_zero] at hnkm
      omega
    · exact h
  rw [hnkm, hcyc_pow_mul q m hq j a b hb]
  have hQ : 0 < q ^ j := pow_pos hq.pos j
  apply size_core q m (a ^ q ^ j) (b ^ q ^ j) hq (pow_pos hb _)
    (Nat.pow_lt_pow_left hab hQ.ne') hqm hmq hm0
  rintro ⟨hA, hq3, hm2⟩
  apply h6
  have ha2 : 2 ≤ a := by omega
  have hj1 : q ^ j = 1 := by
    by_contra hne
    have h2 : 2 ≤ q ^ j := by omega
    have h3 : a ^ 2 ≤ a ^ q ^ j := Nat.pow_le_pow_right (by omega) h2
    nlinarith
  rw [hj1, pow_one] at hA
  have hj0 : j = 0 := by
    rcases Nat.eq_zero_or_pos j with h | h
    · exact h
    · exact absurd hj1 (Nat.one_lt_pow h.ne' hq.one_lt).ne'
  subst hj0
  refine ⟨hA, by omega, ?_⟩
  simp [hnkm, hq3, hm2]

end TuringTask
