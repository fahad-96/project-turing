# Cyclotomic resultant investigation

`TuringTask/Basic.lean` was not modified. No `sorry`, `admit`,
`native_decide`, or new axioms are used.

## Checked results

`BaseCases.lean` proves the exact `n = 1` specializations of both requested
statements. In particular, `r2_n_eq_one` proves the prime-power case and
formally accounts for the excluded case `(n,p,k) = (1,2,1)`: the resultant
there is `-2`, while the requested right-hand side is `2`.

`PartialResultant.lean` proves:

* resultants of distinct integral cyclotomic polynomials are nonzero;
* the exact resultant of `C z * X^a` against `cyclotomic n Int`;
* the degree-padding sign for that resultant;
* a generic bridge from a monomial congruence
  `f = C z * X^a + cyclotomic n Int * q` to the exact resultant.

These lemmas isolate all resultant bookkeeping needed by the suggested
monomial-congruence strategy.

## Remaining blocker

The missing step for general `n` is an integral monomial congruence for
`cyclotomic (n * p^k) Int` modulo `cyclotomic n Int`, including its exact
coefficient and degree/sign data. Equivalently, one can prove the root-product
formula by writing `n = p^a s`, differentiating

```text
Phi_s(X^(p^e)) = Phi_(p^e s)(X) * Phi_s(X^(p^(e-1))),
```

at primitive `n`-th roots, and showing that the derivative ratios cancel in
the product. The available Mathlib declarations
`cyclotomic_expand_eq_cyclotomic_mul` and
`cyclotomic_mul_prime_pow_eq` provide the polynomial identity and its
characteristic-`p` reduction, respectively, but no local theorem packages the
required derivative/root product or the stronger integral congruence.

The characteristic-`p` theorem can detect which primes divide a resultant,
but reduction modulo `p` loses the valuation needed to prove
`p ^ n.totient` in `r2`. Establishing that root-product/congruence lemma is
also the main missing ingredient for proving that the nonzero resultant in
`r1` is the unit `+1`.

## Offline verification

The following commands were checked using only the supplied local
Lean/Mathlib environment:

```sh
lean TuringTask/Basic.lean
lean PartialResultant.lean
lean BaseCases.lean
```

No network request was attempted and no remote dependency or cache was
fetched.
