# Project Turing - Task 13 golden answer

Lean 4 project with complete proofs of the resultant and discriminant formulas for cyclotomic
polynomials: `Res(Phi_m, Phi_n) = 1` when `m / n` is not a prime power, `Res(Phi_{n p^k}, Phi_n) =
p^phi(n)`, the discriminant of `Phi_n`, the coprimality criterion, and `Res(Phi_n, X^m - 1)`. The
required file is `TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The four source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Fibre.lean`: the fibre lemma for the power map on primitive roots of unity, and
  `Res(Phi_m, G(X^d)) = Res(Phi_k, G)^(phi(m)/phi(k))`
- `TuringTask/Resultants.lean`: `Res(Phi_m, X^n - 1)`, non-negativity by conjugate pairing, the
  reduction modulo a prime, theorems 1, 2, 4 and 5
- `TuringTask/Discr.lean`: the recursion for `Res(Phi_n, Psi_n)`, the derivative identity and
  theorem 3
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof
