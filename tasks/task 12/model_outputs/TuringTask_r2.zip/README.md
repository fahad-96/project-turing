# TuringTask

This project targets the supplied Lean 4 and Mathlib environment and uses the
local Mathlib dependency at `/opt/mathlib4`.

Initialize and build offline with:

```sh
lean-offline-init
lake build
```

The requested proofs are not completed. Mathlib at the supplied revision has
basic Fibonacci identities (`Nat.fib_gcd`, `Nat.fib_dvd`, and related lemmas),
but no Fibonacci/Lucas primitive-divisor theorem. The first requested theorem
is Carmichael's full primitive-divisor theorem and needs a substantial new
formalization. No axiom, `sorry`, `admit`, `native_decide`, or remote dependency
was introduced to hide that missing argument.
