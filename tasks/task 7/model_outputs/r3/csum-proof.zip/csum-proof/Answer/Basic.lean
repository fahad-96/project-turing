import Answer.CharacterProof

namespace TuringTask

open scoped BigOperators

noncomputable def csum (p : Nat) [Fact p.Prime] (c : Int) : Int :=
  Finset.sum (Finset.range p) (fun x : Nat => legendreSym p ((x : Int) ^ 3 - c * (x : Int)))

lemma legendre_eq_quadraticChar (p : Nat) [Fact p.Prime] (hp2 : p ≠ 2) (a : Int) :
    legendreSym p a = (quadraticChar (ZMod p)) (a : ZMod p) := by
  have hleg := legendreSym.card_sqrts p hp2 a
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hchar := quadraticChar_card_sqrts (F := ZMod p) hpchar (a : ZMod p)
  omega

lemma natCast_fin_eq_finEquiv (p : Nat) [NeZero p] (x : Fin p) :
    ((x.val : Nat) : ZMod p) = (ZMod.finEquiv p) x := by
  cases p with
  | zero => exact Fin.elim0 x
  | succ n =>
      apply ZMod.val_injective (n + 1)
      change x.val % (n + 1) = x.val
      exact Nat.mod_eq_of_lt x.isLt

lemma csum_eq_curveSum (p : Nat) [Fact p.Prime] (hp2 : p ≠ 2) (a : Int) :
    csum p a = CharacterProof.curveSum (a : ZMod p) := by
  rw [csum, CharacterProof.curveSum, ← Fin.sum_univ_eq_sum_range]
  apply Fintype.sum_equiv (ZMod.finEquiv p)
  intro x
  rw [legendre_eq_quadraticChar p hp2]
  congr 1
  push_cast
  rw [natCast_fin_eq_finEquiv p x]

theorem csum_sq_add_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (c r : Int)
    (hc : legendreSym p c = 1) (hr : legendreSym p r = -1) :
    csum p c ^ 2 + csum p r ^ 2 = 4 * (p : Int) := by
  have hp2 : p ≠ 2 := by omega
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hm1 : (quadraticChar (ZMod p)) (-1) = 1 := by
    have h := legendre_eq_quadraticChar p hp2 (-1)
    rw [legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp] at h
    simpa using h.symm
  have hqc : (quadraticChar (ZMod p)) (c : ZMod p) = 1 := by
    rw [← legendre_eq_quadraticChar p hp2]
    exact hc
  have hqr : (quadraticChar (ZMod p)) (r : ZMod p) = -1 := by
    rw [← legendre_eq_quadraticChar p hp2]
    exact hr
  rw [csum_eq_curveSum p hp2, csum_eq_curveSum p hp2]
  rw [CharacterProof.curveSum_sq_add_sq hpchar hm1 (c : ZMod p) (r : ZMod p) hqc hqr]
  rw [ZMod.card]

end TuringTask
