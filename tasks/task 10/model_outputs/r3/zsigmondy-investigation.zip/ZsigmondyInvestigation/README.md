# Local Mathlib Bang-Zsigmondy Investigation

## Result

No Bang-Zsigmondy theorem or equivalent primitive-prime-divisor existence
theorem was found in the supplied Mathlib environment. Searches for
`zsigmondy`, `primitive prime divisor`, and `primitive divisor` found no
relevant declaration or source text. The workspace also contained no theorem
statements, so the five exact obligations could not be checked or proved.

In particular, Mathlib does not provide the key global step needed for the
usual theorem 1: a prime `p` dividing a cyclotomic value `Φ_n(q)` with
`p ∤ n`, together with the complete exceptional-case analysis when every
prime divisor of that value divides `n`.

## Useful declarations

```lean
Polynomial.isRoot_cyclotomic_iff
  {R} [CommRing R] {n : ℕ} [IsDomain R] [NeZero (n : R)] {μ : R} :
  (Polynomial.cyclotomic n R).IsRoot μ ↔ IsPrimitiveRoot μ n

IsPrimitiveRoot.eq_orderOf
  (h : IsPrimitiveRoot ζ k) : k = orderOf ζ

IsPrimitiveRoot.pow_ne_one_of_pos_of_lt
  (h : IsPrimitiveRoot ζ k) (h0 : l ≠ 0) (hl : l < k) : ζ ^ l ≠ 1

IsPrimitiveRoot.pow_eq_one_iff_dvd
  (h : IsPrimitiveRoot ζ k) (l : ℕ) : ζ ^ l = 1 ↔ k ∣ l

Polynomial.map_cyclotomic_int
  (n : ℕ) (R) [Ring R] :
  Polynomial.map (Int.castRingHom R) (Polynomial.cyclotomic n ℤ) =
    Polynomial.cyclotomic n R

Polynomial.prod_cyclotomic_eq_X_pow_sub_one
  {n : ℕ} (hpos : 0 < n) (R) [CommRing R] :
  ∏ i ∈ n.divisors, Polynomial.cyclotomic i R = Polynomial.X ^ n - 1

Polynomial.sub_one_lt_natAbs_cyclotomic_eval
  {n q : ℕ} (hn : 1 < n) (hq : q ≠ 1) :
  q - 1 < (Polynomial.eval (q : ℤ) (Polynomial.cyclotomic n ℤ)).natAbs

Polynomial.sub_one_pow_totient_lt_natAbs_cyclotomic_eval
  {n q : ℕ} (hn : 1 < n) (hq : q ≠ 1) :
  (q - 1) ^ n.totient <
    (Polynomial.eval (q : ℤ) (Polynomial.cyclotomic n ℤ)).natAbs

Nat.exists_prime_and_dvd
  {N : ℕ} (hN : N ≠ 1) : ∃ p, p.Prime ∧ p ∣ N
```

`Nat.exists_prime_gt_modEq_one` is available, but only proves existence of
arbitrarily large primes congruent to one modulo `n`; it does not make such a
prime divide a fixed number `q^n - 1` and therefore does not prove the needed
claim.

## Feasible route

For the specialization `q^n - 1`, use the cyclotomic evaluation lower bound
and `Nat.exists_prime_and_dvd` to choose `p ∣ |Φ_n(q)|`. If one can separately
prove `p ∤ n`, `Investigation/Bridge.lean` verifies the concise remaining
argument: reduction modulo `p`, `Polynomial.isRoot_cyclotomic_iff`, and
`IsPrimitiveRoot.eq_orderOf` show that `q mod p` has exact order `n`. The
`pow_ne_one` lemma then rules out divisibility of all earlier `q^m - 1`.

The difficult missing proof is exactly the classical Bang-Zsigmondy
valuation and exception argument. For general `a^n - b^n`, further work is
needed to formalize the homogeneous cyclotomic value; the located evaluation
bounds are only for `Φ_n(q)`.

## Offline check

In the supplied environment, from this directory run:

```text
lean Investigation/Bridge.lean
lean-offline-init
lake build
```

The Lake configuration intentionally uses the supplied local Mathlib path
`/opt/mathlib4`; the archive is not self-contained on an arbitrary machine.
