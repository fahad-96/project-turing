import OddGaussSum.Determinant

open scoped BigOperators

namespace OddGaussSum

noncomputable section

theorem normalized_trace_one_mod_four (q : ℕ) :
    (normalizedFourierMatrix (4 * q + 1)).trace = 1 := by
  let n := 4 * q + 1
  let A := normalizedFourierMatrix n
  let b := Pi.basisFun ℂ (ZMod n)
  let f : Module.End ℂ (ZMod n → ℂ) := Matrix.toLin b b A
  have htm : (LinearMap.toMatrix b b) f = A := by
    change (Matrix.toLin b b).symm ((Matrix.toLin b b) A) = A
    exact (Matrix.toLin b b).symm_apply_apply A
  have hf4 : f ^ 4 = 1 := by
    calc
      f ^ 4 = Matrix.toLin b b (A ^ 4) :=
        (Matrix.toLin_pow b A 4).symm
      _ = Matrix.toLin b b 1 := by rw [normalizedFourierMatrix_fourth]
      _ = 1 := by rw [Matrix.toLin_one]; rfl
  obtain ⟨a, c, d, e, hcard, htrace, hsq, hdet⟩ :=
    fourthPowerEndData (ZMod n → ℂ) f hf4
  have hcard' : a + c + d + e = 4 * q + 1 := by
    rw [← hcard]
    simp [n, ZMod.card]
  have htrace' : A.trace = (((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I := by
    rw [← htrace, LinearMap.trace_eq_matrix_trace ℂ b f]
    rw [htm]
  have hsq' : (a : ℤ) + c - d - e = 1 := by
    have hsqC : (((a : ℤ) + c - d - e : ℤ) : ℂ) = 1 := by
      rw [← hsq, LinearMap.trace_eq_matrix_trace ℂ b (f ^ 2)]
      have hm : (LinearMap.toMatrix b b) (f ^ 2) = A * A := by
        rw [show f ^ 2 = f * f by rfl, LinearMap.toMatrix_mul]
        rw [htm]
      rw [hm, trace_normalized_sq_of_odd n]
      exact ⟨2 * q, by omega⟩
    exact_mod_cast hsqC
  have hdet' : ((-1 : ℂ) ^ c) * Complex.I ^ d * (-Complex.I) ^ e =
      Complex.I ^ ((4 * q + 1) * (2 * q)) := by
    rw [← hdet]
    have hlin : LinearMap.det f = A.det := by
      rw [← LinearMap.det_toMatrix b f]
      rw [htm]
    rw [hlin]
    change (normalizedFourierMatrix n).det = _
    exact normalizedFourierMatrix_det_of_eq n (2 * q) (by simp [n]; omega)
  have hnorm' : ‖(((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I‖ = 1 := by
    rw [← htrace']
    exact normalized_trace_norm n ⟨2 * q, by omega⟩
  rw [htrace']
  exact fourthSpectrum_one_mod_four q a c d e hcard' hsq' hdet' hnorm'

theorem normalized_trace_three_mod_four (q : ℕ) :
    (normalizedFourierMatrix (4 * q + 3)).trace = Complex.I := by
  let n := 4 * q + 3
  let A := normalizedFourierMatrix n
  let b := Pi.basisFun ℂ (ZMod n)
  let f : Module.End ℂ (ZMod n → ℂ) := Matrix.toLin b b A
  have htm : (LinearMap.toMatrix b b) f = A := by
    change (Matrix.toLin b b).symm ((Matrix.toLin b b) A) = A
    exact (Matrix.toLin b b).symm_apply_apply A
  have hf4 : f ^ 4 = 1 := by
    calc
      f ^ 4 = Matrix.toLin b b (A ^ 4) :=
        (Matrix.toLin_pow b A 4).symm
      _ = Matrix.toLin b b 1 := by rw [normalizedFourierMatrix_fourth]
      _ = 1 := by rw [Matrix.toLin_one]; rfl
  obtain ⟨a, c, d, e, hcard, htrace, hsq, hdet⟩ :=
    fourthPowerEndData (ZMod n → ℂ) f hf4
  have hcard' : a + c + d + e = 4 * q + 3 := by
    rw [← hcard]
    simp [n, ZMod.card]
  have htrace' : A.trace = (((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I := by
    rw [← htrace, LinearMap.trace_eq_matrix_trace ℂ b f]
    rw [htm]
  have hsq' : (a : ℤ) + c - d - e = 1 := by
    have hsqC : (((a : ℤ) + c - d - e : ℤ) : ℂ) = 1 := by
      rw [← hsq, LinearMap.trace_eq_matrix_trace ℂ b (f ^ 2)]
      have hm : (LinearMap.toMatrix b b) (f ^ 2) = A * A := by
        rw [show f ^ 2 = f * f by rfl, LinearMap.toMatrix_mul]
        rw [htm]
      rw [hm, trace_normalized_sq_of_odd n]
      exact ⟨2 * q + 1, by omega⟩
    exact_mod_cast hsqC
  have hdet' : ((-1 : ℂ) ^ c) * Complex.I ^ d * (-Complex.I) ^ e =
      Complex.I ^ ((4 * q + 3) * (2 * q + 1)) := by
    rw [← hdet]
    have hlin : LinearMap.det f = A.det := by
      rw [← LinearMap.det_toMatrix b f]
      rw [htm]
    rw [hlin]
    change (normalizedFourierMatrix n).det = _
    exact normalizedFourierMatrix_det_of_eq n (2 * q + 1) (by simp [n]; omega)
  have hnorm' : ‖(((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I‖ = 1 := by
    rw [← htrace']
    exact normalized_trace_norm n ⟨2 * q + 1, by omega⟩
  rw [htrace']
  exact fourthSpectrum_three_mod_four q a c d e hcard' hsq' hdet' hnorm'

end

end OddGaussSum
