import Mathlib

open scoped BigOperators ComplexConjugate

namespace OddGaussSum

noncomputable section

/-- The four possible values of a Gaussian integer of complex norm one. -/
private theorem gaussianInteger_norm_one
    (x y : ℤ) (h : ‖(x : ℂ) + (y : ℂ) * Complex.I‖ = 1) :
    (x = 1 ∧ y = 0) ∨ (x = -1 ∧ y = 0) ∨
      (x = 0 ∧ y = 1) ∨ (x = 0 ∧ y = -1) := by
  have hs : x ^ 2 + y ^ 2 = 1 := by
    have hn := congrArg (fun r : ℝ => r ^ 2) h
    rw [Complex.sq_norm] at hn
    norm_num [Complex.normSq_apply] at hn ⊢
    simpa [pow_two] using (show x * x + y * y = 1 by exact_mod_cast hn)
  have hx : -1 ≤ x ∧ x ≤ 1 := by constructor <;> nlinarith [sq_nonneg y]
  have hy : -1 ≤ y ∧ y ≤ 1 := by constructor <;> nlinarith [sq_nonneg x]
  rcases hx with ⟨hx₁, hx₂⟩
  rcases hy with ⟨hy₁, hy₂⟩
  interval_cases x <;> interval_cases y
  all_goals norm_num [pow_two] at hs
  all_goals norm_num

private theorem I_even_pow (q : ℕ) :
    Complex.I ^ (2 * q) = (-1 : ℂ) ^ q := by
  induction q with
  | zero => simp
  | succ q ih =>
      rw [show 2 * (q + 1) = 2 * q + 2 by omega, pow_add, ih]
      rw [show Complex.I ^ 2 = (-1 : ℂ) by norm_num, pow_succ]

private theorem neg_one_even_pow (q : ℕ) : (-1 : ℂ) ^ (2 * q) = 1 := by
  induction q with
  | zero => simp
  | succ q ih =>
      rw [show 2 * (q + 1) = 2 * q + 2 by omega, pow_add, ih]
      norm_num

private theorem neg_I_pow (k : ℕ) : (-Complex.I) ^ k =
    (-1 : ℂ) ^ k * Complex.I ^ k := by
  induction k with
  | zero => simp
  | succ k ih => rw [pow_succ, pow_succ, pow_succ, ih]; ring

private theorem fourth_root_cases (z : ℂ) (hz : z ^ 4 = 1) :
    z = 1 ∨ z = -1 ∨ z = Complex.I ∨ z = -Complex.I := by
  have hfac : (z - 1) * (z + 1) * (z - Complex.I) * (z + Complex.I) = 0 := by
    rw [show (z - 1) * (z + 1) * (z - Complex.I) * (z + Complex.I) =
        z ^ 4 - 1 by
      have hi : Complex.I ^ 2 = (-1 : ℂ) := by norm_num
      calc
        _ = (z ^ 2 - 1) * (z ^ 2 - Complex.I ^ 2) := by ring
        _ = z ^ 4 - 1 := by rw [hi]; ring,
      hz]
    norm_num
  rcases mul_eq_zero.mp hfac with h | h
  · rcases mul_eq_zero.mp h with h | h
    · rcases mul_eq_zero.mp h with h | h
      · left; exact sub_eq_zero.mp h
      · right; left; exact eq_neg_of_add_eq_zero_left h
    · right; right; left; exact sub_eq_zero.mp h
  · right; right; right; exact eq_neg_of_add_eq_zero_left h

/-- Multiplicities of the four fourth roots, together with all spectral data
used below. This is deliberately a multiset statement, so no diagonalization
choices enter the final argument. -/
theorem fourthRootMultiplicityData (s : Multiset ℂ)
    (hfour : ∀ z ∈ s, z ^ 4 = 1) :
    ∃ a b c d : ℕ,
      s.card = a + b + c + d ∧
      s.sum = (((a : ℤ) - b : ℤ) : ℂ) +
        (((c : ℤ) - d : ℤ) : ℂ) * Complex.I ∧
      (s.map fun z => z ^ 2).sum =
        (((a : ℤ) + b - c - d : ℤ) : ℂ) ∧
      s.prod = ((-1 : ℂ) ^ b) * Complex.I ^ c * (-Complex.I) ^ d := by
  induction s using Multiset.induction_on with
  | empty => exact ⟨0, 0, 0, 0, by simp⟩
  | @cons z s ih =>
      have hz := fourth_root_cases z (hfour z (by simp))
      obtain ⟨a, b, c, d, hcard, hsum, hsq, hprod⟩ :=
        ih (fun w hw => hfour w (by simp [hw]))
      rcases hz with rfl | rfl | rfl | rfl
      · refine ⟨a + 1, b, c, d, ?_, ?_, ?_, ?_⟩
        · simp [hcard]; omega
        · simp only [Multiset.sum_cons, hsum]
          push_cast
          ring
        · simp only [Multiset.map_cons, Multiset.sum_cons, hsq]
          push_cast
          ring
        · simp only [Multiset.prod_cons, hprod]
          simp
      · refine ⟨a, b + 1, c, d, ?_, ?_, ?_, ?_⟩
        · simp [hcard]; omega
        · simp only [Multiset.sum_cons, hsum]
          push_cast
          ring
        · simp only [Multiset.map_cons, Multiset.sum_cons, hsq]
          push_cast
          ring
        · simp only [Multiset.prod_cons, hprod]
          rw [pow_succ]
          ring
      · refine ⟨a, b, c + 1, d, ?_, ?_, ?_, ?_⟩
        · simp [hcard]; omega
        · simp only [Multiset.sum_cons, hsum]
          push_cast
          ring
        · simp only [Multiset.map_cons, Multiset.sum_cons, hsq]
          push_cast
          norm_num
          ring
        · simp [hprod, pow_succ]; ring
      · refine ⟨a, b, c, d + 1, ?_, ?_, ?_, ?_⟩
        · simp [hcard]; omega
        · simp only [Multiset.sum_cons, hsum]
          push_cast
          ring
        · simp only [Multiset.map_cons, Multiset.sum_cons, hsq]
          push_cast
          norm_num
          ring
        · simp [hprod, pow_succ]; ring

/-- Spectral data for a finite-dimensional complex endomorphism of fourth
power one. The proof chooses the direct-sum eigenbasis supplied by the
squarefree polynomial `X^4 - 1`; no characteristic-polynomial power-sum
identity is needed. -/
theorem fourthPowerEndData (V : Type*) [AddCommGroup V] [Module ℂ V]
    [FiniteDimensional ℂ V] (f : Module.End ℂ V) (hfour : f ^ 4 = 1) :
    ∃ a b c d : ℕ,
      Module.finrank ℂ V = a + b + c + d ∧
      (LinearMap.trace ℂ V) f = (((a : ℤ) - b : ℤ) : ℂ) +
        (((c : ℤ) - d : ℤ) : ℂ) * Complex.I ∧
      (LinearMap.trace ℂ V) (f ^ 2) =
        (((a : ℤ) + b - c - d : ℤ) : ℂ) ∧
      LinearMap.det f =
        ((-1 : ℂ) ^ b) * Complex.I ^ c * (-Complex.I) ^ d := by
  classical
  let p : Polynomial ℂ := Polynomial.X ^ 4 - Polynomial.C 1
  have hp : Squarefree p := by
    exact (Polynomial.separable_X_pow_sub_C (1 : ℂ) (by norm_num)
      one_ne_zero).squarefree
  have hpf : (Polynomial.aeval f) p = 0 := by
    simp only [p, Polynomial.aeval_sub, Polynomial.aeval_X_pow,
      Polynomial.aeval_C, map_one]
    rw [hfour]
    exact sub_self 1
  have hsemi : f.IsSemisimple :=
    Module.End.isSemisimple_of_squarefree_aeval_eq_zero hp hpf
  have hint : DirectSum.IsInternal f.eigenspace :=
    DirectSum.isInternal_submodule_of_iSupIndep_of_iSup_eq_top
      (Module.End.eigenspaces_iSupIndep f) hsemi.iSup_eigenspace_eq_top
  let idx (μ : ℂ) := Module.Free.ChooseBasisIndex ℂ (f.eigenspace μ)
  let eigBasis (μ : ℂ) : Module.Basis (idx μ) ℂ (f.eigenspace μ) :=
    Module.Free.chooseBasis ℂ (f.eigenspace μ)
  let β := (μ : ℂ) × idx μ
  let basis : Module.Basis β ℂ V := hint.collectedBasis eigBasis
  letI : Finite β := by
    rw [← Cardinal.lt_aleph0_iff_finite,
      ← Module.finrank_eq_card_basis' basis]
    exact Cardinal.nat_lt_aleph0 _
  letI : Fintype β := Fintype.ofFinite β
  have hmatrix : (LinearMap.toMatrix basis basis) f =
      Matrix.diagonal (fun i : β => i.1) := by
    ext i j
    rw [LinearMap.toMatrix_apply]
    have hj : f (basis j) = j.1 • basis j :=
      Module.End.mem_eigenspace_iff.mp (hint.collectedBasis_mem eigBasis j)
    rw [hj, map_smul]
    by_cases hij : i = j
    · subst i
      simp [Matrix.diagonal_apply_eq]
    · simp [Matrix.diagonal_apply_ne _ hij, hij]
  let s : Multiset ℂ := (Finset.univ : Finset β).val.map (fun i => i.1)
  have hs_four : ∀ z ∈ s, z ^ 4 = 1 := by
    intro z hz
    simp only [s, Multiset.mem_map, Finset.mem_val, Finset.mem_univ, true_and] at hz
    obtain ⟨i, rfl⟩ := hz
    have hm4 : Matrix.diagonal (fun j : β => j.1 ^ 4) = 1 := by
      calc
        Matrix.diagonal (fun j : β => j.1 ^ 4) =
            Matrix.diagonal (fun j : β => j.1) ^ 4 := by
              rw [Matrix.diagonal_pow]
              rfl
        _ = (LinearMap.toMatrix basis basis) (f ^ 4) := by
              rw [← LinearMap.toMatrix_pow, hmatrix]
        _ = 1 := by rw [hfour, LinearMap.toMatrix_one]
    have hii := congrArg (fun M : Matrix β β ℂ => M i i) hm4
    simpa using hii
  obtain ⟨a, b, c, d, hcard, hsum, hsq, hprod⟩ :=
    fourthRootMultiplicityData s hs_four
  refine ⟨a, b, c, d, ?_, ?_, ?_, ?_⟩
  · rw [Module.finrank_eq_card_basis basis]
    simpa [s] using hcard
  · rw [LinearMap.trace_eq_matrix_trace ℂ basis f, hmatrix,
      Matrix.trace_diagonal]
    simpa [s] using hsum
  · have hmatrix2 : (LinearMap.toMatrix basis basis) (f ^ 2) =
        Matrix.diagonal (fun i : β => i.1 ^ 2) := by
      rw [← LinearMap.toMatrix_pow, hmatrix, Matrix.diagonal_pow]
      rfl
    rw [LinearMap.trace_eq_matrix_trace ℂ basis (f ^ 2), hmatrix2,
      Matrix.trace_diagonal]
    simpa [s] using hsq
  · rw [← LinearMap.det_toMatrix basis f, hmatrix, Matrix.det_diagonal]
    simpa [s] using hprod

/-- Bookkeeping for the spectrum of the normalized DFT when `n = 1 mod 4`.
The determinant distinguishes the two possible signs of the trace. -/
theorem fourthSpectrum_one_mod_four
    (q a b c d : ℕ)
    (hcard : a + b + c + d = 4 * q + 1)
    (hsq : (a : ℤ) + b - c - d = 1)
    (hdet : ((-1 : ℂ) ^ b) * Complex.I ^ c * (-Complex.I) ^ d =
      Complex.I ^ ((4 * q + 1) * (2 * q)))
    (hnorm : ‖(((a : ℤ) - b : ℤ) : ℂ) +
      (((c : ℤ) - d : ℤ) : ℂ) * Complex.I‖ = 1) :
    (((a : ℤ) - b : ℤ) : ℂ) +
        (((c : ℤ) - d : ℤ) : ℂ) * Complex.I = 1 := by
  rcases gaussianInteger_norm_one ((a : ℤ) - b) ((c : ℤ) - d) hnorm with
      h | h | h | h
  · rcases h with ⟨hab, hcd⟩
    norm_num [hab, hcd]
  · rcases h with ⟨hab, hcd⟩
    have ha : a = q := by omega
    have hb : b = q + 1 := by omega
    have hc : c = q := by omega
    have hd : d = q := by omega
    subst a; subst b; subst c; subst d
    have hne : ((-1 : ℂ) ^ (q + 1)) * Complex.I ^ q *
        (-Complex.I) ^ q ≠ Complex.I ^ ((4 * q + 1) * (2 * q)) := by
      have hIsq : Complex.I ^ q * Complex.I ^ q = Complex.I ^ (2 * q) := by
        rw [← pow_add]
        congr 1 <;> omega
      have hnegSucc : (-1 : ℂ) ^ (q + 1) = -((-1 : ℂ) ^ q) := by
        rw [pow_succ]
        ring
      have hnegSq : (-1 : ℂ) ^ q * (-1 : ℂ) ^ q = 1 := by
        rw [← pow_add, show q + q = 2 * q by omega, neg_one_even_pow]
      rw [show ((-1 : ℂ) ^ (q + 1)) * Complex.I ^ q *
          (-Complex.I) ^ q = -((-1 : ℂ) ^ q) by
        calc
          _ = (-1 : ℂ) ^ (q + 1) * Complex.I ^ q *
              ((-1 : ℂ) ^ q * Complex.I ^ q) := by rw [neg_I_pow]
          _ = (-1 : ℂ) ^ (q + 1) * ((-1 : ℂ) ^ q *
              Complex.I ^ (2 * q)) := by
                calc
                  _ = (-1 : ℂ) ^ (q + 1) *
                      ((-1 : ℂ) ^ q *
                        (Complex.I ^ q * Complex.I ^ q)) := by ring
                  _ = _ := by rw [hIsq]
          _ = (-1 : ℂ) ^ (q + 1) *
              ((-1 : ℂ) ^ q * (-1 : ℂ) ^ q) := by rw [I_even_pow]
          _ = -((-1 : ℂ) ^ q) := by
                rw [hnegSucc]
                calc
                  -(-1 : ℂ) ^ q * ((-1 : ℂ) ^ q * (-1 : ℂ) ^ q) =
                      -(-1 : ℂ) ^ q * 1 := by rw [hnegSq]
                  _ = -(-1 : ℂ) ^ q := by ring]
      rw [show Complex.I ^ ((4 * q + 1) * (2 * q)) = (-1 : ℂ) ^ q by
        rw [show (4 * q + 1) * (2 * q) = 2 * q + 4 * (2 * q * q) by ring,
          pow_add, I_even_pow]
        have hfour : Complex.I ^ (4 * (2 * q * q)) = 1 := by
          calc
            Complex.I ^ (4 * (2 * q * q)) =
                (Complex.I ^ 4) ^ (2 * q * q) := by
                  exact pow_mul Complex.I 4 (2 * q * q)
            _ = 1 := by norm_num
        rw [hfour]
        simp]
      intro heq
      have hz := congrArg (fun z : ℂ => z / ((-1 : ℂ) ^ q)) heq
      norm_num at hz
    exact (hne hdet).elim
  · rcases h with ⟨hab, hcd⟩
    omega
  · rcases h with ⟨hab, hcd⟩
    omega

/-- Bookkeeping for the spectrum of the normalized DFT when `n = 3 mod 4`. -/
theorem fourthSpectrum_three_mod_four
    (q a b c d : ℕ)
    (hcard : a + b + c + d = 4 * q + 3)
    (hsq : (a : ℤ) + b - c - d = 1)
    (hdet : ((-1 : ℂ) ^ b) * Complex.I ^ c * (-Complex.I) ^ d =
      Complex.I ^ ((4 * q + 3) * (2 * q + 1)))
    (hnorm : ‖(((a : ℤ) - b : ℤ) : ℂ) +
      (((c : ℤ) - d : ℤ) : ℂ) * Complex.I‖ = 1) :
    (((a : ℤ) - b : ℤ) : ℂ) +
        (((c : ℤ) - d : ℤ) : ℂ) * Complex.I = Complex.I := by
  rcases gaussianInteger_norm_one ((a : ℤ) - b) ((c : ℤ) - d) hnorm with
      h | h | h | h
  · rcases h with ⟨hab, hcd⟩
    omega
  · rcases h with ⟨hab, hcd⟩
    omega
  · rcases h with ⟨hab, hcd⟩
    norm_num [hab, hcd]
  · rcases h with ⟨hab, hcd⟩
    have ha : a = q + 1 := by omega
    have hb : b = q + 1 := by omega
    have hc : c = q := by omega
    have hd : d = q + 1 := by omega
    subst a; subst b; subst c; subst d
    have hne : ((-1 : ℂ) ^ (q + 1)) * Complex.I ^ q *
        (-Complex.I) ^ (q + 1) ≠
        Complex.I ^ ((4 * q + 3) * (2 * q + 1)) := by
      rw [show ((-1 : ℂ) ^ (q + 1)) * Complex.I ^ q *
          (-Complex.I) ^ (q + 1) =
          Complex.I ^ (2 * q + 1) by
        calc
          _ = ((-1 : ℂ) ^ (q + 1)) * Complex.I ^ q *
              ((-1 : ℂ) ^ (q + 1) * Complex.I ^ (q + 1)) := by
                rw [neg_I_pow]
          _ = (((-1 : ℂ) ^ (q + 1)) * ((-1 : ℂ) ^ (q + 1))) *
                (Complex.I ^ q * Complex.I ^ (q + 1)) := by ring
          _ = (-1 : ℂ) ^ (2 * (q + 1)) * Complex.I ^ (2 * q + 1) := by
                rw [← pow_add, ← pow_add]
                congr 2 <;> omega
          _ = Complex.I ^ (2 * q + 1) := by rw [neg_one_even_pow]; simp]
      rw [show Complex.I ^ ((4 * q + 3) * (2 * q + 1)) =
          -Complex.I ^ (2 * q + 1) by
        calc
          Complex.I ^ ((4 * q + 3) * (2 * q + 1)) =
              (Complex.I ^ (4 * q + 3)) ^ (2 * q + 1) := by rw [pow_mul]
          _ = (-Complex.I) ^ (2 * q + 1) := by
            congr 1
            rw [pow_add, pow_mul]
            norm_num
          _ = -Complex.I ^ (2 * q + 1) := by
            rw [neg_I_pow]
            have : (-1 : ℂ) ^ (2 * q + 1) = -1 := by
              rw [show 2 * q + 1 = 2 * q + 1 by rfl, pow_add,
                neg_one_even_pow]
              norm_num
            rw [this]
            ring]
      intro heq
      have hz := congrArg (fun z : ℂ => z / Complex.I ^ (2 * q + 1)) heq
      norm_num at hz
    exact (hne hdet).elim

end

end OddGaussSum
