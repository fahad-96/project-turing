import TuringTask.Basic

export TuringTask (card_cubic card_cube_pairs card_noncube_pairs two_cube_iff cubic_sum)
