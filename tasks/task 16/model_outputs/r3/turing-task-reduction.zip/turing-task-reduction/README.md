# TuringTask reduction (incomplete)

This project records a checked reduction of the Fibonacci-square theorem to
the two classical Ljunggren quartic equations. The five requested declarations
are retained verbatim in `TuringTask/Basic.lean`, but still contain `sorry` and
therefore this archive is **not** a solution to the requested proof task.

The unresolved obligations are genuine Diophantine classification theorems;
they are not supplied by the pinned Mathlib version. In particular, a complete
solution must formalize the Pocklington/Ljunggren descent rather than assume it.

Offline check in the supplied environment:

```sh
lake build
```

The `/opt/mathlib4` dependency is local to the supplied environment, so this
archive is not self-contained on an arbitrary machine.
