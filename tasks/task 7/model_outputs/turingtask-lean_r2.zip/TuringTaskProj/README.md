# TuringTask — Legendre character sums for `p ≡ 1 (mod 4)`

All five required theorems are proved in `TuringTask/Basic.lean`, with no `sorry`,
no `admit`, no `native_decide`, and no new axioms.

## Requirements (offline)

This project is **not** self-contained. It requires the preinstalled, pinned environment:

* Lean toolchain `leanprover/lean4:v4.33.0-rc1`
* Mathlib (commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`) at `/opt/mathlib4`

`lakefile.toml` uses a **local path dependency** on `/opt/mathlib4`. On a machine
without that directory the build will not work; symlinks into `/opt` do not make
the archive portable.

## Building (no network access required)

```bash
cd TuringTaskProj
lean-offline-init     # seeds .lake/packages with links to the installed deps
lake build            # finishes with no errors
```

`lean-offline-init` only performs local filesystem operations. Do not run
`lake update` or any cache-download command.

## Verifying the axiom footprint

```bash
lake env lean Axioms.lean
```

Expected output — exactly the three standard axioms for each theorem:

```
'TuringTask.csum_sq_add_sq' depends on axioms: [propext, Classical.choice, Quot.sound]
'TuringTask.csum_sq_of_sq'  depends on axioms: [propext, Classical.choice, Quot.sound]
'TuringTask.csum_one_emod'  depends on axioms: [propext, Classical.choice, Quot.sound]
'TuringTask.choose_modEq'   depends on axioms: [propext, Classical.choice, Quot.sound]
'TuringTask.card_curve'     depends on axioms: [propext, Classical.choice, Quot.sound]
```

## Proof outline

Write `χ = quadraticChar (ZMod p)` and `Sz p c = ∑_{x : ZMod p} χ(x³ − c·x)`.
`csum_eq_Sz` identifies `csum p c` with `Sz p (c : ZMod p)` by reindexing
`Finset.range p` along `ZMod.val`. Throughout, `m = p/2 = (p−1)/2`,
`k = p/4 = (p−1)/4`, so `m = 2k` and `p = 4k+1`.

**Supporting lemmas.** `chi_neg_one`: `χ(−1) = 1` because `p ≡ 1 (mod 4)`.
`Lsum`: `∑_u χ(u(u+d))` equals `p−1` when `d = 0` and `−1` otherwise (for `d ≠ 0`
substitute `u ↦ 1 + d/u`, a bijection from the nonzero elements onto
`univ \ {1}`). `Sz_scale`: `Sz p (c·s²) = χ(s)·Sz p c` for `s ≠ 0`, hence
`Sz p c²` depends only on `χ c` (`Sz_sq_eq`).

**Theorem 1 (`csum_sq_add_sq`).** Expanding the square and summing over `c`
first, `inner_c` evaluates `∑_c χ((x³−cx)(y³−cy)) = χ(xy)·L(y²−x²)`. Summing
over `x, y` gives `total_sum : ∑_c Sz p c ² = 2p(p−1)`: the `−1` part
contributes `−2(∑χ)² = 0`, and the `p` part contributes `p·∑_{x≠0}(1+χ(−1)) =
2p(p−1)`. Since residues and non-residues are equinumerous (`card_res`, from
`∑χ = 0`), the left side is `A·(Sz c² + Sz r²)` with `2A = p−1`; cancelling `A`
yields `4p`.

**Theorem 3 (`csum_one_emod`).** `Sz_one_eq`: `Sz p 1 = (p−3) − 2·#M` where
`M = {x : χ(x³−x) = −1}`, using that `x³−x = 0` has exactly the three roots
`0, ±1`. The Klein four-group `x ↦ −x, x ↦ x⁻¹` acts on `M` (`M_closed_neg`,
`M_closed_inv`), and for `x ∈ M` one has `x ≠ 0`, `x² ≠ 1` and `x² ≠ −1`
(if `x² = −1` then `x³−x = −(1+x)²`, forcing `χ = +1`). Hence the four points
`x, −x, x⁻¹, −x⁻¹` are distinct (`four_distinct`) and form exactly the fiber of
`g(x) = (x − x⁻¹)²` through `x` (`fiber_eq`). Fiberwise counting gives
`4 ∣ #M` (`four_dvd_M`), so `Sz p 1 ≡ p − 3 (mod 8)`, which is `2` when
`p ≡ 5 (mod 8)` and `6` when `p ≡ 1 (mod 8)`.

**Theorem 2 (`csum_sq_of_sq`).** By Theorem 3, `Sz p 1 = 2w` with `w` odd;
by Theorem 1, `Sz p r = 2z` and `w² + z² = p`. The elementary uniqueness of the
two-square representation (`two_sq_uniq`, proved from the Brahmagupta–Fibonacci
identities `(au±bv)² + (av∓bu)² = p²` plus a parity argument) forces `w² = a²`,
so `Sz p c² = Sz p 1² = 4a²`.

**Sign (`Sz_one_sign`).** With `a ≡ 1 (mod 4)`, Theorem 2 gives
`Sz p 1 = ±2a`, and the residue mod `8` from Theorem 3 selects the sign:
`Sz p 1 = −2(−1)^k·a`.

**Theorem 5 (`card_curve`).** `quadraticChar_card_sqrts` turns the point count
into `∑_x (χ(x³−x) + 1) = p + Sz p 1` (`curve_count`); substituting the sign
formula gives `p − 2(−1)^k·a`.

**Theorem 4 (`choose_modEq`).** Euler's criterion gives
`(Sz p 1 : ZMod p) = ∑_x (x³−x)^m`. Expanding `(x³−x)^m = x^m(x²−1)^m`
binomially and applying the power-sum formula `∑_x x^n = −1` iff `(p−1) ∣ n`
(`powsum`), only the term `m + 2j = 2m = p−1`, i.e. `j = k`, survives, so
`(Sz p 1 : ZMod p) = −(−1)^k·C(m,k)` (`Sz_pow_expand`). Combined with
`Sz p 1 = −2(−1)^k·a`, this yields `C(m,k) ≡ 2a (mod p)`.
