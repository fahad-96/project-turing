# TuringTask — Weyl equidistribution in Lean 4

Complete, `sorry`-free proofs of the five requested theorems in `TuringTask/Basic.lean`.

## Environment (required)

* Lean toolchain `leanprover/lean4:v4.33.0-rc1`
* Mathlib commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`, available locally at `/opt/mathlib4`

`lakefile.toml` uses a **local path dependency** on `/opt/mathlib4`. This archive is *not*
self-contained on an arbitrary machine: it requires the supplied Lean/Mathlib installation
(or an equivalent local Mathlib at that path).

## Offline build

```bash
lean-offline-init     # seeds .lake/packages with links to the installed deps; no network
lake build            # finishes with no errors (~1 min from scratch)
```

Individual files can also be checked directly with the offline compiler, e.g.

```bash
lake env lean TuringTask/Basic.lean
```

## The five theorems

All in namespace `TuringTask`, file `TuringTask/Basic.lean`:

| name | statement |
|---|---|
| `freq_sq_unif` | `{n²x}` is equidistributed uniformly in `(a,b)`, for irrational `x` |
| `freq_poly` | `{f(n)}` is equidistributed for `f` of degree `≥ 1` with irrational leading coefficient |
| `freq_lead_sq` | leading decimal digit of `2^(n²)` follows Benford's law |
| `mean_abs_sin_sq` | `(1/N) ∑_{n<N} |sin(n²)| → 2/π` |
| `mean_cos_sq` | `(1/N) ∑_{n<N} cos(n²x) → 0` when `x/π` is irrational |

Each depends only on `propext`, `Classical.choice`, `Quot.sound`:

```bash
echo 'import TuringTask.Basic
#print axioms TuringTask.freq_sq_unif
#print axioms TuringTask.freq_poly
#print axioms TuringTask.freq_lead_sq
#print axioms TuringTask.mean_abs_sin_sq
#print axioms TuringTask.mean_cos_sq' > /tmp/ax.lean
lake env lean /tmp/ax.lean
```

## Structure of the development

| file | contents |
|---|---|
| `TuringTask/Poly.lean` | Hasse-derivative computations; degree and top coefficient of the difference polynomial `P(X+r) − P(X)` |
| `TuringTask/Weyl.lean` | the character `e(t) = exp(2πit)`; **van der Corput's inequality** `H·‖S_N‖² ≤ (N+H)(N + 2∑_{k<H}‖C_k‖)` |
| `TuringTask/Equid.lean` | `WeylNull`; the base case (linear phases, geometric sums) and the induction on degree giving **Weyl's theorem** `weylNull_main` |
| `TuringTask/Criterion.lean` | `WeylEquid`; the submodule of "good" continuous functions on `AddCircle 1`, its closedness, membership of the Fourier monomials, and `span_fourier_closure_eq_top` ⟹ **the Weyl criterion** |
| `TuringTask/Trap.lean` | continuous trapezoidal minorants/majorants of interval indicators with integral estimates |
| `TuringTask/Bridge.lean` | transfer from the circle to `Int.fract`; the sandwich argument; **uniform** convergence of the proportions over all `0 ≤ a ≤ b ≤ 1` |
| `TuringTask/Digits.lean` | irrationality of `log₁₀ 2`; `Nat.log 10 (2^E) = ⌊E·log₁₀2⌋`; leading digit ⟺ fractional part in `[log d, log(d+1))` |
| `TuringTask/Basic.lean` | the five theorems |
