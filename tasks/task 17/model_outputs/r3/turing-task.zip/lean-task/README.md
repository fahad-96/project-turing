# TuringTask

Build offline in the supplied Lean 4 / Mathlib environment:

```sh
lean-offline-init
lake build
lake env lean AxiomCheck.lean
```

The project uses the preinstalled Mathlib at `/opt/mathlib4`; the archive is not
self-contained on a machine without that supplied environment.
