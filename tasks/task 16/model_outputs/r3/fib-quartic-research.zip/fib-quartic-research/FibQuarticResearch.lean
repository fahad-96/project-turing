import Mathlib
import Mathlib.NumberTheory.Pell

namespace FibQuarticResearch

def lucas (n : ℕ) : ℤ := 2 * Int.fib (n + 1) - Int.fib n

/-- The norm `±4` identity behind all four quartics in the report. -/
theorem lucas_sq_sub_five_fib_sq (n : ℕ) :
    lucas n ^ 2 - 5 * (Nat.fib n : ℤ) ^ 2 = 4 * (-1 : ℤ) ^ n := by
  have h := Int.fib_add_sq_sub_fib_mul_fib_add_two_mul (n : ℤ) 1
  rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega] at h
  rw [show (n : ℤ) + 2 * 1 = ((n + 2 : ℕ) : ℤ) by omega] at h
  simp only [Int.fib_natCast, Int.fib_one, one_pow, Int.natAbs_natCast] at h
  have hrec : (Nat.fib (n + 2) : ℤ) =
      (Nat.fib n : ℤ) + Nat.fib (n + 1) := by
    rw [Nat.fib_add_two]
    omega
  rw [hrec] at h
  have hn : Int.fib (n + 1) = (Nat.fib (n + 1) : ℤ) := by
    rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega, Int.fib_natCast]
  have h0 : Int.fib n = (Nat.fib n : ℤ) := Int.fib_natCast n
  unfold lucas
  rw [hn, h0]
  nlinarith [h]

/-- One step of descent on a norm `±4` pair. -/
theorem pell_four_step (X Y X' Y' : ℤ)
    (hX : 2 * X' = Y - X) (hY : 2 * Y' = 5 * X - Y) :
    Y' ^ 2 - 5 * X' ^ 2 = -(Y ^ 2 - 5 * X ^ 2) := by
  have hX2 := congrArg (fun z : ℤ => z ^ 2) hX
  have hY2 := congrArg (fun z : ℤ => z ^ 2) hY
  nlinarith

/-- The Gaussian reduction of equation (A) produces this quartic form. -/
def pocklingtonForm (a b : ℤ) : ℤ :=
  a ^ 4 - 6 * a ^ 2 * b ^ 2 + b ^ 4 + 2 * a * b * (a ^ 2 - b ^ 2)

/-- The binary quartic is itself a Pell norm. -/
theorem pocklingtonForm_eq_norm (a b : ℤ) :
    pocklingtonForm a b = (a ^ 2 + a * b - b ^ 2) ^ 2 - 5 * (a * b) ^ 2 := by
  unfold pocklingtonForm
  ring

/-- Factorization used for the odd branch of equation (B). -/
theorem factor_plus_four (x y : ℤ) (h : y ^ 2 = 5 * x ^ 4 + 4) :
    (y - 2) * (y + 2) = 5 * x ^ 4 := by
  nlinarith

/-- Factorization used after writing the odd number `v` as `2k+1`. -/
theorem consecutive_factor (u v k : ℤ) (hv : v = 2 * k + 1)
    (h : v ^ 2 = 20 * u ^ 4 + 1) : k * (k + 1) = 5 * u ^ 4 := by
  subst v
  nlinarith

/-- The second hard quartic isolated by the even branch of equation (B). -/
def PellSquareClassifier : Prop :=
  ∀ a b : ℕ, (b : ℤ) ^ 4 - 5 * (a : ℤ) ^ 4 = 1 →
    (a = 0 ∧ b = 1) ∨ (a = 2 ∧ b = 3)

/-- The stronger square-first-coordinate Pell theorem for twice-square Lucas numbers. -/
def LucasPellClassifier : Prop :=
  ∀ z t : ℕ, (z : ℤ) ^ 4 - 5 * (t : ℤ) ^ 2 = 1 →
    (z = 1 ∧ t = 0) ∨ (z = 3 ∧ t = 4)

/-- The first hard quartic, equation (A). -/
def MinusFourClassifier : Prop :=
  ∀ x y : ℕ, (y : ℤ) ^ 2 + 4 = 5 * (x : ℤ) ^ 4 → x = 1 ∧ y = 1

example : (1 : ℤ) ^ 2 + 4 = 5 * (1 : ℤ) ^ 4 := by norm_num
example : (2 : ℤ) ^ 2 = 5 * (0 : ℤ) ^ 4 + 4 := by norm_num
example : (3 : ℤ) ^ 2 = 5 * (1 : ℤ) ^ 4 + 4 := by norm_num
example : (322 : ℤ) ^ 2 = 5 * (12 : ℤ) ^ 4 + 4 := by norm_num

/-- Exact quartics for square and twice-square Lucas numbers. -/
theorem lucas_companion_equations (z f : ℤ) :
    (z ^ 4 - 5 * f ^ 2 = 4 ↔ z ^ 4 = 5 * f ^ 2 + 4) ∧
    (z ^ 4 - 5 * f ^ 2 = -4 ↔ z ^ 4 + 4 = 5 * f ^ 2) ∧
    (4 * z ^ 4 - 5 * f ^ 2 = 4 ↔ 4 * z ^ 4 = 5 * f ^ 2 + 4) ∧
    (4 * z ^ 4 - 5 * f ^ 2 = -4 ↔ 4 * z ^ 4 + 4 = 5 * f ^ 2) := by
  constructor
  · constructor <;> intro h <;> nlinarith
  constructor
  · constructor <;> intro h <;> nlinarith
  constructor
  · constructor <;> intro h <;> nlinarith
  · constructor <;> intro h <;> nlinarith

end FibQuarticResearch
