import OddGaussSum.Triangular
import OddGaussSum

namespace TuringTask

noncomputable def ex (x : Real) : Complex :=
  Complex.exp (2 * (Real.pi : Complex) * Complex.I * (x : Complex))

noncomputable def rt (n : Nat) : Complex :=
  if n % 4 = 1 then ((Real.sqrt (n : Real) : Real) : Complex)
  else Complex.I * ((Real.sqrt (n : Real) : Real) : Complex)

/-- Exact theorem 1 from the task, discharged by the spectral odd-modulus
quadratic Gauss sum development in `OddGaussSum`. -/
theorem sum_sq (n : Nat) (hn : n % 2 = 1) :
    Finset.sum (Finset.range n) (fun k : Nat => ex ((k : Real) ^ 2 / (n : Real))) = rt n := by
  have hodd : Odd n := Nat.odd_iff.mpr hn
  simpa [ex, rt, div_eq_mul_inv, mul_assoc] using OddGaussSum.sum_sq n hodd

theorem sum_tri (n : Nat) (hn : n % 2 = 1) :
    Finset.sum (Finset.range n) (fun k : Nat =>
        ex ((k : Real) * ((k : Real) + 1) / (2 * (n : Real)))) =
      ex (((n : Real) - 1) / (8 * (n : Real))) *
        ((Real.sqrt (n : Real) : Real) : Complex) := by
  have hodd : Odd n := Nat.odd_iff.mpr hn
  obtain ⟨q, hq⟩ := hodd
  subst n
  simpa [ex] using OddGaussSum.sum_tri_exp q

end TuringTask
