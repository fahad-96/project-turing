import Mathlib

example (p : Nat) [NeZero p] (x : Fin p) :
    ((x.val : Nat) : ZMod p) = (ZMod.finEquiv p) x := by
  cases p with
  | zero => exact Fin.elim0 x
  | succ n =>
      apply ZMod.val_injective (n + 1)
      change x.val % (n + 1) = x.val
      exact Nat.mod_eq_of_lt x.isLt

example (p : Nat) [NeZero p] (x : Fin p) :
    ((x.val : Nat) : ZMod p) = (ZMod.finEquiv p) x := by
  simp [ZMod.finEquiv]
