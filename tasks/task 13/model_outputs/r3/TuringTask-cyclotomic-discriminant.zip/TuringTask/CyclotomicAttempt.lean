import Mathlib

private lemma finish_from_numberField_formula
    (n : Nat) (hn : 1 <= n)
    (hdiscr :
      Polynomial.discr (Polynomial.cyclotomic n Int) =
        (-1) ^ (n.totient / 2) *
          ((n : Int) ^ n.totient /
            (n.primeFactors.prod
              (fun p => (p : Int) ^ (n.totient / (p - 1)))))) :
    Polynomial.discr (Polynomial.cyclotomic n Int) *
        n.primeFactors.prod (fun p => (p : Int) ^ (n.totient / (p - 1))) =
      (-1) ^ (n.totient / 2) * (n : Int) ^ n.totient := by
  rw [hdiscr, mul_assoc]
  congr 1
  apply Int.ediv_mul_cancel
  simpa only [Nat.cast_prod, Int.natCast_pow] using
    (Int.natCast_dvd_natCast.mpr
      (Nat.prod_primeFactors_pow_totient_ediv_dvd (by omega : 0 < n)))

#check @IsCyclotomicExtension.Rat.discr
#check @NumberField.discr_eq_discr
#check @IsPrimitiveRoot.integralPowerBasis
#check @IsPrimitiveRoot.minpoly_eq_cyclotomic_of_irreducible
#check @Algebra.discr_powerBasis_eq_norm

#print axioms finish_from_numberField_formula
