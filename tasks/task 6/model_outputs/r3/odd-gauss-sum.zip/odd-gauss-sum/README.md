# Odd quadratic Gauss sum

This project proves the exact odd-modulus quadratic Gauss sum evaluation

```lean
OddGaussSum.sum_sq
```

The proof constructs the normalized finite Fourier matrix, diagonalizes its
fourth-order action using a collected eigenbasis, proves the norm of its trace,
and computes its determinant phase with the Vandermonde product. The two
possible negative signs are then eliminated from the eigenvalue
multiplicities. `OddGaussSum.lean` converts the resulting `ZMod` sum to the
literal `Finset.range` complex exponential and handles every odd `n`, including
`n = 1`.

The project uses the supplied local Mathlib installation and is not standalone
on an arbitrary machine. In the provided environment, check it offline with:

```sh
lake build
```

No network access or remote dependency fetch is required.
