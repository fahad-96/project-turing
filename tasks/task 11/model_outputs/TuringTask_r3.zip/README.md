# TuringTask

This project uses the Lean and Mathlib versions supplied by the task environment.
The Mathlib dependency in `lakefile.toml` is intentionally a local path.

Build offline with:

```sh
lean-offline-init
lake build
```

Check the permitted axioms with:

```sh
lake env lean Axioms.lean
```

The project depends on the supplied Lean/Mathlib environment and is not
self-contained on machines without `/opt/mathlib4`.
