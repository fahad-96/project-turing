# TuringTask

`TuringTask/Basic.lean` is the supplied task and is unchanged. Compile-tested
proofs of its last three theorem statements are in `TuringTask/Limits.lean`, in
the namespace `TuringTask.Limits`. Supporting divisor identities and harmonic
estimates remain in `TuringTask/Research.lean`.

The limit proofs use only the first supplied quantitative estimate,
`TuringTask.sum_card_divisors_sub_le`. They do not use the supplied declarations
of any of the three limits. The main additional ingredients are a telescoping
Cesaro argument for the logarithmic average, monotone integral bounds for
`x * log x`, and a summed `O(sqrt n)` error bound.

Check the limit development directly, offline:

```sh
lake env lean TuringTask/Limits.lean
```

Build the project offline in the supplied Lean/Mathlib environment:

```sh
lean-offline-init
lake build
```

The project intentionally uses the supplied local Mathlib at `/opt/mathlib4`.
It therefore requires the supplied Lean/Mathlib environment and is not
self-contained on an arbitrary machine.
