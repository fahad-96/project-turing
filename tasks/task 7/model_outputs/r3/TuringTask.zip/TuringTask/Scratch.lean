import Mathlib

namespace Scratch

noncomputable def chi (p : Nat) [Fact p.Prime] (x : ZMod p) : Int :=
  legendreSym p x.val

lemma chi_coe (p : Nat) [Fact p.Prime] (a : Int) :
    chi p (a : ZMod p) = legendreSym p a := by
  rw [chi]
  conv_lhs => rw [legendreSym.mod]
  conv_rhs => rw [legendreSym.mod]
  congr 1
  rw [@ZMod.val_intCast p a inferInstance]
  simp

lemma chi_mul (p : Nat) [Fact p.Prime] (x y : ZMod p) :
    chi p (x * y) = chi p x * chi p y := by
  rw [chi, chi, chi, ZMod.val_mul, ← legendreSym.mul]
  conv_lhs => rw [legendreSym.mod]
  conv_rhs => rw [legendreSym.mod]
  congr 1
  simp [Int.mul_emod]

lemma chi_zero (p : Nat) [Fact p.Prime] : chi p 0 = 0 := by
  simp [chi, legendreSym.eq_zero_iff]

lemma chi_one (p : Nat) [Fact p.Prime] : chi p 1 = 1 := by
  rw [chi]
  have hp : 1 < p := (Fact.out : p.Prime).one_lt
  rw [ZMod.val_one p]
  exact legendreSym.at_one p

lemma legendre_eq_quadraticChar (p : Nat) [Fact p.Prime] (hp2 : p ≠ 2) (a : Int) :
    legendreSym p a = (quadraticChar (ZMod p)) (a : ZMod p) := by
  have hleg := legendreSym.card_sqrts p hp2 a
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  have hchar := quadraticChar_card_sqrts (F := ZMod p) hpchar (a : ZMod p)
  omega

end Scratch
