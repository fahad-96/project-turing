import TuringTask.Size

/-!
# Existence of a primitive prime divisor of `F n` (`n ≥ 3`, `n ≠ 6, 12`)

Every prime factor of `Psi n` divides `F n`.  A prime factor of `Psi n` dividing an earlier
Fibonacci number is unique (`nonprim_unique`), appears with exponent one, and is smaller than
`Psi n` (the size bound), so some other prime factor of `Psi n` is primitive.
-/

namespace TuringTask

/-- `p` divides an earlier Fibonacci number. -/
def NonPrim (p n : ℕ) : Prop := ∃ k, 0 < k ∧ k < n ∧ p ∣ Nat.fib k

theorem rk_eq_rk (p : ℕ) (h h' : HasRank p) : rk p h = rk p h' := rfl

theorem Psi_lt_of_real {n c : ℕ} (hn : 0 < n) (h : (c : ℝ) < ((psi n : ℚ) : ℝ)) : c < Psi n := by
  rw [← Psi_cast n hn] at h
  exact_mod_cast h

/-- Every prime factor of `n` is at most `p` when `n = rk p * p ^ j` with `p` odd. -/
theorem prime_factor_le (p : ℕ) (hp : p.Prime) (hp2 : p ≠ 2) (h : HasRank p) (j : ℕ) (ℓ : ℕ)
    (hℓ : ℓ.Prime) (hdvd : ℓ ∣ rk p h * p ^ j) : ℓ ≤ p := by
  rcases (Nat.Prime.dvd_mul hℓ).mp hdvd with h1 | h1
  · exact prime_dvd_rk_le p hp hp2 h ℓ hℓ h1
  · have := (Nat.prime_dvd_prime_iff_eq hℓ hp).mp (hℓ.dvd_of_dvd_pow h1)
    omega

/-- Two prime factors of `Psi n` that both divide earlier Fibonacci numbers coincide,
for `n ≠ 12`. -/
theorem nonprim_unique (n : ℕ) (hn : 0 < n) (h12 : n ≠ 12) (p q : ℕ) (hp : p.Prime)
    (hq : q.Prime) (hpn : p ∣ Psi n) (hqn : q ∣ Psi n) (hp' : NonPrim p n) (hq' : NonPrim q n) :
    p = q := by
  haveI := Fact.mk hp
  haveI := Fact.mk hq
  obtain ⟨k, hk, hkn, hpk⟩ := hp'
  obtain ⟨k', hk', hkn', hqk⟩ := hq'
  -- an odd non-primitive prime is the largest prime factor of `n`
  have odd_case : ∀ r : ℕ, r.Prime → r ≠ 2 → r ∣ Psi n → NonPrim r n →
      r ∣ n ∧ ∀ ℓ, ℓ.Prime → ℓ ∣ n → ℓ ≤ r := by
    intro r hr hr2 hrn ⟨k0, hk0, hk0n, hrk0⟩
    haveI := Fact.mk hr
    obtain ⟨h, j, hj, hnj, -⟩ := nonprim_odd r hr2 n hn hrn k0 hk0 hk0n hrk0
    refine ⟨?_, fun ℓ hℓ hℓn => ?_⟩
    · rw [hnj]; exact dvd_mul_of_dvd_right (dvd_pow_self r (by omega)) _
    · rw [hnj] at hℓn; exact prime_factor_le r hr hr2 h j ℓ hℓ hℓn
  -- the prime `2` forces `n = 3 * 2 ^ a`
  have two_case : 2 ∣ Psi n → NonPrim 2 n → ∃ a, 1 ≤ a ∧ n = 3 * 2 ^ a := by
    intro h2n ⟨k0, hk0, hk0n, h2k0⟩
    obtain ⟨a, ha, hna, -⟩ := nonprim_two n hn h2n k0 hk0 hk0n h2k0
    exact ⟨a, ha, hna⟩
  -- the mixed case `{2, 3}` leads to `n = 12`
  have mixed : ∀ r : ℕ, r.Prime → r ≠ 2 → r ∣ Psi n → NonPrim r n → 2 ∣ Psi n → NonPrim 2 n →
      False := by
    intro r hr hr2 hrn hr' h2n h2'
    haveI := Fact.mk hr
    obtain ⟨a, ha, hna⟩ := two_case h2n h2'
    obtain ⟨hrdvd, hmax⟩ := odd_case r hr hr2 hrn hr'
    -- `r ∣ 3 * 2 ^ a` and `r` odd, so `r = 3`
    have hr3 : r = 3 := by
      rw [hna] at hrdvd
      rcases (Nat.Prime.dvd_mul hr).mp hrdvd with h1 | h1
      · exact (Nat.prime_dvd_prime_iff_eq hr (by norm_num)).mp h1
      · exact absurd ((Nat.prime_dvd_prime_iff_eq hr Nat.prime_two).mp (hr.dvd_of_dvd_pow h1)) hr2
    subst hr3
    obtain ⟨k0, hk0, hk0n, h3k0⟩ := hr'
    obtain ⟨h, j, hj, hnj, -⟩ := nonprim_odd 3 (by norm_num) n hn hrn k0 hk0 hk0n h3k0
    have hrk : rk 3 h = 4 := by rw [rk_eq_rk 3 h hasRank_three, rk_three]
    rw [hrk] at hnj
    -- `4 * 3 ^ j = 3 * 2 ^ a` forces `j = 1`, `a = 2`
    have h3j : 3 ^ j ∣ 3 * 2 ^ a := by
      rw [← hna, hnj]; exact dvd_mul_left _ _
    have hcop : Nat.Coprime (3 ^ j) (2 ^ a) := Nat.Coprime.pow _ _ (by norm_num)
    have h3j' : 3 ^ j ∣ 3 := hcop.dvd_of_dvd_mul_right h3j
    have hj1 : j = 1 := by
      have := Nat.le_of_dvd (by norm_num) h3j'
      have h2 : 3 ^ 1 ≤ 3 ^ j := Nat.pow_le_pow_right (by norm_num) hj
      have h3 : j < 2 := by
        by_contra hc
        push Not at hc
        have : 3 ^ 2 ≤ 3 ^ j := Nat.pow_le_pow_right (by norm_num) hc
        omega
      omega
    subst hj1
    have ha2 : 2 ^ a = 4 := by omega
    have : a = 2 := by
      have : (2 : ℕ) ^ a = 2 ^ 2 := by rw [ha2]; norm_num
      exact Nat.pow_right_injective le_rfl this
    subst this
    exact h12 (by rw [hna]; norm_num)
  by_cases hp2 : p = 2
  · by_cases hq2 : q = 2
    · rw [hp2, hq2]
    · exact absurd (mixed q hq hq2 hqn ⟨k', hk', hkn', hqk⟩ (hp2 ▸ hpn) ⟨k, hk, hkn, hp2 ▸ hpk⟩)
        not_false
  · by_cases hq2 : q = 2
    · exact absurd (mixed p hp hp2 hpn ⟨k, hk, hkn, hpk⟩ (hq2 ▸ hqn) ⟨k', hk', hkn', hq2 ▸ hqk⟩)
        not_false
    · obtain ⟨hpd, hpmax⟩ := odd_case p hp hp2 hpn ⟨k, hk, hkn, hpk⟩
      obtain ⟨hqd, hqmax⟩ := odd_case q hq hq2 hqn ⟨k', hk', hkn', hqk⟩
      exact le_antisymm (hqmax p hp hpd) (hpmax q hq hqd)

/-- A non-primitive prime factor `p` of `Psi n` satisfies `p < Psi n` and `p ^ 2 ∤ Psi n`
(for `n ≥ 3`, `n ≠ 6, 12`). -/
theorem nonprim_lt_Psi (n : ℕ) (hn : 3 ≤ n) (h6 : n ≠ 6) (h12 : n ≠ 12) (p : ℕ) (hp : p.Prime)
    (hpn : p ∣ Psi n) (hp' : NonPrim p n) : p < Psi n ∧ ¬ p ^ 2 ∣ Psi n := by
  haveI := Fact.mk hp
  have hn0 : 0 < n := by omega
  obtain ⟨k, hk, hkn, hpk⟩ := hp'
  by_cases hp2 : p = 2
  · subst hp2
    obtain ⟨a, ha, hna, hor⟩ := nonprim_two n hn0 hpn k hk hkn hpk
    have ha2 : 2 ≤ a := by
      rcases Nat.lt_or_ge a 2 with h | h
      · exfalso; apply h6; rw [hna]; interval_cases a; rfl
      · exact h
    obtain ⟨b, rfl⟩ : ∃ b, a = b + 1 := ⟨a - 1, by omega⟩
    refine ⟨?_, ?_⟩
    · apply Psi_lt_of_real hn0
      have := psi_gt_prime 2 b 3 Nat.prime_two (by norm_num) (by norm_num) (Or.inr (by omega))
      rw [hna, mul_comm]
      exact_mod_cast this
    · rcases hor with h | h
      · omega
      · simpa using h
  · obtain ⟨h, j, hj, hnj, hsq⟩ := nonprim_odd p hp2 n hn0 hpn k hk hkn hpk
    refine ⟨?_, hsq⟩
    apply Psi_lt_of_real hn0
    by_cases hp5 : p = 5
    · subst hp5
      have hrk : rk 5 h = 5 := by rw [rk_eq_rk 5 h hasRank_five, rk_five]
      rw [hrk] at hnj
      have := psi_gt_prime 5 j 1 (by norm_num) (by norm_num) (by norm_num) (Or.inr hj)
      rw [hnj, show 5 * 5 ^ j = 5 ^ (j + 1) * 1 by ring]
      exact_mod_cast this
    · -- `p ∤ rk p` since `rk p ∣ p ± 1`
      have hnd : ¬ p ∣ rk p h := by
        intro hd
        rcases rk_dvd_pred_or_succ p hp hp5 h with h1 | h1
        · have hpos : 0 < p - 1 := by have := hp.two_le; omega
          have hle : p ≤ p - 1 := Nat.le_of_dvd hpos (hd.trans h1)
          have := hp.two_le
          omega
        · have h2 : p ∣ p + 1 - p := Nat.dvd_sub (hd.trans h1) (dvd_refl p)
          rw [Nat.add_sub_cancel_left] at h2
          exact hp.one_lt.ne' (Nat.dvd_one.mp h2)
      obtain ⟨b, rfl⟩ : ∃ b, j = b + 1 := ⟨j - 1, by omega⟩
      have hor : 7 ≤ p ∨ 1 ≤ b := by
        rcases Nat.lt_or_ge p 7 with hlt | hge
        · right
          -- `p ∈ {3}`: then `rk 3 = 4` and `n = 4 * 3 ^ (b+1) ≠ 12` forces `b ≥ 1`
          have hp3 : p = 3 := by
            have := hp.two_le
            interval_cases p <;> first | rfl | exact absurd rfl hp2 | exact absurd rfl hp5 |
              exact absurd hp (by decide)
          subst hp3
          have hrk : rk 3 h = 4 := by rw [rk_eq_rk 3 h hasRank_three, rk_three]
          rw [hrk] at hnj
          rcases Nat.eq_zero_or_pos b with rfl | hb
          · exfalso; apply h12; rw [hnj]; norm_num
          · exact hb
        · left; exact hge
      have := psi_gt_prime p b (rk p h) hp hnd (rk_pos p h) hor
      rw [hnj, mul_comm]
      exact_mod_cast this

/-- `2 ≤ Psi n` for `n ≥ 3`. -/
theorem two_le_Psi (n : ℕ) (hn : 3 ≤ n) : 2 ≤ Psi n := by
  have hn0 : 0 < n := by omega
  suffices h : 1 < Psi n by omega
  apply Psi_lt_of_real hn0
  obtain ⟨a, m', hm', hn'⟩ := Nat.exists_eq_pow_mul_and_not_dvd hn0.ne' 2 (by norm_num)
  by_cases hm1 : m' = 1
  · subst hm1
    rw [mul_one] at hn'
    have ha : 2 ≤ a := by
      by_contra hc
      push Not at hc
      interval_cases a <;> omega
    obtain ⟨b, rfl⟩ : ∃ b, a = b + 1 := ⟨a - 1, by omega⟩
    have := psi_gt_one 2 b 1 Nat.prime_two (by norm_num) (by norm_num) (Or.inr (by omega))
    rw [mul_one] at this
    rw [hn']
    exact_mod_cast this
  · have hm0 : m' ≠ 0 := by rintro rfl; simp at hn'; omega
    have hq := Nat.minFac_prime hm1
    have hqm : m'.minFac ∣ m' := Nat.minFac_dvd m'
    have hq2 : m'.minFac ≠ 2 := by
      intro h2; rw [h2] at hqm; exact hm' hqm
    have hq3 : 3 ≤ m'.minFac := by have := hq.two_le; omega
    have hqn : m'.minFac ∣ n := hqm.trans (by rw [hn']; exact dvd_mul_left _ _)
    obtain ⟨c, m'', hm'', hn''⟩ := Nat.exists_eq_pow_mul_and_not_dvd hn0.ne' m'.minFac hq.ne_one
    have hc : 1 ≤ c := by
      rcases Nat.eq_zero_or_pos c with rfl | hc
      · rw [pow_zero, one_mul] at hn''; exact absurd (hn'' ▸ hqn) hm''
      · exact hc
    obtain ⟨b, rfl⟩ : ∃ b, c = b + 1 := ⟨c - 1, by omega⟩
    have hm''0 : 0 < m'' := by
      rcases Nat.eq_zero_or_pos m'' with rfl | h
      · simp at hn''; omega
      · exact h
    have := psi_gt_one m'.minFac b m'' hq hm'' hm''0 (Or.inl hq3)
    rw [hn'']
    exact_mod_cast this

/-- **Carmichael's theorem for Fibonacci numbers**: for `n ≥ 3`, `n ≠ 6, 12`, some prime divides
`F n` and no `F k` with `1 ≤ k < n`. -/
theorem exists_primitive_prime (n : ℕ) (hn : 3 ≤ n) (h6 : n ≠ 6) (h12 : n ≠ 12) :
    ∃ q, q.Prime ∧ q ∣ Nat.fib n ∧ ∀ k, 0 < k → k < n → ¬ q ∣ Nat.fib k := by
  have hn0 : 0 < n := by omega
  have hPsi := two_le_Psi n hn
  obtain ⟨p, hp, hpn⟩ := Nat.exists_prime_and_dvd (show Psi n ≠ 1 by omega)
  by_cases hprim : NonPrim p n
  · -- `Psi n = p * M` with `p ∤ M`, `M ≥ 2`; a prime factor of `M` is primitive
    obtain ⟨hlt, hsq⟩ := nonprim_lt_Psi n hn h6 h12 p hp hpn hprim
    obtain ⟨M, hM⟩ := hpn
    have hM2 : 2 ≤ M := by
      by_contra hc
      push Not at hc
      interval_cases M <;> omega
    have hpM : ¬ p ∣ M := by
      intro hd
      apply hsq
      rw [hM, sq]
      exact Nat.mul_dvd_mul_left p hd
    obtain ⟨q, hq, hqM⟩ := Nat.exists_prime_and_dvd (show M ≠ 1 by omega)
    have hqn : q ∣ Psi n := by rw [hM]; exact dvd_mul_of_dvd_right hqM p
    have hqp : q ≠ p := by
      rintro rfl; exact hpM hqM
    refine ⟨q, hq, Psi_dvd_fib n n hn0 dvd_rfl |> fun h => hqn.trans h, ?_⟩
    intro k hk hkn hqk
    exact hqp (nonprim_unique n hn0 h12 q p hq hp hqn ⟨M, hM⟩ ⟨k, hk, hkn, hqk⟩ hprim)
  · refine ⟨p, hp, hpn.trans (Psi_dvd_fib n n hn0 dvd_rfl), ?_⟩
    intro k hk hkn hpk
    exact hprim ⟨k, hk, hkn, hpk⟩

end TuringTask
