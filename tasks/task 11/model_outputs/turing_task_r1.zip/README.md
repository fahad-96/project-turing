# TuringTask Lean 4 Project

This project formalizes and proves five classic Lovász Local Lemma theorems in `TuringTask/Basic.lean`:
1. `color_meet`
2. `color_deg`
3. `sat_exists`
4. `ramsey_color`
5. `ap_color`

## Requirements

This project relies on the pinned local Lean toolchain `leanprover/lean4:v4.33.0-rc1` and precompiled Mathlib located at `/opt/mathlib4` as provided in the environment.

## Offline Build Instructions

1. If `.lake/packages` is not seeded or when testing on a fresh copy of the environment:
   ```bash
   lean-offline-init
   ```
2. Build the project using Lake:
   ```bash
   lake build
   ```
3. Direct verification of `TuringTask/Basic.lean`:
   ```bash
   lean TuringTask/Basic.lean
   ```
4. Verify axiom usage:
   Create a small check file `check.lean`:
   ```lean
   import TuringTask.Basic
   open TuringTask
   #print axioms color_meet
   #print axioms color_deg
   #print axioms sat_exists
   #print axioms ramsey_color
   #print axioms ap_color
   ```
   And run:
   ```bash
   lake env lean check.lean
   ```
   All five theorems report only `propext`, `Classical.choice`, and `Quot.sound`.
