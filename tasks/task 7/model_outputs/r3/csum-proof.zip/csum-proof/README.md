# csum_sq_add_sq proof

This project contains a kernel-checking Lean 4/Mathlib proof of
`TuringTask.csum_sq_add_sq` in `Answer/Basic.lean`.

It is configured for the supplied offline environment, with Mathlib at
`/opt/mathlib4`. Build it there with:

```sh
lean-offline-init
lake build
lake env lean Answer/Basic.lean
```

The local `/opt/mathlib4` dependency means the archive requires the supplied
Lean/Mathlib environment; it is not self-contained on an arbitrary machine.
No network access is required or used.
