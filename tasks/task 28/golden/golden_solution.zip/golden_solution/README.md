# Project Turing - Task 28 golden answer

Lean 4 project with complete proofs of five criteria for fourth and eighth powers modulo a
prime `p`: `2` is a fourth power iff `p = a^2 + 64 b^2` (for `p = 1 mod 4`), `-4` is an eighth
power iff `p = a^2 + 32 b^2` (for `p = 1 mod 8`), `2` is a fourth power iff `e^2 = p + 2 f^2`
with `e = 1, 3 mod 8` (for odd `p`), `q` is a fourth power iff `J(q | c) = 1` when
`p = c^2 + q d^2` and `q = 2, 3 mod 4`, and `1 + sqrt 2` is a square iff `p = a^2 + 32 b^2`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Criterion.lean`: the criteria for fourth and eighth powers, and Euler's
  criterion for Jacobi symbols.
- `TuringTask/Thue.lean`: Thue's lemma and the representations `p = c^2 + 2 d^2` and
  `e^2 = p + 2 f^2`.
- `TuringTask/Core.lean`: the Jacobi-symbol core `u^((p-1)/4) J(d | p) = J(c | p)` and the
  reciprocity steps for `J(c | p)` and `J(d | p)`.
- `TuringTask/Quartic.lean`: theorems 1 and 3 (the quartic character of `2`).
- `TuringTask/Jacobi.lean`: theorem 4 (the quartic character of `q`).
- `TuringTask/Octic.lean`: theorems 2 and 5 (the octic character of `-4` and `1 + sqrt 2`).
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
