import TuringTask.Basic

open TuringTask

example (x a b : Real) (hx : Irrational x) (ha : 0 <= a) (hab : a <= b) (hb : b <= 1) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      a <= Int.fract ((n : Real) * x) /\ Int.fract ((n : Real) * x) < b)).card : Real) / N)
      Filter.atTop (nhds (b - a)) :=
  TuringTask.freq_mul x a b hx ha hab hb

example (x a b : Real) (hx : Irrational x) (ha : 0 <= a) (hab : a <= b) (hb : b <= 1) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      a <= Int.fract ((n : Real) ^ 2 * x) /\ Int.fract ((n : Real) ^ 2 * x) < b)).card : Real)
      / N) Filter.atTop (nhds (b - a)) :=
  TuringTask.freq_sq x a b hx ha hab hb

example (x : Real) (hx : Irrational x) (e : Real) (he : 0 < e) :
    exists N0 : Nat, forall N : Nat, N0 <= N -> forall a b : Real, 0 <= a -> a <= b -> b <= 1 ->
      abs ((((Finset.range N).filter (fun n : Nat =>
        a <= Int.fract ((n : Real) * x) /\ Int.fract ((n : Real) * x) < b)).card : Real) / N
        - (b - a)) < e :=
  TuringTask.freq_unif x hx e he

example (d : Nat) (hd : 1 <= d) (hd' : d <= 9) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      2 ^ n / 10 ^ Nat.log 10 (2 ^ n) = d)).card : Real) / N)
      Filter.atTop (nhds (Real.logb 10 (((d : Real) + 1) / d))) :=
  TuringTask.freq_lead d hd hd'

example :
    Filter.Tendsto
      (fun N : Nat => Finset.sum (Finset.range N) (fun n : Nat => abs (Real.sin n)) / N)
      Filter.atTop (nhds (2 / Real.pi)) :=
  TuringTask.mean_abs_sin

#print axioms TuringTask.freq_mul
#print axioms TuringTask.freq_sq
#print axioms TuringTask.freq_unif
#print axioms TuringTask.freq_lead
#print axioms TuringTask.mean_abs_sin
