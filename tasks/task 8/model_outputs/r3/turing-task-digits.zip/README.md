# TuringTask

This project uses the Lean 4 and Mathlib versions supplied by the task environment.

Build offline with:

```sh
lean-offline-init
lake build
```

To check the equidistribution result directly:

```sh
lake env lean TuringTask/Equidistribution.lean
```

The project intentionally uses the local Mathlib dependency at `/opt/mathlib4`
provided by the task environment.
