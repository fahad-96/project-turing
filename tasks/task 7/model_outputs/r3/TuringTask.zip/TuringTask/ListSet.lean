import Mathlib
open Lean Elab Command
elab "list_decls " needle:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if (toString name).contains needle.getString then logInfo name
list_decls "toFinset_card"
list_decls "card_toFinset"
list_decls "card_subtype"
