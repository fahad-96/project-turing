import TuringTask.Psi

/-!
# The size of the primitive part

`psi n = ψ^φ(n) Φ_n(φ/ψ)` for `n ≥ 2` (a homogeneous cyclotomic value at the golden ratio and its
conjugate).  Bounds on `|Φ_m(z)|` from the factorisation over `ℂ`, the identities
`Φ_{mq}(z) Φ_m(z) = Φ_m(z^q)` (`q ∤ m`) and `Φ_{p^{k+1} m}(z) = Φ_{pm}(z^{p^k})` give
`psi (q^(k+1) m) > q` when `q ≥ 7` or `k ≥ 1`, and `psi (q^(k+1) m) > 1` when `q ≥ 3` or `k ≥ 1`.
-/

open Real goldenRatio Polynomial Finset

namespace TuringTask

/-- The homogeneous cyclotomic value `Y^φ(m) Φ_m(X / Y)`. -/
noncomputable def hcyc (m : ℕ) (X Y : ℝ) : ℝ := Y ^ m.totient * (cyclotomic m ℝ).eval (X / Y)

/-! ### Bounds from the complex roots -/

theorem cyclotomic_eval_complex (m : ℕ) (x : ℝ) :
    (((cyclotomic m ℝ).eval x : ℝ) : ℂ) = (cyclotomic m ℂ).eval (x : ℂ) := by
  have h := Polynomial.eval₂_at_apply (p := cyclotomic m ℝ) (algebraMap ℝ ℂ) x
  rw [← eval_map, map_cyclotomic] at h
  exact h.symm

theorem norm_cyclotomic_eval_complex (m : ℕ) (hm : 0 < m) (z : ℂ) :
    ‖(cyclotomic m ℂ).eval z‖ = ∏ ζ ∈ primitiveRoots m ℂ, ‖z - ζ‖ := by
  rw [cyclotomic_eq_prod_X_sub_primitiveRoots (Complex.isPrimitiveRoot_exp m hm.ne'), eval_prod,
    norm_prod]
  simp

theorem abs_cyclotomic_eval_ge (m : ℕ) (hm : 0 < m) (x : ℝ) (hx : 1 ≤ |x|) :
    (|x| - 1) ^ m.totient ≤ |(cyclotomic m ℝ).eval x| := by
  have h := norm_cyclotomic_eval_complex m hm (x : ℂ)
  rw [← cyclotomic_eval_complex, Complex.norm_real, Real.norm_eq_abs] at h
  rw [h, ← Complex.card_primitiveRoots m, ← prod_const]
  apply prod_le_prod
  · intro ζ _; linarith
  · intro ζ hζ
    have h1 : ‖ζ‖ = 1 := ((mem_primitiveRoots hm).mp hζ).norm'_eq_one hm.ne'
    have h2 := norm_sub_norm_le (x : ℂ) ζ
    rw [h1, Complex.norm_real, Real.norm_eq_abs] at h2
    exact h2

theorem abs_cyclotomic_eval_le (m : ℕ) (hm : 0 < m) (x : ℝ) :
    |(cyclotomic m ℝ).eval x| ≤ (|x| + 1) ^ m.totient := by
  have h := norm_cyclotomic_eval_complex m hm (x : ℂ)
  rw [← cyclotomic_eval_complex, Complex.norm_real, Real.norm_eq_abs] at h
  rw [h, ← Complex.card_primitiveRoots m, ← prod_const]
  apply prod_le_prod
  · intro ζ _; exact norm_nonneg _
  · intro ζ hζ
    have h1 : ‖ζ‖ = 1 := ((mem_primitiveRoots hm).mp hζ).norm'_eq_one hm.ne'
    have h2 := norm_sub_le (x : ℂ) ζ
    rw [h1, Complex.norm_real, Real.norm_eq_abs] at h2
    exact h2

theorem abs_hcyc_ge (m : ℕ) (hm : 0 < m) (X Y : ℝ) (hY : 0 < |Y|) (hXY : |Y| ≤ |X|) :
    (|X| - |Y|) ^ m.totient ≤ |hcyc m X Y| := by
  unfold hcyc
  rw [abs_mul, abs_pow]
  have h1 : 1 ≤ |X / Y| := by
    rw [abs_div]; exact (le_div_iff₀ hY).mpr (by linarith)
  have h2 := abs_cyclotomic_eval_ge m hm (X / Y) h1
  have h3 : (|X| - |Y|) ^ m.totient = |Y| ^ m.totient * (|X / Y| - 1) ^ m.totient := by
    rw [← mul_pow, abs_div, mul_sub, mul_div_cancel₀ _ hY.ne', mul_one]
  rw [h3]
  exact mul_le_mul_of_nonneg_left h2 (by positivity)

theorem abs_hcyc_le (m : ℕ) (hm : 0 < m) (X Y : ℝ) (hY : Y ≠ 0) :
    |hcyc m X Y| ≤ (|X| + |Y|) ^ m.totient := by
  unfold hcyc
  rw [abs_mul, abs_pow]
  have hY' : 0 < |Y| := abs_pos.mpr hY
  have h2 := abs_cyclotomic_eval_le m hm (X / Y)
  have h3 : (|X| + |Y|) ^ m.totient = |Y| ^ m.totient * (|X / Y| + 1) ^ m.totient := by
    rw [← mul_pow, abs_div, mul_add, mul_div_cancel₀ _ hY'.ne', mul_one]
  rw [h3]
  exact mul_le_mul_of_nonneg_left h2 (by positivity)

/-! ### The two product identities -/

theorem hcyc_mul_prime (q m : ℕ) (hq : q.Prime) (hqm : ¬ q ∣ m) (X Y : ℝ) :
    hcyc (m * q) X Y * hcyc m X Y = hcyc m (X ^ q) (Y ^ q) := by
  unfold hcyc
  have hcop : Nat.Coprime m q := (Nat.coprime_comm.mp (hq.coprime_iff_not_dvd.mpr hqm))
  have htot : (m * q).totient = m.totient * (q - 1) := by
    rw [Nat.totient_mul hcop, Nat.totient_prime hq]
  have hq1 : m.totient * (q - 1) + m.totient = q * m.totient := by
    have := hq.two_le
    zify [show 1 ≤ q by omega]
    ring
  have hev : (cyclotomic (m * q) ℝ).eval (X / Y) * (cyclotomic m ℝ).eval (X / Y) =
      (cyclotomic m ℝ).eval ((X / Y) ^ q) := by
    rw [← eval_mul, ← cyclotomic_expand_eq_cyclotomic_mul hq hqm, expand_eval]
  calc Y ^ (m * q).totient * (cyclotomic (m * q) ℝ).eval (X / Y)
        * (Y ^ m.totient * (cyclotomic m ℝ).eval (X / Y))
      = Y ^ ((m * q).totient + m.totient)
        * ((cyclotomic (m * q) ℝ).eval (X / Y) * (cyclotomic m ℝ).eval (X / Y)) := by
          rw [pow_add]; ring
    _ = (Y ^ q) ^ m.totient * (cyclotomic m ℝ).eval (X ^ q / Y ^ q) := by
          rw [hev, htot, hq1, ← pow_mul, div_pow, mul_comm q]

theorem hcyc_prime_pow (p k m : ℕ) (hp : p.Prime) (X Y : ℝ) (hY : Y ≠ 0) :
    hcyc (p ^ (k + 1) * m) X Y = hcyc (p * m) (X ^ p ^ k) (Y ^ p ^ k) := by
  induction k generalizing X Y with
  | zero => simp
  | succ k ih =>
    have hdvd : p ∣ p ^ (k + 1) * m := dvd_mul_of_dvd_left (dvd_pow_self p (by omega)) m
    have hn : p ^ (k + 1 + 1) * m = (p ^ (k + 1) * m) * p := by ring
    have hev : (cyclotomic (p ^ (k + 1 + 1) * m) ℝ).eval (X / Y) =
        (cyclotomic (p ^ (k + 1) * m) ℝ).eval ((X / Y) ^ p) := by
      rw [hn, ← cyclotomic_expand_eq_cyclotomic hp hdvd, expand_eval]
    have htot : (p ^ (k + 1 + 1) * m).totient = p * (p ^ (k + 1) * m).totient := by
      rw [show p ^ (k + 1 + 1) * m = p * (p ^ (k + 1) * m) by ring,
        Nat.totient_mul_of_prime_of_dvd hp hdvd]
    have h1 : hcyc (p ^ (k + 1 + 1) * m) X Y = hcyc (p ^ (k + 1) * m) (X ^ p) (Y ^ p) := by
      unfold hcyc
      rw [hev, htot, pow_mul, div_pow]
    rw [h1, ih (X ^ p) (Y ^ p) (pow_ne_zero p hY), ← pow_mul, ← pow_mul, ← pow_succ']

/-! ### `psi n` as a cyclotomic value -/

theorem phi_pow_sub_psi_pow (n : ℕ) : φ ^ n - ψ ^ n = √5 * Nat.fib n := by
  rw [← fib_real]; ring

theorem phi_pow_sub_psi_pow_ne_zero (n : ℕ) (hn : 0 < n) : φ ^ n - ψ ^ n ≠ 0 := by
  rw [phi_pow_sub_psi_pow]
  have : (0 : ℝ) < Nat.fib n := by exact_mod_cast fib_pos' hn
  positivity

theorem abs_psi_eq : |ψ| = φ⁻¹ := by
  rw [inv_goldenRatio, abs_of_neg goldenConj_neg]

theorem abs_phi_eq : |φ| = φ := abs_of_pos goldenRatio_pos

theorem phi_inv_eq : φ⁻¹ = φ - 1 := by
  rw [inv_goldenRatio, ← one_sub_goldenConj]; ring

theorem hcyc_golden_ne_zero (d : ℕ) (hd : 0 < d) : hcyc d φ ψ ≠ 0 := by
  have h := abs_hcyc_ge d hd φ ψ (by rw [abs_psi_eq]; positivity)
    (by rw [abs_psi_eq, abs_phi_eq, phi_inv_eq]; linarith [one_lt_goldenRatio])
  rw [abs_phi_eq, abs_psi_eq, phi_inv_eq, show φ - (φ - 1) = (1 : ℝ) by ring, one_pow] at h
  intro h0
  rw [h0, abs_zero] at h
  linarith

theorem prod_hcyc_golden (n : ℕ) (hn : 0 < n) :
    ∏ d ∈ n.divisors, hcyc d φ ψ = φ ^ n - ψ ^ n := by
  have key : ∀ a b : ℝ, b ≠ 0 → b ^ n * ((a / b) ^ n - 1) = a ^ n - b ^ n := by
    intro a b hb
    rw [div_pow, mul_sub, mul_div_cancel₀ _ (pow_ne_zero n hb), mul_one]
  unfold hcyc
  rw [prod_mul_distrib, prod_pow_eq_pow_sum, Nat.sum_totient, ← eval_prod,
    prod_cyclotomic_eq_X_pow_sub_one hn ℝ, eval_sub, eval_pow, eval_X, eval_one]
  exact key φ ψ goldenConj_ne_zero

theorem prod_zpow_const {ι : Type*} (s : Finset ι) (f : ι → ℤ) (a : ℝ) (ha : a ≠ 0) :
    ∏ i ∈ s, a ^ f i = a ^ (∑ i ∈ s, f i) := by
  induction s using Finset.cons_induction with
  | empty => simp
  | cons b s hb ih => rw [prod_cons, sum_cons, ih, zpow_add₀ ha]

open scoped ArithmeticFunction.Moebius in
theorem psi_eq_hcyc (n : ℕ) (hn : 2 ≤ n) : ((psi n : ℚ) : ℝ) = hcyc n φ ψ := by
  have key := (ArithmeticFunction.prod_eq_iff_prod_pow_moebius_eq_of_nonzero (R := ℝ)
    (f := fun d => hcyc d φ ψ) (g := fun d => φ ^ d - ψ ^ d)
    (fun d hd => hcyc_golden_ne_zero d hd) (fun d hd => phi_pow_sub_psi_pow_ne_zero d hd)).mp
    (fun d hd => prod_hcyc_golden d hd) n (by omega)
  rw [← key]
  unfold psi
  push_cast
  have hsum : ∑ x ∈ n.divisorsAntidiagonal, (μ x.1 : ℤ) = 0 := by
    have := moebius_sum_one n (by omega)
    simp only [mul_one] at this
    rw [this, if_neg (by omega)]
  have h5 : (√5 : ℝ) ≠ 0 := by positivity
  symm
  calc ∏ x ∈ n.divisorsAntidiagonal, (φ ^ x.2 - ψ ^ x.2) ^ (μ x.1 : ℤ)
      = ∏ x ∈ n.divisorsAntidiagonal,
          ((√5 : ℝ) ^ (μ x.1 : ℤ) * (Nat.fib x.2 : ℝ) ^ (μ x.1 : ℤ)) := by
        refine prod_congr rfl fun x _ => ?_
        rw [phi_pow_sub_psi_pow, mul_zpow]
    _ = (√5 : ℝ) ^ (∑ x ∈ n.divisorsAntidiagonal, (μ x.1 : ℤ))
        * ∏ x ∈ n.divisorsAntidiagonal, (Nat.fib x.2 : ℝ) ^ (μ x.1 : ℤ) := by
        rw [prod_mul_distrib, prod_zpow_const _ _ _ h5]
    _ = ∏ x ∈ n.divisorsAntidiagonal, (Nat.fib x.2 : ℝ) ^ (μ x.1 : ℤ) := by
        rw [hsum, zpow_zero, one_mul]

/-! ### Real inequalities -/

theorem ineq_lin (a : ℝ) (ha : 1 < a) (q0 : ℕ)
    (hbase : (q0 : ℝ) * (a + a⁻¹) < a ^ q0 - a⁻¹ ^ q0)
    (hstep : a + a⁻¹ ≤ a ^ q0 * (a - 1)) :
    ∀ q, q0 ≤ q → (q : ℝ) * (a + a⁻¹) < a ^ q - a⁻¹ ^ q := by
  intro q hq
  induction q, hq using Nat.le_induction with
  | base => exact hbase
  | succ q hq ih =>
    have ha0 : 0 < a := by linarith
    have hinv : a⁻¹ < 1 := inv_lt_one_of_one_lt₀ ha
    have hinv0 : 0 < a⁻¹ := inv_pos.mpr ha0
    have h1 : a ^ q0 ≤ a ^ q := pow_le_pow_right₀ ha.le hq
    have h2 : 0 ≤ a⁻¹ ^ q := by positivity
    have h3 : a ^ q0 * (a - 1) ≤ a ^ q * (a - 1) := mul_le_mul_of_nonneg_right h1 (by linarith)
    push_cast
    rw [pow_succ, pow_succ]
    nlinarith [mul_nonneg h2 (sub_nonneg.mpr hinv.le)]

theorem ineq_const (a : ℝ) (ha : 1 < a) (q0 : ℕ)
    (hbase : a + a⁻¹ < a ^ q0 - a⁻¹ ^ q0) :
    ∀ q, q0 ≤ q → a + a⁻¹ < a ^ q - a⁻¹ ^ q := by
  intro q hq
  induction q, hq using Nat.le_induction with
  | base => exact hbase
  | succ q hq ih =>
    have ha0 : 0 < a := by linarith
    have hinv : a⁻¹ < 1 := inv_lt_one_of_one_lt₀ ha
    have hinv0 : 0 < a⁻¹ := inv_pos.mpr ha0
    have h1 : a ^ q ≤ a ^ (q + 1) := pow_le_pow_right₀ ha.le (by omega)
    have h2 : a⁻¹ ^ (q + 1) ≤ a⁻¹ ^ q := pow_le_pow_of_le_one hinv0.le hinv.le (by omega)
    linarith

theorem phi_pow_three : φ ^ 3 = 2 * φ + 1 := by
  linear_combination (φ + 1) * goldenRatio_sq

theorem phi_pow_seven : φ ^ 7 = 13 * φ + 8 := by
  linear_combination (φ ^ 5 + φ ^ 4 + 2 * φ ^ 3 + 3 * φ ^ 2 + 5 * φ + 8) * goldenRatio_sq

theorem phi_inv_pow_three : φ⁻¹ ^ 3 = 2 * φ - 3 := by
  rw [phi_inv_eq]
  linear_combination (φ - 2) * goldenRatio_sq

theorem phi_inv_pow_seven : φ⁻¹ ^ 7 = 13 * φ - 21 := by
  rw [phi_inv_eq]
  linear_combination (φ ^ 5 - 6 * φ ^ 4 + 16 * φ ^ 3 - 25 * φ ^ 2 + 26 * φ - 20) * goldenRatio_sq

theorem phi_gt : (1.6 : ℝ) < φ := by
  have h : (2.2 : ℝ) < √5 := by
    rw [Real.lt_sqrt (by norm_num)]; norm_num
  unfold goldenRatio
  linarith

/-- `q (φ + φ⁻¹) < φ^q - φ⁻¹^q` for `q ≥ 7`. -/
theorem ineq_phi_seven (q : ℕ) (hq : 7 ≤ q) : (q : ℝ) * (φ + φ⁻¹) < φ ^ q - φ⁻¹ ^ q := by
  apply ineq_lin φ one_lt_goldenRatio 7 _ _ q hq
  · rw [phi_pow_seven, phi_inv_pow_seven, phi_inv_eq]
    push_cast
    linarith [goldenRatio_lt_two]
  · rw [phi_pow_seven, phi_inv_eq]
    nlinarith [goldenRatio_sq, one_lt_goldenRatio]

/-- `φ + φ⁻¹ < φ^q - φ⁻¹^q` for `q ≥ 3`. -/
theorem ineq_phi_three (q : ℕ) (hq : 3 ≤ q) : φ + φ⁻¹ < φ ^ q - φ⁻¹ ^ q := by
  apply ineq_const φ one_lt_goldenRatio 3 _ q hq
  rw [phi_pow_three, phi_inv_pow_three, phi_inv_eq]
  linarith [goldenRatio_lt_two]

/-- For `a ≥ φ^2`: `q (a + a⁻¹) < a^q - a⁻¹^q` for all `q ≥ 2`. -/
theorem ineq_big_lin (a : ℝ) (ha : φ ^ 2 ≤ a) (q : ℕ) (hq : 2 ≤ q) :
    (q : ℝ) * (a + a⁻¹) < a ^ q - a⁻¹ ^ q := by
  have ha26 : (2.6 : ℝ) < a := by
    have := phi_gt
    nlinarith [goldenRatio_sq]
  have ha1 : 1 < a := by linarith
  have ha0 : 0 < a := by linarith
  have hb : a * a⁻¹ = 1 := mul_inv_cancel₀ ha0.ne'
  have hb0 : 0 < a⁻¹ := inv_pos.mpr ha0
  have hb1 : a⁻¹ < 0.385 := by
    rw [inv_lt_comm₀ ha0 (by norm_num)]; linarith
  apply ineq_lin a ha1 2 _ _ q hq
  · push_cast
    nlinarith [mul_pos (by linarith : (0 : ℝ) < a - 2.6) (by linarith : (0 : ℝ) < a + 0.6)]
  · nlinarith [mul_pos (by linarith : (0 : ℝ) < a - 2.6) (by linarith : (0 : ℝ) < a + 0.6)]

/-- For `a ≥ φ^2`: `a + a⁻¹ < a^q - a⁻¹^q` for all `q ≥ 2`. -/
theorem ineq_big_const (a : ℝ) (ha : φ ^ 2 ≤ a) (q : ℕ) (hq : 2 ≤ q) :
    a + a⁻¹ < a ^ q - a⁻¹ ^ q := by
  have h := ineq_big_lin a ha q hq
  have ha0 : 0 < a := by nlinarith [goldenRatio_pos, phi_gt]
  have : (1 : ℝ) ≤ q := by exact_mod_cast (by omega : 1 ≤ q)
  have hpos : 0 < a + a⁻¹ := by positivity
  nlinarith

/-! ### The size bound -/

/-- The abstract estimate behind the size bound. -/
theorem size_aux (q m : ℕ) (hq : q.Prime) (hqm : ¬ q ∣ m) (hm : 0 < m) (A B c : ℝ) (hc : 1 ≤ c)
    (hBpos : 0 < |B|) (hAB : |B| ≤ |A|) (hineq : c * (|A| + |B|) < |A| ^ q - |B| ^ q) :
    c < |hcyc (q * m) A B| := by
  have hB0 : B ≠ 0 := abs_pos.mp hBpos
  have hprod := hcyc_mul_prime q m hq hqm A B
  rw [mul_comm m q] at hprod
  have hH2 := abs_hcyc_le m hm A B hB0
  have hH3 := abs_hcyc_ge m hm (A ^ q) (B ^ q) (by rw [abs_pow]; positivity)
    (by rw [abs_pow, abs_pow]; exact pow_le_pow_left₀ hBpos.le hAB _)
  rw [abs_pow, abs_pow] at hH3
  have hH2pos : 0 < |hcyc m A B| := by
    have h := abs_hcyc_ge m hm A B hBpos hAB
    have h0 : 0 < (|A| - |B|) ^ m.totient := by
      apply pow_pos
      have : |B| ^ q < |A| ^ q := by
        by_contra hcon
        push Not at hcon
        have : c * (|A| + |B|) < 0 := by linarith
        have : 0 ≤ c * (|A| + |B|) := by positivity
        linarith
      have hne : |B| ≠ |A| := by
        intro heq; rw [heq] at this; exact lt_irrefl _ this
      exact lt_of_le_of_ne hAB hne |> sub_pos.mpr
    linarith
  have htot : 1 ≤ m.totient := Nat.totient_pos.mpr hm
  have hpos2 : 0 ≤ c * (|A| + |B|) := by positivity
  have key : c * |hcyc m A B| < |hcyc (q * m) A B| * |hcyc m A B| := by
    calc c * |hcyc m A B| ≤ c * (|A| + |B|) ^ m.totient :=
          mul_le_mul_of_nonneg_left hH2 (by linarith)
      _ ≤ c ^ m.totient * (|A| + |B|) ^ m.totient :=
          mul_le_mul_of_nonneg_right (le_self_pow₀ hc (by omega)) (by positivity)
      _ = (c * (|A| + |B|)) ^ m.totient := (mul_pow _ _ _).symm
      _ < (|A| ^ q - |B| ^ q) ^ m.totient := pow_lt_pow_left₀ hineq hpos2 (by omega)
      _ ≤ |hcyc m (A ^ q) (B ^ q)| := hH3
      _ = |hcyc (q * m) A B| * |hcyc m A B| := by rw [← abs_mul, hprod]
  exact lt_of_mul_lt_mul_right key hH2pos.le

/-- The core estimate: with `t = q ^ k`, if `c (φ^t + φ^-t) < φ^(t q) - φ^-(t q)` and `c ≥ 1`,
then `c < psi (q^(k+1) m)` for every `m ≥ 1` with `q ∤ m`. -/
theorem size_core (q k m : ℕ) (hq : q.Prime) (hqm : ¬ q ∣ m) (hm : 0 < m) (c : ℝ) (hc : 1 ≤ c)
    (hineq : c * (φ ^ q ^ k + φ⁻¹ ^ q ^ k) < (φ ^ q ^ k) ^ q - (φ⁻¹ ^ q ^ k) ^ q) :
    c < ((psi (q ^ (k + 1) * m) : ℚ) : ℝ) := by
  have hn2 : 2 ≤ q ^ (k + 1) * m := by
    have h1 : 2 ≤ q ^ (k + 1) := by
      calc 2 ≤ q := hq.two_le
        _ ≤ q ^ (k + 1) := Nat.le_self_pow (by omega) q
    calc 2 ≤ q ^ (k + 1) := h1
      _ = q ^ (k + 1) * 1 := (mul_one _).symm
      _ ≤ q ^ (k + 1) * m := Nat.mul_le_mul_left _ hm
  have hpsi : (0 : ℝ) < ((psi (q ^ (k + 1) * m) : ℚ) : ℝ) := by exact_mod_cast psi_pos _
  rw [psi_eq_hcyc _ hn2, hcyc_prime_pow q k m hq φ ψ goldenConj_ne_zero] at hpsi ⊢
  have hphi1 : φ⁻¹ < φ := by rw [phi_inv_eq]; linarith [one_lt_goldenRatio]
  have hphi0 : 0 < φ⁻¹ := by rw [phi_inv_eq]; linarith [one_lt_goldenRatio]
  have hAabs : |φ ^ q ^ k| = φ ^ q ^ k := by rw [abs_pow, abs_phi_eq]
  have hBabs : |ψ ^ q ^ k| = φ⁻¹ ^ q ^ k := by rw [abs_pow, abs_psi_eq]
  have hineq' : c * (|φ ^ q ^ k| + |ψ ^ q ^ k|) < |φ ^ q ^ k| ^ q - |ψ ^ q ^ k| ^ q := by
    rw [hAabs, hBabs]; exact hineq
  have hAB : |ψ ^ q ^ k| ≤ |φ ^ q ^ k| := by
    rw [hAabs, hBabs]; exact pow_le_pow_left₀ hphi0.le hphi1.le _
  have hBpos : 0 < |ψ ^ q ^ k| := by rw [hBabs]; positivity
  have h1 := size_aux q m hq hqm hm (φ ^ q ^ k) (ψ ^ q ^ k) c hc hBpos hAB hineq'
  rwa [abs_of_pos hpsi] at h1

/-- `q < psi (q^(k+1) m)` for a prime `q ∤ m`, provided `q ≥ 7` or `k ≥ 1`. -/
theorem psi_gt_prime (q k m : ℕ) (hq : q.Prime) (hqm : ¬ q ∣ m) (hm : 0 < m)
    (hk : 7 ≤ q ∨ 1 ≤ k) : (q : ℝ) < ((psi (q ^ (k + 1) * m) : ℚ) : ℝ) := by
  apply size_core q k m hq hqm hm q (by exact_mod_cast hq.one_lt.le)
  rcases Nat.eq_zero_or_pos k with rfl | hk1
  · rcases hk with h7 | h
    · simp only [pow_zero, pow_one]
      exact ineq_phi_seven q h7
    · omega
  · have ha : φ ^ 2 ≤ φ ^ q ^ k := pow_le_pow_right₀ one_lt_goldenRatio.le
      (by calc 2 ≤ q := hq.two_le
            _ ≤ q ^ k := Nat.le_self_pow hk1.ne' q)
    have := ineq_big_lin (φ ^ q ^ k) ha q hq.two_le
    simpa only [inv_pow] using this

/-- `1 < psi (q^(k+1) m)` for a prime `q ∤ m`, provided `q ≥ 3` or `k ≥ 1`. -/
theorem psi_gt_one (q k m : ℕ) (hq : q.Prime) (hqm : ¬ q ∣ m) (hm : 0 < m)
    (hk : 3 ≤ q ∨ 1 ≤ k) : 1 < ((psi (q ^ (k + 1) * m) : ℚ) : ℝ) := by
  apply size_core q k m hq hqm hm 1 le_rfl
  rw [one_mul]
  rcases Nat.eq_zero_or_pos k with rfl | hk1
  · rcases hk with h3 | h
    · simp only [pow_zero, pow_one]
      exact ineq_phi_three q h3
    · omega
  · have ha : φ ^ 2 ≤ φ ^ q ^ k := pow_le_pow_right₀ one_lt_goldenRatio.le
      (by calc 2 ≤ q := hq.two_le
            _ ≤ q ^ k := Nat.le_self_pow hk1.ne' q)
    have := ineq_big_const (φ ^ q ^ k) ha q hq.two_le
    simpa only [inv_pow] using this

end TuringTask
