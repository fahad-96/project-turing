import TuringTask.LLL

/-!
# Generic two-colouring theorem from the symmetric LLL
-/

namespace TuringTask

open Finset

/-- If both colours occur on `S`, the image has at least two elements. -/
lemma two_le_card_image {α : Type*} [DecidableEq α] (S : Finset α) (f : α → Bool)
    (ht : ∃ x ∈ S, f x = true) (hf : ∃ x ∈ S, f x = false) :
    2 ≤ (S.image f).card := by
  obtain ⟨x, hx, hfx⟩ := ht
  obtain ⟨y, hy, hfy⟩ := hf
  have h1 : (true : Bool) ∈ S.image f := Finset.mem_image.2 ⟨x, hx, hfx⟩
  have h2 : (false : Bool) ∈ S.image f := Finset.mem_image.2 ⟨y, hy, hfy⟩
  have hsub : ({true, false} : Finset Bool) ⊆ S.image f := by
    intro b hb
    simp only [Finset.mem_insert, Finset.mem_singleton] at hb
    rcases hb with rfl | rfl
    · exact h1
    · exact h2
  calc (2:ℕ) = ({true, false} : Finset Bool).card := by decide
    _ ≤ _ := Finset.card_le_card hsub

section Generic

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The "bad" event: the set `D i` is monochromatic under `ω`. -/
def Mono (D : ι → Finset V) (i : ι) : Finset (V → Bool) :=
  univ.filter (fun ω => ¬ ((∃ v ∈ D i, ω v = true) ∧ (∃ v ∈ D i, ω v = false)))

lemma Meas_Mono (D : ι → Finset V) (i : ι) : Meas (D i) (Mono D i) := by
  intro ω ω' hvv hω
  simp only [Mono, Finset.mem_filter, Finset.mem_univ, true_and] at hω ⊢
  intro hc
  refine hω ⟨?_, ?_⟩
  · obtain ⟨v, hv, hval⟩ := hc.1
    exact ⟨v, hv, by rw [hvv v hv]; exact hval⟩
  · obtain ⟨v, hv, hval⟩ := hc.2
    exact ⟨v, hv, by rw [hvv v hv]; exact hval⟩

lemma Mono_subset (D : ι → Finset V) (i : ι) :
    Mono D i ⊆ agree (D i) (fun _ => true) ∪ agree (D i) (fun _ => false) := by
  intro ω hω
  simp only [Mono, Finset.mem_filter, Finset.mem_univ, true_and] at hω
  rw [Finset.mem_union, mem_agree, mem_agree]
  by_cases h : ∃ v ∈ D i, ω v = true
  · -- then no vertex is false, so ω is constantly true on D i
    left
    intro v hv
    cases hb : ω v with
    | true => rfl
    | false => exact absurd ⟨h, ⟨v, hv, hb⟩⟩ hω
  · -- no vertex is true, so ω is constantly false on D i
    right
    push_neg at h
    intro v hv
    cases hb : ω v with
    | false => rfl
    | true => exact absurd hb (by simpa using h v hv)

/-- Generic symmetric-LLL two-colouring theorem for hypergraphs. -/
theorem two_color_hypergraph (D : ι → Finset V) (k d : ℕ)
    (hk : ∀ i, k ≤ (D i).card)
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hcond : Real.exp 1 * ((d : ℝ) + 1) ≤ 2 ^ (k - 1)) :
    ∃ ω : V → Bool, ∀ i, (∃ v ∈ D i, ω v = true) ∧ (∃ v ∈ D i, ω v = false) := by
  -- first, `k ≥ 1`
  have he2 : (2:ℝ) < Real.exp 1 * ((d:ℝ) + 1) := by
    have h1 : (2:ℝ) < Real.exp 1 := by
      have := Real.exp_one_gt_d9
      norm_num at this ⊢
      linarith
    nlinarith [Nat.cast_nonneg (α := ℝ) d]
  have hk1 : 1 ≤ k := by
    by_contra hc
    push_neg at hc
    interval_cases k
    · simp at hcond; linarith
  -- apply the LLL
  have hmain : ∃ ω : V → Bool, ∀ i, ω ∉ Mono D i := by
    refine LLL_sym (Mono D) D d (2 / 2 ^ k) (Meas_Mono D) hdeg ?_ ?_
    · intro i
      exact pr_le_pattern2 (Mono_subset D i) (hk i)
    · have hkk : (2:ℝ) ^ k = 2 ^ (k - 1) * 2 := by
        rw [← pow_succ]
        congr 1
        omega
      have hpow : (0:ℝ) < 2 ^ (k - 1) := by positivity
      rw [hkk]
      rw [show (2:ℝ) / (2 ^ (k-1) * 2) = 1 / 2 ^ (k-1) by
        rw [eq_div_iff (by positivity)]; field_simp]
      rw [mul_one_div, div_mul_eq_mul_div, div_le_one (by positivity)]
      linarith [hcond]
  obtain ⟨ω, hω⟩ := hmain
  refine ⟨ω, fun i => ?_⟩
  have := hω i
  simp only [Mono, Finset.mem_filter, Finset.mem_univ, true_and, not_not] at this
  exact this

end Generic

end TuringTask
