# TuringTask

`TuringTask/Basic.lean` is the supplied task and is unchanged. The compile-tested
supporting development is in `TuringTask/Research.lean`; see `RESEARCH.md` for
the exact reductions, the declarations proved, and the remaining estimates.

Check the research development directly, offline:

```sh
lean TuringTask/Research.lean
```

Build the project offline in the supplied Lean/Mathlib environment:

```sh
lean-offline-init
lake build
```

The project intentionally uses the supplied local Mathlib at `/opt/mathlib4`.
It therefore requires the supplied environment and is not self-contained on an
arbitrary machine.
