import TuringTask.Basic

#print axioms TuringTask.csum_sq_add_sq
#print axioms TuringTask.csum_sq_of_sq
#print axioms TuringTask.csum_one_emod
#print axioms TuringTask.choose_modEq
#print axioms TuringTask.card_curve
