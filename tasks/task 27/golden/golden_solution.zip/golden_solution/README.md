# Project Turing - Task 27 golden answer

Lean 4 project with complete proofs of five representation-number formulas: for `n >= 1` the
number of integer pairs `(x, y)` with `f(x, y) = n` equals a divisor sum of a Jacobi symbol, for
`f = x^2 + x y + y^2`, `x^2 + 3 y^2`, `x^2 + 2 y^2`, `x^2 + x y + 2 y^2` and `x^2 + 7 y^2`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Quad.lean`: positive definite quadratic rings `Z[w]`, the counting box,
  multiples of a fixed element, and divisor sums of a completely multiplicative function.
- `TuringTask/Count.lean`: the recursions of the counts at split, ramified and inert primes,
  and the counting formula by induction.
- `TuringTask/Euclid.lean`: Euclidean division from a rounded quotient, primes of the ring,
  and the link between norms and Jacobi symbols.
- `TuringTask/Rings.lean`: the three Euclidean rings of discriminants -3, -8 and -7.
- `TuringTask/Types.lean`: the type of every rational prime in the three rings.
- `TuringTask/Orders.lean`: the counts for the five forms, including the two orders of index 2.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
