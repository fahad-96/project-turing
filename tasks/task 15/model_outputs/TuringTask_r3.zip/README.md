# TuringTask

This project contains kernel-checked Lean 4 proofs of the five requested character-sum theorems.

It is configured for the supplied offline environment and its local Mathlib checkout at
`/opt/mathlib4`. Build it from the project root with:

```sh
lake build
```
