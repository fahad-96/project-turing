import Mathlib

open Polynomial

namespace TuringTask.ResultantStrategies

-- A zero resultant gives non-coprimality as soon as one polynomial is nonzero.
example {K : Type*} [Field K] {f g : K[X]} (hres : f.resultant g = 0) :
    ¬IsCoprime f g :=
  (Polynomial.resultant_eq_zero_iff.mp hres).2

-- Conversely, non-coprimality plus a nonzero input gives a zero resultant.
example {K : Type*} [Field K] {f g : K[X]} (hf : f ≠ 0) (hcop : ¬IsCoprime f g) :
    f.resultant g = 0 :=
  Polynomial.resultant_eq_zero_iff.mpr ⟨Or.inl hf, hcop⟩

-- Coprimality proves nonvanishing over any commutative domain.
example {R : Type*} [CommRing R] [IsDomain R] (f g : R[X])
    (hcop : IsCoprime f g) : f.resultant g ≠ 0 :=
  Polynomial.resultant_ne_zero f g hcop

-- For a monic first polynomial, a unit resultant is exactly coprimality.
example {R : Type*} [CommRing R] {f g : R[X]} (hf : f.Monic) :
    IsUnit (f.resultant g) ↔ IsCoprime f g :=
  Polynomial.isUnit_resultant_iff_isCoprime hf

end TuringTask.ResultantStrategies
