import Mathlib

open Lean Elab Command

elab "#findnames" s:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if n.toString.toLower.contains s.getString.toLower then
      logInfo m!"{n}"

elab "#find2" s:str t:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    let x := n.toString.toLower
    if x.contains s.getString.toLower && x.contains t.getString.toLower then
      logInfo m!"{n}"

#check Polynomial.cyclotomic_expand_eq_cyclotomic
#check Polynomial.cyclotomic_expand_eq_cyclotomic_mul
#check Polynomial.cyclotomic_prime_pow_mul_X_pow_sub_one
#check Polynomial.cyclotomic_prime_mul_X_sub_one
#check Polynomial.X_pow_sub_one_mul_cyclotomic_dvd_X_pow_sub_one_of_dvd
#check Polynomial.cyclotomic_mul_prime_dvd_eq_pow
