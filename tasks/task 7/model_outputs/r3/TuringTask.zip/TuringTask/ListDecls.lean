import Mathlib

open Lean Elab Command

elab "list_decls " needle:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if (toString name).contains needle.getString then
      logInfo name

list_decls "jacobiSum"
list_decls "JacobiSum"
list_decls "quadraticChar"
list_decls "sum_mulChar"
list_decls "sum_char"
list_decls "sum_legendre"
list_decls "χ₄"
list_decls "legendreSym_eq"
list_decls "eq_legendreSym"
list_decls "quadraticChar_ZMod"
list_decls "quadraticChar_apply_natCast"
list_decls "quadraticChar_apply_intCast"
list_decls "sum_mul_sub"
list_decls "sum_quadraticChar"
list_decls "legendreSym."
