import Mathlib

open Lean Elab Command

elab "#decls_containing " s:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if name.toString.contains s.getString then
      logInfo m!"{name}"

elab "#decls_containing_both " s:str t:str : command => do
  let env ← getEnv
  for (name, _) in env.constants.toList do
    if name.toString.contains s.getString && name.toString.contains t.getString then
      logInfo m!"{name}"

#decls_containing_both "sum" "sqrt"
#decls_containing_both "sum" "factorial"
#decls_containing_both "tendsto" "factorial"
