# TuringTask

A Lean 4 project formalizing Carmichael's theorem on primitive prime factors of Fibonacci numbers and its arithmetic corollaries.

## Requirements & Environment

This project is built and verified offline using the local Lean toolchain and Mathlib environment:
- Lean toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib commit: `9944fe2973b8dc0b86949101ed98232c07cd54a0`
- Local Mathlib path dependency: `/opt/mathlib4`

Note: The supplied Lean/Mathlib environment at `/opt/mathlib4` is required; links to `/opt` mean this archive depends on the pinned container environment.

## Project Structure

- `lakefile.toml`: Lake package configuration pointing to local Mathlib.
- `lean-toolchain`: Pinned toolchain version `leanprover/lean4:v4.33.0-rc1`.
- `TuringTask.lean`: Library root importing `TuringTask.Basic`.
- `TuringTask/Basic.lean`: Implementation of the 5 required theorems:
  1. `exists_prime_fib`: Primitive prime factors of Fibonacci numbers $F_n$.
  2. `exists_prime_lucas`: Primitive prime factors of Lucas numbers $L_n = F_{n-1} + F_{n+1}$.
  3. `card_divisors_le`: Inequality $d(n) \le \omega(F_n) + 4$.
  4. `primeFactors_fib_eq`: Uniqueness of equal prime factor sets $(F_m, F_n) \implies m = 3, n = 6$.
  5. `exists_prime_fib_mod`: Prime factors $q \mid F_n$ with $q \equiv \pm 1 \pmod n$.

## Offline Build Instructions

To build the project offline:
```bash
lake build
```
Or to check `TuringTask/Basic.lean` directly:
```bash
lean TuringTask/Basic.lean
```
