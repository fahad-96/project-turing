import Mathlib

/-!
# A self-contained finite Lovász Local Lemma

The probability space is `V → Bool` with the uniform measure (`V` a finite type).
We develop:

* `Meas T A` : the event `A` depends only on the coordinates in `T`;
* `pr A`     : the uniform probability of `A`;
* independence of events with disjoint supports;
* the symmetric Lovász Local Lemma `LLL_sym`.
-/

namespace TuringTask

open Finset

section Core

variable {V : Type*} [Fintype V] [DecidableEq V]

/-- `A` is determined by the coordinates in `T`. -/
def Meas (T : Finset V) (A : Finset (V → Bool)) : Prop :=
  ∀ ω ω' : V → Bool, (∀ v ∈ T, ω v = ω' v) → ω ∈ A → ω' ∈ A

lemma Meas.mono {T T' : Finset V} {A : Finset (V → Bool)} (h : T ⊆ T') (hA : Meas T A) :
    Meas T' A := fun ω ω' hvv => hA ω ω' (fun v hv => hvv v (h hv))

/-- Uniform probability on `V → Bool`. -/
noncomputable def pr (A : Finset (V → Bool)) : ℝ := (A.card : ℝ) / 2 ^ (Fintype.card V)

lemma pr_nonneg (A : Finset (V → Bool)) : 0 ≤ pr A := by
  unfold pr; positivity

lemma pr_mono {A B : Finset (V → Bool)} (h : A ⊆ B) : pr A ≤ pr B := by
  unfold pr
  have hc : (A.card : ℝ) ≤ (B.card : ℝ) := by exact_mod_cast Finset.card_le_card h
  gcongr <;> try exact hc

lemma pr_union_le (A B : Finset (V → Bool)) : pr (A ∪ B) ≤ pr A + pr B := by
  unfold pr
  rw [← add_div]
  have hc : ((A ∪ B).card : ℝ) ≤ (A.card : ℝ) + (B.card : ℝ) := by
    exact_mod_cast Finset.card_union_le A B
  gcongr <;> try exact hc

lemma pr_empty : pr (∅ : Finset (V → Bool)) = 0 := by
  unfold pr; simp

lemma pr_univ : pr (univ : Finset (V → Bool)) = 1 := by
  unfold pr
  rw [Finset.card_univ, Fintype.card_fun]
  simp

lemma pr_pos_nonempty {X : Finset (V → Bool)} (h : 0 < pr X) : X.Nonempty := by
  rw [← Finset.card_pos]
  by_contra hc
  push_neg at hc
  have h0 : X.card = 0 := Nat.le_zero.1 hc
  rw [pr, h0] at h
  simp at h

lemma pr_sdiff (A B : Finset (V → Bool)) : pr (B \ A) = pr B - pr (A ∩ B) := by
  have h1 : (B \ A).card + (B ∩ A).card = B.card := Finset.card_sdiff_add_card_inter B A
  have h2 : B ∩ A = A ∩ B := Finset.inter_comm B A
  rw [h2] at h1
  have h3 : ((B \ A).card : ℝ) = (B.card : ℝ) - ((A ∩ B).card : ℝ) := by
    have : ((B \ A).card : ℝ) + ((A ∩ B).card : ℝ) = (B.card : ℝ) := by exact_mod_cast h1
    linarith
  unfold pr
  rw [h3, sub_div]

/-- The event "agrees with `ω` on `T`". -/
def agree (T : Finset V) (ω : V → Bool) : Finset (V → Bool) :=
  univ.filter (fun α => ∀ v ∈ T, α v = ω v)

lemma mem_agree {T : Finset V} {ω α : V → Bool} : α ∈ agree T ω ↔ ∀ v ∈ T, α v = ω v := by
  simp [agree]

lemma card_agree (T : Finset V) (ω : V → Bool) : (agree T ω).card = 2 ^ (Tᶜ.card) := by
  have h : agree T ω
      = Fintype.piFinset (fun v => if v ∈ T then ({ω v} : Finset Bool) else Finset.univ) := by
    ext α
    simp only [mem_agree, Fintype.mem_piFinset]
    constructor
    · intro h v
      by_cases hv : v ∈ T
      · simp [hv, h v hv]
      · simp [hv]
    · intro h v hv
      have := h v
      simp [hv] at this
      exact this
  rw [h, Fintype.card_piFinset]
  have hc : ∀ v : V, (if v ∈ T then ({ω v} : Finset Bool) else Finset.univ).card
      = if v ∈ T then 1 else 2 := by
    intro v; by_cases hv : v ∈ T <;> simp [hv]
  simp_rw [hc]
  rw [Finset.prod_ite]
  have h2 : (univ.filter (fun x : V => ¬ x ∈ T)) = Tᶜ := by ext x; simp
  rw [h2]
  simp

lemma pr_agree (T : Finset V) (ω : V → Bool) : pr (agree T ω) = 1 / 2 ^ T.card := by
  unfold pr
  rw [card_agree]
  have h : T.card + Tᶜ.card = Fintype.card V := Finset.card_add_card_compl T
  rw [← h, pow_add]
  push_cast
  rw [div_eq_div_iff (by positivity) (by positivity)]
  ring

/-- Key independence statement: events with complementary supports are independent. -/
lemma card_inter_mul {T : Finset V} {A C : Finset (V → Bool)} (hA : Meas T A) (hC : Meas Tᶜ C) :
    (A ∩ C).card * 2 ^ (Fintype.card V) = A.card * C.card := by
  classical
  set F : ((V → Bool) × (V → Bool)) → (V → Bool) :=
    fun q v => if v ∈ T then q.1 v else q.2 v with hF
  have hmaps : ∀ q ∈ A ×ˢ C, F q ∈ A ∩ C := by
    rintro ⟨α, β⟩ hq
    rw [Finset.mem_product] at hq
    refine Finset.mem_inter.2 ⟨?_, ?_⟩
    · refine hA α (F (α, β)) (fun v hv => ?_) hq.1
      simp [hF, hv]
    · refine hC β (F (α, β)) (fun v hv => ?_) hq.2
      have hv' : v ∉ T := Finset.mem_compl.1 hv
      simp [hF, hv']
  have hfib : ∀ ω ∈ A ∩ C,
      ((A ×ˢ C).filter (fun q => F q = ω)).card = 2 ^ (Fintype.card V) := by
    intro ω hω
    rw [Finset.mem_inter] at hω
    have hset : (A ×ˢ C).filter (fun q => F q = ω) = (agree T ω) ×ˢ (agree Tᶜ ω) := by
      ext q
      obtain ⟨α, β⟩ := q
      simp only [Finset.mem_filter, Finset.mem_product, mem_agree]
      constructor
      · rintro ⟨⟨hα, hβ⟩, heq⟩
        refine ⟨fun v hv => ?_, fun v hv => ?_⟩
        · have : F (α, β) v = ω v := by rw [heq]
          simpa [hF, hv] using this
        · have hv' : v ∉ T := Finset.mem_compl.1 hv
          have : F (α, β) v = ω v := by rw [heq]
          simpa [hF, hv'] using this
      · rintro ⟨hα, hβ⟩
        refine ⟨⟨?_, ?_⟩, ?_⟩
        · exact hA ω α (fun v hv => (hα v hv).symm) hω.1
        · exact hC ω β (fun v hv => (hβ v hv).symm) hω.2
        · funext v
          by_cases hv : v ∈ T
          · simp [hF, hv, hα v hv]
          · simp [hF, hv, hβ v (Finset.mem_compl.2 hv)]
    rw [hset, Finset.card_product, card_agree, card_agree, compl_compl, ← pow_add]
    congr 1
    rw [add_comm]
    exact Finset.card_add_card_compl T
  have h2 := Finset.card_eq_sum_card_fiberwise hmaps
  rw [Finset.sum_congr rfl hfib, Finset.sum_const, smul_eq_mul, Finset.card_product] at h2
  exact h2.symm

lemma pr_inter {T : Finset V} {A C : Finset (V → Bool)} (hA : Meas T A) (hC : Meas Tᶜ C) :
    pr (A ∩ C) = pr A * pr C := by
  have h := card_inter_mul hA hC
  have h2 : ((A ∩ C).card : ℝ) * 2 ^ (Fintype.card V) = (A.card : ℝ) * (C.card : ℝ) := by
    exact_mod_cast h
  have hpos : (0:ℝ) < 2 ^ (Fintype.card V) := by positivity
  unfold pr
  rw [div_mul_div_comm, ← h2]
  field_simp

lemma pr_le_pattern1 {T : Finset V} {ω : V → Bool} {A : Finset (V → Bool)} {c : ℕ}
    (hsub : A ⊆ agree T ω) (hc : c ≤ T.card) : pr A ≤ 1 / 2 ^ c := by
  refine le_trans (pr_mono hsub) ?_
  rw [pr_agree]
  have : (2:ℝ) ^ c ≤ 2 ^ T.card := by
    apply pow_le_pow_right₀ (by norm_num) hc
  apply one_div_le_one_div_of_le (by positivity) this

lemma pr_le_pattern2 {T : Finset V} {ω₁ ω₂ : V → Bool} {A : Finset (V → Bool)} {c : ℕ}
    (hsub : A ⊆ agree T ω₁ ∪ agree T ω₂) (hc : c ≤ T.card) : pr A ≤ 2 / 2 ^ c := by
  have h1 : pr A ≤ pr (agree T ω₁) + pr (agree T ω₂) :=
    le_trans (pr_mono hsub) (pr_union_le _ _)
  rw [pr_agree, pr_agree] at h1
  have h2 : (1:ℝ) / 2 ^ T.card + 1 / 2 ^ T.card = 2 / 2 ^ T.card := by ring
  rw [h2] at h1
  refine le_trans h1 ?_
  have : (2:ℝ) ^ c ≤ 2 ^ T.card := by
    apply pow_le_pow_right₀ (by norm_num) hc
  apply div_le_div_of_nonneg_left (by norm_num) (by positivity) this

end Core

section LLL

variable {V : Type*} [Fintype V] [DecidableEq V]
variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- The event that none of the events indexed by `S` occurs. -/
def Good (A : ι → Finset (V → Bool)) (S : Finset ι) : Finset (V → Bool) :=
  univ.filter (fun ω => ∀ j ∈ S, ω ∉ A j)

lemma mem_Good {A : ι → Finset (V → Bool)} {S : Finset ι} {ω : V → Bool} :
    ω ∈ Good A S ↔ ∀ j ∈ S, ω ∉ A j := by simp [Good]

lemma Good_subset {A : ι → Finset (V → Bool)} {S S' : Finset ι} (h : S ⊆ S') :
    Good A S' ⊆ Good A S := by
  intro ω hω
  rw [mem_Good] at hω ⊢
  exact fun j hj => hω j (h hj)

lemma Good_empty {A : ι → Finset (V → Bool)} : Good A (∅ : Finset ι) = univ := by
  ext ω; simp [mem_Good]

lemma Good_insert {A : ι → Finset (V → Bool)} {S : Finset ι} {j : ι} :
    Good A (insert j S) = Good A S \ A j := by
  ext ω
  simp only [mem_Good, Finset.mem_sdiff, Finset.mem_insert]
  constructor
  · intro h
    exact ⟨fun l hl => h l (Or.inr hl), h j (Or.inl rfl)⟩
  · rintro ⟨h1, h2⟩ l (rfl | hl)
    · exact h2
    · exact h1 l hl

lemma Meas_Good {T : Finset V} {A : ι → Finset (V → Bool)} {S : Finset ι}
    (h : ∀ j ∈ S, Meas T (A j)) : Meas T (Good A S) := by
  intro ω ω' hvv hω
  rw [mem_Good] at hω ⊢
  intro j hj hmem
  exact hω j hj (h j hj ω' ω (fun v hv => (hvv v hv).symm) hmem)

/-- Neighbourhood of `i`: indices `j ≠ i` whose support meets that of `i`. -/
def nbr (D : ι → Finset V) (i : ι) : Finset ι :=
  univ.filter (fun j => j ≠ i ∧ (D i ∩ D j).Nonempty)

lemma pr_indep {A : ι → Finset (V → Bool)} {D : ι → Finset V}
    (hmeas : ∀ i, Meas (D i) (A i)) {i : ι} {S : Finset ι}
    (hS : ∀ j ∈ S, j ≠ i ∧ j ∉ nbr D i) :
    pr (A i ∩ Good A S) = pr (A i) * pr (Good A S) := by
  refine pr_inter (hmeas i) (Meas_Good ?_)
  intro j hj
  obtain ⟨hne, hnb⟩ := hS j hj
  have hdis : ¬ (D i ∩ D j).Nonempty := by
    intro hcon
    exact hnb (Finset.mem_filter.2 ⟨Finset.mem_univ _, hne, hcon⟩)
  refine (hmeas j).mono ?_
  intro v hv
  rw [Finset.mem_compl]
  intro hvi
  exact hdis ⟨v, Finset.mem_inter.2 ⟨hvi, hv⟩⟩

variable {A : ι → Finset (V → Bool)} {D : ι → Finset V} {d : ℕ} {x : ℝ}

lemma chain (hx0 : 0 ≤ x) (hx1 : x ≤ 1) (M : ℕ)
    (hyp : ∀ S : Finset ι, S.card < M → ∀ i, i ∉ S →
      pr (A i ∩ Good A S) ≤ x * pr (Good A S)) :
    ∀ (T U : Finset ι), Disjoint T U → (T ∪ U).card ≤ M →
      (1 - x) ^ T.card * pr (Good A U) ≤ pr (Good A (T ∪ U)) := by
  intro T
  induction T using Finset.induction_on with
  | empty => intro U _ _; simp
  | insert j T hj ih =>
      intro U hdisj hcard
      have hjTU : j ∉ T ∪ U := by
        simp only [Finset.mem_union]
        rintro (h | h)
        · exact hj h
        · exact (Finset.disjoint_left.1 hdisj (Finset.mem_insert_self j T)) h
      have hun : insert j T ∪ U = insert j (T ∪ U) := by
        rw [Finset.insert_union]
      have hcard2 : (T ∪ U).card + 1 ≤ M := by
        rw [hun, Finset.card_insert_of_notMem hjTU] at hcard
        exact hcard
      have hdisj' : Disjoint T U := hdisj.mono_left (Finset.subset_insert j T)
      have h1 := ih U hdisj' (by omega)
      have h2 := hyp (T ∪ U) (by omega) j hjTU
      have hx' : (0:ℝ) ≤ 1 - x := by linarith
      have h3 : (1 - x) * ((1 - x) ^ T.card * pr (Good A U))
          ≤ (1 - x) * pr (Good A (T ∪ U)) := mul_le_mul_of_nonneg_left h1 hx'
      rw [hun, Good_insert, pr_sdiff, Finset.card_insert_of_notMem hj, pow_succ]
      nlinarith [h2, h3]

lemma key_step (hx0 : 0 ≤ x) (hx1 : x ≤ 1)
    (hmeas : ∀ i, Meas (D i) (A i))
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hp : ∀ i, pr (A i) ≤ x * (1 - x) ^ d)
    (M : ℕ)
    (hyp : ∀ S : Finset ι, S.card < M → ∀ i, i ∉ S →
      pr (A i ∩ Good A S) ≤ x * pr (Good A S)) :
    ∀ S : Finset ι, S.card ≤ M → ∀ i, i ∉ S →
      pr (A i ∩ Good A S) ≤ x * pr (Good A S) := by
  intro S hS i hi
  have hS12 : (S ∩ nbr D i) ∪ (S \ nbr D i) = S := by
    ext a
    simp only [Finset.mem_union, Finset.mem_inter, Finset.mem_sdiff]
    tauto
  have hdisj : Disjoint (S ∩ nbr D i) (S \ nbr D i) := by
    rw [Finset.disjoint_left]
    intro a ha hb
    simp only [Finset.mem_inter, Finset.mem_sdiff] at ha hb
    exact hb.2 ha.2
  have hS2sub : S \ nbr D i ⊆ S := Finset.sdiff_subset
  have hS1card : (S ∩ nbr D i).card ≤ d :=
    le_trans (Finset.card_le_card Finset.inter_subset_right) (hdeg i)
  have hindep : pr (A i ∩ Good A (S \ nbr D i)) = pr (A i) * pr (Good A (S \ nbr D i)) := by
    refine pr_indep hmeas ?_
    intro j hj
    simp only [Finset.mem_sdiff] at hj
    refine ⟨?_, hj.2⟩
    intro hji
    exact hi (hji ▸ hj.1)
  have hchain := chain hx0 hx1 M hyp (S ∩ nbr D i) (S \ nbr D i) hdisj (by rw [hS12]; exact hS)
  rw [hS12] at hchain
  have hmono : pr (A i ∩ Good A S) ≤ pr (A i ∩ Good A (S \ nbr D i)) :=
    pr_mono (Finset.inter_subset_inter (le_refl _) (Good_subset hS2sub))
  have hpow : (1 - x) ^ d ≤ (1 - x) ^ (S ∩ nbr D i).card :=
    pow_le_pow_of_le_one (by linarith) (by linarith) hS1card
  have hG2 : 0 ≤ pr (Good A (S \ nbr D i)) := pr_nonneg _
  have step1 : pr (A i ∩ Good A S) ≤ x * (1 - x) ^ d * pr (Good A (S \ nbr D i)) := by
    rw [hindep] at hmono
    exact le_trans hmono (mul_le_mul_of_nonneg_right (hp i) hG2)
  have step2 : x * ((1 - x) ^ d * pr (Good A (S \ nbr D i))) ≤ x * pr (Good A S) := by
    refine mul_le_mul_of_nonneg_left ?_ hx0
    exact le_trans (mul_le_mul_of_nonneg_right hpow hG2) hchain
  nlinarith [step1, step2]

lemma key (hx0 : 0 ≤ x) (hx1 : x ≤ 1)
    (hmeas : ∀ i, Meas (D i) (A i))
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hp : ∀ i, pr (A i) ≤ x * (1 - x) ^ d) :
    ∀ M : ℕ, ∀ S : Finset ι, S.card ≤ M → ∀ i, i ∉ S →
      pr (A i ∩ Good A S) ≤ x * pr (Good A S) := by
  intro M
  induction M with
  | zero =>
      refine key_step hx0 hx1 hmeas hdeg hp 0 ?_
      intro S hS
      exact absurd hS (Nat.not_lt_zero _)
  | succ M ih =>
      refine key_step hx0 hx1 hmeas hdeg hp (M + 1) ?_
      intro S hS i hi
      exact ih S (by omega) i hi

theorem LLL_core (hx0 : 0 ≤ x) (hx1 : x < 1)
    (hmeas : ∀ i, Meas (D i) (A i))
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hp : ∀ i, pr (A i) ≤ x * (1 - x) ^ d) :
    ∃ ω : V → Bool, ∀ i, ω ∉ A i := by
  have hyp : ∀ S : Finset ι, S.card < Fintype.card ι → ∀ i, i ∉ S →
      pr (A i ∩ Good A S) ≤ x * pr (Good A S) := by
    intro S hS i hi
    exact key hx0 (le_of_lt hx1) hmeas hdeg hp (Fintype.card ι) S (le_of_lt hS) i hi
  have hchain := chain hx0 (le_of_lt hx1) (Fintype.card ι) hyp univ ∅
    (by simp) (by simp [Finset.card_univ])
  rw [Finset.union_empty, Good_empty, pr_univ, mul_one, Finset.card_univ] at hchain
  have hpos : 0 < pr (Good A (univ : Finset ι)) := by
    refine lt_of_lt_of_le ?_ hchain
    have : (0:ℝ) < 1 - x := by linarith
    positivity
  obtain ⟨ω, hω⟩ := pr_pos_nonempty hpos
  refine ⟨ω, ?_⟩
  intro i
  exact (mem_Good.1 hω) i (Finset.mem_univ i)

/-- Symmetric Lovász Local Lemma. -/
theorem LLL_sym (A : ι → Finset (V → Bool)) (D : ι → Finset V) (d : ℕ) (p : ℝ)
    (hmeas : ∀ i, Meas (D i) (A i))
    (hdeg : ∀ i, (nbr D i).card ≤ d)
    (hp : ∀ i, pr (A i) ≤ p)
    (hcond : Real.exp 1 * p * ((d : ℝ) + 1) ≤ 1) :
    ∃ ω : V → Bool, ∀ i, ω ∉ A i := by
  set y : ℝ := (d : ℝ) + 1 with hy_def
  have hy : 0 < y := by rw [hy_def]; positivity
  have hz : 0 < y + 1 := by linarith
  set x : ℝ := 1 / (y + 1) with hx_def
  have hx0 : 0 ≤ x := by rw [hx_def]; positivity
  have hx1 : x < 1 := by rw [hx_def, div_lt_one hz]; linarith
  have he : 0 < Real.exp 1 := Real.exp_pos 1
  -- the basic exponential estimate
  have hexp : (y + 1) ^ (d + 1) ≤ Real.exp 1 * y ^ (d + 1) := by
    have h1 : 1 + 1 / y ≤ Real.exp (1 / y) := by
      have := Real.add_one_le_exp (1 / y)
      linarith
    have h2 : (1 + 1 / y) ^ (d + 1) ≤ (Real.exp (1 / y)) ^ (d + 1) :=
      pow_le_pow_left₀ (by positivity) h1 _
    have h3 : (Real.exp (1 / y)) ^ (d + 1) = Real.exp 1 := by
      rw [← Real.exp_nat_mul]
      rw [hy_def]
      push_cast
      field_simp
    rw [h3] at h2
    have h4 : (1 + 1 / y) = (y + 1) / y := by field_simp
    rw [h4, div_pow] at h2
    rw [div_le_iff₀ (by positivity)] at h2
    linarith
  have hple : p ≤ y ^ d / (y + 1) ^ (d + 1) := by
    have h1 : p ≤ 1 / (Real.exp 1 * y) := by
      rw [le_div_iff₀ (by positivity)]
      nlinarith [hcond]
    have h2 : (1:ℝ) / (Real.exp 1 * y) ≤ y ^ d / (y + 1) ^ (d + 1) := by
      rw [div_le_div_iff₀ (by positivity) (by positivity)]
      have h3 : y ^ d * (Real.exp 1 * y) = Real.exp 1 * y ^ (d + 1) := by
        rw [pow_succ]; ring
      rw [one_mul, h3]
      exact hexp
    linarith
  have hxx : x * (1 - x) ^ d = y ^ d / (y + 1) ^ (d + 1) := by
    have hne : (y + 1) ≠ 0 := ne_of_gt hz
    have h1 : (1:ℝ) - x = y / (y + 1) := by
      rw [hx_def, eq_div_iff hne, sub_mul, one_mul, div_mul_cancel₀ _ hne]
      ring
    rw [h1, div_pow, hx_def, pow_succ]
    field_simp
  refine LLL_core hx0 hx1 hmeas hdeg ?_
  intro i
  rw [hxx]
  exact le_trans (hp i) hple

end LLL

end TuringTask
