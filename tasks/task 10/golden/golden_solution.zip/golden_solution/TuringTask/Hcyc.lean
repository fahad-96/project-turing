import Mathlib

/-!
# Homogeneous cyclotomic values

`hcyc n a b = b ^ φ(n) * Φₙ(a / b)` as an integer, the product formula
`∏_{d ∣ n} hcyc d a b = a ^ n - b ^ n`, real bounds from Mathlib's estimates for `Φₙ(x)`, and two
identities that come from `expand` (`Φ_{jq}(x) = Φ_j(x^q)` for `q ∣ j`, and
`Φ_{jq}(x) Φ_j(x) = Φ_j(x^q)` for `q ∤ j`).
-/

open Polynomial Finset

namespace TuringTask

/-! ### The homogeneous cyclotomic value -/

/-- `b ^ φ(n) * Φₙ(a / b)`, written with the integer coefficients of `Φₙ`. -/
noncomputable def hcyc (n a b : ℕ) : ℤ :=
  ∑ i ∈ range (n.totient + 1),
    (cyclotomic n ℤ).coeff i * (a : ℤ) ^ i * (b : ℤ) ^ (n.totient - i)

/-- In a field where `b ≠ 0`, `hcyc n a b = b ^ φ(n) * Φₙ(a / b)`. -/
theorem hcyc_cast {K : Type*} [Field K] (n a b : ℕ) (hb : (b : K) ≠ 0) :
    ((hcyc n a b : ℤ) : K) = (b : K) ^ n.totient * (cyclotomic n K).eval ((a : K) / b) := by
  have hdeg : (cyclotomic n K).natDegree < n.totient + 1 := by
    rw [natDegree_cyclotomic]
    exact Nat.lt_succ_self _
  have hcoeff : ∀ i, (cyclotomic n K).coeff i = (((cyclotomic n ℤ).coeff i : ℤ) : K) := by
    intro i
    rw [← map_cyclotomic_int n K, coeff_map, eq_intCast]
  rw [eval_eq_sum_range' hdeg, Finset.mul_sum, hcyc]
  push_cast
  refine Finset.sum_congr rfl (fun i hi => ?_)
  have hi' : i ≤ n.totient := Nat.lt_succ_iff.mp (Finset.mem_range.mp hi)
  have hsplit : (b : K) ^ n.totient = (b : K) ^ (n.totient - i) * (b : K) ^ i := by
    rw [← pow_add, Nat.sub_add_cancel hi']
  have hbi : (b : K) ^ i ≠ 0 := pow_ne_zero _ hb
  rw [hcoeff i, div_pow, hsplit]
  rw [show (b : K) ^ (n.totient - i) * (b : K) ^ i *
      ((((cyclotomic n ℤ).coeff i : ℤ) : K) * ((a : K) ^ i / (b : K) ^ i)) =
      ((((cyclotomic n ℤ).coeff i : ℤ) : K) * (a : K) ^ i * (b : K) ^ (n.totient - i)) *
        ((b : K) ^ i / (b : K) ^ i) by ring]
  rw [div_self hbi, mul_one]

/-- The product formula `∏_{d ∣ n} hcyc d a b = a ^ n - b ^ n`. -/
theorem prod_hcyc (n a b : ℕ) (hn : 0 < n) (hb : 0 < b) :
    ∏ d ∈ n.divisors, hcyc d a b = (a : ℤ) ^ n - (b : ℤ) ^ n := by
  have hbQ : (b : ℚ) ≠ 0 := by exact_mod_cast hb.ne'
  apply Int.cast_injective (α := ℚ)
  push_cast
  simp only [hcyc_cast (K := ℚ) _ a b hbQ]
  rw [Finset.prod_mul_distrib, Finset.prod_pow_eq_pow_sum, Nat.sum_totient, ← eval_prod,
    prod_cyclotomic_eq_X_pow_sub_one hn ℚ]
  simp only [eval_sub, eval_pow, eval_X, eval_one]
  rw [div_pow, mul_sub, mul_one, mul_div_cancel₀ _ (pow_ne_zero n hbQ)]

theorem hcyc_dvd (n a b : ℕ) (hn : 0 < n) (hb : 0 < b) :
    hcyc n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := by
  rw [← prod_hcyc n a b hn hb]
  exact Finset.dvd_prod_of_mem (fun d => hcyc d a b) (Nat.mem_divisors_self n hn.ne')

theorem hcyc_one (a b : ℕ) (hb : 0 < b) : hcyc 1 a b = (a : ℤ) - b := by
  have h := prod_hcyc 1 a b one_pos hb
  rw [Nat.divisors_one, Finset.prod_singleton, pow_one, pow_one] at h
  exact h

theorem hcyc_prime_mul (q a b : ℕ) (hq : q.Prime) (hb : 0 < b) :
    hcyc q a b * ((a : ℤ) - b) = (a : ℤ) ^ q - (b : ℤ) ^ q := by
  have h := prod_hcyc q a b hq.pos hb
  rw [hq.divisors, Finset.prod_pair hq.one_lt.ne, hcyc_one a b hb] at h
  rw [mul_comm]
  exact h

/-! ### Real values and bounds -/

theorem hcyc_real (n a b : ℕ) (hb : 0 < b) :
    ((hcyc n a b : ℤ) : ℝ) = (b : ℝ) ^ n.totient * (cyclotomic n ℝ).eval ((a : ℝ) / b) :=
  hcyc_cast n a b (by exact_mod_cast hb.ne')

theorem one_lt_div_real {a b : ℕ} (hb : 0 < b) (hab : b < a) : (1 : ℝ) < (a : ℝ) / b := by
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  rw [one_lt_div hbR]
  exact_mod_cast hab

theorem sub_pow_eq (a b : ℕ) (hb : 0 < b) (k : ℕ) :
    ((a : ℝ) - b) ^ k = (b : ℝ) ^ k * ((a : ℝ) / b - 1) ^ k := by
  have hbR : (b : ℝ) ≠ 0 := by exact_mod_cast hb.ne'
  rw [← mul_pow, mul_sub, mul_div_cancel₀ _ hbR, mul_one]

theorem add_pow_eq (a b : ℕ) (hb : 0 < b) (k : ℕ) :
    ((a : ℝ) + b) ^ k = (b : ℝ) ^ k * ((a : ℝ) / b + 1) ^ k := by
  have hbR : (b : ℝ) ≠ 0 := by exact_mod_cast hb.ne'
  rw [← mul_pow, mul_add, mul_div_cancel₀ _ hbR, mul_one]

theorem hcyc_ge (n a b : ℕ) (hb : 0 < b) (hab : b < a) :
    ((a : ℝ) - b) ^ n.totient ≤ ((hcyc n a b : ℤ) : ℝ) := by
  rw [hcyc_real n a b hb, sub_pow_eq a b hb]
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  exact mul_le_mul_of_nonneg_left
    (sub_one_pow_totient_le_cyclotomic_eval (one_lt_div_real hb hab) n) (pow_pos hbR _).le

theorem hcyc_gt (n a b : ℕ) (hn : 2 ≤ n) (hb : 0 < b) (hab : b < a) :
    ((a : ℝ) - b) ^ n.totient < ((hcyc n a b : ℤ) : ℝ) := by
  rw [hcyc_real n a b hb, sub_pow_eq a b hb]
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  exact mul_lt_mul_of_pos_left
    (sub_one_pow_totient_lt_cyclotomic_eval hn (one_lt_div_real hb hab)) (pow_pos hbR _)

theorem hcyc_le (n a b : ℕ) (hb : 0 < b) (hab : b < a) :
    ((hcyc n a b : ℤ) : ℝ) ≤ ((a : ℝ) + b) ^ n.totient := by
  rw [hcyc_real n a b hb, add_pow_eq a b hb]
  have hbR : (0 : ℝ) < b := by exact_mod_cast hb
  exact mul_le_mul_of_nonneg_left
    (cyclotomic_eval_le_add_one_pow_totient (one_lt_div_real hb hab) n) (pow_pos hbR _).le

theorem hcyc_pos (n a b : ℕ) (hb : 0 < b) (hab : b < a) : 0 < hcyc n a b := by
  have h := hcyc_ge n a b hb hab
  have hba : (b : ℝ) < a := by exact_mod_cast hab
  have h1 : (0 : ℝ) < ((a : ℝ) - b) ^ n.totient := pow_pos (by linarith) _
  exact_mod_cast h1.trans_le h

/-! ### Two identities from `expand` -/

theorem hcyc_mul_dvd (q j a b : ℕ) (hq : q.Prime) (hqj : q ∣ j) (hb : 0 < b) :
    hcyc (j * q) a b = hcyc j (a ^ q) (b ^ q) := by
  apply Int.cast_injective (α := ℝ)
  have hbq : 0 < b ^ q := pow_pos hb q
  rw [hcyc_real (j * q) a b hb, hcyc_real j (a ^ q) (b ^ q) hbq]
  rw [← cyclotomic_expand_eq_cyclotomic hq hqj ℝ, expand_eval]
  rw [mul_comm j q, Nat.totient_mul_of_prime_of_dvd hq hqj]
  push_cast
  rw [div_pow, pow_mul]

theorem hcyc_mul_not_dvd (q j a b : ℕ) (hq : q.Prime) (hqj : ¬ q ∣ j) (hb : 0 < b) :
    hcyc (j * q) a b * hcyc j a b = hcyc j (a ^ q) (b ^ q) := by
  apply Int.cast_injective (α := ℝ)
  have hbq : 0 < b ^ q := pow_pos hb q
  rw [Int.cast_mul, hcyc_real (j * q) a b hb, hcyc_real j a b hb,
    hcyc_real j (a ^ q) (b ^ q) hbq]
  have hE : (cyclotomic (j * q) ℝ).eval ((a : ℝ) / b) * (cyclotomic j ℝ).eval ((a : ℝ) / b) =
      (cyclotomic j ℝ).eval ((a : ℝ) ^ q / (b : ℝ) ^ q) := by
    rw [← eval_mul, ← cyclotomic_expand_eq_cyclotomic_mul hq hqj ℝ, expand_eval, div_pow]
  have hφ : (j * q).totient + j.totient = q * j.totient := by
    rw [mul_comm j q, Nat.totient_mul_of_prime_of_not_dvd hq hqj]
    have h1 : 1 ≤ q := hq.one_lt.le
    calc (q - 1) * j.totient + j.totient = (q - 1 + 1) * j.totient := by ring
      _ = q * j.totient := by rw [Nat.sub_add_cancel h1]
  push_cast
  calc (b : ℝ) ^ (j * q).totient * (cyclotomic (j * q) ℝ).eval ((a : ℝ) / b) *
        ((b : ℝ) ^ j.totient * (cyclotomic j ℝ).eval ((a : ℝ) / b))
      = (b : ℝ) ^ ((j * q).totient + j.totient) *
        ((cyclotomic (j * q) ℝ).eval ((a : ℝ) / b) * (cyclotomic j ℝ).eval ((a : ℝ) / b)) := by
        rw [pow_add]; ring
    _ = ((b : ℝ) ^ q) ^ j.totient * (cyclotomic j ℝ).eval ((a : ℝ) ^ q / (b : ℝ) ^ q) := by
        rw [hE, hφ, pow_mul]

theorem hcyc_pow_mul (q m : ℕ) (hq : q.Prime) :
    ∀ k a b : ℕ, 0 < b → hcyc (q ^ (k + 1) * m) a b = hcyc (q * m) (a ^ q ^ k) (b ^ q ^ k) := by
  intro k
  induction k with
  | zero => intro a b _; simp
  | succ k ih =>
    intro a b hb
    have hdvd : q ∣ q ^ (k + 1) * m := Dvd.dvd.mul_right (dvd_pow_self q (Nat.succ_ne_zero k)) m
    have heq : q ^ (k + 1 + 1) * m = (q ^ (k + 1) * m) * q := by ring
    rw [heq, hcyc_mul_dvd q _ a b hq hdvd hb, ih (a ^ q) (b ^ q) (pow_pos hb q),
      ← pow_mul, ← pow_mul, ← pow_succ']

end TuringTask
