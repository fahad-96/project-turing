# TuringTask: Formalization of Character Sums and Elliptic Curves in Lean 4

This project provides complete, machine-checked proofs of five theorems regarding character sums $S_p(c) = \sum_{x=0}^{p-1} \big(\frac{x^3 - cx}{p}\big)$, their squares, values modulo 8, binomial coefficients modulo $p$, and the number of points on the elliptic curve $y^2 = x^3 - x$ over $\mathbb{F}_p$.

## Theorems Proven in `TuringTask/Basic.lean`

1. `csum_sq_add_sq`: For $p \equiv 1 \pmod 4$, quadratic residue $c$ and quadratic non-residue $r$, $S_p(c)^2 + S_p(r)^2 = 4p$.
2. `csum_sq_of_sq`: For $p = a^2 + b^2$ with $a$ odd and quadratic residue $c$, $S_p(c)^2 = 4a^2$.
3. `csum_one_emod`: $S_p(1) \equiv 2 \pmod 8$ if $p \equiv 5 \pmod 8$, and $S_p(1) \equiv 6 \pmod 8$ if $p \equiv 1 \pmod 8$.
4. `choose_modEq`: For $p = a^2 + b^2$ with $a \equiv 1 \pmod 4$, $\binom{(p-1)/2}{(p-1)/4} \equiv 2a \pmod p$.
5. `card_curve`: For $p = a^2 + b^2$ with $a \equiv 1 \pmod 4$, the number of affine solutions to $y^2 = x^3 - x$ over $\mathbb{Z}/p\mathbb{Z}$ is $p - 2(-1)^{(p-1)/4}a$.

## Offline Build Instructions

Note: This project is configured with a local path dependency to Mathlib 4 (`/opt/mathlib4`) provided in the container environment. It does not perform any remote package downloads.

To build the project offline:
```bash
lean-offline-init
lake build
```
Or to compile `TuringTask/Basic.lean` directly:
```bash
lean TuringTask/Basic.lean
```
