import Mathlib

open scoped BigOperators

noncomputable section

def mur (n : Nat) : Real := ArithmeticFunction.moebius n

lemma mur_abs_le_one (n : Nat) : |mur n| ≤ 1 := by
  change |(ArithmeticFunction.moebius n : Real)| ≤ 1
  rw [← Int.cast_abs]
  exact_mod_cast ArithmeticFunction.abs_moebius_le_one (n := n)

lemma summable_mur_div_sq : Summable (fun n : Nat => mur n / (n : Real) ^ 2) := by
  apply Summable.of_norm_bounded
    ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2))
  intro n
  have hnabs : |(n : Real)| = (n : Real) := abs_of_nonneg (Nat.cast_nonneg n)
  calc
    ‖mur n / (n : Real) ^ 2‖ = |mur n| / (n : Real) ^ 2 := by
      rw [Real.norm_eq_abs, abs_div, abs_pow, hnabs]
    _ ≤ 1 / (n : Real) ^ 2 :=
      div_le_div_of_nonneg_right (mur_abs_le_one n) (sq_nonneg _)

lemma lseries_moebius_two :
    LSeries (fun n => (ArithmeticFunction.moebius n : Complex)) 2 =
      (6 / Real.pi ^ 2 : Real) := by
  have hprod := ArithmeticFunction.LSeries_zeta_mul_Lseries_moebius
    (s := (2 : Complex)) (by norm_num)
  have hz : LSeries (fun n => (ArithmeticFunction.zeta n : Complex)) 2 =
      (Real.pi ^ 2 / 6 : Real) := by
    rw [LSeries]
    have hc := Complex.ofRealCLM.hasSum hasSum_zeta_two
    have hc' : HasSum (LSeries.term (fun n =>
        (ArithmeticFunction.zeta n : Complex)) 2)
        ((Real.pi ^ 2 / 6 : Real) : Complex) := by
      apply Filter.Tendsto.congr (fun s => ?_) hc
      apply Finset.sum_congr rfl
      intro n _
      by_cases hn : n = 0
      · simp [hn, LSeries.term]
      · simp [hn, LSeries.term]
    exact hc'.tsum_eq
  rw [hz] at hprod
  apply (mul_left_cancel₀ (show ((Real.pi ^ 2 / 6 : Real) : Complex) ≠ 0 by
    exact_mod_cast div_ne_zero (pow_ne_zero 2 Real.pi_ne_zero)
      (by norm_num : (6 : Real) ≠ 0)))
  rw [hprod]
  push_cast
  field_simp

lemma hasSum_mur_div_sq :
    HasSum (fun n : Nat => mur n / (n : Real) ^ 2) (6 / Real.pi ^ 2) := by
  have htsum : (∑' n : Nat, mur n / (n : Real) ^ 2) = 6 / Real.pi ^ 2 := by
    apply Complex.ofReal_injective
    rw [Complex.ofReal_tsum]
    calc
      ∑' (n : Nat), ((mur n / (n : Real) ^ 2 : Real) : Complex) =
          LSeries (fun n => (ArithmeticFunction.moebius n : Complex)) 2 := by
            rw [LSeries]
            congr 1
            funext n
            by_cases hn : n = 0
            · simp [hn, mur, LSeries.term]
            · simp [hn, mur, LSeries.term]
      _ = ((6 / Real.pi ^ 2 : Real) : Complex) := lseries_moebius_two
  rw [← htsum]
  exact summable_mur_div_sq.hasSum

lemma sum_moebius_divisors_totient (k : Nat) (hk : k ≠ 0) :
    (∑ d ∈ k.divisors, ArithmeticFunction.moebius d) = if k = 1 then 1 else 0 := by
  have h := DFunLike.congr_fun ArithmeticFunction.moebius_mul_coe_zeta k
  rw [ArithmeticFunction.mul_apply] at h
  calc
    (∑ d ∈ k.divisors, ArithmeticFunction.moebius d) =
        ∑ d ∈ k.divisors,
          ArithmeticFunction.moebius d * (ArithmeticFunction.zeta (k / d) : Int) := by
            apply Finset.sum_congr rfl
            intro d hd
            have hdiv := (Nat.mem_divisors.mp hd).1
            have hpos := Nat.pos_of_dvd_of_pos hdiv (Nat.pos_of_ne_zero hk)
            have hdk : d ≤ k := Nat.le_of_dvd (Nat.pos_of_ne_zero hk) hdiv
            have hq : k / d ≠ 0 := Nat.ne_of_gt (Nat.div_pos hdk hpos)
            simp [ArithmeticFunction.zeta_apply, hq]
    _ = ∑ x ∈ k.divisorsAntidiagonal,
          ArithmeticFunction.moebius x.1 * (ArithmeticFunction.zeta x.2 : Int) := by
            symm
            exact Nat.sum_divisorsAntidiagonal
              (fun a b => ArithmeticFunction.moebius a * (ArithmeticFunction.zeta b : Int))
    _ = if k = 1 then 1 else 0 := by
      simpa [ArithmeticFunction.one_apply] using h

lemma tsum_one_div_nat_add_sq_le_totient (K : Nat) (hK : 1 ≤ K) :
    (∑' n : Nat, 1 / ((n + K + 1 : Nat) : Real) ^ 2) ≤ 1 / (K : Real) := by
  let g : Nat → Real := fun n =>
    1 / ((n + K : Nat) : Real) - 1 / ((n + K + 1 : Nat) : Real)
  have hs : Summable (fun n : Nat => 1 / ((n + K : Nat) : Real) ^ 2) := by
    simpa [Nat.cast_add] using
      (summable_nat_add_iff K).2
        ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2))
  have hg0 : ∀ n, 0 ≤ g n := by
    intro n
    dsimp [g]
    have ha : 0 < ((n + K : Nat) : Real) := by positivity
    have hb : 0 < ((n + K + 1 : Nat) : Real) := by positivity
    field_simp
    norm_num
  have hgle : ∀ n, g n ≤ 1 / ((n + K : Nat) : Real) ^ 2 := by
    intro n
    dsimp [g]
    have ha : 0 < ((n + K : Nat) : Real) := by positivity
    have hb : 0 < ((n + K + 1 : Nat) : Real) := by positivity
    have hab : ((n + K + 1 : Nat) : Real) = (n + K : Nat) + 1 := by
      push_cast
      ring
    field_simp
    nlinarith [hab]
  have hg : Summable g := Summable.of_nonneg_of_le hg0 hgle hs
  have hden : Filter.Tendsto (fun n : Nat => (K : Real) + n)
      Filter.atTop Filter.atTop :=
    Filter.tendsto_atTop_add_const_left Filter.atTop (K : Real)
      tendsto_natCast_atTop_atTop
  have hinv : Filter.Tendsto (fun n : Nat => ((K : Real) + n)⁻¹)
      Filter.atTop (nhds 0) := tendsto_inv_atTop_zero.comp hden
  have hgsum : HasSum g (1 / (K : Real)) := by
    apply hg.hasSum_iff_tendsto_nat.mpr
    have ht : Filter.Tendsto
        (fun n : Nat => 1 / (K : Real) - (((K : Real) + n)⁻¹))
        Filter.atTop (nhds (1 / (K : Real))) := by
      simpa using (tendsto_const_nhds.sub hinv)
    convert ht using 1
    funext m
    simpa [g, Nat.cast_add, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm] using
      (Finset.sum_range_sub' (fun i : Nat => 1 / (((i + K : Nat) : Real))) m)
  have hf : Summable (fun n : Nat =>
      1 / ((n + K + 1 : Nat) : Real) ^ 2) := by
    simpa [Nat.add_assoc, Nat.cast_add] using
      (summable_nat_add_iff (K + 1)).2
        ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2))
  have hfg : ∀ n : Nat,
      1 / ((n + K + 1 : Nat) : Real) ^ 2 ≤ g n := by
    intro n
    dsimp [g]
    have ha : 0 < ((n + K : Nat) : Real) := by positivity
    have hb : 0 < ((n + K + 1 : Nat) : Real) := by positivity
    have hab : ((n + K + 1 : Nat) : Real) = (n + K : Nat) + 1 := by
      push_cast
      ring
    field_simp
    nlinarith [hab]
  calc
    (∑' n : Nat, 1 / ((n + K + 1 : Nat) : Real) ^ 2) ≤ ∑' n, g n :=
      Summable.tsum_le_tsum hfg hf hg
    _ = 1 / (K : Real) := hgsum.tsum_eq

lemma abs_partial_mur_sub_le_totient (K : Nat) (hK : 1 ≤ K) :
    |(∑ d ∈ Finset.Icc 1 K, mur d / (d : Real) ^ 2) - 6 / Real.pi ^ 2| ≤
      1 / (K : Real) := by
  let f : Nat → Real := fun n => mur n / (n : Real) ^ 2
  have hnorm : Summable (fun n : Nat =>
      ‖f (n + K + 1)‖) := by
    apply Summable.of_nonneg_of_le (fun _ => norm_nonneg _) _
      ((summable_nat_add_iff (K + 1)).2
        ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2)))
    intro n
    have hn : 0 ≤ (((n + K + 1 : Nat) : Real) ^ 2) := sq_nonneg _
    have hnabs : |((n + K + 1 : Nat) : Real)| = (n + K + 1 : Nat) :=
      abs_of_nonneg (Nat.cast_nonneg _)
    change ‖mur (n + K + 1) / ((n + K + 1 : Nat) : Real) ^ 2‖ ≤ _
    rw [Real.norm_eq_abs, abs_div, abs_pow, hnabs]
    exact div_le_div_of_nonneg_right (mur_abs_le_one _) hn
  have htail : |∑' n : Nat, f (n + K + 1)| ≤ 1 / (K : Real) := by
    calc
      |∑' n : Nat, f (n + K + 1)| = ‖∑' n : Nat, f (n + K + 1)‖ :=
        (Real.norm_eq_abs _).symm
      _ ≤ ∑' n : Nat, ‖f (n + K + 1)‖ := norm_tsum_le_tsum_norm hnorm
      _ ≤ ∑' n : Nat, 1 / ((n + K + 1 : Nat) : Real) ^ 2 := by
        apply Summable.tsum_le_tsum _ hnorm
          ((summable_nat_add_iff (K + 1)).2
            ((Real.summable_one_div_nat_pow).2 (by norm_num : 1 < 2)))
        intro n
        have hn : 0 ≤ (((n + K + 1 : Nat) : Real) ^ 2) := sq_nonneg _
        have hnabs : |((n + K + 1 : Nat) : Real)| = (n + K + 1 : Nat) :=
          abs_of_nonneg (Nat.cast_nonneg _)
        change ‖mur (n + K + 1) / ((n + K + 1 : Nat) : Real) ^ 2‖ ≤ _
        rw [Real.norm_eq_abs, abs_div, abs_pow, hnabs]
        exact div_le_div_of_nonneg_right (mur_abs_le_one _) hn
      _ ≤ 1 / (K : Real) := tsum_one_div_nat_add_sq_le_totient K hK
  have hset : Finset.Icc 1 K = Finset.Ico 1 (K + 1) := by
    ext n
    simp only [Finset.mem_Icc, Finset.mem_Ico]
    omega
  have hfinite : (∑ n ∈ Finset.range (K + 1), f n) =
      ∑ n ∈ Finset.Icc 1 K, f n := by
    rw [hset, Finset.sum_Ico_eq_sub f (by omega)]
    simp [f, mur]
  have hsplit := summable_mur_div_sq.sum_add_tsum_nat_add (K + 1)
  have heq : (∑ d ∈ Finset.Icc 1 K, f d) +
      (∑' n : Nat, f (n + K + 1)) = 6 / Real.pi ^ 2 := by
    rw [← hfinite]
    calc
      (∑ n ∈ Finset.range (K + 1), f n) + ∑' n : Nat, f (n + K + 1) =
          ∑' n : Nat, f n := by
            simpa [f, Nat.add_assoc] using hsplit
      _ = 6 / Real.pi ^ 2 := hasSum_mur_div_sq.tsum_eq
  rw [show (∑ d ∈ Finset.Icc 1 K, mur d / (d : Real) ^ 2) -
      6 / Real.pi ^ 2 = -(∑' n : Nat, f (n + K + 1)) by
        change (∑ d ∈ Finset.Icc 1 K, f d) - 6 / Real.pi ^ 2 = _
        linarith]
  simpa using htail

lemma card_multiples_Icc_totient (N q : Nat) :
    ((Finset.Icc 1 N).filter (fun n => q ∣ n)).card = N / q := by
  have hinterval : Finset.Icc 1 N = Finset.Ioc 0 N := by
    ext n
    simp only [Finset.mem_Icc, Finset.mem_Ioc]
    omega
  rw [hinterval]
  exact Nat.Ioc_filter_dvd_card_eq_div N q

lemma sum_moebius_common_divisors (N a b : Nat)
    (ha : a ∈ Finset.Icc 1 N) (_hb : b ∈ Finset.Icc 1 N) :
    (∑ d ∈ Finset.Icc 1 N,
      if d ∣ a ∧ d ∣ b then ArithmeticFunction.moebius d else 0) =
        if Nat.Coprime a b then 1 else 0 := by
  let g := Nat.gcd a b
  have hg0 : g ≠ 0 := by
    have ha1 : 1 ≤ a := (Finset.mem_Icc.mp ha).1
    dsimp [g]
    intro h
    rw [Nat.gcd_eq_zero_iff] at h
    omega
  have hsets : (Finset.Icc 1 N).filter (fun d => d ∣ a ∧ d ∣ b) = g.divisors := by
    ext d
    simp only [Finset.mem_filter, Finset.mem_Icc, Nat.mem_divisors]
    constructor
    · rintro ⟨⟨hd1, _⟩, hda, hdb⟩
      exact ⟨Nat.dvd_gcd hda hdb, hg0⟩
    · rintro ⟨hdg, _⟩
      have hda : d ∣ a := dvd_trans hdg (Nat.gcd_dvd_left a b)
      have hdb : d ∣ b := dvd_trans hdg (Nat.gcd_dvd_right a b)
      have hdpos := Nat.pos_of_dvd_of_pos hdg (Nat.pos_of_ne_zero hg0)
      have hdN : d ≤ N :=
        (Nat.le_of_dvd (Finset.mem_Icc.mp ha).1 hda).trans (Finset.mem_Icc.mp ha).2
      exact ⟨⟨hdpos, hdN⟩, hda, hdb⟩
  rw [← Finset.sum_filter, hsets, sum_moebius_divisors_totient g hg0]

lemma sum_mur_common_divisors (N a b : Nat)
    (ha : a ∈ Finset.Icc 1 N) (hb : b ∈ Finset.Icc 1 N) :
    (∑ d ∈ Finset.Icc 1 N, if d ∣ a ∧ d ∣ b then mur d else 0) =
      if Nat.Coprime a b then 1 else 0 := by
  unfold mur
  exact_mod_cast sum_moebius_common_divisors N a b ha hb

lemma sum_common_multiples (N d : Nat) :
    (∑ a ∈ Finset.Icc 1 N, ∑ b ∈ Finset.Icc 1 N,
      if d ∣ a ∧ d ∣ b then mur d else 0) =
        mur d * ((N / d : Nat) : Real) ^ 2 := by
  calc
    (∑ a ∈ Finset.Icc 1 N, ∑ b ∈ Finset.Icc 1 N,
        if d ∣ a ∧ d ∣ b then mur d else 0) =
        ∑ a ∈ Finset.Icc 1 N,
          if d ∣ a then mur d * (N / d : Nat) else 0 := by
            apply Finset.sum_congr rfl
            intro a _
            by_cases hda : d ∣ a
            · simp only [hda, true_and, if_true]
              rw [← Finset.sum_filter]
              simp [card_multiples_Icc_totient, mul_comm]
            · simp [hda]
    _ = ∑ a ∈ (Finset.Icc 1 N).filter (fun a => d ∣ a),
          mur d * (N / d : Nat) := by rw [Finset.sum_filter]
    _ = mur d * ((N / d : Nat) : Real) ^ 2 := by
      rw [Finset.sum_const, card_multiples_Icc_totient]
      ring

lemma card_coprime_eq_mur_floor_sum (N : Nat) :
    (((Finset.product (Finset.Icc 1 N) (Finset.Icc 1 N)).filter
      (fun p : Prod Nat Nat => Nat.Coprime p.1 p.2)).card : Real) =
        ∑ d ∈ Finset.Icc 1 N, mur d * ((N / d : Nat) : Real) ^ 2 := by
  calc
    (((Finset.product (Finset.Icc 1 N) (Finset.Icc 1 N)).filter
        (fun p : Prod Nat Nat => Nat.Coprime p.1 p.2)).card : Real) =
        ∑ p ∈ Finset.product (Finset.Icc 1 N) (Finset.Icc 1 N),
          if Nat.Coprime p.1 p.2 then 1 else 0 := by simp
    _ = ∑ a ∈ Finset.Icc 1 N, ∑ b ∈ Finset.Icc 1 N,
          if Nat.Coprime a b then 1 else 0 := by
            simpa using (Finset.sum_product (Finset.Icc 1 N) (Finset.Icc 1 N)
              (fun p : Nat × Nat => if Nat.Coprime p.1 p.2 then (1 : Real) else 0))
    _ = ∑ a ∈ Finset.Icc 1 N, ∑ b ∈ Finset.Icc 1 N,
          ∑ d ∈ Finset.Icc 1 N, if d ∣ a ∧ d ∣ b then mur d else 0 := by
            apply Finset.sum_congr rfl
            intro a ha
            apply Finset.sum_congr rfl
            intro b hb
            symm
            exact sum_mur_common_divisors N a b ha hb
    _ = ∑ a ∈ Finset.Icc 1 N, ∑ d ∈ Finset.Icc 1 N,
          ∑ b ∈ Finset.Icc 1 N, if d ∣ a ∧ d ∣ b then mur d else 0 := by
            apply Finset.sum_congr rfl
            intro a _
            exact Finset.sum_comm
    _ = ∑ d ∈ Finset.Icc 1 N, ∑ a ∈ Finset.Icc 1 N,
          ∑ b ∈ Finset.Icc 1 N, if d ∣ a ∧ d ∣ b then mur d else 0 := by
            exact Finset.sum_comm
    _ = ∑ d ∈ Finset.Icc 1 N, mur d * ((N / d : Nat) : Real) ^ 2 := by
      apply Finset.sum_congr rfl
      intro d _
      exact sum_common_multiples N d

lemma abs_nat_div_cast_sub_le_one (N d : Nat) :
    |((N / d : Nat) : Real) - (N : Real) / (d : Real)| ≤ 1 := by
  have h := Nat.abs_floor_sub_le
    (a := (N : Real) / (d : Real)) (by positivity)
  rw [Nat.floor_div_natCast] at h
  simpa using h

lemma nat_div_cast_le_div (N d : Nat) (hd : 1 ≤ d) :
    ((N / d : Nat) : Real) ≤ (N : Real) / (d : Real) := by
  have hdr : (0 : Real) < d := by exact_mod_cast hd
  apply (le_div_iff₀ hdr).2
  exact_mod_cast Nat.div_mul_le_self N d

lemma abs_nat_div_sq_sub_le (N d : Nat) (hd : 1 ≤ d) :
    |((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2| ≤
      2 * ((N : Real) / (d : Real)) := by
  let q : Real := (N / d : Nat)
  let x : Real := (N : Real) / (d : Real)
  have hqx : q ≤ x := nat_div_cast_le_div N d hd
  have hq0 : 0 ≤ q := Nat.cast_nonneg _
  have hx0 : 0 ≤ x := by positivity
  have herr : |q - x| ≤ 1 := abs_nat_div_cast_sub_le_one N d
  calc
    |((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2| =
        |q - x| * |q + x| := by
          rw [← abs_mul]
          dsimp [q, x]
          congr 1
          ring
    _ = |q - x| * (q + x) := by rw [abs_of_nonneg (add_nonneg hq0 hx0)]
    _ ≤ 1 * (q + x) := mul_le_mul_of_nonneg_right herr (add_nonneg hq0 hx0)
    _ ≤ 2 * x := by nlinarith
    _ = 2 * ((N : Real) / (d : Real)) := rfl

lemma real_sum_Icc_one_div (N : Nat) :
    (∑ d ∈ Finset.Icc 1 N, 1 / (d : Real)) = (harmonic N : Real) := by
  have h := congrArg (fun q : Rat => (q : Real))
    (harmonic_eq_sum_Icc (n := N))
  push_cast at h
  simpa [one_div] using h.symm

lemma abs_coprime_floor_sum_sub_le (N : Nat) :
    |(∑ d ∈ Finset.Icc 1 N, mur d * ((N / d : Nat) : Real) ^ 2) -
        (N : Real) ^ 2 * ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2| ≤
      2 * N * (harmonic N : Real) := by
  have heq :
      (∑ d ∈ Finset.Icc 1 N, mur d * ((N / d : Nat) : Real) ^ 2) -
          (N : Real) ^ 2 * ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2 =
        ∑ d ∈ Finset.Icc 1 N, mur d *
          (((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro d _
    ring
  rw [heq]
  calc
    |∑ d ∈ Finset.Icc 1 N, mur d *
        (((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2)| ≤
        ∑ d ∈ Finset.Icc 1 N, |mur d *
          (((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 N, 2 * ((N : Real) / (d : Real)) := by
      apply Finset.sum_le_sum
      intro d hd
      rw [abs_mul]
      calc
        |mur d| * |((N / d : Nat) : Real) ^ 2 - ((N : Real) / (d : Real)) ^ 2| ≤
            1 * (2 * ((N : Real) / (d : Real))) :=
          mul_le_mul (mur_abs_le_one d)
            (abs_nat_div_sq_sub_le N d (Finset.mem_Icc.mp hd).1)
            (abs_nonneg _) zero_le_one
        _ = 2 * ((N : Real) / (d : Real)) := one_mul _
    _ = 2 * N * (harmonic N : Real) := by
      rw [← real_sum_Icc_one_div N]
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro d _
      ring

lemma totient_eq_card_coprime_Icc (n : Nat) (hn : 1 ≤ n) :
    Nat.totient n = ((Finset.Icc 1 n).filter (fun a => Nat.Coprime n a)).card := by
  by_cases hn1 : n = 1
  · subst n
    norm_num
  rw [Nat.totient_eq_card_coprime]
  congr 1
  ext a
  simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_Icc]
  constructor
  · rintro ⟨han, hcop⟩
    have ha1 : 1 ≤ a := by
      by_contra h
      have ha0 : a = 0 := by omega
      subst a
      have : n = 1 := by simpa using hcop
      exact hn1 this
    exact ⟨⟨ha1, by omega⟩, hcop⟩
  · rintro ⟨⟨ha1, han⟩, hcop⟩
    have halt : a < n := by
      by_contra h
      have haeq : a = n := by omega
      subst a
      have : n = 1 := by simpa using hcop
      exact hn1 this
    exact ⟨halt, hcop⟩

lemma totient_eq_moebius_sum (n : Nat) (hn : 1 ≤ n) :
    (Nat.totient n : Int) = ∑ d ∈ Finset.Icc 1 n,
      if d ∣ n then ArithmeticFunction.moebius d * (n / d : Nat) else 0 := by
  calc
    (Nat.totient n : Int) = ∑ a ∈ Finset.Icc 1 n,
        if Nat.Coprime n a then 1 else 0 := by
          rw [totient_eq_card_coprime_Icc n hn]
          simp
    _ = ∑ a ∈ Finset.Icc 1 n, ∑ d ∈ Finset.Icc 1 n,
          if d ∣ n ∧ d ∣ a then ArithmeticFunction.moebius d else 0 := by
            apply Finset.sum_congr rfl
            intro a ha
            symm
            exact sum_moebius_common_divisors n n a (by simp [hn]) ha
    _ = ∑ d ∈ Finset.Icc 1 n, ∑ a ∈ Finset.Icc 1 n,
          if d ∣ n ∧ d ∣ a then ArithmeticFunction.moebius d else 0 :=
      Finset.sum_comm
    _ = ∑ d ∈ Finset.Icc 1 n,
          if d ∣ n then ArithmeticFunction.moebius d * (n / d : Nat) else 0 := by
      apply Finset.sum_congr rfl
      intro d _
      by_cases hdn : d ∣ n
      · simp only [hdn, true_and, if_true]
        rw [← Finset.sum_filter]
        simp [card_multiples_Icc_totient, mul_comm]
      · simp [hdn]

lemma totient_div_eq_mur_sum (n : Nat) (hn : 1 ≤ n) :
    (Nat.totient n : Real) / n = ∑ d ∈ Finset.Icc 1 n,
      if d ∣ n then mur d / (d : Real) else 0 := by
  have hphi : (Nat.totient n : Real) = ∑ d ∈ Finset.Icc 1 n,
      if d ∣ n then mur d * ((n / d : Nat) : Real) else 0 := by
    have h := congrArg (fun z : Int => (z : Real)) (totient_eq_moebius_sum n hn)
    simp only [Int.cast_natCast, Int.cast_sum, Int.cast_ite, Int.cast_zero,
      Int.cast_mul] at h
    simpa [mur] using h
  rw [hphi, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hdn : d ∣ n
  · simp only [hdn, if_true]
    have hd0 : d ≠ 0 := by
      have hd1 := (Finset.mem_Icc.mp hd).1
      omega
    have hn0 : n ≠ 0 := by omega
    have hdr : (d : Real) ≠ 0 := by exact_mod_cast hd0
    have hnr : (n : Real) ≠ 0 := by exact_mod_cast hn0
    rw [Nat.cast_div hdn hdr]
    field_simp
  · simp [hdn]

lemma totient_div_eq_mur_sum_to (N n : Nat) (hn : n ∈ Finset.Icc 1 N) :
    (Nat.totient n : Real) / n = ∑ d ∈ Finset.Icc 1 N,
      if d ∣ n then mur d / (d : Real) else 0 := by
  rw [totient_div_eq_mur_sum n (Finset.mem_Icc.mp hn).1]
  apply Finset.sum_subset (by
    intro d hd
    simp only [Finset.mem_Icc] at hd ⊢
    exact ⟨hd.1, hd.2.trans (Finset.mem_Icc.mp hn).2⟩)
  intro d hdN hdn
  have hdlarge : n < d := by
    simp only [Finset.mem_Icc, not_and_or, not_le] at hdn
    have hd1 := (Finset.mem_Icc.mp hdN).1
    omega
  have hnotdvd : ¬d ∣ n := by
    intro hdvd
    have hdle := Nat.le_of_dvd (Finset.mem_Icc.mp hn).1 hdvd
    omega
  simp [hnotdvd]

lemma sum_totient_div_eq_mur_floor_sum (N : Nat) :
    (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real) / n) =
      ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) * (N / d : Nat) := by
  calc
    (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real) / n) =
        ∑ n ∈ Finset.Icc 1 N, ∑ d ∈ Finset.Icc 1 N,
          if d ∣ n then mur d / (d : Real) else 0 := by
            apply Finset.sum_congr rfl
            intro n hn
            exact totient_div_eq_mur_sum_to N n hn
    _ = ∑ d ∈ Finset.Icc 1 N, ∑ n ∈ Finset.Icc 1 N,
          if d ∣ n then mur d / (d : Real) else 0 := Finset.sum_comm
    _ = ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) * (N / d : Nat) := by
      apply Finset.sum_congr rfl
      intro d _
      rw [← Finset.sum_filter]
      simp [card_multiples_Icc_totient, mul_comm]

lemma abs_totient_div_floor_sum_sub_le (N : Nat) :
    |(∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) * (N / d : Nat)) -
        (N : Real) * ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2| ≤
      (harmonic N : Real) := by
  have heq :
      (∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) * (N / d : Nat)) -
          (N : Real) * ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2 =
        ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) *
          (((N / d : Nat) : Real) - (N : Real) / (d : Real)) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro d _
    ring
  rw [heq]
  calc
    |∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) *
        (((N / d : Nat) : Real) - (N : Real) / (d : Real))| ≤
        ∑ d ∈ Finset.Icc 1 N, |mur d / (d : Real) *
          (((N / d : Nat) : Real) - (N : Real) / (d : Real))| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 N, 1 / (d : Real) := by
      apply Finset.sum_le_sum
      intro d hd
      have hdr : (0 : Real) ≤ d := Nat.cast_nonneg d
      rw [abs_mul, abs_div, abs_of_nonneg hdr]
      calc
        |mur d| / (d : Real) *
            |((N / d : Nat) : Real) - (N : Real) / (d : Real)| ≤
            1 / (d : Real) * 1 :=
          mul_le_mul
            (div_le_div_of_nonneg_right (mur_abs_le_one d) hdr)
            (abs_nat_div_cast_sub_le_one N d) (abs_nonneg _) (by positivity)
        _ = 1 / (d : Real) := mul_one _
    _ = (harmonic N : Real) := real_sum_Icc_one_div N

lemma image_div_multiples_Icc (N d : Nat) (hd : 1 ≤ d) :
    ((Finset.Icc 1 N).filter (fun n => d ∣ n)).image (fun n => n / d) =
      Finset.Icc 1 (N / d) := by
  ext k
  simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_Icc]
  constructor
  · rintro ⟨n, ⟨⟨hn1, hnN⟩, hdn⟩, rfl⟩
    have hdnle : d ≤ n := Nat.le_of_dvd hn1 hdn
    exact ⟨Nat.div_pos hdnle (by omega), Nat.div_le_div_right hnN⟩
  · rintro ⟨hk1, hkN⟩
    refine ⟨k * d, ?_, ?_⟩
    · refine ⟨⟨Nat.mul_pos (by omega) (by omega), ?_⟩, dvd_mul_left d k⟩
      exact (Nat.mul_le_mul_right d hkN).trans (Nat.div_mul_le_self N d)
    · exact Nat.mul_div_cancel k (by omega)

lemma sum_quotients_multiples_Icc (N d : Nat) (hd : 1 ≤ d) :
    (∑ n ∈ Finset.Icc 1 N, if d ∣ n then ((n / d : Nat) : Real) else 0) =
      ∑ k ∈ Finset.Icc 1 (N / d), (k : Real) := by
  rw [← Finset.sum_filter]
  rw [← image_div_multiples_Icc N d hd]
  symm
  apply Finset.sum_image
  intro a ha b hb hab
  have hda : d ∣ a := (Finset.mem_filter.mp ha).2
  have hdb : d ∣ b := (Finset.mem_filter.mp hb).2
  change a / d = b / d at hab
  calc
    a = a / d * d := (Nat.div_mul_cancel hda).symm
    _ = b / d * d := by rw [hab]
    _ = b := Nat.div_mul_cancel hdb

lemma sum_Icc_natCast (q : Nat) :
    (∑ k ∈ Finset.Icc 1 q, (k : Real)) = (q : Real) * (q + 1) / 2 := by
  induction q with
  | zero => simp
  | succ q ih =>
      rw [Finset.sum_Icc_succ_top (by omega : 1 ≤ q + 1)]
      rw [ih]
      push_cast
      ring

lemma sum_totient_eq_mur_triangle_sum (N : Nat) :
    (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real)) =
      ∑ d ∈ Finset.Icc 1 N, mur d *
        (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2) := by
  calc
    (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real)) =
        ∑ n ∈ Finset.Icc 1 N, ∑ d ∈ Finset.Icc 1 N,
          if d ∣ n then mur d * ((n / d : Nat) : Real) else 0 := by
            apply Finset.sum_congr rfl
            intro n hn
            have hphi : (Nat.totient n : Real) = ∑ d ∈ Finset.Icc 1 n,
                if d ∣ n then mur d * ((n / d : Nat) : Real) else 0 := by
              have h := congrArg (fun z : Int => (z : Real))
                (totient_eq_moebius_sum n (Finset.mem_Icc.mp hn).1)
              simp only [Int.cast_natCast, Int.cast_sum, Int.cast_ite, Int.cast_zero,
                Int.cast_mul] at h
              simpa [mur] using h
            rw [hphi]
            apply Finset.sum_subset (by
              intro d hd
              simp only [Finset.mem_Icc] at hd ⊢
              exact ⟨hd.1, hd.2.trans (Finset.mem_Icc.mp hn).2⟩)
            intro d hdN hdnot
            have hdlarge : n < d := by
              simp only [Finset.mem_Icc, not_and_or, not_le] at hdnot
              have hd1 := (Finset.mem_Icc.mp hdN).1
              omega
            have hnotdvd : ¬d ∣ n := by
              intro hdvd
              have := Nat.le_of_dvd (Finset.mem_Icc.mp hn).1 hdvd
              omega
            simp [hnotdvd]
    _ = ∑ d ∈ Finset.Icc 1 N, ∑ n ∈ Finset.Icc 1 N,
          if d ∣ n then mur d * ((n / d : Nat) : Real) else 0 := Finset.sum_comm
    _ = ∑ d ∈ Finset.Icc 1 N, mur d *
          (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2) := by
      apply Finset.sum_congr rfl
      intro d hd
      have hq := sum_quotients_multiples_Icc N d (Finset.mem_Icc.mp hd).1
      calc
        (∑ n ∈ Finset.Icc 1 N,
            if d ∣ n then mur d * ((n / d : Nat) : Real) else 0) =
            mur d * ∑ n ∈ Finset.Icc 1 N,
              if d ∣ n then ((n / d : Nat) : Real) else 0 := by
                rw [Finset.mul_sum]
                apply Finset.sum_congr rfl
                intro n _
                by_cases hdn : d ∣ n <;> simp [hdn]
        _ = mur d * (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2) := by
          rw [hq, sum_Icc_natCast]

lemma abs_triangle_floor_sub_le (N d : Nat) (hd : 1 ≤ d) :
    |((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
        ((N : Real) / (d : Real)) ^ 2 / 2| ≤
      (3 / 2 : Real) * ((N : Real) / (d : Real)) := by
  let q : Real := (N / d : Nat)
  let x : Real := (N : Real) / (d : Real)
  have hq0 : 0 ≤ q := Nat.cast_nonneg _
  have hx0 : 0 ≤ x := by positivity
  have hqx : q ≤ x := nat_div_cast_le_div N d hd
  have hsq : |q ^ 2 - x ^ 2| ≤ 2 * x := by
    simpa [q, x] using abs_nat_div_sq_sub_le N d hd
  calc
    |((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
        ((N : Real) / (d : Real)) ^ 2 / 2| =
        |(q ^ 2 - x ^ 2) + q| / 2 := by
          rw [show ((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
              ((N : Real) / (d : Real)) ^ 2 / 2 =
              ((q ^ 2 - x ^ 2) + q) / 2 by
                dsimp [q, x]
                ring]
          rw [abs_div]
          norm_num
    _ ≤ (|q ^ 2 - x ^ 2| + |q|) / 2 := by
      gcongr
      exact abs_add_le _ _
    _ = (|q ^ 2 - x ^ 2| + q) / 2 := by rw [abs_of_nonneg hq0]
    _ ≤ (3 / 2 : Real) * x := by nlinarith
    _ = (3 / 2 : Real) * ((N : Real) / (d : Real)) := rfl

lemma abs_totient_triangle_sum_sub_le (N : Nat) :
    |(∑ d ∈ Finset.Icc 1 N, mur d *
          (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2)) -
        ((N : Real) ^ 2 / 2) *
          ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2| ≤
      (3 / 2 : Real) * N * (harmonic N : Real) := by
  have heq :
      (∑ d ∈ Finset.Icc 1 N, mur d *
          (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2)) -
          ((N : Real) ^ 2 / 2) *
            ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2 =
        ∑ d ∈ Finset.Icc 1 N, mur d *
          (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
            ((N : Real) / (d : Real)) ^ 2 / 2) := by
    rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro d _
    ring
  rw [heq]
  calc
    |∑ d ∈ Finset.Icc 1 N, mur d *
        (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
          ((N : Real) / (d : Real)) ^ 2 / 2)| ≤
        ∑ d ∈ Finset.Icc 1 N, |mur d *
          (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
            ((N : Real) / (d : Real)) ^ 2 / 2)| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ d ∈ Finset.Icc 1 N,
          (3 / 2 : Real) * ((N : Real) / (d : Real)) := by
      apply Finset.sum_le_sum
      intro d hd
      rw [abs_mul]
      calc
        |mur d| * |((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2 -
            ((N : Real) / (d : Real)) ^ 2 / 2| ≤
            1 * ((3 / 2 : Real) * ((N : Real) / (d : Real))) :=
          mul_le_mul (mur_abs_le_one d)
            (abs_triangle_floor_sub_le N d (Finset.mem_Icc.mp hd).1)
            (abs_nonneg _) zero_le_one
        _ = (3 / 2 : Real) * ((N : Real) / (d : Real)) := one_mul _
    _ = (3 / 2 : Real) * N * (harmonic N : Real) := by
      rw [← real_sum_Icc_one_div N, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro d _
      ring

namespace TuringTask

theorem sum_totient_div_sub_le (N : Nat) (hN : 1 <= N) :
    abs ((Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real) / n) - 6 / Real.pi ^ 2 * N) <=
      Real.log N + 2 := by
  let A : Real := ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) * (N / d : Nat)
  let S : Real := ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2
  let C : Real := 6 / Real.pi ^ 2
  have hfloor : |A - (N : Real) * S| ≤ (harmonic N : Real) := by
    simpa [A, S] using abs_totient_div_floor_sum_sub_le N
  have hpartial : |S - C| ≤ 1 / (N : Real) := by
    simpa [S, C] using abs_partial_mur_sub_le_totient N hN
  have hmain : |(N : Real) * S - C * N| ≤ 1 := by
    rw [show (N : Real) * S - C * N = (N : Real) * (S - C) by ring]
    rw [abs_mul, abs_of_nonneg (Nat.cast_nonneg N)]
    calc
      (N : Real) * |S - C| ≤ (N : Real) * (1 / (N : Real)) :=
        mul_le_mul_of_nonneg_left hpartial (Nat.cast_nonneg N)
      _ = 1 := by
        have hNr : (N : Real) ≠ 0 := by exact_mod_cast (by omega : N ≠ 0)
        field_simp
  have hsum :
      (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real) / n) = A := by
    simpa [A] using sum_totient_div_eq_mur_floor_sum N
  have hharm : (harmonic N : Real) ≤ Real.log N + 1 := by
    simpa [add_comm] using harmonic_le_one_add_log N
  rw [hsum]
  change |A - C * (N : Real)| ≤ _
  calc
    |A - C * (N : Real)| = |(A - (N : Real) * S) + ((N : Real) * S - C * N)| := by
      ring_nf
    _ ≤ |A - (N : Real) * S| + |(N : Real) * S - C * N| := abs_add_le _ _
    _ ≤ (harmonic N : Real) + 1 := add_le_add hfloor hmain
    _ ≤ Real.log N + 2 := by linarith

theorem sum_totient_sub_le (N : Nat) (hN : 1 <= N) :
    abs ((Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real)) - 3 / Real.pi ^ 2 * N ^ 2) <=
      4 * N * (Real.log N + 1) := by
  let A : Real := ∑ d ∈ Finset.Icc 1 N, mur d *
    (((N / d : Nat) : Real) * ((N / d : Nat) + 1) / 2)
  let S : Real := ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2
  let C : Real := 6 / Real.pi ^ 2
  have hfloor : |A - ((N : Real) ^ 2 / 2) * S| ≤
      (3 / 2 : Real) * N * (harmonic N : Real) := by
    simpa [A, S] using abs_totient_triangle_sum_sub_le N
  have hpartial : |S - C| ≤ 1 / (N : Real) := by
    simpa [S, C] using abs_partial_mur_sub_le_totient N hN
  have hmain : |((N : Real) ^ 2 / 2) * S - (C / 2) * N ^ 2| ≤ (N : Real) / 2 := by
    rw [show ((N : Real) ^ 2 / 2) * S - (C / 2) * N ^ 2 =
        ((N : Real) ^ 2 / 2) * (S - C) by ring]
    rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ (N : Real) ^ 2 / 2)]
    calc
      ((N : Real) ^ 2 / 2) * |S - C| ≤
          ((N : Real) ^ 2 / 2) * (1 / (N : Real)) :=
        mul_le_mul_of_nonneg_left hpartial (by positivity)
      _ = (N : Real) / 2 := by
        have hNr : (N : Real) ≠ 0 := by exact_mod_cast (by omega : N ≠ 0)
        field_simp
  have hsum :
      (Finset.Icc 1 N).sum (fun n => (Nat.totient n : Real)) = A := by
    simpa [A] using sum_totient_eq_mur_triangle_sum N
  have hcoef : (3 / Real.pi ^ 2 : Real) = C / 2 := by
    dsimp [C]
    ring
  have hlog : 0 ≤ Real.log (N : Real) := Real.log_nonneg (by exact_mod_cast hN)
  have hharm : (harmonic N : Real) ≤ Real.log N + 1 := by
    simpa [add_comm] using harmonic_le_one_add_log N
  rw [hsum, hcoef]
  change |A - (C / 2) * (N : Real) ^ 2| ≤ _
  calc
    |A - (C / 2) * (N : Real) ^ 2| =
        |(A - ((N : Real) ^ 2 / 2) * S) +
          (((N : Real) ^ 2 / 2) * S - (C / 2) * N ^ 2)| := by ring_nf
    _ ≤ |A - ((N : Real) ^ 2 / 2) * S| +
        |((N : Real) ^ 2 / 2) * S - (C / 2) * N ^ 2| := abs_add_le _ _
    _ ≤ (3 / 2 : Real) * N * (harmonic N : Real) + N / 2 :=
      add_le_add hfloor hmain
    _ ≤ (3 / 2 : Real) * N * (Real.log N + 1) + N / 2 := by
      gcongr
    _ ≤ 4 * N * (Real.log N + 1) := by
      have hNr : (0 : Real) ≤ N := Nat.cast_nonneg N
      nlinarith

theorem card_coprime_sub_le (N : Nat) (hN : 1 <= N) :
    abs ((((Finset.product (Finset.Icc 1 N) (Finset.Icc 1 N)).filter
        (fun p : Prod Nat Nat => Nat.Coprime p.1 p.2)).card : Real) - 6 / Real.pi ^ 2 * N ^ 2) <=
      6 * N * (Real.log N + 1) := by
  let A : Real := ∑ d ∈ Finset.Icc 1 N, mur d * ((N / d : Nat) : Real) ^ 2
  let S : Real := ∑ d ∈ Finset.Icc 1 N, mur d / (d : Real) ^ 2
  let C : Real := 6 / Real.pi ^ 2
  have hfloor : |A - (N : Real) ^ 2 * S| ≤ 2 * N * (harmonic N : Real) := by
    simpa [A, S] using abs_coprime_floor_sum_sub_le N
  have hpartial : |S - C| ≤ 1 / (N : Real) := by
    simpa [S, C] using abs_partial_mur_sub_le_totient N hN
  have hmain : |(N : Real) ^ 2 * S - C * N ^ 2| ≤ (N : Real) := by
    rw [show (N : Real) ^ 2 * S - C * N ^ 2 = (N : Real) ^ 2 * (S - C) by ring]
    rw [abs_mul, abs_of_nonneg (sq_nonneg (N : Real))]
    calc
      (N : Real) ^ 2 * |S - C| ≤ (N : Real) ^ 2 * (1 / (N : Real)) :=
        mul_le_mul_of_nonneg_left hpartial (sq_nonneg _)
      _ = (N : Real) := by
        have hNr : (N : Real) ≠ 0 := by exact_mod_cast (by omega : N ≠ 0)
        field_simp
  have hcount :
      (((Finset.product (Finset.Icc 1 N) (Finset.Icc 1 N)).filter
        (fun p : Prod Nat Nat => Nat.Coprime p.1 p.2)).card : Real) = A := by
    simpa [A] using card_coprime_eq_mur_floor_sum N
  have hlog : 0 ≤ Real.log (N : Real) := Real.log_nonneg (by exact_mod_cast hN)
  have hharm : (harmonic N : Real) ≤ Real.log N + 1 := by
    simpa [add_comm] using harmonic_le_one_add_log N
  rw [hcount]
  change |A - C * (N : Real) ^ 2| ≤ _
  calc
    |A - C * (N : Real) ^ 2| =
        |(A - (N : Real) ^ 2 * S) + ((N : Real) ^ 2 * S - C * N ^ 2)| := by ring_nf
    _ ≤ |A - (N : Real) ^ 2 * S| + |(N : Real) ^ 2 * S - C * N ^ 2| :=
      abs_add_le _ _
    _ ≤ 2 * N * (harmonic N : Real) + N := add_le_add hfloor hmain
    _ ≤ 2 * N * (Real.log N + 1) + N := by
      gcongr
    _ ≤ 6 * N * (Real.log N + 1) := by
      have hNr : (0 : Real) ≤ N := Nat.cast_nonneg N
      nlinarith

end TuringTask
