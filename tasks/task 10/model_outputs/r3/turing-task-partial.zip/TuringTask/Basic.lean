import Mathlib

namespace TuringTask

/-!
This file contains the checked reduction from the missing Bang--Zsigmondy
existence theorem to the primitive-divisor conclusion requested by the task.
Mathlib at the pinned revision does not contain that existence theorem.
-/

theorem primitive_prime_of_exact_order
    (q : Nat) [Fact q.Prime] (a b n : Nat) (hba : b < a) (hqb : Not (q ∣ b))
    (horder : orderOf ((a : ZMod q) / (b : ZMod q)) = n) :
    (a ^ n - b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k - b ^ k) % q = 0) := by
  have hb0 : (b : ZMod q) ≠ 0 := by
    intro hb
    exact hqb ((ZMod.natCast_eq_zero_iff b q).mp hb)
  have cast_eq_of_pow_eq_one : forall {k : Nat},
      ((a : ZMod q) / (b : ZMod q)) ^ k = 1 ->
        ((a ^ k : Nat) : ZMod q) = ((b ^ k : Nat) : ZMod q) := by
    intro k hk
    simpa only [Nat.cast_pow] using
      (show (a : ZMod q) ^ k = (b : ZMod q) ^ k from calc
        (a : ZMod q) ^ k =
            (((a : ZMod q) / (b : ZMod q)) ^ k) * (b : ZMod q) ^ k := by
              rw [div_pow, div_mul_cancel₀ _ (pow_ne_zero k hb0)]
        _ = (b : ZMod q) ^ k := by rw [hk, one_mul])
  have pow_le (k : Nat) : b ^ k <= a ^ k :=
    Nat.pow_le_pow_left (Nat.le_of_lt hba) k
  constructor
  · have hpow : ((a : ZMod q) / (b : ZMod q)) ^ n = 1 := by
      rw [← horder]
      exact pow_orderOf_eq_one _
    have hcast : ((a ^ n - b ^ n : Nat) : ZMod q) = 0 := by
      rw [Nat.cast_sub (pow_le n)]
      exact sub_eq_zero.mpr (cast_eq_of_pow_eq_one hpow)
    exact Nat.dvd_iff_mod_eq_zero.mp
      ((ZMod.natCast_eq_zero_iff (a ^ n - b ^ n) q).mp hcast)
  · intro k hk1 hkn hmod
    have hcast : ((a ^ k - b ^ k : Nat) : ZMod q) = 0 :=
      (ZMod.natCast_eq_zero_iff (a ^ k - b ^ k) q).mpr
        (Nat.dvd_iff_mod_eq_zero.mpr hmod)
    have habpow : ((a ^ k : Nat) : ZMod q) = ((b ^ k : Nat) : ZMod q) := by
      rw [Nat.cast_sub (pow_le k)] at hcast
      exact sub_eq_zero.mp hcast
    have hpow : ((a : ZMod q) / (b : ZMod q)) ^ k = 1 := by
      rw [div_pow, div_eq_one_iff_eq (pow_ne_zero k hb0)]
      exact_mod_cast habpow
    have hminimal := (orderOf_eq_iff (by omega : 0 < n)).mp horder
    exact hminimal.2 k hkn (by omega) hpow

theorem primitive_prime_of_cyclotomic_root
    (q : Nat) [Fact q.Prime] (a b n : Nat) (hba : b < a) (hqb : Not (q ∣ b))
    (hqn : Not (q ∣ n))
    (hroot : (Polynomial.cyclotomic n (ZMod q)).IsRoot
      ((a : ZMod q) / (b : ZMod q))) :
    q.Prime /\ (a ^ n - b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k - b ^ k) % q = 0) := by
  letI : NeZero (n : ZMod q) :=
    ⟨by
      intro hn
      exact hqn ((ZMod.natCast_eq_zero_iff n q).mp hn)⟩
  have horder : orderOf ((a : ZMod q) / (b : ZMod q)) = n :=
    (Polynomial.isRoot_cyclotomic_iff.mp hroot).eq_orderOf.symm
  exact ⟨Fact.out, primitive_prime_of_exact_order q a b n hba hqb horder⟩

end TuringTask
