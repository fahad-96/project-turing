# TuringTask

Lean 4 proofs of five classical density estimates:

1. `card_squarefree_sub_le` — `|Q(N) - (6/π²)N| ≤ 3√N`, where `Q(N)` counts squarefree integers in `[1,N]`.
2. `card_coprime_sub_le` — `|C(N) - (6/π²)N²| ≤ 6N(log N + 1)`, where `C(N)` counts coprime pairs in `[1,N]²`.
3. `sum_totient_sub_le` — `|Σ_{n≤N} φ(n) - (3/π²)N²| ≤ 4N(log N + 1)`.
4. `sum_totient_div_sub_le` — `|Σ_{n≤N} φ(n)/n - (6/π²)N| ≤ log N + 2`.
5. `tendsto_card_squarefree_div` — `Q(N)/N → 6/π²`.

All five live in `TuringTask/Basic.lean`, in namespace `TuringTask`.

## Environment requirement

This project is **not** self-contained. It requires the pinned, pre-built offline
Lean/Mathlib environment supplied by the task image:

- Lean toolchain `leanprover/lean4:v4.33.0-rc1`
- Mathlib at commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`, installed at `/opt/mathlib4`

`lakefile.toml` declares Mathlib as a **local path dependency** (`path = "/opt/mathlib4"`).
There is no remote Git requirement, so no network access is needed or attempted.
On a machine without `/opt/mathlib4` this project will not build as-is.

## Offline build

From the project root:

```sh
lean-offline-init   # seeds .lake/packages with links to the installed deps (local FS only)
lake build
```

`lake build` must finish with no errors. Do not run `lake update` or any cache-download
command; they are unnecessary here and would require network access.

A single-file check of the main file also works and avoids Lake entirely:

```sh
lean TuringTask/Basic.lean
```

## Axiom check

Each of the five theorems depends only on `propext`, `Classical.choice`, `Quot.sound`.
To reproduce, append to a copy of the file:

```lean
#print axioms TuringTask.card_squarefree_sub_le
#print axioms TuringTask.card_coprime_sub_le
#print axioms TuringTask.sum_totient_sub_le
#print axioms TuringTask.sum_totient_div_sub_le
#print axioms TuringTask.tendsto_card_squarefree_div
```

## Proof outline

The common engine is Möbius inversion plus one analytic input.

- **Analytic input.** `hasSum_moebius_div_sq` : `Σ_d μ(d)/d² = 6/π²`. This is obtained
  from Mathlib's `LSeries_zeta_mul_Lseries_moebius` (i.e. `ζ(s)·Σμ(n)n^{-s} = 1`) together
  with `riemannZeta_two` (`ζ(2) = π²/6`), transported from `ℂ` to `ℝ`.
- **Tail bound.** `moeb_tail_le` : truncating that series at `D` costs at most `1/D`,
  via `Σ_{d>D} 1/d² ≤ 1/D` (`sum_Ioc_inv_sq_le_sub`).
- **Square part.** `sqrtPart n` is the largest `m` with `m² ∣ n`, defined through the
  factorization. Key facts: `d² ∣ n ↔ d ∣ sqrtPart n` and `sqrtPart n = 1 ↔ Squarefree n`.
  Combined with `μ * ζ = 1` this gives the exact indicator
  `Σ_{d² ∣ n} μ(d) = [n squarefree]` (`sum_moebius_sq_dvd`).
- **Counting.** Swapping the order of summation turns each count into a truncated Möbius
  sum: `Q(N) = Σ_d μ(d)⌊N/d²⌋`, `C(N) = Σ_d μ(d)⌊N/d⌋²`, `Σφ(n) = Σ_d μ(d)·T(⌊N/d⌋)`,
  `Σφ(n)/n = Σ_d (μ(d)/d)⌊N/d⌋`. The lattice-point counts use
  `Nat.Ioc_filter_dvd_card_eq_div`.
- **Error splitting.** Each result is then `(floor-vs-exact error) + (series tail error)`.
  Floor errors are summed against the harmonic bound `Σ_{d≤N} 1/d ≤ log N + 1`
  (Mathlib's `harmonic_le_one_add_log`); for Theorem 1 only `d ≤ √N` contributes, giving
  `√N + 2√N ≤ 3√N`.
- **Theorem 5** follows from Theorem 1 by a squeeze: the deviation is `≤ 3/√N → 0`.
