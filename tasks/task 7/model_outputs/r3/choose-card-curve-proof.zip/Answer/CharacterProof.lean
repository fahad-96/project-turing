import Mathlib

namespace CharacterProof

open scoped BigOperators

variable {F : Type*} [Field F] [Fintype F] [DecidableEq F]

local notation "Q" => quadraticChar F

lemma sum_comp_sq (hF : ringChar F ≠ 2) (f : F → Int) :
    (∑ x : F, f (x ^ 2)) = ∑ u : F, (Q u + 1) * f u := by
  rw [← Finset.sum_fiberwise Finset.univ (fun x : F => x ^ 2) (fun x => f (x ^ 2))]
  apply Finset.sum_congr rfl
  intro u _
  rw [show (∑ x ∈ Finset.univ with x ^ 2 = u, f (x ^ 2)) =
      ({x : F | x ^ 2 = u}.toFinset.card : Int) * f u by
    have hs : (∑ x ∈ Finset.univ with x ^ 2 = u, f (x ^ 2)) =
        ∑ _x ∈ Finset.univ with _x ^ 2 = u, f u := by
      apply Finset.sum_congr rfl
      intro x hx
      rw [(Finset.mem_filter.mp hx).2]
    rw [hs]
    simp [mul_comm]]
  rw [quadraticChar_card_sqrts hF]

lemma jacobi_quadratic (hF : ringChar F ≠ 2) :
    jacobiSum Q Q = -Q (-1) := by
  simpa [(quadraticChar_isQuadratic F).inv] using
    (jacobiSum_nontrivial_inv (quadraticChar_ne_one hF))

lemma quadratic_correlation (hF : ringChar F ≠ 2) (hm1 : Q (-1) = 1)
    {a b : F} (hab : a ≠ b) :
    (∑ x : F, Q (x - a) * Q (x - b)) = -1 := by
  let d := b - a
  have hd : d ≠ 0 := sub_ne_zero.mpr (Ne.symm hab)
  let e : F ≃ F := (Equiv.mulRight₀ d hd).trans (Equiv.addRight a)
  have hreindex : (∑ x : F, Q (x - a) * Q (x - b)) =
      ∑ x : F, Q (e x - a) * Q (e x - b) := by
    symm
    exact Fintype.sum_equiv e _ _ (fun _ => rfl)
  rw [hreindex]
  rw [show (∑ x : F, Q (e x - a) * Q (e x - b)) = jacobiSum Q Q by
      simp only [e, Equiv.trans_apply, Equiv.mulRight₀_apply]
      rw [jacobiSum]
      apply Finset.sum_congr rfl
      intro x _
      have hdm1 : Q d * Q d = 1 := by
        rw [← map_mul, ← pow_two]
        exact quadraticChar_sq_one' hd
      change Q (x * d + a - a) * Q (x * d + a - b) = _
      rw [show x * d + a - a = x * d by ring]
      rw [show x * d + a - b = (x - 1) * d by dsimp [d]; ring]
      simp only [map_mul]
      rw [show Q (x - 1) = Q (-1) * Q (1 - x) by
        rw [← map_mul]
        congr 1
        ring]
      rw [hm1]
      calc
        Q x * Q d * (1 * Q (1 - x) * Q d) =
            Q x * Q (1 - x) * (Q d * Q d) := by ring
        _ = Q x * Q (1 - x) := by rw [hdm1]; ring]
  rw [jacobi_quadratic hF, hm1]

noncomputable def curveSum (a : F) : Int :=
  ∑ x : F, Q (x ^ 3 - a * x)

lemma curveSum_factor (a : F) :
    curveSum a = ∑ x : F, Q x * Q (x ^ 2 - a) := by
  apply Finset.sum_congr rfl
  intro x _
  rw [← map_mul]
  congr 1
  ring

lemma curveSum_sq_formula (hF : ringChar F ≠ 2) {a : F} (ha : a ≠ 0) :
    curveSum a ^ 2 =
      ∑ t : F, ∑ v : F,
        (Q a * Q v + 1) * (Q a * Q v) * Q t * Q (v - 1) * Q (t ^ 2 * v - 1) := by
  let A : F → Int := fun x => Q x * Q (x ^ 2 - a)
  have hA0 : A 0 = 0 := by simp [A]
  have hreindex (x : F) : (∑ y : F, A x * A y) = ∑ t : F, A x * A (t * x) := by
    by_cases hx : x = 0
    · subst x
      simp [hA0]
    · symm
      exact Fintype.sum_equiv (Equiv.mulRight₀ x hx) _ _ (fun _ => rfl)
  rw [curveSum_factor]
  change (∑ x : F, A x) ^ 2 = _
  rw [pow_two, Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  simp_rw [hreindex]
  rw [Finset.sum_comm]
  have halg (t x : F) :
      A x * A (t * x) =
        Q (x ^ 2) * Q t * Q (x ^ 2 - a) * Q (t ^ 2 * x ^ 2 - a) := by
    dsimp [A]
    simp only [map_mul]
    rw [map_pow]
    ring_nf
  simp_rw [halg]
  apply Finset.sum_congr rfl
  intro t _
  rw [sum_comp_sq hF (fun u => Q u * Q t * Q (u - a) * Q (t ^ 2 * u - a))]
  let e := Equiv.mulRight₀ a ha
  rw [← Fintype.sum_equiv e]
  · intro v
    simp only [e, Equiv.mulRight₀_apply, map_mul]
    have ha2 : Q a * Q a = 1 := by
      rw [← map_mul, ← pow_two]
      exact quadraticChar_sq_one' ha
    rw [show v * a - a = a * (v - 1) by ring]
    rw [show t ^ 2 * (v * a) - a = a * (t ^ 2 * v - 1) by ring]
    simp only [map_mul]
    linear_combination
      -((Q a * Q v + 1) * (Q a * Q v) * Q t * Q (v - 1) *
        Q (t ^ 2 * v - 1)) * ha2

lemma sum_quadratic_sq :
    (∑ x : F, Q x ^ 2) = (Fintype.card F : Int) - 1 := by
  calc
    _ = ∑ x : F, if x = 0 then (0 : Int) else 1 := by
      apply Finset.sum_congr rfl
      intro x _
      split_ifs with hx
      · subst x
        rw [quadraticChar_zero]
        norm_num
      · exact quadraticChar_sq_one hx
    _ = _ := by
      have hpoint (x : F) : (if x = 0 then (0 : Int) else 1) =
          1 - if x = 0 then 1 else 0 := by
        split_ifs <;> ring
      simp_rw [hpoint, Finset.sum_sub_distrib, Fintype.sum_ite_eq']
      simp

lemma sum_quadratic_sq_mul (g : F → Int) :
    (∑ x : F, Q x ^ 2 * g x) = (∑ x : F, g x) - g 0 := by
  calc
    _ = ∑ x : F, if x = 0 then 0 else g x := by
      apply Finset.sum_congr rfl
      intro x _
      split_ifs with hx
      · subst x
        rw [quadraticChar_zero]
        ring
      · rw [quadraticChar_sq_one hx]
        simp
    _ = _ := by
      have hpoint (x : F) : (if x = 0 then (0 : Int) else g x) =
          g x - if x = 0 then g x else 0 := by
        split_ifs <;> ring
      simp_rw [hpoint, Finset.sum_sub_distrib, Fintype.sum_ite_eq']

lemma quadratic_polynomial_sum (hF : ringChar F ≠ 2) (hm1 : Q (-1) = 1)
    {t : F} (ht : t ≠ 0) :
    (∑ v : F, Q (v - 1) * Q (t ^ 2 * v - 1)) =
      if t ^ 2 = 1 then (Fintype.card F : Int) - 1 else -1 := by
  split_ifs with ht1
  · simp_rw [ht1, one_mul]
    let e : F ≃ F := Equiv.addRight 1
    calc
      (∑ v : F, Q (v - 1) * Q (v - 1)) =
          ∑ v : F, Q (v - 1) ^ 2 := by
            apply Finset.sum_congr rfl
            intro v _
            ring
      _ = ∑ x : F, Q x ^ 2 := by
        symm
        exact Fintype.sum_equiv e _ _ (by
          intro x
          change Q x ^ 2 = Q (x + 1 - 1) ^ 2
          congr 2
          ring)
      _ = _ := sum_quadratic_sq
  · have ht2 : t ^ 2 ≠ 0 := pow_ne_zero _ ht
    have hinv : (t ^ 2)⁻¹ ≠ 1 := by
      intro h
      have := congrArg (fun z : F => z⁻¹) h
      rw [inv_inv, inv_one] at this
      exact ht1 this
    have hcorr := quadratic_correlation hF hm1 (a := (1 : F))
      (b := (t ^ 2)⁻¹) (Ne.symm hinv)
    rw [← hcorr]
    apply Finset.sum_congr rfl
    intro v _
    have hfactor : t ^ 2 * v - 1 = t ^ 2 * (v - (t ^ 2)⁻¹) := by
      field_simp
    rw [hfactor, map_mul, quadraticChar_sq_one' ht]
    ring

lemma weighted_polynomial_sum (hF : ringChar F ≠ 2) (hm1 : Q (-1) = 1) (t : F) :
    (∑ v : F, Q v ^ 2 * Q t * Q (v - 1) * Q (t ^ 2 * v - 1)) =
      Q t * (if t ^ 2 = 1 then (Fintype.card F : Int) - 2 else -2) := by
  by_cases ht : t = 0
  · subst t
    rw [quadraticChar_zero]
    simp
  · rw [show (∑ v : F, Q v ^ 2 * Q t * Q (v - 1) * Q (t ^ 2 * v - 1)) =
        Q t * ∑ v : F, Q v ^ 2 * (Q (v - 1) * Q (t ^ 2 * v - 1)) by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro v _
      ring]
    rw [sum_quadratic_sq_mul]
    rw [quadratic_polynomial_sum hF hm1 ht]
    norm_num [hm1]
    split_ifs <;> ring

lemma moment_eq (hF : ringChar F ≠ 2) (hm1 : Q (-1) = 1) :
    (∑ t : F, ∑ v : F,
      Q v ^ 2 * Q t * Q (v - 1) * Q (t ^ 2 * v - 1)) =
      2 * (Fintype.card F : Int) := by
  simp_rw [weighted_polynomial_sum hF hm1]
  have hroot : (∑ t : F, if t ^ 2 = 1 then Q t else 0) = 2 := by
    calc
      _ = ∑ t : F, if t ^ 2 = 1 then (1 : Int) else 0 := by
        apply Finset.sum_congr rfl
        intro t _
        split_ifs with ht
        · rcases sq_eq_one_iff.mp ht with rfl | rfl
          · simp
          · simpa using hm1
        · rfl
      _ = ({t : F | t ^ 2 = (1 : F)}.toFinset.card : Int) := by simp
      _ = 2 := by
        rw [quadraticChar_card_sqrts hF]
        simp
  calc
    (∑ t : F, Q t * (if t ^ 2 = 1 then (Fintype.card F : Int) - 2 else -2)) =
        ∑ t : F, (-2 * Q t +
          if t ^ 2 = 1 then (Fintype.card F : Int) * Q t else 0) := by
      apply Finset.sum_congr rfl
      intro t _
      split_ifs <;> ring
    _ = -2 * (∑ t : F, Q t) +
        (Fintype.card F : Int) * (∑ t : F, if t ^ 2 = 1 then Q t else 0) := by
      rw [Finset.sum_add_distrib, Finset.mul_sum, Finset.mul_sum]
      apply congrArg₂ (· + ·) rfl
      apply Finset.sum_congr rfl
      intro t _
      split_ifs <;> ring
    _ = 2 * (Fintype.card F : Int) := by
      rw [quadraticChar_sum_zero hF, hroot]
      ring

theorem curveSum_sq_add_sq (hF : ringChar F ≠ 2) (hm1 : Q (-1) = 1)
    (c r : F) (hc : Q c = 1) (hr : Q r = -1) :
    curveSum c ^ 2 + curveSum r ^ 2 = 4 * (Fintype.card F : Int) := by
  have hc0 : c ≠ 0 := by
    intro h
    subst c
    rw [quadraticChar_zero] at hc
    norm_num at hc
  have hr0 : r ≠ 0 := by
    intro h
    subst r
    rw [quadraticChar_zero] at hr
    norm_num at hr
  rw [curveSum_sq_formula hF hc0, curveSum_sq_formula hF hr0]
  rw [hc, hr]
  rw [← Finset.sum_add_distrib]
  simp_rw [← Finset.sum_add_distrib]
  calc
    (∑ t : F, ∑ v : F,
      ((1 * Q v + 1) * (1 * Q v) * Q t * Q (v - 1) * Q (t ^ 2 * v - 1) +
       (-1 * Q v + 1) * (-1 * Q v) * Q t * Q (v - 1) * Q (t ^ 2 * v - 1))) =
        2 * ∑ t : F, ∑ v : F,
          Q v ^ 2 * Q t * Q (v - 1) * Q (t ^ 2 * v - 1) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t _
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro v _
      ring
    _ = 4 * (Fintype.card F : Int) := by
      rw [moment_eq hF hm1]
      ring

end CharacterProof
