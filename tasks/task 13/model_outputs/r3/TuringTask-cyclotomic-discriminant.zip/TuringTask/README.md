# TuringTask

This project uses the supplied Lean 4 and local Mathlib installation.

Build offline from this directory with:

```sh
lean-offline-init
lake build
```
