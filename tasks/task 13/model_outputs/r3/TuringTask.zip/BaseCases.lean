import Mathlib

open Polynomial

namespace TuringTask

theorem r1_n_eq_one (m : Nat) (hm : 1 < m)
    (h : ∀ p k : Nat, p.Prime → ¬m = 1 * p ^ k) :
    Polynomial.resultant (Polynomial.cyclotomic m Int)
        (Polynomial.cyclotomic 1 Int) = 1 := by
  have hm2 : 2 < m := by
    have hne : m ≠ 2 := by
      intro hm'
      exact h 2 1 Nat.prime_two (by simp [hm'])
    omega
  have heven : Even m.totient := Nat.totient_even hm2
  have heval : eval (1 : Int) (cyclotomic m Int) = 1 := by
    apply eval_one_cyclotomic_not_prime_pow
    intro p hp k heq
    exact h p k hp (by simpa using heq.symm)
  have hres := resultant_X_sub_C_right (cyclotomic m Int)
    m.totient (1 : Int) (by rw [natDegree_cyclotomic])
  rw [heval, heven.neg_one_pow] at hres
  rw [cyclotomic_one,
    show (1 : Int[X]) = C (1 : Int) by rfl,
    natDegree_cyclotomic, natDegree_X_sub_C]
  simpa using hres

theorem r2_n_eq_one (p k : Nat) (hp : p.Prime) (hk : 1 ≤ k)
    (h : ¬(1 = 1 ∧ p = 2 ∧ k = 1)) :
    Polynomial.resultant (Polynomial.cyclotomic (1 * p ^ k) Int)
        (Polynomial.cyclotomic 1 Int) =
      (p : Int) ^ Nat.totient 1 := by
  letI : Fact p.Prime := ⟨hp⟩
  have hpk : 2 < p ^ k := by
    rcases hp.eq_two_or_odd with rfl | hpodd
    · have hk1 : k ≠ 1 := by
        intro hk'
        exact h ⟨rfl, rfl, hk'⟩
      have hk2 : 2 ≤ k := by omega
      have hpow : 2 ^ 2 ≤ 2 ^ k := Nat.pow_le_pow_right (by omega) hk2
      norm_num at hpow ⊢
      omega
    · have hp3 : 3 ≤ p := by
        have hp2 := hp.two_le
        omega
      have hle : p ≤ p ^ k := Nat.le_pow (by omega)
      omega
  have heven : Even (p ^ k).totient := Nat.totient_even hpk
  have heval : eval (1 : Int) (cyclotomic (p ^ k) Int) = (p : Int) := by
    have hk' : k - 1 + 1 = k := by omega
    rw [← hk']
    exact eval_one_cyclotomic_prime_pow (R := Int) (k - 1)
  have hres := resultant_X_sub_C_right (cyclotomic (p ^ k) Int)
    (p ^ k).totient (1 : Int) (by rw [natDegree_cyclotomic])
  rw [heval, heven.neg_one_pow] at hres
  rw [one_mul, cyclotomic_one,
    show (1 : Int[X]) = C (1 : Int) by rfl,
    natDegree_cyclotomic, natDegree_X_sub_C]
  simpa using hres

end TuringTask
