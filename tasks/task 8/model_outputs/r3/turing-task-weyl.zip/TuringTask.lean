import TuringTask.Basic
import TuringTask.Weyl
