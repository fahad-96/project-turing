import Mathlib
import TuringTask.Fibre

/-!
# Resultants of cyclotomic polynomials

* `resultant_cyclotomic_X_pow_sub_one_eq`: `Res(Phi_m, X^n - 1)` through the fibre lemma.
* `resultant_cyclotomic_nonneg`: for `m >= 3` the resultant of `Phi_m` with any integer polynomial
  is non-negative (the primitive roots come in conjugate pairs).
* `resultant_cyclotomic_eq_one_of_not_prime_pow`: `Res(Phi_m, Phi_n) = 1` when `m / n` is not a
  prime power (no prime divides the resultant, by reduction modulo that prime).
* `resultant_cyclotomic_mul_prime_pow_eq`: `Res(Phi_{n p^k}, Phi_n) = p ^ phi(n)`.
-/

namespace TuringTask

open Polynomial

/-! ### Evaluation against `X ^ n - 1` -/

theorem expand_X_sub_one (n : ℕ) : expand ℤ n (X - 1) = X ^ n - 1 := by
  rw [map_sub, expand_X, map_one]

theorem resultant_cyclotomic_X_sub_one (k : ℕ) :
    resultant (cyclotomic k ℤ) (X - 1) = (-1) ^ Nat.totient k * eval 1 (cyclotomic k ℤ) := by
  have h : (X - 1 : ℤ[X]) = X - C 1 := by rw [map_one]
  rw [h, natDegree_X_sub_C, natDegree_cyclotomic,
    resultant_X_sub_C_right _ _ _ (natDegree_cyclotomic k ℤ).le]

/-- `Res(Phi_m, X ^ n - 1)` as a power of `(-1) ^ phi(k) * Phi_k(1)`, `k = m / gcd m n`. -/
theorem resultant_cyclotomic_X_pow_sub_one_eq (m n : ℕ) (hm : 0 < m) (hn : 0 < n) :
    resultant (cyclotomic m ℤ) (X ^ n - 1) =
      ((-1) ^ Nat.totient (m / Nat.gcd m n) * eval 1 (cyclotomic (m / Nat.gcd m n) ℤ)) ^
        (Nat.totient m / Nat.totient (m / Nat.gcd m n)) := by
  rw [← expand_X_sub_one, resultant_cyclotomic_expand m n hm hn, resultant_cyclotomic_X_sub_one]

/-! ### Non-negativity by conjugate pairing -/

theorem eval_map_conj (g : ℤ[X]) (z : ℂ) :
    (g.map (Int.castRingHom ℂ)).eval ((starRingEnd ℂ) z) =
      (starRingEnd ℂ) ((g.map (Int.castRingHom ℂ)).eval z) := by
  rw [eval_map, eval_map, hom_eval₂]
  congr 1
  exact Subsingleton.elim _ _

theorem prod_conj_pairs_nonneg (s : Finset ℂ) (hs : ∀ z ∈ s, (starRingEnd ℂ) z ∈ s)
    (hs' : ∀ z ∈ s, z.im ≠ 0) (f : ℂ → ℂ)
    (hf : ∀ z, f ((starRingEnd ℂ) z) = (starRingEnd ℂ) (f z)) :
    ∃ r : ℝ, 0 ≤ r ∧ ∏ z ∈ s, f z = r := by
  classical
  set sp := s.filter (fun z : ℂ => 0 < z.im) with hsp
  set sm := s.filter (fun z : ℂ => z.im < 0) with hsm
  have hsplit : s = sp ∪ sm := by
    ext z
    simp only [hsp, hsm, Finset.mem_union, Finset.mem_filter]
    constructor
    · intro hz
      rcases lt_or_gt_of_ne (hs' z hz) with h | h
      · exact Or.inr ⟨hz, h⟩
      · exact Or.inl ⟨hz, h⟩
    · rintro (⟨hz, -⟩ | ⟨hz, -⟩) <;> exact hz
  have hdisj : Disjoint sp sm := by
    rw [Finset.disjoint_filter]
    intro z _ h1 h2
    exact absurd h2 (not_lt.mpr h1.le)
  have himage : sm = sp.image (starRingEnd ℂ) := by
    ext z
    simp only [hsp, hsm, Finset.mem_image, Finset.mem_filter]
    constructor
    · intro hz
      obtain ⟨hz, hneg⟩ := hz
      refine ⟨(starRingEnd ℂ) z, ⟨hs z hz, ?_⟩, Complex.conj_conj z⟩
      rw [Complex.conj_im]
      linarith
    · rintro ⟨w, ⟨hw, hpos⟩, rfl⟩
      refine ⟨hs w hw, ?_⟩
      rw [Complex.conj_im]
      linarith
  refine ⟨∏ z ∈ sp, Complex.normSq (f z),
    Finset.prod_nonneg fun z _ => Complex.normSq_nonneg _, ?_⟩
  rw [hsplit, Finset.prod_union hdisj, himage,
    Finset.prod_image (fun x _ y _ h => (starRingEnd ℂ).injective h),
    ← Finset.prod_mul_distrib, Complex.ofReal_prod]
  refine Finset.prod_congr rfl fun z _ => ?_
  rw [hf, Complex.mul_conj]

theorem conj_mem_primitiveRoots {m : ℕ} (hm : 0 < m) {α : ℂ} (hα : α ∈ primitiveRoots m ℂ) :
    (starRingEnd ℂ) α ∈ primitiveRoots m ℂ := by
  rw [mem_primitiveRoots hm] at hα ⊢
  exact hα.map_of_injective (starRingEnd ℂ).injective

theorem im_ne_zero_of_mem_primitiveRoots {m : ℕ} (hm : 3 ≤ m) {α : ℂ}
    (hα : α ∈ primitiveRoots m ℂ) : α.im ≠ 0 := by
  intro him
  have hm0 : 0 < m := by omega
  rw [mem_primitiveRoots hm0] at hα
  have hre : α = ((α.re : ℝ) : ℂ) := by
    apply Complex.ext
    · simp
    · simp [him]
  rw [hre] at hα
  have hα' : IsPrimitiveRoot (α.re : ℝ) m :=
    (IsPrimitiveRoot.map_iff_of_injective (f := Complex.ofRealHom) Complex.ofReal_injective).mp hα
  have h2 : orderOf (α.re : ℝ) ≤ 2 := LinearOrderedRing.orderOf_le_two
  rw [← hα'.eq_orderOf] at h2
  omega

/-- For `m >= 3`, `Res(Phi_m, g)` is non-negative for every integer polynomial `g`. -/
theorem resultant_cyclotomic_nonneg (m : ℕ) (hm : 3 ≤ m) (g : ℤ[X]) :
    0 ≤ resultant (cyclotomic m ℤ) g := by
  have hm0 : 0 < m := by omega
  obtain ⟨r, hr0, hr⟩ := prod_conj_pairs_nonneg (primitiveRoots m ℂ)
    (fun z hz => conj_mem_primitiveRoots hm0 hz)
    (fun z hz => im_ne_zero_of_mem_primitiveRoots hm hz)
    (fun z => (g.map (Int.castRingHom ℂ)).eval z) (eval_map_conj g)
  have h := resultant_cyclotomic_eq_prod m hm0 g
  rw [hr] at h
  have h' : ((resultant (cyclotomic m ℤ) g : ℤ) : ℝ) = r := by
    apply Complex.ofReal_injective
    rw [Complex.ofReal_intCast]
    exact h
  have h'' : (0 : ℝ) ≤ ((resultant (cyclotomic m ℤ) g : ℤ) : ℝ) := h' ▸ hr0
  exact_mod_cast h''

/-! ### Theorem 1: no prime divides the resultant -/

theorem resultant_cyclotomic_ne_zero (m n : ℕ) (hmn : m ≠ n) :
    resultant (cyclotomic m ℤ) (cyclotomic n ℤ) ≠ 0 := by
  intro h
  have h1 := resultant_map_map (cyclotomic m ℤ) (cyclotomic n ℤ) (cyclotomic m ℤ).natDegree
    (cyclotomic n ℤ).natDegree (Int.castRingHom ℚ)
  rw [h, map_zero, map_cyclotomic_int, map_cyclotomic_int, natDegree_cyclotomic,
    natDegree_cyclotomic, ← natDegree_cyclotomic m ℚ, ← natDegree_cyclotomic n ℚ] at h1
  exact (resultant_eq_zero_iff.mp h1).2 (cyclotomic.isCoprime_rat hmn)

theorem not_prime_dvd_resultant_cyclotomic (m n : ℕ) (hm : 0 < m) (hn : 0 < n) (hnm : n < m)
    (h : ∀ p k : ℕ, p.Prime → ¬ m = n * p ^ k) (q : ℕ) (hq : q.Prime) :
    ¬ (q : ℤ) ∣ resultant (cyclotomic m ℤ) (cyclotomic n ℤ) := by
  intro hdvd
  haveI := Fact.mk hq
  let K := AlgebraicClosure (ZMod q)
  have h0 : (Int.castRingHom K) (resultant (cyclotomic m ℤ) (cyclotomic n ℤ)) = 0 := by
    obtain ⟨c, hc⟩ := hdvd
    rw [hc, map_mul, eq_intCast, Int.cast_natCast, CharP.cast_eq_zero K q, zero_mul]
  have h1 := resultant_map_map (cyclotomic m ℤ) (cyclotomic n ℤ) (cyclotomic m ℤ).natDegree
    (cyclotomic n ℤ).natDegree (Int.castRingHom K)
  rw [h0, map_cyclotomic_int, map_cyclotomic_int, natDegree_cyclotomic, natDegree_cyclotomic,
    ← natDegree_cyclotomic m K, ← natDegree_cyclotomic n K] at h1
  have h2 := (resultant_eq_zero_iff.mp h1).2
  rw [isCoprime_iff_aeval_ne_zero_of_isAlgClosed K K (cyclotomic m K) (cyclotomic n K)] at h2
  push Not at h2
  obtain ⟨μ, hμm, hμn⟩ := h2
  rw [coe_aeval_eq_eval] at hμm hμn
  obtain ⟨a, m', hqm', hm'⟩ := Nat.exists_eq_pow_mul_and_not_dvd hm.ne' q hq.ne_one
  obtain ⟨b, n', hqn', hn'⟩ := Nat.exists_eq_pow_mul_and_not_dvd hn.ne' q hq.ne_one
  haveI : NeZero (m' : K) := ⟨(CharP.cast_eq_zero_iff K q m').not.mpr hqm'⟩
  haveI : NeZero (n' : K) := ⟨(CharP.cast_eq_zero_iff K q n').not.mpr hqn'⟩
  have hμm' : IsPrimitiveRoot μ m' := by
    rw [hm'] at hμm
    exact isRoot_cyclotomic_prime_pow_mul_iff_of_charP.mp hμm
  have hμn' : IsPrimitiveRoot μ n' := by
    rw [hn'] at hμn
    exact isRoot_cyclotomic_prime_pow_mul_iff_of_charP.mp hμn
  have hm'n' : m' = n' := hμm'.unique hμn'
  subst hm'n'
  have hm'pos : 0 < m' := by
    rcases Nat.eq_zero_or_pos m' with h0 | h0
    · rw [h0, mul_zero] at hm'
      omega
    · exact h0
  have hab : b < a := by
    rw [hm', hn'] at hnm
    have := Nat.lt_of_mul_lt_mul_right hnm
    exact (Nat.pow_lt_pow_iff_right hq.one_lt).mp this
  apply h q (a - b) hq
  obtain ⟨c, rfl⟩ := Nat.exists_eq_add_of_lt hab
  rw [hm', hn', show b + c + 1 - b = c + 1 by omega]
  ring

/-- Theorem 1 in its working form. -/
theorem resultant_cyclotomic_eq_one_of_not_prime_pow (m n : ℕ) (hn : 1 ≤ n) (hnm : n < m)
    (h : ∀ p k : ℕ, p.Prime → ¬ m = n * p ^ k) :
    resultant (cyclotomic m ℤ) (cyclotomic n ℤ) = 1 := by
  have hm : 0 < m := by omega
  set R := resultant (cyclotomic m ℤ) (cyclotomic n ℤ) with hR
  have hR0 : R ≠ 0 := resultant_cyclotomic_ne_zero m n (by omega)
  have habs : R.natAbs = 1 := by
    rw [Nat.eq_one_iff_not_exists_prime_dvd]
    intro q hq hqdvd
    exact not_prime_dvd_resultant_cyclotomic m n hm hn hnm h q hq (Int.natCast_dvd.mpr hqdvd)
  have hm3 : 3 ≤ m := by
    by_contra hlt
    push Not at hlt
    have hm2 : m = 2 := by omega
    have hn1 : n = 1 := by omega
    exact h 2 1 Nat.prime_two (by rw [hm2, hn1]; norm_num)
  have hnonneg : 0 ≤ R := resultant_cyclotomic_nonneg m hm3 _
  rcases Int.natAbs_eq_iff.mp habs with h1 | h1
  · exact_mod_cast h1
  · rw [h1] at hnonneg
    norm_num at hnonneg

/-! ### Theorem 2: `Res(Phi_{n p^k}, Phi_n) = p ^ phi(n)` -/

/-- `Res(Phi_m, X^n - 1)` is the product of `Res(Phi_m, Phi_d)` over the divisors `d` of `n`. -/
theorem resultant_cyclotomic_X_pow_sub_one_eq_prod_divisors (m n : ℕ) (hn : 0 < n) :
    resultant (cyclotomic m ℤ) (X ^ n - 1) =
      ∏ d ∈ n.divisors, resultant (cyclotomic m ℤ) (cyclotomic d ℤ) := by
  rw [← prod_cyclotomic_eq_X_pow_sub_one hn ℤ]
  exact resultant_prod_right _ _ _ _ le_rfl (by simp [(cyclotomic.monic _ ℤ).leadingCoeff])

/-- For `p` prime not dividing `n` and `k >= 1`, a proper divisor `d` of `n` never satisfies
`n * p ^ k = d * q ^ j` with `q` prime. -/
theorem not_eq_mul_prime_pow_of_properDivisor {n p k d : ℕ} (hp : p.Prime) (hpn : ¬ p ∣ n)
    (hk : 1 ≤ k) (hd : d ∈ n.properDivisors) (q j : ℕ) (hq : q.Prime) :
    ¬ n * p ^ k = d * q ^ j := by
  intro heq
  rw [Nat.mem_properDivisors] at hd
  obtain ⟨⟨e, rfl⟩, hlt⟩ := hd
  have hd0 : 0 < d := Nat.pos_of_ne_zero (by rintro rfl; simp at hlt)
  have he1 : 1 < e := by
    by_contra hle
    push Not at hle
    interval_cases e <;> simp at hlt
  have heq' : e * p ^ k = q ^ j := by
    have : d * (e * p ^ k) = d * q ^ j := by rw [← mul_assoc]; exact heq
    exact Nat.eq_of_mul_eq_mul_left hd0 this
  have hpq : p ∣ q := by
    have h1 : p ∣ q ^ j := by
      rw [← heq']
      exact Dvd.dvd.mul_left (dvd_pow_self p (by omega)) e
    exact hp.dvd_of_dvd_pow h1
  have hpq' : p = q := (Nat.prime_dvd_prime_iff_eq hp hq).mp hpq
  subst hpq'
  have he : e ∣ p ^ j := ⟨p ^ k, by rw [← heq']⟩
  obtain ⟨i, -, rfl⟩ := (Nat.dvd_prime_pow hp).mp he
  have hi0 : i ≠ 0 := by rintro rfl; simp at he1
  exact hpn (Dvd.dvd.mul_left (dvd_pow_self p hi0) d)

theorem totient_mul_prime_pow_eq {n p : ℕ} (hp : p.Prime) (hpn : ¬ p ∣ n) (j : ℕ) (hj : 0 < j) :
    Nat.totient (n * p ^ j) = Nat.totient n * (p ^ (j - 1) * (p - 1)) := by
  rw [Nat.totient_mul ((hp.coprime_iff_not_dvd.mpr hpn).symm.pow_right j),
    Nat.totient_prime_pow hp hj]

/-- The coprime case with its sign: `Res(Phi_{n p^k}, Phi_n) = (-1)^(phi(p^k) phi(n)) p^phi(n)`. -/
theorem resultant_cyclotomic_mul_prime_pow_coprime_signed (n p k : ℕ) (hn : 1 ≤ n) (hp : p.Prime)
    (hk : 1 ≤ k) (hpn : ¬ p ∣ n) :
    resultant (cyclotomic (n * p ^ k) ℤ) (cyclotomic n ℤ) =
      (-1) ^ (Nat.totient (p ^ k) * Nat.totient n) * (p : ℤ) ^ Nat.totient n := by
  have hpk : 0 < p ^ k := pow_pos hp.pos k
  have hm : 0 < n * p ^ k := Nat.mul_pos hn hpk
  have hnm : n < n * p ^ k := by
    have h1 : 1 < p ^ k := Nat.one_lt_pow (by omega) hp.one_lt
    calc n = n * 1 := (mul_one n).symm
      _ < n * p ^ k := Nat.mul_lt_mul_of_pos_left h1 hn
  have hE := resultant_cyclotomic_X_pow_sub_one_eq_prod_divisors (n * p ^ k) n hn
  rw [← Nat.insert_self_properDivisors (by omega : n ≠ 0),
    Finset.prod_insert Nat.self_notMem_properDivisors] at hE
  have hprop : ∏ d ∈ n.properDivisors,
      resultant (cyclotomic (n * p ^ k) ℤ) (cyclotomic d ℤ) = 1 := by
    apply Finset.prod_eq_one
    intro d hd
    have hd' := Nat.mem_properDivisors.mp hd
    have hd1 : 1 ≤ d := Nat.pos_of_dvd_of_pos hd'.1 hn
    exact resultant_cyclotomic_eq_one_of_not_prime_pow _ d hd1 (lt_trans hd'.2 hnm)
      (fun q j hq => not_eq_mul_prime_pow_of_properDivisor hp hpn hk hd q j hq)
  rw [hprop, mul_one, resultant_cyclotomic_X_pow_sub_one_eq _ _ hm hn] at hE
  have hgcd : Nat.gcd (n * p ^ k) n = n := Nat.gcd_eq_right (Dvd.intro _ rfl)
  have hquot : n * p ^ k / n = p ^ k := Nat.mul_div_cancel_left _ hn
  have htot : Nat.totient (n * p ^ k) / Nat.totient (p ^ k) = Nat.totient n := by
    rw [Nat.totient_mul ((hp.coprime_iff_not_dvd.mpr hpn).symm.pow_right k)]
    exact Nat.mul_div_cancel _ (Nat.totient_pos.mpr hpk)
  rw [hgcd, hquot, htot] at hE
  obtain ⟨k', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k ≠ 0)
  haveI := Fact.mk hp
  rw [eval_one_cyclotomic_prime_pow] at hE
  rw [← hE, mul_pow, ← pow_mul]

/-- The coprime case: `Res(Phi_{n p^k}, Phi_n) = p^phi(n)` for `p` not dividing `n`, outside
`(n, p, k) = (1, 2, 1)`. -/
theorem resultant_cyclotomic_mul_prime_pow_coprime (n p k : ℕ) (hn : 1 ≤ n) (hp : p.Prime)
    (hk : 1 ≤ k) (hpn : ¬ p ∣ n) (h : ¬ (n = 1 ∧ p = 2 ∧ k = 1)) :
    resultant (cyclotomic (n * p ^ k) ℤ) (cyclotomic n ℤ) = (p : ℤ) ^ Nat.totient n := by
  rw [resultant_cyclotomic_mul_prime_pow_coprime_signed n p k hn hp hk hpn]
  have heven : Even (Nat.totient (p ^ k) * Nat.totient n) := by
    by_cases h2 : 2 < p ^ k
    · exact (Nat.totient_even h2).mul_right _
    · have hpk2 : p ^ k = 2 := by
        have : 2 ≤ p ^ k := le_trans hp.two_le (Nat.le_self_pow (by omega) p)
        omega
      have hp2 : p = 2 := by
        have hdvd : p ∣ 2 := by rw [← hpk2]; exact dvd_pow_self p (by omega)
        exact (Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp hdvd
      have hk1 : k = 1 := by
        subst hp2
        exact Nat.pow_right_injective (le_refl 2) (by simpa using hpk2)
      have hn1 : n ≠ 1 := fun hn1 => h ⟨hn1, hp2, hk1⟩
      have hn2 : n ≠ 2 := by
        rintro rfl
        apply hpn
        rw [hp2]
      have hn3 : 2 < n := by omega
      exact (Nat.totient_even hn3).mul_left _
  rw [heven.neg_one_pow, one_mul]

/-- `expand (p ^ j)` of `Phi_n` when `p ∣ n`. -/
theorem cyclotomic_expand_pow (n p : ℕ) (hp : p.Prime) (hpn : p ∣ n) :
    ∀ j : ℕ, expand ℤ (p ^ j) (cyclotomic n ℤ) = cyclotomic (n * p ^ j) ℤ := by
  intro j
  induction j generalizing n with
  | zero => simp [expand_one]
  | succ j ih =>
    rw [pow_succ, expand_mul, cyclotomic_expand_eq_cyclotomic hp hpn ℤ,
      ih (n * p) (Dvd.intro_left n rfl)]
    congr 1
    ring

/-- `Res(Phi_{n' p^{k+1}}, Phi_{n' p}) = p^phi(n' p)` for `p` not dividing `n'`. -/
theorem resultant_cyclotomic_mul_prime_pow_once (n' p k : ℕ) (hn' : 1 ≤ n') (hp : p.Prime)
    (hk : 1 ≤ k) (hpn' : ¬ p ∣ n') :
    resultant (cyclotomic (n' * p * p ^ k) ℤ) (cyclotomic (n' * p) ℤ) =
      (p : ℤ) ^ Nat.totient (n' * p) := by
  have hp0 : 0 < p := hp.pos
  have hM : 0 < n' * p * p ^ k := by positivity
  have hexp : expand ℤ p (cyclotomic n' ℤ) = cyclotomic (n' * p) ℤ * cyclotomic n' ℤ :=
    cyclotomic_expand_eq_cyclotomic_mul hp hpn' ℤ
  have h1 : resultant (cyclotomic (n' * p * p ^ k) ℤ) (expand ℤ p (cyclotomic n' ℤ)) =
      resultant (cyclotomic (n' * p * p ^ k) ℤ) (cyclotomic (n' * p) ℤ) *
        resultant (cyclotomic (n' * p * p ^ k) ℤ) (cyclotomic n' ℤ) := by
    rw [hexp, natDegree_mul (cyclotomic_ne_zero _ ℤ) (cyclotomic_ne_zero _ ℤ),
      resultant_mul_right _ _ _ _ le_rfl]
  obtain ⟨k', rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : k ≠ 0)
  have h2 : resultant (cyclotomic (n' * p * p ^ (k' + 1)) ℤ) (expand ℤ p (cyclotomic n' ℤ)) =
      (resultant (cyclotomic (n' * p ^ (k' + 1)) ℤ) (cyclotomic n' ℤ)) ^ p := by
    rw [resultant_cyclotomic_expand _ _ hM hp0]
    have hg : Nat.gcd (n' * p * p ^ (k' + 1)) p = p :=
      Nat.gcd_eq_right ⟨n' * p ^ (k' + 1), by ring⟩
    have hq : n' * p * p ^ (k' + 1) / p = n' * p ^ (k' + 1) := by
      rw [show n' * p * p ^ (k' + 1) = n' * p ^ (k' + 1) * p by ring]
      exact Nat.mul_div_cancel _ hp0
    have ht : Nat.totient (n' * p * p ^ (k' + 1)) / Nat.totient (n' * p ^ (k' + 1)) = p := by
      rw [show n' * p * p ^ (k' + 1) = n' * p ^ (k' + 1 + 1) by ring,
        totient_mul_prime_pow_eq hp hpn' (k' + 1 + 1) (by omega),
        totient_mul_prime_pow_eq hp hpn' (k' + 1) (by omega), Nat.add_sub_cancel,
        Nat.add_sub_cancel]
      have hden : 0 < Nat.totient n' * (p ^ k' * (p - 1)) :=
        Nat.mul_pos (Nat.totient_pos.mpr hn')
          (Nat.mul_pos (pow_pos hp0 _) (Nat.sub_pos_of_lt hp.one_lt))
      rw [show Nat.totient n' * (p ^ (k' + 1) * (p - 1)) =
        Nat.totient n' * (p ^ k' * (p - 1)) * p by ring]
      exact Nat.mul_div_cancel_left p hden
    rw [hg, hq, ht]
  rw [h2] at h1
  have h3 : resultant (cyclotomic (n' * p * p ^ (k' + 1)) ℤ) (cyclotomic n' ℤ) =
      (p : ℤ) ^ Nat.totient n' := by
    rw [show n' * p * p ^ (k' + 1) = n' * p ^ (k' + 1 + 1) by ring]
    exact resultant_cyclotomic_mul_prime_pow_coprime n' p (k' + 1 + 1) hn' hp (by omega) hpn'
      (by omega)
  rw [h3, resultant_cyclotomic_mul_prime_pow_coprime_signed n' p (k' + 1) hn' hp hk hpn', mul_pow,
    ← pow_mul, ← pow_mul] at h1
  have hev : Even (Nat.totient (p ^ (k' + 1)) * Nat.totient n' * p) := by
    rcases hp.eq_two_or_odd' with rfl | hodd
    · exact even_two.mul_left _
    · have h3' : 3 ≤ p := by
        have := hp.two_le
        rcases hodd with ⟨t, ht⟩
        omega
      have h2 : 2 < p ^ (k' + 1) :=
        calc 2 < 3 := by norm_num
          _ ≤ p := h3'
          _ ≤ p ^ (k' + 1) := Nat.le_self_pow (by omega) p
      exact ((Nat.totient_even h2).mul_right _).mul_right _
  rw [hev.neg_one_pow, one_mul] at h1
  have hpz : (p : ℤ) ^ Nat.totient n' ≠ 0 := pow_ne_zero _ (by exact_mod_cast hp.ne_zero)
  apply mul_right_cancel₀ hpz
  rw [← h1, ← pow_add]
  congr 1
  rw [Nat.totient_mul (hp.coprime_iff_not_dvd.mpr hpn').symm, Nat.totient_prime hp]
  obtain ⟨q, rfl⟩ : ∃ q, p = q + 1 := ⟨p - 1, (Nat.sub_add_cancel hp.one_lt.le).symm⟩
  rw [Nat.add_sub_cancel]
  ring

/-- Theorem 2 in its working form. -/
theorem resultant_cyclotomic_mul_prime_pow_eq (n p k : ℕ) (hn : 1 ≤ n) (hp : p.Prime)
    (hk : 1 ≤ k) (h : ¬ (n = 1 ∧ p = 2 ∧ k = 1)) :
    resultant (cyclotomic (n * p ^ k) ℤ) (cyclotomic n ℤ) = (p : ℤ) ^ Nat.totient n := by
  obtain ⟨v, n', hpn', hn'⟩ := Nat.exists_eq_pow_mul_and_not_dvd (by omega : n ≠ 0) p hp.ne_one
  have hn'pos : 1 ≤ n' := by
    rcases Nat.eq_zero_or_pos n' with h0 | h0
    · rw [h0, mul_zero] at hn'
      omega
    · exact h0
  rcases Nat.eq_zero_or_pos v with hv | hv
  · rw [hv, pow_zero, one_mul] at hn'
    subst hn'
    exact resultant_cyclotomic_mul_prime_pow_coprime n p k hn hp hk hpn' h
  · obtain ⟨w, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hv.ne'
    have hp0 := hp.pos
    have hn2 : n = n' * p * p ^ w := by rw [hn', Nat.succ_eq_add_one, pow_succ]; ring
    have e1 : cyclotomic n ℤ = expand ℤ (p ^ w) (cyclotomic (n' * p) ℤ) := by
      rw [cyclotomic_expand_pow (n' * p) p hp (Dvd.intro_left n' rfl) w, hn2]
    have e2 : n * p ^ k = n' * p * p ^ k * p ^ w := by rw [hn2]; ring
    rw [e1, e2, resultant_cyclotomic_expand _ _ (by positivity) (pow_pos hp0 w)]
    have hg : Nat.gcd (n' * p * p ^ k * p ^ w) (p ^ w) = p ^ w :=
      Nat.gcd_eq_right (Dvd.intro_left _ rfl)
    have hq : n' * p * p ^ k * p ^ w / p ^ w = n' * p * p ^ k :=
      Nat.mul_div_cancel _ (pow_pos hp0 w)
    have ht : Nat.totient (n' * p * p ^ k * p ^ w) / Nat.totient (n' * p * p ^ k) = p ^ w := by
      rw [show n' * p * p ^ k * p ^ w = n' * p ^ (k + w + 1) by ring,
        show n' * p * p ^ k = n' * p ^ (k + 1) by ring,
        totient_mul_prime_pow_eq hp hpn' _ (by omega),
        totient_mul_prime_pow_eq hp hpn' _ (by omega),
        Nat.add_sub_cancel, Nat.add_sub_cancel]
      have hden : 0 < Nat.totient n' * (p ^ k * (p - 1)) :=
        Nat.mul_pos (Nat.totient_pos.mpr hn'pos)
          (Nat.mul_pos (pow_pos hp0 _) (Nat.sub_pos_of_lt hp.one_lt))
      rw [show Nat.totient n' * (p ^ (k + w) * (p - 1)) =
        Nat.totient n' * (p ^ k * (p - 1)) * p ^ w by ring]
      exact Nat.mul_div_cancel_left _ hden
    rw [hg, hq, ht, resultant_cyclotomic_mul_prime_pow_once n' p k hn'pos hp hk hpn', ← pow_mul]
    congr 1
    rw [hn2, show n' * p * p ^ w = n' * p ^ (w + 1) by ring,
      totient_mul_prime_pow_eq hp hpn' _ (by omega), show n' * p = n' * p ^ 1 by ring,
      totient_mul_prime_pow_eq hp hpn' 1 (by omega), Nat.add_sub_cancel, Nat.sub_self, pow_zero]
    ring

/-! ### Theorems 4 and 5 -/

/-- Theorem 4 in its working form. -/
theorem isCoprime_cyclotomic_iff' (m n : ℕ) (hn : 1 ≤ n) (hnm : n < m) :
    IsCoprime (cyclotomic m ℤ) (cyclotomic n ℤ) ↔ ∀ p k : ℕ, p.Prime → ¬ m = n * p ^ k := by
  rw [← isUnit_resultant_iff_isCoprime (cyclotomic.monic m ℤ)]
  constructor
  · intro hu p k hp hmk
    have hk : 1 ≤ k := by
      rcases Nat.eq_zero_or_pos k with h0 | h0
      · rw [h0, pow_zero, mul_one] at hmk
        omega
      · exact h0
    rw [hmk] at hu
    by_cases hexc : n = 1 ∧ p = 2 ∧ k = 1
    · obtain ⟨rfl, rfl, rfl⟩ := hexc
      rw [show (1 : ℕ) * 2 ^ 1 = 2 by norm_num, cyclotomic_two, cyclotomic_one] at hu
      have hres : resultant (X + 1 : ℤ[X]) (X - 1) = -2 := by
        rw [show (X - 1 : ℤ[X]) = X - C 1 by rw [C_1], show (X + 1 : ℤ[X]) = X + C 1 by rw [C_1],
          natDegree_X_sub_C, resultant_X_sub_C_right _ _ _ le_rfl, natDegree_X_add_C]
        simp
      rw [hres, Int.isUnit_iff] at hu
      omega
    · rw [resultant_cyclotomic_mul_prime_pow_eq n p k hn hp hk hexc, Int.isUnit_iff] at hu
      rcases hu with hu | hu
      · have h' : p ^ Nat.totient n = 1 := by exact_mod_cast hu
        rcases Nat.pow_eq_one.mp h' with h1 | h1
        · exact hp.one_lt.ne' h1
        · exact (Nat.totient_pos.mpr hn).ne' h1
      · have hpos : (0 : ℤ) ≤ (p : ℤ) ^ Nat.totient n := by positivity
        rw [hu] at hpos
        omega
  · intro h
    rw [resultant_cyclotomic_eq_one_of_not_prime_pow m n hn hnm h]
    exact isUnit_one

/-- Theorem 5 in its working form. The hypothesis `n ∤ m` of the task is carried along but not
needed: when `n ∣ m` both sides are `0`. -/
theorem resultant_cyclotomic_X_pow_sub_one_eval (n m : ℕ) (hn : 3 ≤ n) (hm : 1 ≤ m)
    (_h : ¬ (m % n = 0)) :
    resultant (cyclotomic n ℤ) (X ^ m - 1) =
      eval 1 (cyclotomic (n / Nat.gcd n m) ℤ) ^
        (Nat.totient n / Nat.totient (n / Nat.gcd n m)) := by
  have hn0 : 0 < n := by omega
  rw [resultant_cyclotomic_X_pow_sub_one_eq n m hn0 hm, mul_pow, ← pow_mul]
  have hk : n / Nat.gcd n m ∣ n := Nat.div_dvd_of_dvd (Nat.gcd_dvd_left n m)
  rw [Nat.mul_div_cancel' (Nat.totient_dvd_of_dvd hk), (Nat.totient_even hn).neg_one_pow, one_mul]

end TuringTask
