import Fourier
import CotPointwise

open scoped BigOperators

namespace Research

private theorem sum_cos_Ico (n l : ℕ) (hn : 0 < n) (hl : 0 < l) (hln : l < n) :
    ∑ k ∈ Finset.Ico 1 n, Real.cos (2 * Real.pi * l * k / n) = -1 := by
  rw [Finset.sum_Ico_eq_sub
    (fun k : ℕ => Real.cos (2 * Real.pi * l * k / n)) (by omega)]
  rw [sum_cos_root n l hn hl hln]
  norm_num

private theorem sin_pi_mul_div_ne_zero (n k : ℕ) (hn : 0 < n)
    (hk : k ∈ Finset.Ico 1 n) : Real.sin (Real.pi * k / n) ≠ 0 := by
  have hk' : 1 ≤ k ∧ k < n := Finset.mem_Ico.mp hk
  have hkpos : (0 : ℝ) < k := by exact_mod_cast hk'.1
  have hnR : (0 : ℝ) < n := by exact_mod_cast hn
  have hpos : 0 < Real.pi * k / n :=
    div_pos (mul_pos Real.pi_pos hkpos) hnR
  have hlt : Real.pi * k / n < Real.pi := by
    apply (div_lt_iff₀ hnR).2
    exact mul_lt_mul_of_pos_left (by exact_mod_cast hk'.2) Real.pi_pos
  exact ne_of_gt (Real.sin_pos_of_pos_of_lt_pi hpos hlt)

/-- The discrete sine transform of cotangent. The index is written as `j + 1`
so all side conditions are subtraction-free. -/
theorem sum_cot_sin_succ (n j : ℕ) (hn : 0 < n) (hj : j + 1 < n) :
    ∑ k ∈ Finset.Ico 1 n,
        Real.sin (2 * Real.pi * (j + 1) * k / n) *
          Real.cot (Real.pi * k / n) =
      (n : ℝ) - 2 * (j + 1) := by
  have hpoint (k : ℕ) (hk : k ∈ Finset.Ico 1 n) :
      Real.sin (2 * Real.pi * (j + 1) * k / n) *
          Real.cot (Real.pi * k / n) =
        1 + Real.cos (2 * Real.pi * (j + 1) * k / n) +
          2 * ∑ l ∈ Finset.range j,
            Real.cos (2 * Real.pi * (l + 1) * k / n) := by
    have h := cot_sin_dirichlet (Real.pi * k / n) j
      (sin_pi_mul_div_ne_zero n k hn hk)
    convert h using 1 <;> field_simp
  calc
    ∑ k ∈ Finset.Ico 1 n,
        Real.sin (2 * Real.pi * (j + 1) * k / n) *
          Real.cot (Real.pi * k / n) =
      ∑ k ∈ Finset.Ico 1 n,
        (1 + Real.cos (2 * Real.pi * (j + 1) * k / n) +
          2 * ∑ l ∈ Finset.range j,
            Real.cos (2 * Real.pi * (l + 1) * k / n)) := by
              apply Finset.sum_congr rfl
              intro k hk
              exact hpoint k hk
    _ = (n : ℝ) - 2 * (j + 1) := by
      rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
      have hjpos : 0 < j + 1 := by omega
      have hcosj := sum_cos_Ico n (j + 1) hn hjpos hj
      norm_num at hcosj
      rw [hcosj]
      have hinner :
          ∑ k ∈ Finset.Ico 1 n,
              (2 * ∑ l ∈ Finset.range j,
                Real.cos (2 * Real.pi * (l + 1) * k / n)) =
            -2 * j := by
        rw [← Finset.mul_sum]
        rw [Finset.sum_comm]
        have hfreq (l : ℕ) (hl : l ∈ Finset.range j) :
            ∑ k ∈ Finset.Ico 1 n,
                Real.cos (2 * Real.pi * (l + 1) * k / n) = -1 := by
          have hlj : l < j := Finset.mem_range.mp hl
          simpa [Nat.cast_add, Nat.cast_one] using
            sum_cos_Ico n (l + 1) hn (by omega) (by omega)
        calc
          2 * ∑ l ∈ Finset.range j, ∑ k ∈ Finset.Ico 1 n,
              Real.cos (2 * Real.pi * (l + 1) * k / n) =
              2 * ∑ l ∈ Finset.range j, (-1 : ℝ) := by
                congr 1
                apply Finset.sum_congr rfl
                intro l hl
                exact hfreq l hl
          _ = -2 * j := by simp
      rw [hinner]
      have hn1 : 1 ≤ n := by omega
      simp [Nat.cast_sub hn1]
      ring

/-- The conventional positive-frequency finite cotangent Fourier identity. -/
theorem sum_cot_sin (n m : ℕ) (hm : 0 < m) (hmn : m < n) :
    ∑ k ∈ Finset.Ico 1 n,
        Real.sin (2 * Real.pi * m * k / n) * Real.cot (Real.pi * k / n) =
      (n : ℝ) - 2 * m := by
  obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : m ≠ 0)
  simpa [Nat.cast_succ] using sum_cot_sin_succ n j (by omega) (by omega)

private theorem cot_pair (n k : ℕ) (hn : 0 < n) (hk : k ∈ Finset.Ico 1 n) :
    Real.cot (Real.pi * k / n) +
      Real.cot (Real.pi * ((n - k : ℕ) : ℝ) / n) = 0 := by
  have hk' := Finset.mem_Ico.mp hk
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast (ne_of_gt hn)
  have hangle : Real.pi * ((n - k : ℕ) : ℝ) / n =
      Real.pi - Real.pi * k / n := by
    rw [Nat.cast_sub (by omega : k ≤ n)]
    field_simp
  rw [hangle, Real.cot_eq_cos_div_sin, Real.cot_eq_cos_div_sin,
    Real.cos_pi_sub, Real.sin_pi_sub]
  ring

/-- Cotangents at the nonzero equally spaced points cancel in opposite pairs. -/
theorem sum_cot (n : ℕ) (hn : 0 < n) :
    ∑ k ∈ Finset.Ico 1 n, Real.cot (Real.pi * k / n) = 0 := by
  apply Finset.sum_involution (fun k _ => n - k)
  · intro k hk
    exact cot_pair n k hn hk
  · intro k hk hcot heq
    have hpair := cot_pair n k hn hk
    rw [heq] at hpair
    have : Real.cot (Real.pi * k / n) = 0 := by linarith
    exact hcot this
  · intro k hk
    simp only [Finset.mem_Ico] at hk ⊢
    omega
  · intro k hk
    simp only [Finset.mem_Ico] at hk
    omega

end Research
