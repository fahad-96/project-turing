import OddGaussSum.DFT

open scoped BigOperators

namespace OddGaussSum

noncomputable section

private def pairCount (n : ℕ) : ℕ :=
  ∑ i ∈ Finset.range n, (Finset.Ico (i + 1) n).card

private def pairIndexSum (n : ℕ) : ℕ :=
  ∑ i ∈ Finset.range n, ∑ j ∈ Finset.Ico (i + 1) n, (i + j)

private theorem pairCount_succ (n : ℕ) :
    pairCount (n + 1) = pairCount n + n := by
  rw [pairCount, pairCount, Finset.sum_range_succ]
  simp only [Finset.Ico_self, Finset.card_empty, add_zero]
  rw [show (∑ i ∈ Finset.range n, (Finset.Ico (i + 1) (n + 1)).card) =
      ∑ i ∈ Finset.range n, ((Finset.Ico (i + 1) n).card + 1) by
    apply Finset.sum_congr rfl
    intro i hi
    simp only [Finset.mem_range] at hi
    simp only [Nat.card_Ico]
    omega]
  rw [Finset.sum_add_distrib]
  simp

private theorem pairCount_eq (n : ℕ) :
    2 * pairCount n = n * (n - 1) := by
  induction n with
  | zero => simp [pairCount]
  | succ n ih =>
      rw [pairCount_succ]
      cases n with
      | zero => simp [pairCount]
      | succ n =>
          simp only [Nat.add_sub_cancel] at ih ⊢
          nlinarith

private theorem pairIndexSum_succ (n : ℕ) :
    pairIndexSum (n + 1) = pairIndexSum n +
      (∑ i ∈ Finset.range n, (i + n)) := by
  rw [pairIndexSum, pairIndexSum, Finset.sum_range_succ]
  simp only [Finset.Ico_self, Finset.sum_empty, add_zero]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  have hin : i + 1 ≤ n := by simpa using hi
  rw [Finset.sum_Ico_succ_top hin]

private theorem pairIndexSum_eq (n : ℕ) :
    2 * pairIndexSum n = n * (n - 1) ^ 2 := by
  induction n with
  | zero => simp [pairIndexSum]
  | succ n ih =>
      rw [pairIndexSum_succ, Nat.mul_add, ih]
      have hsum : 2 * (∑ i ∈ Finset.range n, (i + n)) =
          n * (3 * n - 1) := by
        have hr := Finset.sum_range_id_mul_two n
        rw [Finset.sum_add_distrib]
        simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
        cases n with
        | zero => simp
        | succ n =>
            simp only [Nat.add_sub_cancel] at hr ⊢
            have h3 : 3 * (n + 1) - 1 = 3 * n + 2 := by omega
            rw [h3]
            ring_nf at hr ⊢
            nlinarith
      cases n with
      | zero => simp [pairIndexSum]
      | succ n =>
          simp only [Nat.add_sub_cancel] at ih hsum ⊢
          have h3 : 3 * (n + 1) - 1 = 3 * n + 2 := by omega
          rw [h3] at hsum
          ring_nf at ih hsum ⊢
          nlinarith

private theorem pairCount_odd (m : ℕ) :
    pairCount (2 * m + 1) = (2 * m + 1) * m := by
  have := pairCount_eq (2 * m + 1)
  have hsub : 2 * m + 1 - 1 = 2 * m := by omega
  rw [hsub] at this
  nlinarith

private theorem pairIndexSum_odd (m : ℕ) :
    pairIndexSum (2 * m + 1) = 2 * (2 * m + 1) * m ^ 2 := by
  have := pairIndexSum_eq (2 * m + 1)
  have hsub : 2 * m + 1 - 1 = 2 * m := by omega
  rw [hsub] at this
  nlinarith

private def root (n : ℕ) (i : ℕ) : ℂ :=
  Complex.exp (2 * Real.pi * Complex.I * (i : ℂ) / n)

private theorem root_eq_stdAddChar (n : ℕ) [NeZero n] (i : Fin n) :
    root n i = ZMod.stdAddChar (ZMod.finEquiv n i) := by
  cases n with
  | zero => exact (NeZero.ne 0 rfl).elim
  | succ n =>
      rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]
      rfl

private theorem natCast_val_eq_finEquiv (n : ℕ) [NeZero n] (i : Fin n) :
    (i.val : ZMod n) = ZMod.finEquiv n i := by
  have hv : (ZMod.finEquiv n i).val = i.val := by
    cases n with
    | zero => exact (NeZero.ne 0 rfl).elim
    | succ n => rfl
  rw [← hv, ZMod.natCast_zmod_val]

private theorem fourierMatrix_det_eq_vandermonde (n : ℕ) [NeZero n] :
    (fourierMatrix n).det = (Matrix.vandermonde (fun i : Fin n => root n i)).det := by
  let e : Fin n ≃ ZMod n := (ZMod.finEquiv n).toEquiv
  let V := Matrix.vandermonde (fun i : Fin n => root n i)
  have hmat : Matrix.reindex e e V = fourierMatrix n := by
    ext i j
    rw [Matrix.reindex_apply]
    change V (e.symm i) (e.symm j) = ZMod.stdAddChar (i * j)
    rw [show V (e.symm i) (e.symm j) =
        root n (e.symm i) ^ (e.symm j).val by
      simp [V, Matrix.vandermonde_apply]]
    rw [root_eq_stdAddChar]
    rw [← AddChar.map_nsmul_eq_pow]
    congr 1
    change (e.symm j).val • (ZMod.finEquiv n (e.symm i)) = i * j
    rw [show (e.symm j).val • (ZMod.finEquiv n (e.symm i)) =
        ((e.symm j).val : ZMod n) * (ZMod.finEquiv n (e.symm i)) by
      exact nsmul_eq_mul _ _, natCast_val_eq_finEquiv]
    change e (e.symm j) * e (e.symm i) = i * j
    rw [e.apply_symm_apply, e.apply_symm_apply]
    ring
  rw [← hmat, Matrix.det_reindex_self]

private theorem root_sub_factor (n i j : ℕ) (hn : 0 < n) (hij : i < j) :
    root n j - root n i =
      Complex.I *
        Complex.exp (((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I) *
        (2 * Real.sin (Real.pi * ((j - i : ℕ) : ℝ) / n) : ℝ) := by
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast (ne_of_gt hn)
  let a : ℝ := Real.pi * (i + j) / n
  let b : ℝ := Real.pi * ((j - i : ℕ) : ℝ) / n
  change root n j - root n i =
    Complex.I * Complex.exp ((a : ℂ) * Complex.I) * (2 * Real.sin b : ℝ)
  have hj : 2 * (Real.pi : ℂ) * Complex.I * (j : ℂ) / n =
      (a : ℂ) * Complex.I + (b : ℂ) * Complex.I := by
    have this : (((j - i : ℕ) : ℂ) + ((i + j : ℕ) : ℂ)) =
        2 * (j : ℂ) := by norm_cast; omega
    calc
      _ = (Real.pi : ℂ) * Complex.I / n * (2 * (j : ℂ)) := by ring
      _ = (Real.pi : ℂ) * Complex.I / n *
          (((i + j : ℕ) : ℂ) + ((j - i : ℕ) : ℂ)) := by
            congr 1
            rw [add_comm, this]
      _ = _ := by simp only [a, b]; push_cast; ring
  have hi : 2 * (Real.pi : ℂ) * Complex.I * (i : ℂ) / n =
      (a : ℂ) * Complex.I + ((-b : ℝ) : ℂ) * Complex.I := by
    have this : (((i + j : ℕ) : ℂ) - ((j - i : ℕ) : ℂ)) =
        2 * (i : ℂ) := by
      have hnat : (i + j : ℕ) = 2 * i + (j - i) := by omega
      exact_mod_cast (by omega : (i + j : ℤ) - (j - i : ℕ) = 2 * i)
    calc
      _ = (Real.pi : ℂ) * Complex.I / n * (2 * (i : ℂ)) := by ring
      _ = (Real.pi : ℂ) * Complex.I / n *
          (((i + j : ℕ) : ℂ) - ((j - i : ℕ) : ℂ)) := by rw [this]
      _ = _ := by simp only [a, b]; push_cast; ring
  rw [root, root, hj, hi, Complex.exp_add, Complex.exp_add]
  simp_rw [Complex.exp_mul_I]
  simp [Complex.ofReal_cos, Complex.ofReal_sin,
    Complex.cos_neg, Complex.sin_neg]
  ring

private theorem root_sub_positive_factor (n i j : ℕ) (hn : 0 < n)
    (hij : i < j) (hjn : j < n) :
    0 < 2 * Real.sin (Real.pi * ((j - i : ℕ) : ℝ) / n) := by
  have hdiff : 0 < ((j - i : ℕ) : ℝ) := by
    exact_mod_cast Nat.sub_pos_of_lt hij
  have hdiffn : ((j - i : ℕ) : ℝ) < n := by
    exact_mod_cast (lt_of_le_of_lt (Nat.sub_le j i) hjn)
  have harg0 : 0 < Real.pi * ((j - i : ℕ) : ℝ) / n := by positivity
  have hargpi : Real.pi * ((j - i : ℕ) : ℝ) / n < Real.pi := by
    apply (div_lt_iff₀ (show (0 : ℝ) < n by exact_mod_cast hn)).2
    nlinarith [Real.pi_pos]
  have hs := Real.sin_pos_of_pos_of_lt_pi harg0 hargpi
  positivity

private theorem vandermonde_det_eq_pairProd (n : ℕ) :
    (Matrix.vandermonde (fun i : Fin n => root n i)).det =
      ∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
        (root n j - root n i) := by
  rw [Matrix.det_vandermonde]
  change (∏ i ∈ (Finset.univ : Finset (Fin n)),
      ∏ j ∈ Finset.Ioi i, (root n j - root n i)) = _
  refine Finset.prod_bij' (fun i _ => i.val)
      (fun i hi => ⟨i, by simpa using hi⟩) ?_ ?_ ?_ ?_ ?_
  · intro i _
    simp
  · intro i hi
    simpa using hi
  · intro i _
    rfl
  · intro i hi
    simp only [Finset.mem_range] at hi
    rfl
  · intro i _
    refine Finset.prod_bij' (fun j _ => j.val)
        (fun j hj => ⟨j, by
          simp only [Finset.mem_Ico] at hj
          exact hj.2⟩) ?_ ?_ ?_ ?_ ?_
    · intro j hj
      simp only [Finset.mem_Ioi] at hj
      simp only [Finset.mem_Ico]
      omega
    · intro j hj
      simp only [Finset.mem_Ico] at hj
      simp only [Finset.mem_Ioi]
      exact hj.1
    · intro j _
      rfl
    · intro j hj
      simp only [Finset.mem_Ico] at hj
      rfl
    · intro j _
      rfl

private def positiveFactor (n : ℕ) : ℝ :=
  ∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
    2 * Real.sin (Real.pi * ((j - i : ℕ) : ℝ) / n)

private theorem positiveFactor_pos (n : ℕ) (hn : 0 < n) :
    0 < positiveFactor n := by
  apply Finset.prod_pos
  intro i hi
  apply Finset.prod_pos
  intro j hj
  simp only [Finset.mem_Ico] at hj
  exact root_sub_positive_factor n i j hn hj.1 hj.2

private theorem prod_exp_eq_exp_sum {α : Type*} (s : Finset α) (f : α → ℂ) :
    (∏ x ∈ s, Complex.exp (f x)) = Complex.exp (∑ x ∈ s, f x) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih => simp [ha, ih, Complex.exp_add]

private theorem pair_exp_product (n m : ℕ) (hn : n = 2 * m + 1) :
    (∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
      Complex.exp ((((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I))) = 1 := by
  have hn0 : (n : ℂ) ≠ 0 := by
    exact_mod_cast (Nat.ne_of_gt (by omega : 0 < n))
  rw [show (∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
      Complex.exp ((((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I))) =
      ∏ i ∈ Finset.range n, Complex.exp
        (∑ j ∈ Finset.Ico (i + 1) n,
          (((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I)) by
    apply Finset.prod_congr rfl
    intro i _
    exact prod_exp_eq_exp_sum _ _]
  rw [prod_exp_eq_exp_sum]
  have hsum : (∑ i ∈ Finset.range n,
      ∑ j ∈ Finset.Ico (i + 1) n, (i + j)) = 2 * n * m ^ 2 := by
    change pairIndexSum n = 2 * n * m ^ 2
    rw [hn, pairIndexSum_odd]
  rw [show (∑ i ∈ Finset.range n,
      ∑ j ∈ Finset.Ico (i + 1) n,
        (((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I)) =
      (m ^ 2 : ℕ) * (2 * (Real.pi : ℂ) * Complex.I) by
    calc
      _ = ∑ i ∈ Finset.range n, ∑ j ∈ Finset.Ico (i + 1) n,
          (((i + j : ℕ) : ℂ) * ((Real.pi : ℂ) / n * Complex.I)) := by
            apply Finset.sum_congr rfl
            intro i _
            apply Finset.sum_congr rfl
            intro j _
            push_cast
            ring
      _ = (((∑ i ∈ Finset.range n,
          ∑ j ∈ Finset.Ico (i + 1) n, (i + j) : ℕ) : ℂ) *
          ((Real.pi : ℂ) / n * Complex.I)) := by
            simp_rw [← Finset.sum_mul]
            push_cast
            rfl
      _ = _ := by rw [hsum]; push_cast; field_simp]
  rw [Complex.exp_nat_mul]
  norm_num

private theorem vandermonde_det_phase (m : ℕ) :
    (Matrix.vandermonde (fun i : Fin (2 * m + 1) => root (2 * m + 1) i)).det =
      Complex.I ^ ((2 * m + 1) * m) * (positiveFactor (2 * m + 1) : ℂ) := by
  let n := 2 * m + 1
  have hn : 0 < n := by omega
  rw [vandermonde_det_eq_pairProd]
  have hfactor : (∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
      (root n j - root n i)) =
      ∏ i ∈ Finset.range n, ∏ j ∈ Finset.Ico (i + 1) n,
        (Complex.I *
          Complex.exp ((((Real.pi * (i + j) / n : ℝ) : ℂ) * Complex.I)) *
          (2 * Real.sin (Real.pi * ((j - i : ℕ) : ℝ) / n) : ℝ)) := by
    apply Finset.prod_congr rfl
    intro i hi
    apply Finset.prod_congr rfl
    intro j hj
    simp only [Finset.mem_Ico] at hj
    exact root_sub_factor n i j hn hj.1
  rw [hfactor]
  simp_rw [Finset.prod_mul_distrib]
  rw [show (∏ i ∈ Finset.range n, ∏ _j ∈ Finset.Ico (i + 1) n,
      Complex.I) = Complex.I ^ (n * m) by
    simp_rw [Finset.prod_const]
    rw [Finset.prod_pow_eq_pow_sum]
    change Complex.I ^ pairCount n = Complex.I ^ (n * m)
    rw [pairCount_odd m]]
  rw [pair_exp_product n m rfl]
  simp [positiveFactor, n]

theorem normalizedFourierMatrix_det (m : ℕ) :
    (normalizedFourierMatrix (2 * m + 1)).det =
      Complex.I ^ ((2 * m + 1) * m) := by
  let n := 2 * m + 1
  let r : ℝ := Real.sqrt n
  have hn : 0 < n := by omega
  have hr : 0 < r := Real.sqrt_pos.2 (by exact_mod_cast hn)
  have hdetF : (fourierMatrix n).det =
      Complex.I ^ (n * m) * (positiveFactor n : ℂ) := by
    rw [fourierMatrix_det_eq_vandermonde]
    exact vandermonde_det_phase m
  have hdetA : (normalizedFourierMatrix n).det =
      Complex.I ^ (n * m) * ((positiveFactor n / r ^ n : ℝ) : ℂ) := by
    rw [normalizedFourierMatrix, Matrix.det_smul, hdetF]
    rw [ZMod.card]
    simp only [r]
    push_cast
    field_simp
    ring
  let t : ℝ := positiveFactor n / r ^ n
  have ht : 0 < t := div_pos (positiveFactor_pos n hn) (pow_pos hr n)
  have hfour := congrArg Matrix.det (normalizedFourierMatrix_fourth n)
  rw [Matrix.det_pow, Matrix.det_one] at hfour
  rw [hdetA] at hfour
  have ht4c : ((t : ℂ) ^ 4) = 1 := by
    have hi4 : (Complex.I ^ (n * m)) ^ 4 = 1 := by
      rw [← pow_mul]
      rw [show n * m * 4 = 4 * (n * m) by ring, pow_mul]
      norm_num
    rw [mul_pow, hi4, one_mul] at hfour
    exact hfour
  have ht4 : t ^ 4 = 1 := by exact_mod_cast ht4c
  have ht1 : t = 1 := by nlinarith [sq_nonneg (t ^ 2 - 1)]
  simpa [n, t, ht1] using hdetA

theorem normalizedFourierMatrix_det_of_eq (n m : ℕ) [NeZero n]
    (hn : n = 2 * m + 1) :
    (normalizedFourierMatrix n).det = Complex.I ^ (n * m) := by
  subst n
  exact normalizedFourierMatrix_det m

end

end OddGaussSum
