# The choose congruence and curve cardinality

This project contains kernel-checked Lean 4/Mathlib proofs of the exact
`TuringTask.choose_modEq` and `TuringTask.card_curve` statements from
`TuringTask/Basic.lean`. The root task file was not edited.

`Answer/Basic.lean` and `Answer/CharacterProof.lean` contain the previously
proved character-sum prerequisites. `Answer/Remaining.lean` proves the two
requested theorems. `Answer/ExactCheck.lean` restates both target signatures as
examples and applies the resulting theorems, providing an explicit signature
check.

The choose proof casts the character sum to `ZMod p`, applies Euler's
criterion, expands `(x^3-x)^(p/2)`, and evaluates every finite-field power sum.
The latter evaluation is proved from cyclicity of `(ZMod p)ˣ`: all exponents
except `p-1` vanish, while the `p-1` term is `-1`. The prior square and mod-8
character-sum theorems then determine the integral sign and produce the stated
congruence.

The curve proof counts each fiber in the second coordinate with
`quadraticChar_card_sqrts`, obtaining `p + csum p 1`, and substitutes the same
signed character-sum identity.

It is configured for the supplied offline environment, with Mathlib at
`/opt/mathlib4`. Build it there with:

```sh
lean-offline-init
lake build
lake env lean Answer/ExactCheck.lean
```

The local `/opt/mathlib4` dependency means the archive requires the supplied
Lean/Mathlib environment; it is not self-contained on an arbitrary machine.
These commands use only the supplied local toolchain and dependencies. The
proof contains no `sorry`, `admit`, `native_decide`, or custom axioms.
