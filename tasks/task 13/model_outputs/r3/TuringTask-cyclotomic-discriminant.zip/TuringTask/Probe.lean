import Mathlib

open Lean Elab Command

elab "#findnames" s:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if n.toString.toLower.contains s.getString.toLower then
      logInfo m!"{n}"

elab "#find2" s:str t:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    let x := n.toString.toLower
    if x.contains s.getString.toLower && x.contains t.getString.toLower then
      logInfo m!"{n}"

#find2 "discr" "integral"
#find2 "discr" "adjoin"
#find2 "discr" "basis"
