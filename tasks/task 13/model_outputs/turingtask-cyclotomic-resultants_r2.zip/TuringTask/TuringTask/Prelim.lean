import Mathlib

/-!
# Auxiliary results for resultants and discriminants of cyclotomic polynomials

This file develops the machinery used in `TuringTask.Basic`.

The strategy throughout is to pass from `ℤ` to `ℂ`, where `cyclotomic n ℂ` splits with roots
exactly the primitive `n`-th roots of unity, and so a resultant `Res(Φ_n, g)` becomes the
product `∏_{ζ primitive n-th root} g(ζ)`.

The main combinatorial engine is `TTAux.prod_prim_pow`: for `k ∣ M`, raising to the power
`M / k` maps the primitive `M`-th roots onto the primitive `k`-th roots, and it does so
exactly `φ M / φ k`-to-one.  This is proved by transporting the statement to the reduction
homomorphism `(ZMod M)ˣ → (ZMod k)ˣ`, which is a surjection of finite groups, hence has
uniform fibres.
-/

open Polynomial Finset Nat

namespace TTAux

/-- The ring homomorphism `ℤ → ℂ`. -/
noncomputable abbrev toC : ℤ →+* ℂ := Int.castRingHom ℂ

/-! ### Products over primitive roots of unity -/

/-- Two powers of a primitive `M`-th root of unity agree exactly when the exponents are
congruent mod `M`. -/
theorem prim_pow_eq_iff {M : ℕ} (hM : M ≠ 0) {ζ₀ : ℂ} (h : IsPrimitiveRoot ζ₀ M) (a b : ℕ) :
    ζ₀ ^ a = ζ₀ ^ b ↔ a ≡ b [MOD M] := by
  have hfin : IsOfFinOrder ζ₀ := h.isOfFinOrder hM
  rw [hfin.pow_eq_pow_iff_modEq, ← h.eq_orderOf]

/-- A product over the primitive `M`-th roots of unity in `ℂ` may be reindexed by the unit
group of `ZMod M`, via `a ↦ ζ₀ ^ a.val` for any fixed primitive `M`-th root `ζ₀`. -/
theorem prod_prim_eq_prod_units {M : ℕ} [NeZero M] {ζ₀ : ℂ} (h : IsPrimitiveRoot ζ₀ M)
    {Mo : Type*} [CommMonoid Mo] (F : ℂ → Mo) :
    ∏ ζ ∈ primitiveRoots M ℂ, F ζ = ∏ a : (ZMod M)ˣ, F (ζ₀ ^ ((a : ZMod M).val)) := by
  have hM : 0 < M := NeZero.pos M
  symm
  refine Finset.prod_bij (fun a _ => ζ₀ ^ ((a : ZMod M).val)) ?_ ?_ ?_ ?_
  · intro a _
    exact (mem_primitiveRoots hM).2 (h.pow_of_coprime _ (ZMod.val_coe_unit_coprime a))
  · intro a _ b _ hab
    exact Units.ext (ZMod.val_injective M
      (h.pow_inj (ZMod.val_lt (a : ZMod M)) (ZMod.val_lt (b : ZMod M)) hab))
  · intro ξ hξ
    obtain ⟨i, hiM, hic, hiξ⟩ := (h.isPrimitiveRoot_iff).1 ((mem_primitiveRoots hM).1 hξ)
    refine ⟨ZMod.unitOfCoprime i hic, Finset.mem_univ _, ?_⟩
    rw [← hiξ]
    congr 1
    simp [ZMod.unitOfCoprime, ZMod.val_natCast_of_lt hiM]
  · intro a _
    rfl

/-- Compatibility of `a ↦ ζ₀ ^ a.val` with the reduction map `(ZMod M)ˣ → (ZMod k)ˣ`:
raising to the power `M / k` corresponds to reducing the index modulo `k`. -/
theorem pow_val_unitsMap {M k : ℕ} [NeZero M] (hk : k ∣ M) {ζ₀ : ℂ}
    (h : IsPrimitiveRoot ζ₀ M) (a : (ZMod M)ˣ) :
    (ζ₀ ^ ((a : ZMod M).val)) ^ (M / k)
      = (ζ₀ ^ (M / k)) ^ (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k).val) := by
  haveI hkne : NeZero k := ⟨by
    rintro rfl
    exact (NeZero.ne M) (Nat.eq_zero_of_zero_dvd hk)⟩
  have hcast : (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k)) = ((a : ZMod M).val : ZMod k) := by
    rw [ZMod.unitsMap_val, ZMod.natCast_val]
  have h2 : (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k)).val ≡ (a : ZMod M).val [MOD k] := by
    rw [Nat.ModEq, ← ZMod.natCast_eq_natCast_iff', ZMod.natCast_val, ZMod.cast_id, hcast]
  have hMk : k * (M / k) = M := Nat.mul_div_cancel' hk
  rw [← pow_mul, ← pow_mul, prim_pow_eq_iff (NeZero.ne M) h]
  have step : (a : ZMod M).val * (M / k)
      ≡ (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k)).val * (M / k) [MOD k * (M / k)] :=
    Nat.ModEq.mul_right' (M / k) h2.symm
  rw [hMk] at step
  calc (a : ZMod M).val * (M / k)
      ≡ (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k)).val * (M / k) [MOD M] := step
    _ = (M / k) * (((ZMod.unitsMap hk a : (ZMod k)ˣ) : ZMod k)).val := by ring

/-! ### Fibres of a surjection of finite groups -/

/-- All fibres of a surjective homomorphism of finite groups have the same cardinality, namely
`|G| / |H|`. -/
theorem card_fiber {G H : Type*} [Group G] [Group H] [Fintype G] [Fintype H] [DecidableEq H]
    (ψ : G →* H) (hψ : Function.Surjective ψ) (c : H) :
    #{a : G | ψ a = c} * Fintype.card H = Fintype.card G := by
  classical
  have hsum : Fintype.card G = ∑ x : H, #{a : G | ψ a = x} := by
    rw [← Finset.card_univ]
    exact Finset.card_eq_sum_card_fiberwise (fun a _ => Finset.mem_univ (ψ a))
  have heq : ∀ x : H, #{a : G | ψ a = x} = #{a : G | ψ a = c} := fun x =>
    MonoidHom.card_fiber_eq_of_mem_range ψ (hψ x) (hψ c)
  rw [hsum, Finset.sum_congr rfl (fun x _ => heq x), Finset.sum_const, Finset.card_univ,
    smul_eq_mul, mul_comm]

/-- Pulling a product back along a surjective homomorphism of finite groups raises it to the
power `|G| / |H|`. -/
theorem prod_comp_surjective {G H : Type*} {Mo : Type*} [Group G] [Group H] [Fintype G]
    [Fintype H] [DecidableEq H] [CommMonoid Mo] (ψ : G →* H) (hψ : Function.Surjective ψ)
    (f : H → Mo) :
    ∏ a : G, f (ψ a) = (∏ c : H, f c) ^ (Fintype.card G / Fintype.card H) := by
  classical
  have hcard : Fintype.card H ≠ 0 := Fintype.card_ne_zero
  have key : ∀ c : H, #{a : G | ψ a = c} = Fintype.card G / Fintype.card H := by
    intro c
    have h := card_fiber ψ hψ c
    rw [← h, Nat.mul_div_cancel _ (Nat.pos_of_ne_zero hcard)]
  calc ∏ a : G, f (ψ a)
      = ∏ c : H, ∏ a ∈ {a : G | ψ a = c}, f (ψ a) :=
        (Finset.prod_fiberwise (κ := H) Finset.univ ψ (fun a => f (ψ a))).symm
    _ = ∏ c : H, f c ^ (Fintype.card G / Fintype.card H) := by
        refine Finset.prod_congr rfl (fun c _ => ?_)
        rw [Finset.prod_congr rfl (fun a ha => ?_), Finset.prod_const, key c]
        simp only [Finset.mem_filter] at ha
        rw [ha.2]
    _ = (∏ c : H, f c) ^ (Fintype.card G / Fintype.card H) := by rw [Finset.prod_pow]

/-! ### The main counting lemma -/

/-- **Main counting lemma.** For `k ∣ M`, the map `ζ ↦ ζ ^ (M / k)` sends the primitive `M`-th
roots of unity onto the primitive `k`-th roots of unity, uniformly `φ M / φ k`-to-one.  Hence a
product of `F (ζ ^ (M / k))` over the primitive `M`-th roots is the product of `F` over the
primitive `k`-th roots, raised to the power `φ M / φ k`. -/
theorem prod_prim_pow {M k : ℕ} [NeZero M] (hk : k ∣ M) {Mo : Type*} [CommMonoid Mo]
    (F : ℂ → Mo) :
    ∏ ζ ∈ primitiveRoots M ℂ, F (ζ ^ (M / k))
      = (∏ ξ ∈ primitiveRoots k ℂ, F ξ) ^ (M.totient / k.totient) := by
  classical
  haveI hkne : NeZero k := ⟨by
    rintro rfl
    exact (NeZero.ne M) (Nat.eq_zero_of_zero_dvd hk)⟩
  obtain ⟨ζ₀, hζ₀⟩ : ∃ z : ℂ, IsPrimitiveRoot z M :=
    ⟨_, Complex.isPrimitiveRoot_exp M (NeZero.ne M)⟩
  have hξ₀ : IsPrimitiveRoot (ζ₀ ^ (M / k)) k :=
    hζ₀.pow (NeZero.pos M) (Nat.div_mul_cancel hk).symm
  rw [prod_prim_eq_prod_units hζ₀ (fun ζ => F (ζ ^ (M / k))), prod_prim_eq_prod_units hξ₀ F,
    Finset.prod_congr rfl (fun a _ => by rw [pow_val_unitsMap hk hζ₀ a]),
    prod_comp_surjective (ZMod.unitsMap hk) (ZMod.unitsMap_surjective hk)
      (fun c : (ZMod k)ˣ => F ((ζ₀ ^ (M / k)) ^ ((c : ZMod k).val))),
    ZMod.card_units_eq_totient, ZMod.card_units_eq_totient]

/-- Raising to a power coprime to `k` permutes the primitive `k`-th roots of unity, so it does
not change products over them. -/
theorem prod_prim_pow_coprime {k j : ℕ} [NeZero k] (hj : Nat.Coprime j k)
    {Mo : Type*} [CommMonoid Mo] (F : ℂ → Mo) :
    ∏ ξ ∈ primitiveRoots k ℂ, F (ξ ^ j) = ∏ ξ ∈ primitiveRoots k ℂ, F ξ := by
  set e := IsPrimitiveRoot.primitiveRootsPowEquivOfCoprime (R := ℂ) hj with he
  rw [← Finset.prod_attach (primitiveRoots k ℂ) (fun ξ => F (ξ ^ j)),
    ← Finset.prod_attach (primitiveRoots k ℂ) (fun ξ => F ξ)]
  refine Fintype.prod_equiv e _ _ ?_
  intro x
  have hx : ((e x : primitiveRoots k ℂ) : ℂ) = (x : ℂ) ^ j := by rw [he]; simp
  rw [hx]

/-! ### Resultants against cyclotomic polynomials -/

/-- The resultant of `cyclotomic M ℤ` with `g`, viewed in `ℂ`, is the product of `g` over the
primitive `M`-th roots of unity. -/
theorem res_eq_prod (M : ℕ) (hM : 0 < M) (g : ℤ[X]) :
    ((Polynomial.resultant (cyclotomic M ℤ) g : ℤ) : ℂ) =
      ∏ ζ ∈ primitiveRoots M ℂ, Polynomial.eval ζ (g.map toC) := by
  haveI : NeZero ((M : ℕ) : ℂ) := ⟨by simpa using (Nat.cast_ne_zero (R := ℂ)).2 hM.ne'⟩
  have hd : (cyclotomic M ℂ).natDegree = (cyclotomic M ℤ).natDegree := by
    simp [natDegree_cyclotomic]
  have h2 := resultant_map_map (f := cyclotomic M ℤ) (g := g)
      (m := (cyclotomic M ℤ).natDegree) (n := g.natDegree) toC
  rw [map_cyclotomic] at h2
  have h4 := resultant_eq_prod_eval (cyclotomic M ℂ) (g.map toC) g.natDegree natDegree_map_le
    (IsAlgClosed.splits _)
  rw [hd, h2, (cyclotomic.monic M ℂ).leadingCoeff, one_pow, one_mul,
    cyclotomic.roots_eq_primitiveRoots_val] at h4
  exact h4

/-- `Res(Φ_M, X ^ N - 1)`, as a complex number, is `∏_{ζ} (ζ ^ N - 1)` over the primitive
`M`-th roots of unity `ζ`. -/
theorem res_X_pow_sub_one_eq_prod (M N : ℕ) (hM : 0 < M) :
    ((Polynomial.resultant (cyclotomic M ℤ) (X ^ N - 1) : ℤ) : ℂ) =
      ∏ ζ ∈ primitiveRoots M ℂ, (ζ ^ N - 1) := by
  rw [res_eq_prod M hM]
  exact Finset.prod_congr rfl (fun ζ _ => by simp)

/-- The value `Φ_k(1)` over `ℂ`, as a product over the primitive `k`-th roots of unity. -/
theorem eval_one_cyclotomic_eq_prod (k : ℕ) [NeZero k] :
    Polynomial.eval 1 (cyclotomic k ℂ) = ∏ ξ ∈ primitiveRoots k ℂ, (1 - ξ) := by
  obtain ⟨ζ, hζ⟩ : ∃ z : ℂ, IsPrimitiveRoot z k :=
    ⟨_, Complex.isPrimitiveRoot_exp k (NeZero.ne k)⟩
  rw [cyclotomic_eq_prod_X_sub_primitiveRoots hζ, eval_prod]
  exact Finset.prod_congr rfl (fun ξ _ => by simp)

end TTAux

namespace TTAux

/-! ### Values of cyclotomic polynomials at `1` -/

/-- `Φ_{p^k}(1) = p` for a prime `p` and `k ≥ 1`. -/
theorem eval_one_cyclotomic_prime_pow' {p k : ℕ} (hp : p.Prime) (hk : 1 ≤ k) :
    Polynomial.eval 1 (cyclotomic (p ^ k) ℤ) = p := by
  haveI : Fact p.Prime := ⟨hp⟩
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  exact eval_one_cyclotomic_prime_pow j

/-- `Φ_N(1) = 1` when `N ≠ 1` is not a prime power. -/
theorem eval_one_cyclotomic_of_not_isPrimePow {N : ℕ} (hN : N ≠ 1) (h : ¬ IsPrimePow N) :
    Polynomial.eval 1 (cyclotomic N ℤ) = 1 := by
  apply eval_one_cyclotomic_not_prime_pow
  intro p hp k hk
  refine h ⟨p, k, hp.prime, ?_, hk⟩
  rcases Nat.eq_zero_or_pos k with rfl | hk0
  · simp at hk
    exact absurd hk.symm hN
  · exact hk0

/-- If `k ∣ e`, `k ≠ 1` and `k` is not a prime power, then neither is `e`, and `e ≠ 1`. -/
theorem not_isPrimePow_of_dvd {k e : ℕ} (hke : k ∣ e) (hk1 : k ≠ 1) (hk : ¬ IsPrimePow k) :
    ¬ IsPrimePow e ∧ e ≠ 1 := by
  constructor
  · rintro ⟨p, a, hp, ha, rfl⟩
    obtain ⟨b, hb, rfl⟩ := (Nat.dvd_prime_pow hp.nat_prime).1 hke
    refine hk ⟨p, b, hp, ?_, rfl⟩
    rcases Nat.eq_zero_or_pos b with rfl | h
    · simp at hk1
    · exact h
  · rintro rfl
    exact hk1 (Nat.dvd_one.1 hke)

/-! ### Elementary arithmetic -/

/-- `∑_{i=0}^{E} φ(p^i) = p^E`. -/
theorem sum_totient_prime_pow {p : ℕ} (hp : p.Prime) (E : ℕ) :
    ∑ i ∈ Finset.range (E + 1), (p ^ i).totient = p ^ E := by
  induction E with
  | zero => simp
  | succ E ih =>
    rw [Finset.sum_range_succ, ih, Nat.totient_prime_pow hp (Nat.succ_pos E), Nat.succ_sub_one]
    have h1 : p ^ E + p ^ E * (p - 1) = p ^ E * (1 + (p - 1)) := by ring
    rw [h1, Nat.add_sub_cancel' hp.one_lt.le, pow_succ, mul_comm]

/-- `φ(mp * p^v) = φ(mp) * φ(p^v)` when `p ∤ mp`. -/
theorem totient_mul_prime_pow {p mp : ℕ} (hp : p.Prime) (hmp : ¬ p ∣ mp) (v : ℕ) :
    (mp * p ^ v).totient = mp.totient * (p ^ v).totient :=
  Nat.totient_mul (Nat.Coprime.pow_right v ((Nat.Prime.coprime_iff_not_dvd hp).2 hmp).symm)

/-- `φ(p^A * mp) / φ(p^b) = p^(A-b) * φ(mp)` when `p ∤ mp` and `1 ≤ b ≤ A`. -/
theorem totient_div_prime_pow {p A b mp : ℕ} (hp : p.Prime) (hmp : ¬ p ∣ mp)
    (hb : 1 ≤ b) (hbA : b ≤ A) :
    (p ^ A * mp).totient / (p ^ b).totient = p ^ (A - b) * mp.totient := by
  have hcop : Nat.Coprime (p ^ A) mp :=
    Nat.Coprime.pow_left A ((Nat.Prime.coprime_iff_not_dvd hp).2 hmp)
  rw [Nat.totient_mul hcop, Nat.totient_prime_pow hp (by omega),
    Nat.totient_prime_pow hp (by omega)]
  have hp1 : 0 < p - 1 := by have := hp.two_le; omega
  have hsplit : p ^ (A - 1) = p ^ (b - 1) * p ^ (A - b) := by
    rw [← pow_add]; congr 1; omega
  have hrw : p ^ (A - 1) * (p - 1) * mp.totient
      = (p ^ (b - 1) * (p - 1)) * (p ^ (A - b) * mp.totient) := by rw [hsplit]; ring
  rw [hrw, Nat.mul_div_cancel_left _ (Nat.mul_pos (pow_pos hp.pos _) hp1)]

/-- `(p^A * mp) / (mp * p^v) = p^(A-v)` for `v ≤ A` and `mp > 0`. -/
theorem div_prime_pow_mul {p A mp v : ℕ} (hp : p.Prime) (hmp0 : 0 < mp) (hv : v ≤ A) :
    (p ^ A * mp) / (mp * p ^ v) = p ^ (A - v) := by
  rw [Nat.mul_comm (p ^ A) mp, Nat.mul_comm mp (p ^ v), Nat.mul_comm (p ^ v) mp,
    Nat.mul_div_mul_left _ _ hmp0, Nat.pow_div hv hp.pos]

/-- The divisors of `p^E * mp` that are multiples of `mp` are exactly the `mp * p^v`
for `v ≤ E`. -/
theorem prod_divisors_filter_dvd {p E mp : ℕ} (hp : p.Prime) (hmp0 : 0 < mp)
    {M : Type*} [CommMonoid M] (f : ℕ → M) :
    ∏ d ∈ (p ^ E * mp).divisors with mp ∣ d, f d
      = ∏ v ∈ Finset.range (E + 1), f (mp * p ^ v) := by
  symm
  refine Finset.prod_nbij' (fun v => mp * p ^ v) (fun d => (d / mp).factorization p) ?_ ?_ ?_ ?_ ?_
  · intro v hv
    simp only [Finset.mem_range] at hv
    have hdvd : mp * p ^ v ∣ p ^ E * mp := by
      refine ⟨p ^ (E - v), ?_⟩
      have h : p ^ v * p ^ (E - v) = p ^ E := by rw [← pow_add]; congr 1; omega
      calc p ^ E * mp = mp * (p ^ v * p ^ (E - v)) := by rw [h]; ring
        _ = mp * p ^ v * p ^ (E - v) := by ring
    simp only [Finset.mem_filter, Nat.mem_divisors]
    exact ⟨⟨hdvd, Nat.mul_ne_zero (pow_ne_zero E hp.pos.ne') hmp0.ne'⟩, Dvd.intro _ rfl⟩
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    obtain ⟨⟨hdvd, -⟩, hmd⟩ := hd
    obtain ⟨t, rfl⟩ := hmd
    have ht : t ∣ p ^ E := by
      have h1 : mp * t ∣ p ^ E * mp := hdvd
      rw [mul_comm (p ^ E) mp] at h1
      exact (mul_dvd_mul_iff_left hmp0.ne').1 h1
    obtain ⟨v, hv, rfl⟩ := (Nat.dvd_prime_pow hp).1 ht
    simp only [Finset.mem_range]
    rw [Nat.mul_div_cancel_left _ hmp0, Nat.Prime.factorization_pow hp]
    simp
    omega
  · intro v hv
    rw [Nat.mul_div_cancel_left _ hmp0, Nat.Prime.factorization_pow hp]
    simp
  · intro d hd
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    obtain ⟨⟨hdvd, -⟩, hmd⟩ := hd
    obtain ⟨t, rfl⟩ := hmd
    have ht : t ∣ p ^ E := by
      have h1 : mp * t ∣ p ^ E * mp := hdvd
      rw [mul_comm (p ^ E) mp] at h1
      exact (mul_dvd_mul_iff_left hmp0.ne').1 h1
    obtain ⟨v, hv, rfl⟩ := (Nat.dvd_prime_pow hp).1 ht
    rw [Nat.mul_div_cancel_left _ hmp0, Nat.Prime.factorization_pow hp]
    simp
  · intro v hv; rfl

end TTAux

namespace TTAux

/-! ### The key arithmetic identity

For `g ∣ m` with `g < m`, writing `k = m / g`:
`∏_{d ∣ g} Φ_{m/d}(1) ^ φ(d) = Φ_k(1) ^ (φ(m) / φ(k))`.

This is the engine behind Theorems 1 and 2.  Both sides are `1` unless `k` is a prime power
`p ^ b`, in which case both sides are a power of `p`, and the exponents match by an explicit
computation with `φ`.
-/

/-- If `d ∣ p^(A-b) · mp` but `mp ∤ d`, then `(p^A · mp)/d` is divisible by `p` and by some
prime `q ≠ p`, hence is not a prime power, so `Φ` of it evaluates to `1` at `1`. -/
theorem eval_one_cyclotomic_div_eq_one {p A b mp d : ℕ} (hp : p.Prime) (hmp : ¬ p ∣ mp)
    (hmp0 : 0 < mp) (hb : 1 ≤ b) (hbA : b ≤ A) (hd : d ∣ p ^ (A - b) * mp) (hnd : ¬ mp ∣ d) :
    Polynomial.eval 1 (cyclotomic ((p ^ A * mp) / d) ℤ) = 1 := by
  obtain ⟨v, t, hv, ht, rfl⟩ : ∃ v t, v ≤ A - b ∧ t ∣ mp ∧ d = p ^ v * t := by
    obtain ⟨a, c, ha, hc, rfl⟩ := exists_dvd_and_dvd_of_dvd_mul hd
    obtain ⟨v, hv, rfl⟩ := (Nat.dvd_prime_pow hp).1 ha
    exact ⟨v, c, hv, hc, rfl⟩
  have hvA : v ≤ A := by omega
  have ht0 : 0 < t := Nat.pos_of_dvd_of_pos ht hmp0
  have hmd : (p ^ A * mp) / (p ^ v * t) = p ^ (A - v) * (mp / t) := by
    rw [← Nat.div_mul_div_comm (pow_dvd_pow p hvA) ht, Nat.pow_div hvA hp.pos]
  rw [hmd]
  have htne : t ≠ mp := by rintro rfl; exact hnd ⟨p ^ v, by ring⟩
  have hq : 1 < mp / t := by
    have h1 : mp / t ≠ 1 := fun h => htne (by
      have := Nat.div_mul_cancel ht; rw [h, one_mul] at this; exact this)
    have h2 : 0 < mp / t := Nat.div_pos (Nat.le_of_dvd hmp0 ht) ht0
    omega
  obtain ⟨q, hq', hqd⟩ := Nat.exists_prime_and_dvd (by omega : mp / t ≠ 1)
  have hqmp : q ∣ mp := hqd.trans (Nat.div_dvd_of_dvd ht)
  have hqp : q ≠ p := by rintro rfl; exact hmp hqmp
  have hpdvd : p ∣ p ^ (A - v) * (mp / t) := Dvd.dvd.mul_right (dvd_pow_self p (by omega)) _
  have hqdvd : q ∣ p ^ (A - v) * (mp / t) := Dvd.dvd.mul_left hqd _
  refine eval_one_cyclotomic_of_not_isPrimePow ?_ ?_
  · intro h1
    exact Nat.Prime.one_lt hp |>.ne' (Nat.dvd_one.1 (h1 ▸ hpdvd))
  · rintro ⟨r, a, hr, ha, hra⟩
    have hrp : p = r := (Nat.prime_dvd_prime_iff_eq hp hr.nat_prime).1
      (Nat.Prime.dvd_of_dvd_pow hp (hra ▸ hpdvd))
    have hrq : q = r := (Nat.prime_dvd_prime_iff_eq hq' hr.nat_prime).1
      (Nat.Prime.dvd_of_dvd_pow hq' (hra ▸ hqdvd))
    exact hqp (hrq.trans hrp.symm)

/-- The key identity, in the case where `m / g` is the prime power `p ^ b`. -/
theorem key_identity_prime_pow {p A b mp : ℕ} (hp : p.Prime) (hmp : ¬ p ∣ mp) (hmp0 : 0 < mp)
    (hb : 1 ≤ b) (hbA : b ≤ A) :
    ∏ d ∈ (p ^ (A - b) * mp).divisors,
        Polynomial.eval 1 (cyclotomic ((p ^ A * mp) / d) ℤ) ^ d.totient
      = (p : ℤ) ^ ((p ^ A * mp).totient / (p ^ b).totient) := by
  set E := A - b with hE
  rw [← Finset.prod_filter_mul_prod_filter_not (p ^ E * mp).divisors (fun d => mp ∣ d)]
  have h2 : ∏ d ∈ (p ^ E * mp).divisors with ¬ mp ∣ d,
      Polynomial.eval 1 (cyclotomic ((p ^ A * mp) / d) ℤ) ^ d.totient = 1 := by
    refine Finset.prod_eq_one (fun d hd => ?_)
    simp only [Finset.mem_filter, Nat.mem_divisors] at hd
    rw [eval_one_cyclotomic_div_eq_one hp hmp hmp0 hb hbA hd.1.1 hd.2, one_pow]
  rw [h2, mul_one, prod_divisors_filter_dvd hp hmp0
    (fun d => Polynomial.eval 1 (cyclotomic ((p ^ A * mp) / d) ℤ) ^ d.totient)]
  have hterm : ∀ v ∈ Finset.range (E + 1),
      Polynomial.eval 1 (cyclotomic ((p ^ A * mp) / (mp * p ^ v)) ℤ) ^ (mp * p ^ v).totient
        = (p : ℤ) ^ (mp.totient * (p ^ v).totient) := by
    intro v hv
    simp only [Finset.mem_range] at hv
    have hvA : v ≤ A := by omega
    rw [div_prime_pow_mul hp hmp0 hvA, eval_one_cyclotomic_prime_pow' hp (by omega),
      totient_mul_prime_pow hp hmp v]
  rw [Finset.prod_congr rfl hterm, Finset.prod_pow_eq_pow_sum]
  congr 1
  rw [← Finset.mul_sum, sum_totient_prime_pow hp E, totient_div_prime_pow hp hmp hb hbA]
  ring

/-- The key identity, in the case where `m / g` is not a prime power (and `≠ 1`). -/
theorem key_identity_not_prime_pow {m g : ℕ} (hg : g ∣ m) (hk1 : m / g ≠ 1)
    (hk : ¬ IsPrimePow (m / g)) :
    ∏ d ∈ g.divisors, Polynomial.eval 1 (cyclotomic (m / d) ℤ) ^ d.totient
      = Polynomial.eval 1 (cyclotomic (m / g) ℤ) ^ (m.totient / (m / g).totient) := by
  rw [eval_one_cyclotomic_of_not_isPrimePow hk1 hk, one_pow]
  refine Finset.prod_eq_one (fun d hd => ?_)
  rw [Nat.mem_divisors] at hd
  obtain ⟨h1, h2⟩ := not_isPrimePow_of_dvd (Nat.div_dvd_div_left hg hd.1) hk1 hk
  rw [eval_one_cyclotomic_of_not_isPrimePow h2 h1, one_pow]

/-- **The key identity.**  For `g ∣ m` with `m / g ≠ 1`:
`∏_{d ∣ g} Φ_{m/d}(1) ^ φ(d) = Φ_{m/g}(1) ^ (φ m / φ(m/g))`. -/
theorem key_identity {m g : ℕ} (hm : 0 < m) (hg : g ∣ m) (hk1 : m / g ≠ 1) :
    ∏ d ∈ g.divisors, Polynomial.eval 1 (cyclotomic (m / d) ℤ) ^ d.totient
      = Polynomial.eval 1 (cyclotomic (m / g) ℤ) ^ (m.totient / (m / g).totient) := by
  by_cases hk : IsPrimePow (m / g)
  · -- `m / g = p ^ b`
    obtain ⟨p, b, hp, hb, hpb⟩ := hk
    have hp' : p.Prime := hp.nat_prime
    -- decompose `m = p ^ A * mp` with `p ∤ mp`
    set A := m.factorization p with hA
    set mp := m / p ^ A with hmp
    have hmp' : ¬ p ∣ mp := not_dvd_ordCompl hp' hm.ne'
    have hmp0 : 0 < mp := Nat.ordCompl_pos p hm.ne'
    have hmeq : m = p ^ A * mp := (ordProj_mul_ordCompl_eq_self m p).symm
    have hbA : b ≤ A := by
      refine (Nat.Prime.pow_dvd_iff_le_factorization hp' hm.ne').1 ?_
      rw [hpb]
      exact Nat.div_dvd_of_dvd hg
    have hgeq : g = p ^ (A - b) * mp := by
      have hg' : g = m / (m / g) := (Nat.div_div_self hg hm.ne').symm
      rw [hg', ← hpb]
      conv_lhs => rw [hmeq]
      rw [Nat.mul_comm (p ^ A) mp, Nat.mul_comm (p ^ (A - b)) mp,
        Nat.mul_div_assoc mp (pow_dvd_pow p hbA), Nat.pow_div hbA hp'.pos]
    have hmg : m / g = p ^ b := hpb.symm
    have hgoal := key_identity_prime_pow (p := p) (A := A) (b := b) (mp := mp)
      hp' hmp' hmp0 hb hbA
    rw [← hmeq, ← hgeq] at hgoal
    rw [hgoal, hmg, eval_one_cyclotomic_prime_pow' hp' hb]
  · exact key_identity_not_prime_pow hg hk1 hk

end TTAux

namespace TTAux

/-! ### Resultants of two cyclotomic polynomials

We first compute `Res(Φ_m, X^N - 1)` for every `N` (this is Theorem 5 in the general form),
then use the factorisation `X^N - 1 = ∏_{d ∣ N} Φ_d` and strong induction on `N` to peel off
the individual factors `Res(Φ_m, Φ_n)`.
-/

/-- `Res(Φ_m, X^N - 1) = Φ_{m/gcd(m,N)}(1) ^ (φ m / φ(m/gcd(m,N)))` for `m ≥ 3` and any `N`. -/
theorem resultant_cyclotomic_X_pow_sub_one' (m N : ℕ) (hm : 3 ≤ m) :
    Polynomial.resultant (cyclotomic m ℤ) (X ^ N - 1)
      = Polynomial.eval 1 (cyclotomic (m / Nat.gcd m N) ℤ) ^
          (m.totient / (m / Nat.gcd m N).totient) := by
  have hm0 : 0 < m := by omega
  haveI : NeZero m := ⟨hm0.ne'⟩
  set d := Nat.gcd m N with hd
  set k := m / d with hk
  have hdpos : 0 < d := Nat.gcd_pos_of_pos_left N hm0
  have hdn : d ∣ m := Nat.gcd_dvd_left m N
  have hdm : d ∣ N := Nat.gcd_dvd_right m N
  have hkn : k ∣ m := Nat.div_dvd_of_dvd hdn
  have hkpos : 0 < k := Nat.div_pos (Nat.le_of_dvd hm0 hdn) hdpos
  haveI : NeZero k := ⟨hkpos.ne'⟩
  have hnk : m / k = d := Nat.div_div_self hdn hm0.ne'
  have hcop : Nat.Coprime (N / d) k := by
    rw [hk]; exact (Nat.coprime_div_gcd_div_gcd hdpos).symm
  apply (Int.cast_injective (α := ℂ))
  rw [res_X_pow_sub_one_eq_prod m N hm0]
  have hRHS : ((Polynomial.eval 1 (cyclotomic k ℤ) : ℤ) : ℂ)
      = ∏ ξ ∈ primitiveRoots k ℂ, (1 - ξ) := by
    rw [← eval_one_cyclotomic_eq_prod k, ← map_cyclotomic k (Int.castRingHom ℂ),
      Polynomial.eval_map]
    simp [Polynomial.eval₂_at_one]
  rw [Int.cast_pow, hRHS]
  have hstep : ∀ ζ : ℂ, ζ ^ N = (ζ ^ (m / k)) ^ (N / d) := by
    intro ζ
    rw [hnk, ← pow_mul, Nat.mul_div_cancel' hdm]
  rw [Finset.prod_congr rfl (fun ζ _ => by rw [hstep ζ]),
    prod_prim_pow hkn (fun w => w ^ (N / d) - 1),
    prod_prim_pow_coprime hcop (fun w => w - 1)]
  have hcard : (primitiveRoots k ℂ).card = k.totient := Complex.card_primitiveRoots k
  have hdvd : k.totient ∣ m.totient := Nat.totient_dvd_of_dvd hkn
  have hmul : k.totient * (m.totient / k.totient) = m.totient := Nat.mul_div_cancel' hdvd
  have heven : Even m.totient := Nat.totient_even hm
  have hsplit : ∏ ξ ∈ primitiveRoots k ℂ, (ξ - 1)
      = (-1 : ℂ) ^ k.totient * ∏ ξ ∈ primitiveRoots k ℂ, (1 - ξ) := by
    calc ∏ ξ ∈ primitiveRoots k ℂ, (ξ - 1)
        = ∏ ξ ∈ primitiveRoots k ℂ, ((-1) * (1 - ξ)) :=
          Finset.prod_congr rfl (fun ξ _ => by ring)
      _ = (-1 : ℂ) ^ (primitiveRoots k ℂ).card * ∏ ξ ∈ primitiveRoots k ℂ, (1 - ξ) := by
          rw [Finset.prod_mul_distrib, Finset.prod_const]
      _ = _ := by rw [hcard]
  rw [hsplit, mul_pow, ← pow_mul, hmul, heven.neg_one_pow, one_mul]

/-- Multiplicativity of the resultant along `X^N - 1 = ∏_{d ∣ N} Φ_d`. -/
theorem resultant_X_pow_sub_one_eq_prod_resultant (m N : ℕ) (hN : 0 < N) :
    Polynomial.resultant (cyclotomic m ℤ) (X ^ N - 1)
      = ∏ d ∈ N.divisors, Polynomial.resultant (cyclotomic m ℤ) (cyclotomic d ℤ) := by
  rw [← prod_cyclotomic_eq_X_pow_sub_one hN ℤ]
  exact resultant_prod_right N.divisors (cyclotomic m ℤ) (fun d => cyclotomic d ℤ) _ le_rfl
    (by simp [(cyclotomic.monic _ ℤ).leadingCoeff])

/-- The conjectured value of `Res(Φ_m, Φ_n)`: it is `Φ_{m/n}(1) ^ φ(n)` if `n ∣ m`, and `1`
otherwise. -/
noncomputable def claimed (m n : ℕ) : ℤ :=
  if n ∣ m then Polynomial.eval 1 (cyclotomic (m / n) ℤ) ^ n.totient else 1

/-- `Φ_e(1) ≠ 0` for `e ≠ 1`, hence `claimed m n ≠ 0` for `n ≠ m`. -/
theorem claimed_ne_zero {m n : ℕ} (hnm : n ≠ m) : claimed m n ≠ 0 := by
  unfold claimed
  split_ifs with h
  · refine pow_ne_zero _ ?_
    have hne : m / n ≠ 1 := fun h1 => hnm (by
      have := Nat.div_mul_cancel h; rw [h1, one_mul] at this; exact this)
    by_cases hp : IsPrimePow (m / n)
    · obtain ⟨p, b, hp', hb, he⟩ := hp
      rw [← he, eval_one_cyclotomic_prime_pow' hp'.nat_prime hb]
      exact_mod_cast hp'.nat_prime.pos.ne'
    · rw [eval_one_cyclotomic_of_not_isPrimePow hne hp]; norm_num
  · norm_num

/-- The product of the conjectured values over the divisors of `N` matches the value of
`Res(Φ_m, X^N - 1)` computed above. -/
theorem prod_claimed (m N : ℕ) (hm : 0 < m) (hN : 0 < N) (hmN : ¬ m ∣ N) :
    ∏ d ∈ N.divisors, claimed m d
      = Polynomial.eval 1 (cyclotomic (m / Nat.gcd m N) ℤ) ^
          (m.totient / (m / Nat.gcd m N).totient) := by
  have hstep : ∏ d ∈ N.divisors, claimed m d = ∏ d ∈ (Nat.gcd m N).divisors,
      Polynomial.eval 1 (cyclotomic (m / d) ℤ) ^ d.totient := by
    rw [← Finset.prod_filter_mul_prod_filter_not N.divisors (fun d => d ∣ m)]
    have h2 : ∏ d ∈ N.divisors with ¬ d ∣ m, claimed m d = 1 := by
      refine Finset.prod_eq_one (fun d hd => ?_)
      simp only [Finset.mem_filter] at hd
      simp [claimed, hd.2]
    rw [h2, mul_one]
    have hset : (N.divisors.filter (fun d => d ∣ m)) = (Nat.gcd m N).divisors := by
      ext d
      simp only [Finset.mem_filter, Nat.mem_divisors]
      exact ⟨fun ⟨⟨h1, h2⟩, h3⟩ => ⟨Nat.dvd_gcd h3 h1, Nat.gcd_ne_zero_right h2⟩,
        fun ⟨h1, h2⟩ => ⟨⟨h1.trans (Nat.gcd_dvd_right m N), hN.ne'⟩,
          h1.trans (Nat.gcd_dvd_left m N)⟩⟩
    rw [hset]
    refine Finset.prod_congr rfl (fun d hd => ?_)
    rw [Nat.mem_divisors] at hd
    simp [claimed, hd.1.trans (Nat.gcd_dvd_left m N)]
  rw [hstep]
  refine key_identity hm (Nat.gcd_dvd_left m N) ?_
  intro h
  have hg : Nat.gcd m N = m := by
    have := Nat.div_mul_cancel (Nat.gcd_dvd_left m N)
    rw [h, one_mul] at this
    exact this
  exact hmN (hg ▸ Nat.gcd_dvd_right m N)

/-- **The computation of `Res(Φ_m, Φ_n)` for `n < m`**, by strong induction on `n`. -/
theorem resultant_cyclotomic_eq_claimed {m : ℕ} (hm : 3 ≤ m) :
    ∀ n : ℕ, 0 < n → n < m →
      Polynomial.resultant (cyclotomic m ℤ) (cyclotomic n ℤ) = claimed m n := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
    intro hn hnm
    have hm0 : 0 < m := by omega
    have hmn : ¬ m ∣ n := fun h => absurd (Nat.le_of_dvd hn h) (by omega)
    have hA : ∏ d ∈ n.divisors, Polynomial.resultant (cyclotomic m ℤ) (cyclotomic d ℤ)
        = ∏ d ∈ n.divisors, claimed m d := by
      rw [← resultant_X_pow_sub_one_eq_prod_resultant m n hn,
        resultant_cyclotomic_X_pow_sub_one' m n hm, ← prod_claimed m n hm0 hn hmn]
    rw [← Nat.cons_self_properDivisors hn.ne', Finset.prod_cons, Finset.prod_cons] at hA
    have hB : ∏ d ∈ n.properDivisors, Polynomial.resultant (cyclotomic m ℤ) (cyclotomic d ℤ)
        = ∏ d ∈ n.properDivisors, claimed m d := by
      refine Finset.prod_congr rfl (fun d hd => ?_)
      rw [Nat.mem_properDivisors] at hd
      exact ih d hd.2 (Nat.pos_of_dvd_of_pos hd.1 hn) (by omega)
    rw [hB] at hA
    have hne : ∏ d ∈ n.properDivisors, claimed m d ≠ 0 := by
      refine Finset.prod_ne_zero_iff.2 (fun d hd => ?_)
      rw [Nat.mem_properDivisors] at hd
      exact claimed_ne_zero (by omega)
    exact mul_right_cancel₀ hne hA

end TTAux

namespace TTAux

/-! ### Towards the discriminant

We prove the second arithmetic identity
`∏_{d ∣ n, d < n} Φ_{n/d}(1) ^ φ(d) = ∏_{p ∣ n} p ^ (φ(n)/(p-1))`,
which converts the "correction factor" appearing in Theorem 3 into a product over the
prime factors of `n`.
-/

/-- `(p ^ (b+1)).minFac = p` for `p` prime. -/
theorem minFac_prime_pow {p b : ℕ} (hp : p.Prime) : (p ^ (b + 1)).minFac = p := by
  have h2 : p ^ (b + 1) ≠ 1 := by
    intro h
    rcases (Nat.pow_eq_one).1 h with h' | h'
    · exact hp.one_lt.ne' h'
    · omega
  have hq := Nat.minFac_prime h2
  exact (Nat.prime_dvd_prime_iff_eq hq hp).1 (Nat.Prime.dvd_of_dvd_pow hq (Nat.minFac_dvd _))

/-- The prime power divisors of `n` are exactly the `p ^ a` with `p` a prime factor of `n`
and `1 ≤ a ≤ v_p(n)`. -/
theorem prod_primePow_divisors (n : ℕ) (hn : 0 < n) {M : Type*} [CommMonoid M] (f : ℕ → M) :
    ∏ e ∈ n.divisors with IsPrimePow e, f e
      = ∏ x ∈ n.primeFactors.sigma (fun p => Finset.Icc 1 (n.factorization p)), f (x.1 ^ x.2) := by
  refine Finset.prod_nbij' (fun e => (⟨e.minFac, e.factorization e.minFac⟩ : Σ _ : ℕ, ℕ))
    (fun x => x.1 ^ x.2) ?_ ?_ ?_ ?_ ?_
  · intro e he
    simp only [Finset.mem_filter, Nat.mem_divisors] at he
    obtain ⟨⟨hedvd, -⟩, hpp⟩ := he
    have hmf : e.minFac ^ (e.factorization e.minFac) = e := hpp.minFac_pow_factorization_eq
    have he1 : e ≠ 1 := by rintro rfl; exact not_isPrimePow_one hpp
    have hep : (e.minFac).Prime := Nat.minFac_prime he1
    simp only [Finset.mem_sigma, Nat.mem_primeFactors, Finset.mem_Icc]
    refine ⟨⟨hep, (Nat.minFac_dvd e).trans hedvd, hn.ne'⟩, ?_, ?_⟩
    · by_contra hc
      have hz : e.factorization e.minFac = 0 := by omega
      rw [hz, pow_zero] at hmf
      exact he1 hmf.symm
    · rw [← Nat.Prime.pow_dvd_iff_le_factorization hep hn.ne', hmf]
      exact hedvd
  · intro x hx
    simp only [Finset.mem_sigma, Nat.mem_primeFactors, Finset.mem_Icc] at hx
    obtain ⟨⟨hp, hpn, -⟩, ha1, ha2⟩ := hx
    simp only [Finset.mem_filter, Nat.mem_divisors]
    exact ⟨⟨(Nat.Prime.pow_dvd_iff_le_factorization hp hn.ne').2 ha2, hn.ne'⟩,
      ⟨x.1, x.2, hp.prime, by omega, rfl⟩⟩
  · intro e he
    simp only [Finset.mem_filter, Nat.mem_divisors] at he
    exact he.2.minFac_pow_factorization_eq
  · rintro ⟨p, a⟩ hx
    simp only [Finset.mem_sigma, Nat.mem_primeFactors, Finset.mem_Icc] at hx
    obtain ⟨⟨hp, -, -⟩, ha1, -⟩ := hx
    obtain ⟨b, rfl⟩ : ∃ b, a = b + 1 := ⟨a - 1, by omega⟩
    simp only [Sigma.mk.injEq]
    have h1 : (p ^ (b + 1)).minFac = p := minFac_prime_pow hp
    refine ⟨h1, ?_⟩
    rw [h1, Nat.Prime.factorization_pow hp]
    simp
  · intro e he
    simp only [Finset.mem_filter, Nat.mem_divisors] at he
    exact congrArg f he.2.minFac_pow_factorization_eq.symm

/-- Reindexing a product over proper divisors `d` of `n` by `e = n / d`. -/
theorem prod_properDivisors_reindex (n : ℕ) (hn : 0 < n) {M : Type*} [CommMonoid M] (f : ℕ → M) :
    ∏ d ∈ n.properDivisors, f (n / d) = ∏ e ∈ n.divisors.erase 1, f e := by
  refine Finset.prod_nbij' (fun d => n / d) (fun e => n / e) ?_ ?_ ?_ ?_ ?_
  · intro d hd
    rw [Nat.mem_properDivisors] at hd
    rw [Finset.mem_erase, Nat.mem_divisors]
    refine ⟨?_, Nat.div_dvd_of_dvd hd.1, hn.ne'⟩
    intro h1
    have := Nat.div_mul_cancel hd.1
    rw [h1, one_mul] at this
    omega
  · intro e he
    rw [Finset.mem_erase, Nat.mem_divisors] at he
    rw [Nat.mem_properDivisors]
    refine ⟨Nat.div_dvd_of_dvd he.2.1, ?_⟩
    exact Nat.div_lt_self hn (by have := Nat.pos_of_dvd_of_pos he.2.1 hn; omega)
  · intro d hd
    rw [Nat.mem_properDivisors] at hd
    exact Nat.div_div_self hd.1 hn.ne'
  · intro e he
    rw [Finset.mem_erase, Nat.mem_divisors] at he
    exact Nat.div_div_self he.2.1 hn.ne'
  · intro d hd; rfl

/-- `∑_{j < A} φ(p^j m) = φ(p^A m)/(p-1)` for `p ∤ m`, `A ≥ 1`. -/
theorem sum_totient_eq_totient_div {p A m : ℕ} (hp : p.Prime) (hm : ¬ p ∣ m) (hA : 1 ≤ A) :
    ∑ j ∈ Finset.range A, (p ^ j * m).totient = (p ^ A * m).totient / (p - 1) := by
  have hcop : ∀ j, Nat.Coprime (p ^ j) m :=
    fun j => Nat.Coprime.pow_left j ((Nat.Prime.coprime_iff_not_dvd hp).2 hm)
  have h1 : ∑ j ∈ Finset.range A, (p ^ j * m).totient
      = (∑ j ∈ Finset.range A, (p ^ j).totient) * m.totient := by
    rw [Finset.sum_mul]
    exact Finset.sum_congr rfl (fun j _ => Nat.totient_mul (hcop j))
  have h2 : ∑ j ∈ Finset.range A, (p ^ j).totient = p ^ (A - 1) := by
    obtain ⟨B, rfl⟩ : ∃ B, A = B + 1 := ⟨A - 1, by omega⟩
    simpa using sum_totient_prime_pow hp B
  rw [h1, h2, Nat.totient_mul (hcop A), Nat.totient_prime_pow hp (by omega)]
  have hp1 : 0 < p - 1 := by have := hp.two_le; omega
  have hr : p ^ (A - 1) * (p - 1) * m.totient = (p - 1) * (p ^ (A - 1) * m.totient) := by ring
  rw [hr, Nat.mul_div_cancel_left _ hp1]

end TTAux

namespace TTAux

/-- **The second key identity.**
`∏_{d ∣ n, d < n} Φ_{n/d}(1) ^ φ(d) = ∏_{p ∣ n} p ^ (φ(n)/(p-1))`. -/
theorem key_identity_two (n : ℕ) (hn : 0 < n) :
    ∏ d ∈ n.properDivisors, Polynomial.eval 1 (cyclotomic (n / d) ℤ) ^ d.totient
      = ∏ p ∈ n.primeFactors, (p : ℤ) ^ (n.totient / (p - 1)) := by
  -- reindex `d ↦ n / d`
  have step1 : ∏ d ∈ n.properDivisors, Polynomial.eval 1 (cyclotomic (n / d) ℤ) ^ d.totient
      = ∏ e ∈ n.divisors.erase 1, Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient := by
    rw [← prod_properDivisors_reindex n hn
      (fun e => Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient)]
    refine Finset.prod_congr rfl (fun d hd => ?_)
    rw [Nat.mem_properDivisors] at hd
    rw [Nat.div_div_self hd.1 hn.ne']
  -- only prime powers contribute
  have step2 : ∏ e ∈ n.divisors.erase 1, Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient
      = ∏ e ∈ n.divisors with IsPrimePow e,
          Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient := by
    rw [← Finset.prod_filter_mul_prod_filter_not (n.divisors.erase 1) (fun e => IsPrimePow e)]
    have h2 : ∏ e ∈ (n.divisors.erase 1) with ¬ IsPrimePow e,
        Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient = 1 := by
      refine Finset.prod_eq_one (fun e he => ?_)
      simp only [Finset.mem_filter, Finset.mem_erase] at he
      rw [eval_one_cyclotomic_of_not_isPrimePow he.1.1 he.2, one_pow]
    rw [h2, mul_one]
    congr 1
    ext e
    simp only [Finset.mem_filter, Finset.mem_erase]
    constructor
    · rintro ⟨⟨-, h1⟩, h2⟩
      exact ⟨h1, h2⟩
    · rintro ⟨h1, h2⟩
      exact ⟨⟨by rintro rfl; exact not_isPrimePow_one h2, h1⟩, h2⟩
  -- group the prime powers by their prime
  have step3 : ∏ e ∈ n.divisors with IsPrimePow e,
        Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient
      = ∏ p ∈ n.primeFactors, ∏ a ∈ Finset.Icc 1 (n.factorization p),
          (p : ℤ) ^ (n / p ^ a).totient := by
    rw [prod_primePow_divisors n hn
      (fun e => Polynomial.eval 1 (cyclotomic e ℤ) ^ (n / e).totient), Finset.prod_sigma]
    refine Finset.prod_congr rfl (fun p hp => Finset.prod_congr rfl (fun a ha => ?_))
    simp only [Nat.mem_primeFactors] at hp
    simp only [Finset.mem_Icc] at ha
    rw [eval_one_cyclotomic_prime_pow' hp.1 ha.1]
  -- evaluate the inner product for each prime
  have step4 : ∀ p ∈ n.primeFactors,
      ∏ a ∈ Finset.Icc 1 (n.factorization p), (p : ℤ) ^ (n / p ^ a).totient
        = (p : ℤ) ^ (n.totient / (p - 1)) := by
    intro p hp
    simp only [Nat.mem_primeFactors] at hp
    obtain ⟨hp', hpn, -⟩ := hp
    rw [Finset.prod_pow_eq_pow_sum]
    congr 1
    set A := n.factorization p with hA
    have hA1 : 1 ≤ A := by
      rw [hA, ← Nat.Prime.pow_dvd_iff_le_factorization hp' hn.ne', pow_one]
      exact hpn
    set m := n / p ^ A with hm
    have hm' : ¬ p ∣ m := not_dvd_ordCompl hp' hn.ne'
    have hneq : n = p ^ A * m := (ordProj_mul_ordCompl_eq_self n p).symm
    have hdiv : ∀ a ∈ Finset.Icc 1 A, n / p ^ a = p ^ (A - a) * m := by
      intro a ha
      simp only [Finset.mem_Icc] at ha
      conv_lhs => rw [hneq]
      rw [Nat.mul_comm (p ^ A) m, Nat.mul_div_assoc m (pow_dvd_pow p ha.2),
        Nat.pow_div ha.2 hp'.pos, Nat.mul_comm]
    rw [Finset.sum_congr rfl (fun a ha => by rw [hdiv a ha])]
    have hre : ∑ a ∈ Finset.Icc 1 A, (p ^ (A - a) * m).totient
        = ∑ j ∈ Finset.range A, (p ^ j * m).totient := by
      refine Finset.sum_nbij' (fun a => A - a) (fun j => A - j) ?_ ?_ ?_ ?_ ?_
      · intro a ha; simp only [Finset.mem_Icc] at ha; simp only [Finset.mem_range]; omega
      · intro j hj; simp only [Finset.mem_range] at hj; simp only [Finset.mem_Icc]; omega
      · intro a ha; simp only [Finset.mem_Icc] at ha; omega
      · intro j hj; simp only [Finset.mem_range] at hj; omega
      · intro a ha; rfl
    rw [hre, sum_totient_eq_totient_div hp' hm' hA1, ← hneq]
  rw [step1, step2, step3, Finset.prod_congr rfl step4]

end TTAux

namespace TTAux

/-- The product over all primitive `n`-th roots of unity is `1` for `n ≥ 3`. -/
theorem prod_primitiveRoots_eq_one {n : ℕ} [NeZero n] (hn : 3 ≤ n) :
    ∏ ζ ∈ primitiveRoots n ℂ, ζ = 1 := by
  obtain ⟨z, hz⟩ : ∃ z : ℂ, IsPrimitiveRoot z n := ⟨_, Complex.isPrimitiveRoot_exp n (NeZero.ne n)⟩
  have h0 := cyclotomic_eq_prod_X_sub_primitiveRoots hz
  have hev : Polynomial.eval 0 (cyclotomic n ℂ) = 1 := by
    rw [← coeff_zero_eq_eval_zero, cyclotomic_coeff_zero ℂ (by omega)]
  rw [h0, eval_prod] at hev
  simp only [eval_sub, eval_X, eval_C] at hev
  have hcard : (primitiveRoots n ℂ).card = n.totient := Complex.card_primitiveRoots n
  have heven : Even n.totient := Nat.totient_even hn
  have hh : ∏ ζ ∈ primitiveRoots n ℂ, (0 - ζ)
      = (-1 : ℂ) ^ n.totient * ∏ ζ ∈ primitiveRoots n ℂ, ζ := by
    rw [← hcard, ← Finset.prod_const, ← Finset.prod_mul_distrib]
    exact Finset.prod_congr rfl (fun ζ _ => by ring)
  rw [hh, heven.neg_one_pow, one_mul] at hev
  exact hev

/-- Differentiating `X^n - 1 = Φ_n · G` and evaluating at the primitive `n`-th roots of unity
gives `∏_ζ Φ_n'(ζ) · ∏_ζ G(ζ) = n ^ φ(n)`. -/
theorem prod_eval_derivative_mul {n : ℕ} [NeZero n] (hn : 3 ≤ n) :
    (∏ ζ ∈ primitiveRoots n ℂ, Polynomial.eval ζ (derivative (cyclotomic n ℂ)))
      * (∏ ζ ∈ primitiveRoots n ℂ,
          Polynomial.eval ζ (∏ d ∈ n.properDivisors, cyclotomic d ℂ))
      = (n : ℂ) ^ n.totient := by
  have hn0 : 0 < n := by omega
  set G : ℂ[X] := ∏ d ∈ n.properDivisors, cyclotomic d ℂ with hG
  have hFG : (X ^ n - 1 : ℂ[X]) = cyclotomic n ℂ * G := by
    rw [hG, ← prod_cyclotomic_eq_X_pow_sub_one hn0 ℂ, ← Nat.cons_self_properDivisors hn0.ne',
      Finset.prod_cons]
  have hkey : ∀ ζ ∈ primitiveRoots n ℂ,
      Polynomial.eval ζ (derivative (cyclotomic n ℂ)) * Polynomial.eval ζ G
        = (n : ℂ) * ζ ^ (n - 1) := by
    intro ζ hζ
    have hζp : IsPrimitiveRoot ζ n := (mem_primitiveRoots hn0).1 hζ
    haveI : NeZero ((n : ℕ) : ℂ) := ⟨by simpa using (Nat.cast_ne_zero (R := ℂ)).2 hn0.ne'⟩
    have hroot : Polynomial.eval ζ (cyclotomic n ℂ) = 0 := hζp.isRoot_cyclotomic hn0
    have h1 : derivative (X ^ n - 1 : ℂ[X])
        = derivative (cyclotomic n ℂ) * G + cyclotomic n ℂ * derivative G := by
      rw [hFG, derivative_mul]
    have h2 : derivative (X ^ n - 1 : ℂ[X]) = C (n : ℂ) * X ^ (n - 1) := by
      simp [derivative_X_pow]
    apply_fun (Polynomial.eval ζ) at h1
    rw [h2] at h1
    simp only [eval_add, eval_mul, eval_C, eval_pow, eval_X] at h1
    rw [hroot, zero_mul, add_zero] at h1
    exact h1.symm
  rw [← Finset.prod_mul_distrib, Finset.prod_congr rfl hkey, Finset.prod_mul_distrib,
    Finset.prod_const, Complex.card_primitiveRoots, Finset.prod_pow,
    prod_primitiveRoots_eq_one hn, one_pow, mul_one]

/-- The integral form: `Res(Φ_n, Φ_n') · Res(Φ_n, ∏_{d < n} Φ_d) = n ^ φ(n)`. -/
theorem resultant_derivative_mul (n : ℕ) (hn : 3 ≤ n) :
    Polynomial.resultant (cyclotomic n ℤ) (derivative (cyclotomic n ℤ))
      * Polynomial.resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ)
      = (n : ℤ) ^ n.totient := by
  have hn0 : 0 < n := by omega
  haveI : NeZero n := ⟨hn0.ne'⟩
  apply (Int.cast_injective (α := ℂ))
  push_cast
  rw [res_eq_prod n hn0, res_eq_prod n hn0, ← Polynomial.derivative_map, map_cyclotomic,
    Polynomial.map_prod]
  simp only [map_cyclotomic]
  exact prod_eval_derivative_mul hn

/-- `Res(Φ_n, ∏_{d < n} Φ_d) = ∏_{p ∣ n} p ^ (φ(n)/(p-1))`. -/
theorem resultant_prod_properDivisors (n : ℕ) (hn : 3 ≤ n) :
    Polynomial.resultant (cyclotomic n ℤ) (∏ d ∈ n.properDivisors, cyclotomic d ℤ)
      = ∏ p ∈ n.primeFactors, (p : ℤ) ^ (n.totient / (p - 1)) := by
  have hn0 : 0 < n := by omega
  rw [resultant_prod_right n.properDivisors (cyclotomic n ℤ) (fun d => cyclotomic d ℤ) _ le_rfl
    (by simp [(cyclotomic.monic _ ℤ).leadingCoeff])]
  rw [← key_identity_two n hn0]
  refine Finset.prod_congr rfl (fun d hd => ?_)
  rw [Nat.mem_properDivisors] at hd
  rw [resultant_cyclotomic_eq_claimed hn d (Nat.pos_of_dvd_of_pos hd.1 hn0) hd.2]
  unfold claimed
  rw [if_pos hd.1]

end TTAux

namespace TTAux

/-- `(-1)^(d(d-1)/2) = (-1)^(d/2)` for even `d`. -/
theorem neg_one_pow_half {d : ℕ} (hd : Even d) : ((-1 : ℤ)) ^ (d * (d - 1) / 2) = (-1) ^ (d / 2) := by
  obtain ⟨c, rfl⟩ := hd
  have h1 : c + c = 2 * c := by ring
  rw [h1]
  rcases Nat.eq_zero_or_pos c with rfl | hc
  · simp
  · have h2 : 2 * c * (2 * c - 1) / 2 = c * (2 * c - 1) := by
      rw [mul_assoc, Nat.mul_div_cancel_left _ (by norm_num)]
    have h3 : 2 * c / 2 = c := by omega
    rw [h2, h3, pow_mul']
    rw [Odd.neg_one_pow (Nat.odd_iff.2 (by omega : (2 * c - 1) % 2 = 1))]

/-- Mathlib's `resultant_deriv` specialised to the (monic) cyclotomic polynomial. -/
theorem resultant_derivative_cyclotomic (n : ℕ) (hn : 3 ≤ n) :
    Polynomial.resultant (cyclotomic n ℤ) (derivative (cyclotomic n ℤ))
      = (-1) ^ (n.totient * (n.totient - 1) / 2) * Polynomial.discr (cyclotomic n ℤ) := by
  have hd : (cyclotomic n ℤ).natDegree = n.totient := natDegree_cyclotomic n ℤ
  have hpos : 0 < (cyclotomic n ℤ).degree := by
    rw [degree_cyclotomic]
    exact_mod_cast Nat.totient_pos.2 (show 0 < n by omega)
  have hdd : (derivative (cyclotomic n ℤ)).natDegree = n.totient - 1 := by
    rw [Polynomial.natDegree_derivative, hd]
  have key := Polynomial.resultant_deriv (f := cyclotomic n ℤ) hpos
  rw [hd, (cyclotomic.monic n ℤ).leadingCoeff, mul_one] at key
  rw [Polynomial.resultant, hd, hdd]
  exact key

/-- `Res(Φ₂, Φ₁) = -2`.  (Note the sign: this is the exceptional case excluded from
Theorem 2 by the hypothesis `(n, p, k) ≠ (1, 2, 1)`.) -/
theorem resultant_cyclotomic_two_one :
    Polynomial.resultant (cyclotomic 2 ℤ) (cyclotomic 1 ℤ) = -2 := by
  have h1 : (cyclotomic 2 ℤ) = X - C (-1) := by rw [cyclotomic_two]; simp [sub_eq_add_neg]
  have h2 : (cyclotomic 1 ℤ) = X - C 1 := by rw [cyclotomic_one]; simp
  have hd1 : (cyclotomic 2 ℤ).natDegree = 1 := by rw [natDegree_cyclotomic]; decide
  have hd2 : (cyclotomic 1 ℤ).natDegree = 1 := by rw [natDegree_cyclotomic]; decide
  have hle : (X - C (1 : ℤ)).natDegree ≤ 1 := le_of_eq (Polynomial.natDegree_X_sub_C 1)
  have key := Polynomial.resultant_X_sub_C_left (R := ℤ) (g := X - C (1 : ℤ)) (n := 1) (-1) hle
  rw [Polynomial.resultant, hd1, hd2, ← Polynomial.resultant, h1, h2, key]
  simp

/-- `p ^ φ(n)` is never a unit of `ℤ` when `p` is prime and `n ≥ 1`. -/
theorem not_isUnit_prime_pow_totient {p n : ℕ} (hp : p.Prime) (hn : 1 ≤ n) :
    ¬ IsUnit ((p : ℤ) ^ n.totient) := by
  intro hu
  rw [Int.isUnit_iff] at hu
  have h1 : (1 : ℕ) ≤ n.totient := Nat.totient_pos.2 hn
  have h2 : (2 : ℤ) ≤ (p : ℤ) := by exact_mod_cast hp.two_le
  have h3 : (2 : ℤ) ≤ (p : ℤ) ^ n.totient := by
    calc (2 : ℤ) = 2 ^ 1 := by norm_num
      _ ≤ (2 : ℤ) ^ n.totient := pow_le_pow_right₀ (by norm_num) h1
      _ ≤ (p : ℤ) ^ n.totient := pow_le_pow_left₀ (by norm_num) h2 _
  rcases hu with h | h <;> omega

end TTAux
