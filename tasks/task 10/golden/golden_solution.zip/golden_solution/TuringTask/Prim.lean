import Mathlib
import TuringTask.Hcyc

/-!
# Prime divisors of `hcyc n a b`

* `primitive_of_not_dvd`: a prime of `hcyc n a b` that does not divide `n` is primitive.
* `structure_of_dvd`: a prime `q` of `hcyc n a b` that divides `n` gives `n = q ^ k * m` with
  `m ∣ q - 1` and `q ∣ a ^ (n / q) - b ^ (n / q)`.
* `not_sq_dvd_hcyc`: for `n ≥ 3` such a prime divides `hcyc n a b` only once.
-/

open Polynomial Finset

namespace TuringTask

/-! ### Primes of `hcyc n a b` -/

/-- A prime dividing `a ^ n - b ^ n` (with `a, b` coprime, `n > 0`) does not divide `b`. -/
theorem not_dvd_right {n a b q : ℕ} (hq : q.Prime) (hcop : Nat.Coprime a b) (hn : 0 < n)
    (h : (q : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n) : ¬ q ∣ b := by
  intro hqb
  have hqbn : (q : ℤ) ∣ (b : ℤ) ^ n :=
    dvd_pow (Int.natCast_dvd_natCast.mpr hqb) hn.ne'
  have hqa : (q : ℤ) ∣ (a : ℤ) ^ n := by
    have := dvd_add h hqbn
    rwa [sub_add_cancel] at this
  have hqa' : q ∣ a := hq.dvd_of_dvd_pow (n := n) (by exact_mod_cast hqa)
  have h1 : q ∣ Nat.gcd a b := Nat.dvd_gcd hqa' hqb
  rw [Nat.Coprime.gcd_eq_one hcop] at h1
  exact hq.one_lt.ne' (Nat.dvd_one.mp h1)

/-- A prime of `hcyc n a b` that does not divide `n` is a primitive divisor. -/
theorem primitive_of_not_dvd {n a b q : ℕ} (hq : q.Prime) (hb : 0 < b) (hab : b < a)
    (hcop : Nat.Coprime a b) (hn : 0 < n) (hqN : (q : ℤ) ∣ hcyc n a b) (hqn : ¬ q ∣ n) :
    ∀ k : ℕ, 1 ≤ k → k < n → ¬ q ∣ a ^ k - b ^ k := by
  haveI := Fact.mk hq
  have hdiv : (q : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := hqN.trans (hcyc_dvd n a b hn hb)
  have hqb : ¬ q ∣ b := not_dvd_right hq hcop hn hdiv
  have hbq0 : (b : ZMod q) ≠ 0 := by
    rw [Ne, ZMod.natCast_eq_zero_iff]
    exact hqb
  have hN0 : ((hcyc n a b : ℤ) : ZMod q) = 0 := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr hqN
  rw [hcyc_cast n a b hbq0] at hN0
  have hroot : (cyclotomic n (ZMod q)).IsRoot ((a : ZMod q) / b) := by
    rcases mul_eq_zero.mp hN0 with h | h
    · exact absurd h (pow_ne_zero _ hbq0)
    · exact h
  haveI : NeZero (n : ZMod q) := ⟨by rw [Ne, ZMod.natCast_eq_zero_iff]; exact hqn⟩
  have hprim : IsPrimitiveRoot ((a : ZMod q) / b) n := isRoot_cyclotomic_iff.mp hroot
  intro k hk1 hkn hdvd
  have hcast : ((a ^ k - b ^ k : ℕ) : ZMod q) = 0 := (ZMod.natCast_eq_zero_iff _ _).mpr hdvd
  have hle : b ^ k ≤ a ^ k := Nat.pow_le_pow_left hab.le k
  rw [Nat.cast_sub hle, sub_eq_zero] at hcast
  push_cast at hcast
  apply hprim.pow_ne_one_of_pos_of_lt (by omega) hkn
  rw [div_pow, hcast, div_self (pow_ne_zero _ hbq0)]

/-- A prime `q` of `hcyc n a b` that divides `n`: `n = q ^ k * m` with `m ∣ q - 1`, and
`q ∣ a ^ (n / q) - b ^ (n / q)`. -/
theorem structure_of_dvd {n a b q : ℕ} (hq : q.Prime) (hb : 0 < b) (hab : b < a)
    (hcop : Nat.Coprime a b) (hn : 0 < n) (hqN : (q : ℤ) ∣ hcyc n a b) (hqn : q ∣ n) :
    ∃ k m : ℕ, 0 < k ∧ ¬ q ∣ m ∧ n = q ^ k * m ∧ m ∣ q - 1 ∧
      q ∣ a ^ (q ^ (k - 1) * m) - b ^ (q ^ (k - 1) * m) := by
  haveI := Fact.mk hq
  obtain ⟨k, m, hqm, hnkm⟩ := Nat.exists_eq_pow_mul_and_not_dvd hn.ne' q hq.ne_one
  have hk : 0 < k := by
    rcases Nat.eq_zero_or_pos k with h | h
    · rw [h, pow_zero, one_mul] at hnkm
      rw [hnkm] at hqn
      exact absurd hqn hqm
    · exact h
  have hm0 : m ≠ 0 := by
    rintro rfl
    rw [mul_zero] at hnkm
    omega
  have hdiv : (q : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := hqN.trans (hcyc_dvd n a b hn hb)
  have hqb : ¬ q ∣ b := not_dvd_right hq hcop hn hdiv
  have hbq0 : (b : ZMod q) ≠ 0 := by
    rw [Ne, ZMod.natCast_eq_zero_iff]
    exact hqb
  have hN0 : ((hcyc n a b : ℤ) : ZMod q) = 0 := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr hqN
  rw [hcyc_cast n a b hbq0] at hN0
  have hroot : (cyclotomic n (ZMod q)).eval ((a : ZMod q) / b) = 0 := by
    rcases mul_eq_zero.mp hN0 with h | h
    · exact absurd h (pow_ne_zero _ hbq0)
    · exact h
  rw [hnkm, cyclotomic_mul_prime_pow_eq (ZMod q) hqm hk, eval_pow] at hroot
  have hexp : q ^ k - q ^ (k - 1) ≠ 0 := by
    have : q ^ (k - 1) < q ^ k := Nat.pow_lt_pow_right hq.one_lt (by omega)
    omega
  rw [pow_eq_zero_iff hexp] at hroot
  haveI : NeZero (m : ZMod q) := ⟨by rw [Ne, ZMod.natCast_eq_zero_iff]; exact hqm⟩
  have hprim : IsPrimitiveRoot ((a : ZMod q) / b) m := isRoot_cyclotomic_iff.mp hroot
  have hx0 : ((a : ZMod q) / b) ≠ 0 := hprim.ne_zero hm0
  have hmq : m ∣ q - 1 :=
    (hprim.pow_eq_one_iff_dvd (q - 1)).mp (ZMod.pow_card_sub_one_eq_one hx0)
  refine ⟨k, m, hk, hqm, hnkm, hmq, ?_⟩
  have hpow : ((a : ZMod q) / b) ^ (q ^ (k - 1) * m) = 1 :=
    (hprim.pow_eq_one_iff_dvd _).mpr (dvd_mul_left m _)
  rw [div_pow, div_eq_one_iff_eq (pow_ne_zero _ hbq0)] at hpow
  have hle : b ^ (q ^ (k - 1) * m) ≤ a ^ (q ^ (k - 1) * m) := Nat.pow_le_pow_left hab.le _
  rw [← ZMod.natCast_eq_zero_iff, Nat.cast_sub hle, sub_eq_zero]
  push_cast
  exact hpow

theorem odd_sq_mod_four {u : ℕ} (hu : ¬ 2 ∣ u) : u ^ 2 % 4 = 1 := by
  have h : u % 4 = 1 ∨ u % 4 = 3 := by omega
  rcases h with h | h <;> simp [Nat.pow_mod, h]

/-- For `n ≥ 3`, a prime `q` of `hcyc n a b` that divides `n` divides it only once. -/
theorem not_sq_dvd_hcyc {n a b q : ℕ} (hq : q.Prime) (hb : 0 < b) (hab : b < a)
    (hcop : Nat.Coprime a b) (hn3 : 3 ≤ n) (hqN : (q : ℤ) ∣ hcyc n a b) (hqn : q ∣ n) :
    ¬ ((q : ℤ) ^ 2 ∣ hcyc n a b) := by
  haveI := Fact.mk hq
  have hn : 0 < n := by omega
  have hdiv : (q : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := hqN.trans (hcyc_dvd n a b hn hb)
  have hqb : ¬ q ∣ b := not_dvd_right hq hcop hn hdiv
  obtain ⟨k, m, hk, hqm, hnkm, hmq, hdivr⟩ := structure_of_dvd hq hb hab hcop hn hqN hqn
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  rw [Nat.add_sub_cancel] at hdivr
  have hm0 : 0 < m := by
    rcases Nat.eq_zero_or_pos m with h | h
    · rw [h, mul_zero] at hnkm
      omega
    · exact h
  obtain ⟨r, hr⟩ : ∃ r, r = q ^ j * m := ⟨_, rfl⟩
  rw [← hr] at hdivr
  have hnr : n = r * q := by rw [hnkm, hr, pow_succ]; ring
  have hr0 : 0 < r := by rw [hr]; exact Nat.mul_pos (pow_pos hq.pos j) hm0
  have hrn : r < n := by rw [hnr]; nlinarith [hq.two_le]
  have hzy : b ^ r < a ^ r := Nat.pow_lt_pow_left hab hr0.ne'
  -- `hcyc n a b * (a ^ r - b ^ r)` divides `a ^ n - b ^ n`
  have hdvd1 : hcyc n a b * ((a : ℤ) ^ r - (b : ℤ) ^ r) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := by
    rw [← prod_hcyc n a b hn hb, ← prod_hcyc r a b hr0 hb]
    have hnot : n ∉ r.divisors := fun h =>
      absurd (Nat.le_of_dvd hr0 (Nat.dvd_of_mem_divisors h)) (by omega)
    have hsub : insert n r.divisors ⊆ n.divisors := by
      intro d hd
      rcases Finset.mem_insert.mp hd with hd | hd
      · rw [hd]
        exact Nat.mem_divisors_self _ hn.ne'
      · exact Nat.divisors_subset_of_dvd hn.ne' ⟨q, hnr⟩ hd
    rw [← Finset.prod_insert (f := fun d => hcyc d a b) hnot]
    exact Finset.prod_dvd_prod_of_subset _ _ _ hsub
  have hgeom : (∑ i ∈ Finset.range q, ((a : ℤ) ^ r) ^ i * ((b : ℤ) ^ r) ^ (q - 1 - i)) *
      ((a : ℤ) ^ r - (b : ℤ) ^ r) = (a : ℤ) ^ n - (b : ℤ) ^ n := by
    rw [geom_sum₂_mul, ← pow_mul, ← pow_mul, hnr]
  have hD : (a : ℤ) ^ r - (b : ℤ) ^ r ≠ 0 := by
    have : (b : ℤ) ^ r < (a : ℤ) ^ r := by exact_mod_cast hzy
    exact sub_ne_zero.mpr this.ne'
  have hNS : hcyc n a b ∣
      ∑ i ∈ Finset.range q, ((a : ℤ) ^ r) ^ i * ((b : ℤ) ^ r) ^ (q - 1 - i) := by
    rw [← hgeom] at hdvd1
    exact (mul_dvd_mul_iff_right hD).mp hdvd1
  intro hsq
  have hq2 := hsq.trans hNS
  rcases hq.eq_two_or_odd' with hq2' | hodd
  · -- `q = 2`: then `n` is a power of `2`, and `a ^ r + b ^ r ≡ 2 (mod 4)`
    subst hq2'
    have hm1 : m = 1 := by simpa using hmq
    subst hm1
    have hj : j ≠ 0 := by
      rintro rfl
      simp at hnkm
      omega
    obtain ⟨i, rfl⟩ : ∃ i, j = i + 1 := ⟨j - 1, by omega⟩
    have hS2 : ∑ i ∈ Finset.range 2, ((a : ℤ) ^ r) ^ i * ((b : ℤ) ^ r) ^ (2 - 1 - i) =
        (a : ℤ) ^ r + (b : ℤ) ^ r := by
      rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_zero]
      norm_num
      ring
    rw [hS2] at hq2
    have h4 : 4 ∣ a ^ r + b ^ r := by
      have h := hq2
      push_cast at h
      exact_mod_cast h
    have ha2 : ¬ 2 ∣ a := by
      intro h2a
      have h1 : 2 ∣ a ^ r := dvd_pow h2a hr0.ne'
      have h2 : 2 ∣ b ^ r := by omega
      exact hqb (Nat.prime_two.dvd_of_dvd_pow h2)
    have hra : a ^ r % 4 = 1 := by
      rw [hr, mul_one, pow_succ, pow_mul]
      exact odd_sq_mod_four (fun h => ha2 (Nat.prime_two.dvd_of_dvd_pow h))
    have hrb : b ^ r % 4 = 1 := by
      rw [hr, mul_one, pow_succ, pow_mul]
      exact odd_sq_mod_four (fun h => hqb (Nat.prime_two.dvd_of_dvd_pow h))
    omega
  · -- `q` odd: lifting the exponent
    have hcastS : ((∑ i ∈ Finset.range q, (a ^ r) ^ i * (b ^ r) ^ (q - 1 - i) : ℕ) : ℤ) =
        ∑ i ∈ Finset.range q, ((a : ℤ) ^ r) ^ i * ((b : ℤ) ^ r) ^ (q - 1 - i) := by
      push_cast
      rfl
    rw [← hcastS] at hq2
    have hq2N : q ^ 2 ∣ ∑ i ∈ Finset.range q, (a ^ r) ^ i * (b ^ r) ^ (q - 1 - i) := by
      exact_mod_cast hq2
    obtain ⟨S, hS⟩ : ∃ S, S = ∑ i ∈ Finset.range q, (a ^ r) ^ i * (b ^ r) ^ (q - 1 - i) :=
      ⟨_, rfl⟩
    rw [← hS] at hq2N
    have hgeomN : S * (a ^ r - b ^ r) = (a ^ r) ^ q - (b ^ r) ^ q := by
      rw [hS]
      exact geom_sum₂_mul_of_ge hzy.le q
    have hpowlt : (b ^ r) ^ q < (a ^ r) ^ q := Nat.pow_lt_pow_left hzy hq.ne_zero
    have hS0 : S ≠ 0 := by
      intro h0
      rw [h0, zero_mul] at hgeomN
      omega
    have hD0 : a ^ r - b ^ r ≠ 0 := by omega
    have hqa : ¬ q ∣ a ^ r := by
      intro h
      have h1 : q ∣ a ^ r - (a ^ r - b ^ r) := Nat.dvd_sub h hdivr
      rw [Nat.sub_sub_self hzy.le] at h1
      exact hqb (hq.dvd_of_dvd_pow h1)
    have hlte := padicValNat.pow_sub_pow (p := q) hodd hzy hdivr hqa hq.ne_zero
    rw [padicValNat_self, ← hgeomN, padicValNat.mul hS0 hD0] at hlte
    have hv2 : 2 ≤ padicValNat q S := (padicValNat_dvd_iff_le hS0).mp hq2N
    omega

end TuringTask
