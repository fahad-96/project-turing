import Mathlib

/-!
# Fibonacci and Lucas numbers: the identities behind primitive divisors

`luc n = 2 F (n+1) - F n` are the Lucas numbers.  We prove Binet's formula for them,
`L n ^ 2 - 5 F n ^ 2 = 4 (-1)^n`, `F (2n) = F n * L n`, Cassini's identity, the expansion of
`F (q m)` in powers of `F m` (the key to the exponent computations) and `F q ^ 2 = 1 (mod q)`
for primes `q ≠ 5`, hence `q ∣ F (q - 1) F (q + 1)`.
-/

open Real goldenRatio

namespace TuringTask

/-- The Lucas numbers, as integers: `L n = 2 F (n+1) - F n`. -/
def luc (n : ℕ) : ℤ := 2 * (Nat.fib (n + 1) : ℤ) - Nat.fib n

theorem luc_zero : luc 0 = 2 := by simp [luc]

theorem luc_succ (n : ℕ) : luc (n + 1) = (Nat.fib (n + 1) : ℤ) + 2 * Nat.fib n := by
  unfold luc
  rw [Nat.fib_add_two]
  push_cast
  ring

theorem luc_eq_fib_add (n : ℕ) (hn : 1 ≤ n) :
    luc n = (Nat.fib (n - 1) : ℤ) + Nat.fib (n + 1) := by
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  rw [luc_succ, Nat.add_sub_cancel, Nat.fib_add_two]
  push_cast
  ring

/-- Binet's formula for the Lucas numbers. -/
theorem luc_real (n : ℕ) : (luc n : ℝ) = φ ^ n + ψ ^ n := by
  rcases n with _ | n
  · norm_num [luc_zero]
  · rw [luc_succ]
    push_cast
    have h1 := goldenRatio_mul_fib_succ_add_fib n
    have h2 := goldenConj_mul_fib_succ_add_fib n
    have h3 := goldenRatio_add_goldenConj
    linear_combination h1 + h2 - (Nat.fib (n + 1) : ℝ) * h3

theorem fib_real (n : ℕ) : (Nat.fib n : ℝ) * √5 = φ ^ n - ψ ^ n := by
  rw [coe_fib_eq]
  have h5 : (√5 : ℝ) ≠ 0 := by positivity
  field_simp

theorem sqrt_five_sq : (√5 : ℝ) ^ 2 = 5 := Real.sq_sqrt (by norm_num)

/-- `L n ^ 2 - 5 F n ^ 2 = 4 (-1) ^ n`. -/
theorem luc_sq_sub (n : ℕ) : luc n ^ 2 - 5 * (Nat.fib n : ℤ) ^ 2 = 4 * (-1) ^ n := by
  have key : ∀ a b : ℝ, a * b = -1 → (a ^ n + b ^ n) ^ 2 - (a ^ n - b ^ n) ^ 2 = 4 * (-1) ^ n := by
    intro a b hab
    have : (a ^ n + b ^ n) ^ 2 - (a ^ n - b ^ n) ^ 2 = 4 * (a * b) ^ n := by rw [mul_pow]; ring
    rw [this, hab]
  have h : ((luc n ^ 2 - 5 * (Nat.fib n : ℤ) ^ 2 : ℤ) : ℝ) = ((4 * (-1) ^ n : ℤ) : ℝ) := by
    push_cast
    rw [luc_real]
    have hf := fib_real n
    have h5 := sqrt_five_sq
    have hf2 : 5 * (Nat.fib n : ℝ) ^ 2 = (φ ^ n - ψ ^ n) ^ 2 := by
      rw [← hf, mul_pow, h5]; ring
    rw [hf2]
    exact key φ ψ goldenRatio_mul_goldenConj
  exact_mod_cast h

/-- `F (2 n) = F n * L n`. -/
theorem fib_two_mul_luc (n : ℕ) : (Nat.fib (2 * n) : ℤ) = Nat.fib n * luc n := by
  rw [Nat.fib_two_mul]
  have h : Nat.fib n ≤ 2 * Nat.fib (n + 1) := by
    have := Nat.fib_le_fib_succ (n := n); omega
  unfold luc
  push_cast [h]
  ring

/-- Cassini's identity. -/
theorem cassini (n : ℕ) :
    (Nat.fib (n + 2) : ℤ) * Nat.fib n - (Nat.fib (n + 1) : ℤ) ^ 2 = (-1) ^ (n + 1) := by
  induction n with
  | zero => simp [Nat.fib_add_two]
  | succ n ih =>
    have h1 : (Nat.fib (n + 3) : ℤ) = Nat.fib (n + 1) + Nat.fib (n + 2) := by
      exact_mod_cast Nat.fib_add_two
    have h2 : (Nat.fib (n + 2) : ℤ) = Nat.fib n + Nat.fib (n + 1) := by
      exact_mod_cast Nat.fib_add_two
    rw [pow_succ]
    linear_combination (-1 : ℤ) * ih + (Nat.fib (n + 1) : ℤ) * h1 - (Nat.fib (n + 2) : ℤ) * h2

theorem fib_pos' {n : ℕ} (hn : 0 < n) : 0 < Nat.fib n := Nat.fib_pos.mpr hn

/-! ### The expansion of `F (q m)` in powers of `F m` -/

/-- With `F = F (m+1)` and `f = F m`: `F ((q+2) m) = (q+2) F^(q+1) f - C(q+2,2) F^q f^2 + f^3 u`
and `F ((q+2) m + 1) = F^(q+2) + f^2 t` for some integers `u, t`. -/
theorem fib_mul_expand (m : ℕ) (hm : 1 ≤ m) (q : ℕ) :
    ∃ u t : ℤ,
      (Nat.fib ((q + 2) * m) : ℤ) = (q + 2) * (Nat.fib (m + 1) : ℤ) ^ (q + 1) * Nat.fib m
          - (Nat.choose (q + 2) 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ q * (Nat.fib m : ℤ) ^ 2
          + (Nat.fib m : ℤ) ^ 3 * u ∧
      (Nat.fib ((q + 2) * m + 1) : ℤ) =
        (Nat.fib (m + 1) : ℤ) ^ (q + 2) + (Nat.fib m : ℤ) ^ 2 * t := by
  -- the recurrences for `A q = F ((q+2) m)`, `B q = F ((q+2) m + 1)`
  have hrecA : ∀ q : ℕ, (Nat.fib ((q + 3) * m) : ℤ) =
      Nat.fib ((q + 2) * m) * ((Nat.fib (m + 1) : ℤ) - Nat.fib m)
        + Nat.fib ((q + 2) * m + 1) * Nat.fib m := by
    intro q
    have h1 : (q + 3) * m = (q + 2) * m + (m - 1) + 1 := by
      have : 1 ≤ m := hm
      zify [this]
      ring
    have h2 : (Nat.fib (m + 1) : ℤ) = Nat.fib (m - 1) + Nat.fib m := by
      have := Nat.fib_add_one (n := m) (by omega)
      exact_mod_cast this
    rw [h1, Nat.fib_add, Nat.sub_add_cancel hm]
    push_cast
    rw [h2]
    ring
  have hrecB : ∀ q : ℕ, (Nat.fib ((q + 3) * m + 1) : ℤ) =
      Nat.fib ((q + 2) * m) * Nat.fib m + Nat.fib ((q + 2) * m + 1) * Nat.fib (m + 1) := by
    intro q
    have h1 : (q + 3) * m + 1 = (q + 2) * m + m + 1 := by ring
    rw [h1, Nat.fib_add]
    push_cast
    ring
  induction q with
  | zero =>
    refine ⟨0, 1, ?_, ?_⟩
    · have h := fib_two_mul_luc m
      rw [show (0 + 2) * m = 2 * m by ring, h]
      unfold luc
      simp only [Nat.choose_self, Nat.cast_one, pow_zero, zero_add, pow_one]
      ring
    · rw [show (0 + 2) * m + 1 = 2 * m + 1 by ring, Nat.fib_two_mul_add_one]
      push_cast
      ring
  | succ q ih =>
    obtain ⟨u, t, hA, hB⟩ := ih
    refine ⟨(Nat.choose (q + 2) 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ q
        + u * ((Nat.fib (m + 1) : ℤ) - Nat.fib m) + t,
      (q + 2) * (Nat.fib (m + 1) : ℤ) ^ (q + 1)
        - (Nat.choose (q + 2) 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ q * Nat.fib m
        + (Nat.fib m : ℤ) ^ 2 * u + t * Nat.fib (m + 1), ?_, ?_⟩
    · have hc : (Nat.choose (q + 3) 2 : ℤ) = Nat.choose (q + 2) 2 + (q + 2) := by
        rw [show q + 3 = (q + 2) + 1 by ring, Nat.choose_succ_succ' (q + 2) 1,
          Nat.choose_one_right]
        push_cast
        ring
      rw [show q + 1 + 2 = q + 3 by ring, hrecA q, hA, hB, hc]
      push_cast
      ring
    · rw [show q + 1 + 2 = q + 3 by ring, hrecB q, hA, hB]
      ring

/-- First-order form: `F (e m) = e F^(e-1) f + f^2 s` for every `e ≥ 1`. -/
theorem fib_mul_expand' (m : ℕ) (hm : 1 ≤ m) (e : ℕ) (he : 1 ≤ e) :
    ∃ s : ℤ, (Nat.fib (e * m) : ℤ) =
      e * (Nat.fib (m + 1) : ℤ) ^ (e - 1) * Nat.fib m + (Nat.fib m : ℤ) ^ 2 * s := by
  rcases Nat.lt_or_ge e 2 with h | h
  · obtain rfl : e = 1 := by omega
    exact ⟨0, by simp⟩
  · obtain ⟨q, rfl⟩ : ∃ q, e = q + 2 := ⟨e - 2, by omega⟩
    obtain ⟨u, t, hA, -⟩ := fib_mul_expand m hm q
    refine ⟨-(Nat.choose (q + 2) 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ q + Nat.fib m * u, ?_⟩
    rw [hA, show q + 2 - 1 = q + 1 by omega]
    push_cast
    ring

/-! ### `F q ^ 2 = 1 (mod q)` for primes `q ≠ 5` -/

/-- The integer `T n = ∑_{k odd} C(n,k) 5^((k-1)/2)`. -/
def oddSum (n : ℕ) : ℕ :=
  ∑ k ∈ Finset.range (n + 1), if Odd k then Nat.choose n k * 5 ^ (k / 2) else 0

theorem two_pow_mul_fib_real (n : ℕ) :
    (2 : ℝ) ^ n * ((Nat.fib n : ℝ) * √5) = (1 + √5) ^ n - (1 - √5) ^ n := by
  rw [fib_real]
  have h1 : (1 + √5 : ℝ) = 2 * φ := by
    unfold goldenRatio; ring
  have h2 : (1 - √5 : ℝ) = 2 * ψ := by
    unfold goldenConj; ring
  rw [h1, h2, mul_pow, mul_pow]
  ring

theorem binom_odd_real (n : ℕ) :
    (1 + √5 : ℝ) ^ n - (1 - √5) ^ n = 2 * √5 * (oddSum n : ℝ) := by
  have h5 : (√5 : ℝ) ^ 2 = 5 := sqrt_five_sq
  have e1 : (1 + √5 : ℝ) ^ n = ∑ k ∈ Finset.range (n + 1), √5 ^ k * (Nat.choose n k : ℝ) := by
    rw [add_comm, add_pow]; simp
  have e2 : (1 - √5 : ℝ) ^ n = ∑ k ∈ Finset.range (n + 1), (-√5) ^ k * (Nat.choose n k : ℝ) := by
    rw [sub_eq_add_neg, add_comm, add_pow]; simp
  rw [e1, e2, ← Finset.sum_sub_distrib]
  unfold oddSum
  push_cast
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl ?_
  intro k hk
  rcases Nat.even_or_odd k with he | ho
  · have : ¬ Odd k := Nat.not_odd_iff_even.mpr he
    simp only [this, if_false, mul_zero]
    rw [he.neg_pow]
    ring
  · simp only [ho, if_true]
    obtain ⟨j, rfl⟩ := ho
    rw [Odd.neg_pow ⟨j, rfl⟩, show (2 * j + 1) / 2 = j by omega]
    have : (√5 : ℝ) ^ (2 * j + 1) = 5 ^ j * √5 := by
      rw [pow_succ, pow_mul, h5]
    rw [this]
    ring

/-- `2 ^ n F n = 2 T n`. -/
theorem two_pow_mul_fib (n : ℕ) : 2 ^ n * Nat.fib n = 2 * oddSum n := by
  have h : ((2 ^ n * Nat.fib n : ℕ) : ℝ) * √5 = ((2 * oddSum n : ℕ) : ℝ) * √5 := by
    push_cast
    have := two_pow_mul_fib_real n
    rw [binom_odd_real] at this
    linear_combination this
  have h5 : (√5 : ℝ) ≠ 0 := by positivity
  exact_mod_cast mul_right_cancel₀ h5 h

/-- For a prime `q`, `T q = 5 ^ ((q-1)/2) (mod q)`. -/
theorem oddSum_prime_modEq (q : ℕ) (hq : q.Prime) (hodd : Odd q) :
    (oddSum q : ZMod q) = 5 ^ (q / 2) := by
  unfold oddSum
  push_cast
  rw [Finset.sum_range_succ, Finset.sum_eq_zero]
  · simp [hodd, Nat.choose_self]
  · intro k hk
    rw [Finset.mem_range] at hk
    split_ifs with ho
    · rcases Nat.eq_zero_or_pos k with rfl | hk0
      · simp at ho
      · have hdvd : q ∣ Nat.choose q k := hq.dvd_choose_self hk0.ne' hk
        have : (Nat.choose q k : ZMod q) = 0 := (ZMod.natCast_eq_zero_iff _ _).mpr hdvd
        simp [this]
    · rfl

/-- `F q ^ 2 = 1 (mod q)` for every prime `q ≠ 5`. -/
theorem fib_sq_eq_one (q : ℕ) (hq : q.Prime) (h5 : q ≠ 5) :
    ((Nat.fib q : ZMod q)) ^ 2 = 1 := by
  haveI := Fact.mk hq
  rcases hq.eq_two_or_odd' with rfl | hodd
  · simp [Nat.fib_two]
  · have h2 : (2 : ZMod q) ≠ 0 := by
      intro h
      have : q ∣ 2 := (ZMod.natCast_eq_zero_iff 2 q).mp (by exact_mod_cast h)
      have h22 := (Nat.prime_dvd_prime_iff_eq hq Nat.prime_two).mp this
      subst h22
      exact absurd hodd (by decide)
    have h5' : (5 : ZMod q) ≠ 0 := by
      intro h
      have : q ∣ 5 := (ZMod.natCast_eq_zero_iff 5 q).mp (by exact_mod_cast h)
      exact h5 ((Nat.prime_dvd_prime_iff_eq hq (by norm_num)).mp this)
    obtain ⟨c, hc⟩ := hodd
    have hqc : q / 2 = c := by omega
    have hq1 : q - 1 = 2 * c := by omega
    have hT := oddSum_prime_modEq q hq ⟨c, hc⟩
    rw [hqc] at hT
    have hmain : (2 : ZMod q) ^ q * Nat.fib q = 2 * oddSum q := by
      have := two_pow_mul_fib q
      exact_mod_cast congrArg (Nat.cast : ℕ → ZMod q) this
    have hfermat2 : (2 : ZMod q) ^ (q - 1) = 1 := ZMod.pow_card_sub_one_eq_one h2
    have hfermat5 : (5 : ZMod q) ^ (q - 1) = 1 := ZMod.pow_card_sub_one_eq_one h5'
    have h2q : (2 : ZMod q) ^ q = 2 := by
      have : (2 : ZMod q) ^ q = 2 ^ (q - 1) * 2 := by
        rw [← pow_succ]; congr 1; omega
      rw [this, hfermat2, one_mul]
    rw [h2q, hT] at hmain
    have hF : (Nat.fib q : ZMod q) = 5 ^ c := mul_left_cancel₀ h2 hmain
    rw [hF, ← pow_mul, mul_comm, ← hq1, hfermat5]

/-- A prime `q ≠ 5` divides `F (q-1)` or `F (q+1)`. -/
theorem prime_dvd_fib_pred_or_succ (q : ℕ) (hq : q.Prime) (h5 : q ≠ 5) :
    q ∣ Nat.fib (q - 1) ∨ q ∣ Nat.fib (q + 1) := by
  haveI := Fact.mk hq
  have hc := cassini (q - 1)
  have hq1 : q - 1 + 2 = q + 1 := by have := hq.two_le; omega
  have hq2 : q - 1 + 1 = q := by have := hq.two_le; omega
  rw [hq1, hq2] at hc
  have hsq := fib_sq_eq_one q hq h5
  have hprod : ((Nat.fib (q + 1) * Nat.fib (q - 1) : ℕ) : ZMod q) = 0 := by
    push_cast
    have h' : ((Nat.fib (q + 1) : ℤ) * Nat.fib (q - 1) : ℤ) = Nat.fib q ^ 2 + (-1) ^ q := by
      linear_combination hc
    have h'' := congrArg (Int.cast : ℤ → ZMod q) h'
    push_cast at h''
    rw [h'', hsq]
    rcases hq.eq_two_or_odd' with rfl | hodd
    · decide +revert
    · rw [hodd.neg_one_pow]; ring
  have := (ZMod.natCast_eq_zero_iff _ _).mp hprod
  rcases (Nat.Prime.dvd_mul hq).mp this with h | h
  · exact Or.inr h
  · exact Or.inl h

end TuringTask
