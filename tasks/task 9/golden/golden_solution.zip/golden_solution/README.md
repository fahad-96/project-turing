# Project Turing - Task 9 golden answer

Lean 4 project with complete proofs of five statements about cubes modulo a prime
`p = 1 mod 3`: the number of solutions of `x^3 + y^3 = 1`, two counts of consecutive cubes and
non-cubes, the cubic character of 2, and the cubic exponential sum. The required file is
`TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The five source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Cubes.lean`: a character of order 3 on `ZMod p`; the number of cube roots of `c`
  is `1 + chi(c) + chi^-1(c)`
- `TuringTask/Jacobi3.lean`: the cubic Jacobi sum gives `4 p = L^2 + 27 M^2`; uniqueness of `L`
- `TuringTask/Counts.lean`: the three counts, the parity argument for 2, the cubic Gauss sum
- `TuringTask/Main.lean`: the five statements of the prompt, proved
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof in `Main.lean`
