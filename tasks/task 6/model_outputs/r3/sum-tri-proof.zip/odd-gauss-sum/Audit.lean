import OddGaussSum
import TuringTask

#check OddGaussSum.sum_sq
#print axioms OddGaussSum.sum_sq
#check TuringTask.sum_sq
#print axioms TuringTask.sum_sq
#check TuringTask.sum_tri
#print axioms TuringTask.sum_tri
