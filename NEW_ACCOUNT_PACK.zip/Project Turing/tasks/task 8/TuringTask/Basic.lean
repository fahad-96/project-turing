import Mathlib

namespace TuringTask

theorem freq_mul (x a b : Real) (hx : Irrational x) (ha : 0 <= a) (hab : a <= b) (hb : b <= 1) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      a <= Int.fract ((n : Real) * x) /\ Int.fract ((n : Real) * x) < b)).card : Real) / N)
      Filter.atTop (nhds (b - a)) := by
  sorry

theorem freq_sq (x a b : Real) (hx : Irrational x) (ha : 0 <= a) (hab : a <= b) (hb : b <= 1) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      a <= Int.fract ((n : Real) ^ 2 * x) /\ Int.fract ((n : Real) ^ 2 * x) < b)).card : Real)
      / N) Filter.atTop (nhds (b - a)) := by
  sorry

theorem freq_unif (x : Real) (hx : Irrational x) (e : Real) (he : 0 < e) :
    exists N0 : Nat, forall N : Nat, N0 <= N -> forall a b : Real, 0 <= a -> a <= b -> b <= 1 ->
      abs ((((Finset.range N).filter (fun n : Nat =>
        a <= Int.fract ((n : Real) * x) /\ Int.fract ((n : Real) * x) < b)).card : Real) / N
        - (b - a)) < e := by
  sorry

theorem freq_lead (d : Nat) (hd : 1 <= d) (hd' : d <= 9) :
    Filter.Tendsto (fun N : Nat => (((Finset.range N).filter (fun n : Nat =>
      2 ^ n / 10 ^ Nat.log 10 (2 ^ n) = d)).card : Real) / N)
      Filter.atTop (nhds (Real.logb 10 (((d : Real) + 1) / d))) := by
  sorry

theorem mean_abs_sin :
    Filter.Tendsto
      (fun N : Nat => Finset.sum (Finset.range N) (fun n : Nat => abs (Real.sin n)) / N)
      Filter.atTop (nhds (2 / Real.pi)) := by
  sorry

end TuringTask
