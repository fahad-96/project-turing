# Odd quadratic and triangular Gauss sums

This project proves the exact task statements

```lean
TuringTask.sum_sq
TuringTask.sum_tri
```

The quadratic proof constructs the normalized finite Fourier matrix, diagonalizes its
fourth-order action using a collected eigenbasis, proves the norm of its trace,
and computes its determinant phase with the Vandermonde product. The two
possible negative signs are then eliminated from the eigenvalue
multiplicities. `OddGaussSum.lean` converts the resulting `ZMod` sum to the
literal `Finset.range` complex exponential and handles every odd `n`, including
`n = 1`.

The triangular proof completes the square using the inverse of `2` modulo the
odd modulus. It evaluates the resulting unit-twisted DFT trace. Reindexing rows
changes the normalized determinant by the permutation sign; `DoubleSign.lean`
proves that the doubling permutation has sign
`(-1)^(q*(q+1)/2)`. This determinant-sensitive sign resolves the four residue
classes modulo `8`, after which `Triangular.lean` converts back to the exact
real-exponential statement.

The project uses the supplied local Mathlib installation and is not standalone
on an arbitrary machine. In the provided environment, check it offline with:

```sh
lake build
```

No network access or remote dependency fetch is required.
