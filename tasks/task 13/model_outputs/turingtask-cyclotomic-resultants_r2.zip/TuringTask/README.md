# Resultants and discriminants of cyclotomic polynomials

A Lean 4 / Mathlib project proving five theorems about resultants and discriminants of
cyclotomic polynomials over `ℤ`.

## Contents

| File | Role |
| --- | --- |
| `TuringTask/Basic.lean` | The five requested theorems, in namespace `TuringTask`, stated verbatim as specified. |
| `TuringTask/Prelim.lean` | All supporting lemmas (namespace `TTAux`). |
| `TuringTask.lean` | Library root, imports both modules. |
| `lakefile.toml` | Build configuration; depends on Mathlib via a **local path**. |
| `lean-toolchain` | Pins `leanprover/lean4:v4.33.0-rc1`. |

The five theorems:

1. `TuringTask.resultant_cyclotomic_eq_one` — if `1 ≤ n < m` and `m` is not `n·pᵏ` for a prime `p`, then `Res(Φ_m, Φ_n) = 1`.
2. `TuringTask.resultant_cyclotomic_mul_prime_pow` — `Res(Φ_{n·pᵏ}, Φ_n) = p^φ(n)` for `n ≥ 1`, `p` prime, `k ≥ 1`, `(n,p,k) ≠ (1,2,1)`.
3. `TuringTask.discr_cyclotomic` — `disc(Φ_n) · ∏_{p ∣ n} p^(φ(n)/(p−1)) = (−1)^(φ(n)/2) · n^φ(n)`.
4. `TuringTask.isCoprime_cyclotomic_iff` — for `1 ≤ n < m`, `Φ_m` and `Φ_n` are coprime in `ℤ[X]` iff `m` is not `n·pᵏ`.
5. `TuringTask.resultant_cyclotomic_X_pow_sub_one` — for `n ≥ 3`, `Res(Φ_n, Xᵐ−1) = Φ_k(1)^(φ(n)/φ(k))` with `k = n/gcd(n,m)`.

## Proof outline

Everything is computed by base change to `ℂ`, where `cyclotomic n ℂ` splits and its roots are
exactly the primitive `n`-th roots of unity, so that `Res(Φ_n, g)` becomes `∏_ζ g(ζ)`
(`TTAux.res_eq_prod`).

The combinatorial engine is **`TTAux.prod_prim_pow`**: for `k ∣ M`, the map `ζ ↦ ζ^(M/k)` carries
the primitive `M`-th roots onto the primitive `k`-th roots, uniformly `φ(M)/φ(k)`-to-one. This is
proved by transporting the statement along `a ↦ ζ₀^a` to the reduction homomorphism
`(ZMod M)ˣ → (ZMod k)ˣ`, which is a surjection of finite groups and hence has fibres of equal
size (`TTAux.card_fiber`, `TTAux.prod_comp_surjective`).

This yields `Res(Φ_m, X^N − 1) = Φ_{m/gcd(m,N)}(1)^(φ(m)/φ(m/gcd(m,N)))` for every `N` when
`m ≥ 3` (`TTAux.resultant_cyclotomic_X_pow_sub_one'`), which is Theorem 5.

Factoring `X^N − 1 = ∏_{d ∣ N} Φ_d` and inducting strongly on `N` then peels off the individual
factors, giving `Res(Φ_m, Φ_n) = Φ_{m/n}(1)^φ(n)` when `n ∣ m` and `1` otherwise
(`TTAux.resultant_cyclotomic_eq_claimed`). The cancellation step needs the arithmetic identity

> `∏_{d ∣ g} Φ_{m/d}(1)^φ(d) = Φ_{m/g}(1)^(φ(m)/φ(m/g))`  (`TTAux.key_identity`),

proved by splitting on whether `m/g` is a prime power. Theorems 1, 2 and 4 follow; Theorem 4 uses
Mathlib's `Polynomial.isUnit_resultant_iff_isCoprime`.

For Theorem 3 we differentiate `X^n − 1 = Φ_n · G` with `G = ∏_{d < n} Φ_d` and evaluate at the
primitive roots, obtaining `Res(Φ_n, Φ_n') · Res(Φ_n, G) = n^φ(n)`. Mathlib's
`Polynomial.resultant_deriv` converts the first factor into the discriminant (up to the sign
`(−1)^(d(d−1)/2) = (−1)^(d/2)`, valid since `φ(n)` is even for `n ≥ 3`), and the second
arithmetic identity

> `∏_{d ∣ n, d < n} Φ_{n/d}(1)^φ(d) = ∏_{p ∣ n} p^(φ(n)/(p−1))`  (`TTAux.key_identity_two`)

converts the second factor. The cases `n = 1, 2` are handled separately, where `Φ_n` has degree
one and the discriminant is `1`.

## Environment

This project requires the **supplied offline Lean/Mathlib environment**:

* Lean toolchain `leanprover/lean4:v4.33.0-rc1`
* A prebuilt Mathlib at `/opt/mathlib4` (commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`)

`lakefile.toml` references Mathlib by the local path `/opt/mathlib4`. The archive is therefore
**not self-contained on an arbitrary machine**: it is intended to be built inside the provided
image, where that path exists and Mathlib is already compiled.

## Offline build instructions

From the project directory, with no network access:

```sh
lean-offline-init   # seeds .lake/packages with links to the installed deps (local only)
lake build          # compiles TuringTask.Prelim and TuringTask.Basic
```

`lake build` completes with no errors and no warnings.

To re-check that the five theorems rest only on Lean's standard axioms:

```sh
cat > /tmp/axioms.lean <<'EOF'
import TuringTask.Basic
#print axioms TuringTask.resultant_cyclotomic_eq_one
#print axioms TuringTask.resultant_cyclotomic_mul_prime_pow
#print axioms TuringTask.discr_cyclotomic
#print axioms TuringTask.isCoprime_cyclotomic_iff
#print axioms TuringTask.resultant_cyclotomic_X_pow_sub_one
EOF
lake env lean /tmp/axioms.lean
```

Each prints exactly `[propext, Classical.choice, Quot.sound]`.

No `sorry`, `admit`, `native_decide`, or added axioms appear anywhere in the sources.

## A note on Theorem 5's hypotheses

The hypotheses `1 ≤ m` and `¬ (m % n = 0)` are retained verbatim as requested, but are not
actually needed: for `n ≥ 3` the identity holds for every `m`. (If `n ∣ m` then `k = 1`, and both
sides are `0` because `Φ₁(1) = 0`.) The unconstrained version is
`TTAux.resultant_cyclotomic_X_pow_sub_one'`.
