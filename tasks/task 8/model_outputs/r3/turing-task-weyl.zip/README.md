# TuringTask

This project uses the Lean 4 and Mathlib versions supplied by the task environment.

Build offline with:

```sh
lean-offline-init
lake build
```
