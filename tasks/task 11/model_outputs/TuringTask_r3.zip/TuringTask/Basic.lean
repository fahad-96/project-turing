import Mathlib

namespace TuringTask

open scoped ENNReal
open MeasureTheory ProbabilityTheory Set

private def avoid {Ω ι : Type*} (A : ι → Set Ω) (S : Finset ι) : Set Ω :=
  {w | ∀ i ∈ S, w ∉ A i}

private lemma measurableSet_avoid {Ω ι : Type*} [MeasurableSpace Ω]
    (A : ι → Set Ω) (hA : ∀ i, MeasurableSet (A i)) (S : Finset ι) :
    MeasurableSet (avoid A S) := by
  classical
  rw [show avoid A S = ⋂ i ∈ S, (A i)ᶜ by ext; simp [avoid]]
  exact Finset.measurableSet_biInter S (fun i _ => (hA i).compl)

private lemma avoid_mono {Ω ι : Type*} (A : ι → Set Ω) {S T : Finset ι}
    (h : S ⊆ T) : avoid A T ⊆ avoid A S := by
  intro w hw i hi
  exact hw i (h hi)

/-- The symmetric local lemma, in the form used below.  Independence is only
required between one bad event and exclusions of its non-neighbours. -/
private theorem local_lemma {Ω ι : Type*} [MeasurableSpace Ω]
    [Fintype ι] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (A : ι → Set Ω) (hA : ∀ i, MeasurableSet (A i))
    (near : ι → ι → Prop) [DecidableRel near] (d : ℕ) (p x : ℝ)
    (hp0 : 0 ≤ p) (hx0 : 0 ≤ x) (hx1 : x < 1)
    (hprob : ∀ i, μ.real (A i) ≤ p)
    (hdegree : ∀ i, (Finset.univ.filter (near i)).card ≤ d)
    (hind : ∀ i (S : Finset ι), i ∉ S → (∀ j ∈ S, ¬ near i j) →
      μ.real (A i ∩ avoid A S) = μ.real (A i) * μ.real (avoid A S))
    (hpx : p ≤ x * (1 - x) ^ d) :
    ∃ w, ∀ i, w ∉ A i := by
  classical
  have hxnonneg : 0 ≤ 1 - x := sub_nonneg.mpr (le_of_lt hx1)
  have hxle : 1 - x ≤ 1 := by linarith
  have main : ∀ S : Finset ι, ∀ i,
      μ.real (A i ∩ avoid A S) ≤ x * μ.real (avoid A S) := by
    intro S
    induction S using Finset.strongInductionOn
    next S ih =>
      intro i
      by_cases hiS : i ∈ S
      · have hempty : A i ∩ avoid A S = ∅ := by
          ext w
          simp only [mem_inter_iff, avoid, mem_setOf_eq, mem_empty_iff_false]
          constructor
          · intro hw
            exact (hw.2 i hiS) hw.1
          · exact False.elim
        rw [hempty, measureReal_empty]
        positivity
      let U := S.filter (near i)
      let T := S.filter (fun j => ¬ near i j)
      have hUT : U ∪ T = S := by
        ext j
        by_cases h : near i j <;> simp [U, T, h]
      have hUsub : U ⊆ S := Finset.filter_subset _ _
      have hTsub : T ⊆ S := Finset.filter_subset _ _
      have hdis : Disjoint U T := by
        simp only [Finset.disjoint_left, U, T, Finset.mem_filter]
        aesop
      have hUc : U.card ≤ d :=
        le_trans (Finset.card_le_card (by
          intro j hj
          exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hj).2⟩))
          (hdegree i)
      have hindT : μ.real (A i ∩ avoid A T) =
          μ.real (A i) * μ.real (avoid A T) := by
        apply hind
        · exact fun hiT => hiS (hTsub hiT)
        simp [T]
      have hupper : μ.real (A i ∩ avoid A S) ≤
          p * μ.real (avoid A T) := by
        calc
          μ.real (A i ∩ avoid A S) ≤ μ.real (A i ∩ avoid A T) :=
            measureReal_mono (inter_subset_inter_right _ (avoid_mono A hTsub))
          _ = μ.real (A i) * μ.real (avoid A T) := hindT
          _ ≤ p * μ.real (avoid A T) :=
            mul_le_mul_of_nonneg_right (hprob i) measureReal_nonneg
      have hlower : (1 - x) ^ U.card * μ.real (avoid A T) ≤
          μ.real (avoid A S) := by
        have step : ∀ R : Finset ι, R ⊆ U →
            (1 - x) ^ R.card * μ.real (avoid A T) ≤
              μ.real (avoid A (T ∪ R)) := by
          intro R hRU
          induction R using Finset.induction_on with
          | empty => simp
          | @insert j R hj hR =>
            have hRsub : R ⊆ U := fun a ha => hRU (Finset.mem_insert_of_mem ha)
            have hjU : j ∈ U := hRU (Finset.mem_insert_self _ _)
            have hjT : j ∉ T := Finset.disjoint_left.mp hdis hjU
            have hLsub : T ∪ R ⊂ S := by
              rw [← hUT]
              apply Finset.ssubset_iff_subset_ne.mpr
              constructor
              · intro a ha
                rcases Finset.mem_union.mp ha with ha | ha
                · exact Finset.mem_union_right _ ha
                · exact Finset.mem_union_left _ (hRsub ha)
              · intro heq
                have : j ∈ T ∪ R := by rw [heq]; exact Finset.mem_union_left _ hjU
                exact (Finset.mem_union.mp this).elim hjT hj
            have hbad := ih (T ∪ R) hLsub j
            have hdiff : avoid A (T ∪ insert j R) =
                avoid A (T ∪ R) \ (A j ∩ avoid A (T ∪ R)) := by
              ext w
              constructor <;> simp only [avoid, mem_setOf_eq, Finset.mem_union,
                Finset.mem_insert, mem_diff, mem_inter_iff]
              · aesop
              · aesop
            have hmeasure : μ.real (avoid A (T ∪ insert j R)) =
                μ.real (avoid A (T ∪ R)) -
                  μ.real (A j ∩ avoid A (T ∪ R)) := by
              rw [hdiff, measureReal_diff]
              · exact inter_subset_right
              · exact (hA j).inter (measurableSet_avoid A hA _)
            rw [Finset.card_insert_of_notMem hj, pow_succ, hmeasure]
            calc
              (1 - x) ^ R.card * (1 - x) * μ.real (avoid A T) =
                  (1 - x) * ((1 - x) ^ R.card * μ.real (avoid A T)) := by ring
              _ ≤ (1 - x) * μ.real (avoid A (T ∪ R)) :=
                mul_le_mul_of_nonneg_left (hR hRsub) hxnonneg
              _ ≤ μ.real (avoid A (T ∪ R)) -
                    μ.real (A j ∩ avoid A (T ∪ R)) := by
                  nlinarith
        have h := step U (fun _ h => h)
        rwa [Finset.union_comm T U, hUT] at h
      have hpow : (1 - x) ^ d ≤ (1 - x) ^ U.card := by
        exact pow_le_pow_of_le_one hxnonneg hxle hUc
      calc
        μ.real (A i ∩ avoid A S) ≤ p * μ.real (avoid A T) := hupper
        _ ≤ (x * (1 - x) ^ d) * μ.real (avoid A T) := by gcongr
        _ ≤ x * ((1 - x) ^ U.card * μ.real (avoid A T)) := by
          have hpw := mul_le_mul_of_nonneg_left hpow hx0
          have := mul_le_mul_of_nonneg_right hpw (measureReal_nonneg :
            0 ≤ μ.real (avoid A T))
          simpa [mul_assoc] using this
        _ ≤ x * μ.real (avoid A S) := by gcongr
  have hall : 0 < μ.real (avoid A Finset.univ) := by
    have chain : ∀ S : Finset ι,
        (1 - x) ^ S.card ≤ μ.real (avoid A S) := by
      intro S
      induction S using Finset.induction_on with
      | empty => simp [avoid, measureReal_def]
      | @insert i S hi ih =>
        have hbad := main S i
        have hdiff : avoid A (insert i S) = avoid A S \ (A i ∩ avoid A S) := by
          ext w
          constructor <;> simp only [avoid, mem_setOf_eq, Finset.mem_insert, mem_diff,
            mem_inter_iff, not_or]
          · aesop
          · aesop
        rw [Finset.card_insert_of_notMem hi, pow_succ, hdiff, measureReal_diff]
        · nlinarith
        · exact inter_subset_right
        · exact (hA i).inter (measurableSet_avoid A hA _)
    exact lt_of_lt_of_le (pow_pos (sub_pos.mpr hx1) _) (chain Finset.univ)
  by_contra hn
  push_neg at hn
  have hempty : avoid A Finset.univ = ∅ := by
    apply Set.eq_empty_iff_forall_notMem.mpr
    intro w hw
    obtain ⟨i, hi⟩ := hn w
    exact hw i (Finset.mem_univ i) hi
  rw [hempty, measureReal_empty] at hall
  exact lt_irrefl 0 hall

private theorem boolean_local_lemma {ν ι : Type*} [Fintype ν] [Fintype ι]
    [DecidableEq ν] [DecidableEq ι]
    (supp : ι → Finset ν) (bad : ι → (ν → Bool) → Prop)
    (hlocal : ∀ i x y, (∀ v ∈ supp i, x v = y v) → (bad i x ↔ bad i y))
    (d : ℕ) (p x : ℝ) (hp0 : 0 ≤ p) (hx0 : 0 ≤ x) (hx1 : x < 1)
    (hprob : ∀ i, (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
      {w | bad i w} ≤ p)
    (hdegree : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧
      ¬ Disjoint (supp i) (supp j))).card ≤ d)
    (hpx : p ≤ x * (1 - x) ^ d) :
    ∃ w, ∀ i, ¬ bad i w := by
  classical
  let μb : Measure Bool := uniformOn Set.univ
  let μ : Measure (ν → Bool) := Measure.pi fun _ => μb
  letI : IsProbabilityMeasure μb := by dsimp [μb]; infer_instance
  letI : IsProbabilityMeasure μ := by dsimp [μ]; infer_instance
  have hcoord : iIndepFun (fun v (w : ν → Bool) => w v) μ := by
    have h := iIndepFun_pi (μ := fun _ : ν => μb)
      (X := fun _ (b : Bool) => b) (fun _ => Measurable.aemeasurable measurable_id)
    simpa [μ] using h
  let A : ι → Set (ν → Bool) := fun i => {w | bad i w}
  let near : ι → ι → Prop := fun i j => j ≠ i ∧ ¬ Disjoint (supp i) (supp j)
  have hA : ∀ i, MeasurableSet (A i) := fun _ => MeasurableSet.of_discrete
  apply local_lemma μ A hA near d p x hp0 hx0 hx1
  · simpa [μ, μb, A] using hprob
  · simpa [near] using hdegree
  · intro i J hiJ hJ
    let W := J.biUnion supp
    have hdis : Disjoint (supp i) W := by
      rw [Finset.disjoint_left]
      intro v hvi hvW
      obtain ⟨j, hjJ, hvj⟩ := Finset.mem_biUnion.mp hvW
      have hn := hJ j hjJ
      have hji : j ≠ i := by
        intro h
        subst j
        exact hiJ hjJ
      exact hn ⟨hji, Finset.not_disjoint_iff.mpr ⟨v, hvi, hvj⟩⟩
    let f : (ν → Bool) → (↥(supp i) → Bool) := fun w v => w v
    let g : (ν → Bool) → (↥W → Bool) := fun w v => w v
    have hfg : IndepFun f g μ := by
      simpa [f, g] using hcoord.indepFun_finset (supp i) W hdis
        (fun _ => measurable_pi_apply _)
    let B : Set (↥(supp i) → Bool) :=
      {z | ∃ w : ν → Bool, f w = z ∧ bad i w}
    let C : Set (↥W → Bool) :=
      {z | ∃ w : ν → Bool, g w = z ∧ w ∈ avoid A J}
    have hpreB : f ⁻¹' B = A i := by
      ext w
      change (∃ y : ν → Bool, f y = f w ∧ bad i y) ↔ bad i w
      constructor
      · rintro ⟨y, hy, hby⟩
        have heq : ∀ v ∈ supp i, w v = y v := by
          intro v hv
          have hh := congrFun hy ⟨v, hv⟩
          simpa [f] using hh.symm
        exact (hlocal i w y heq).mpr hby
      · intro hw
        exact ⟨w, rfl, hw⟩
    have hpreC : g ⁻¹' C = avoid A J := by
      ext w
      change (∃ y : ν → Bool, g y = g w ∧ y ∈ avoid A J) ↔ w ∈ avoid A J
      constructor
      · rintro ⟨y, hy, havoid⟩
        intro j hj hbadw
        have hjW : supp j ⊆ W := fun v hv =>
          Finset.mem_biUnion.mpr ⟨j, hj, hv⟩
        have heq : ∀ v ∈ supp j, w v = y v := by
          intro v hv
          have hh := congrFun hy ⟨v, hjW hv⟩
          simpa [g] using hh.symm
        exact (havoid j hj) ((hlocal j w y heq).mp hbadw)
      · intro hw
        exact ⟨w, rfl, hw⟩
    have hm := hfg.measure_inter_preimage_eq_mul B C
      MeasurableSet.of_discrete MeasurableSet.of_discrete
    rw [hpreB, hpreC] at hm
    have hm' := congrArg ENNReal.toReal hm
    simpa [measureReal_def, ENNReal.toReal_mul] using hm'
  · exact hpx

private lemma cylinder_prob_fun {ν : Type*} [Fintype ν] [DecidableEq ν]
    (S : Finset ν) (b : ν → Bool) :
    (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
      {w | ∀ v ∈ S, w v = b v} = (1 / 2 : ℝ) ^ S.card := by
  classical
  let f : ν → Set Bool := fun v => if v ∈ S then {b v} else Set.univ
  have hevent : {w : ν → Bool | ∀ v ∈ S, w v = b v} = Set.univ.pi f := by
    ext w
    constructor
    · intro h v
      by_cases hv : v ∈ S
      · simpa [f, hv] using h v hv
      · simp [f, hv]
    · intro h v hv
      simpa [f, hv] using h v
  rw [hevent, measureReal_def, Measure.pi_pi, ENNReal.toReal_prod]
  have hsingle : ∀ v : ν,
      (uniformOn (Set.univ : Set Bool) (f v)).toReal =
        if v ∈ S then (1 / 2 : ℝ) else 1 := by
    intro v
    have hu : (↑(Finset.univ : Finset Bool) : Set Bool) = Set.univ := by ext; simp
    by_cases hv : v ∈ S
    · simp only [f, hv, if_true]
      have h := uniformOn_apply_finset
        (s := (Finset.univ : Finset Bool)) (t := {b v})
      have h' := congrArg ENNReal.toReal h
      rw [← hu]
      simpa [measureReal_def] using h'
    · simp only [f, hv, if_false]
      haveI : IsProbabilityMeasure (uniformOn (Set.univ : Set Bool)) := inferInstance
      rw [measure_univ, ENNReal.toReal_one]
  simp_rw [hsingle]
  simp

private lemma cylinder_prob {ν : Type*} [Fintype ν] [DecidableEq ν]
    (S : Finset ν) (b : Bool) :
    (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
      {w | ∀ v ∈ S, w v = b} = (1 / 2 : ℝ) ^ S.card := by
  simpa using cylinder_prob_fun S (fun _ => b)

private lemma exp_neg_one_le_local_factor (d : ℕ) :
    Real.exp (-1) ≤ (1 - 1 / ((d : ℝ) + 1)) ^ d := by
  by_cases hd : d = 0
  · subst d
    simpa using (Real.exp_le_one_iff.mpr (by norm_num : (-1 : ℝ) ≤ 0))
  · have hdpos : (0 : ℝ) < d := by exact_mod_cast Nat.pos_of_ne_zero hd
    have hbpos : 0 < (1 + ((d : ℝ))⁻¹) ^ d :=
      pow_pos (by positivity) _
    have hi : (Real.exp 1)⁻¹ ≤ ((1 + ((d : ℝ))⁻¹) ^ d)⁻¹ :=
      (inv_le_inv₀ (Real.exp_pos 1) hbpos).mpr Real.one_add_inv_pow_le_exp
    rw [← inv_pow] at hi
    have heq : (1 + ((d : ℝ))⁻¹)⁻¹ = 1 - 1 / ((d : ℝ) + 1) := by
      field_simp
      ring
    simpa [Real.exp_neg, heq] using hi

private lemma lll_numeric (d q : ℕ)
    (h : Real.exp 1 * ((d : ℝ) + 1) ≤ (2 : ℝ) ^ q) :
    (1 / 2 : ℝ) ^ q ≤ (1 / ((d : ℝ) + 1)) *
      (1 - 1 / ((d : ℝ) + 1)) ^ d := by
  have ha : 0 < (d : ℝ) + 1 := by positivity
  have he : 0 < Real.exp 1 * ((d : ℝ) + 1) := mul_pos (Real.exp_pos _) ha
  have htwo : 0 < (2 : ℝ) ^ q := by positivity
  have hinv : 1 / (2 : ℝ) ^ q ≤
      1 / (Real.exp 1 * ((d : ℝ) + 1)) := one_div_le_one_div_of_le he h
  have hfac := exp_neg_one_le_local_factor d
  rw [Real.exp_neg] at hfac
  calc
    (1 / 2 : ℝ) ^ q = 1 / (2 : ℝ) ^ q := one_div_pow 2 q
    _ ≤ 1 / (Real.exp 1 * ((d : ℝ) + 1)) := hinv
    _ = (1 / ((d : ℝ) + 1)) * (Real.exp 1)⁻¹ := by field_simp
    _ ≤ (1 / ((d : ℝ) + 1)) *
        (1 - 1 / ((d : ℝ) + 1)) ^ d := by gcongr

theorem color_meet (n m k d : Nat) (I : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => I i v = true)).card = k)
    (hd : forall i, (Finset.univ.filter (fun j => Not (j = i) /\
      exists v, I i v = true /\ I j v = true)).card <= d)
    (hkd : Real.exp 1 * ((d : Real) + 1) <= 2 ^ (k - 1)) :
    exists c : Fin n -> Bool, forall i,
      (exists v, I i v = true /\ c v = true) /\ (exists v, I i v = true /\ c v = false) := by
  classical
  have hkpos : 0 < k := by
    by_contra hn
    have hk0 : k = 0 := by omega
    have he : 1 < Real.exp 1 := Real.one_lt_exp_iff.mpr (by norm_num)
    have hd0 : (0 : ℝ) ≤ d := by positivity
    rw [hk0] at hkd
    norm_num at hkd
    nlinarith
  let supp : Fin m → Finset (Fin n) := fun i =>
    Finset.univ.filter (fun v => I i v = true)
  let bad : Fin m → (Fin n → Bool) → Prop := fun i c =>
    (∀ v ∈ supp i, c v = true) ∨ (∀ v ∈ supp i, c v = false)
  have hlocal : ∀ i x y, (∀ v ∈ supp i, x v = y v) → (bad i x ↔ bad i y) := by
    intro i x y heq
    simp only [bad]
    constructor <;> rintro (h | h)
    · left; intro v hv; rw [← heq v hv]; exact h v hv
    · right; intro v hv; rw [← heq v hv]; exact h v hv
    · left; intro v hv; rw [heq v hv]; exact h v hv
    · right; intro v hv; rw [heq v hv]; exact h v hv
  have hprob : ∀ i, (Measure.pi (fun _ : Fin n =>
      uniformOn (Set.univ : Set Bool))).real {w | bad i w} ≤
      (1 / 2 : ℝ) ^ (k - 1) := by
    intro i
    let E₁ : Set (Fin n → Bool) := {w | ∀ v ∈ supp i, w v = true}
    let E₀ : Set (Fin n → Bool) := {w | ∀ v ∈ supp i, w v = false}
    have hevent : {w | bad i w} = E₁ ∪ E₀ := by rfl
    rw [hevent]
    calc
      _ ≤ (Measure.pi (fun _ : Fin n => uniformOn (Set.univ : Set Bool))).real E₁ +
          (Measure.pi (fun _ : Fin n => uniformOn (Set.univ : Set Bool))).real E₀ :=
        measureReal_union_le _ _
      _ = (1 / 2 : ℝ) ^ (supp i).card + (1 / 2 : ℝ) ^ (supp i).card := by
        rw [show E₁ = {w | ∀ v ∈ supp i, w v = true} by rfl,
          show E₀ = {w | ∀ v ∈ supp i, w v = false} by rfl,
          cylinder_prob, cylinder_prob]
      _ = (1 / 2 : ℝ) ^ (k - 1) := by
        rw [show (supp i).card = k by simpa [supp] using hk i]
        conv_lhs => rw [show k = (k - 1) + 1 by omega, pow_succ]
        ring
  have hdegree : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧
      ¬ Disjoint (supp i) (supp j))).card ≤ d := by
    intro i
    simpa only [supp, Finset.not_disjoint_iff, Finset.mem_filter, Finset.mem_univ,
      true_and] using hd i
  let x : ℝ := if d = 0 then 1 / 2 else 1 / ((d : ℝ) + 1)
  have hx0 : 0 ≤ x := by simp [x]; positivity
  have hx1 : x < 1 := by
    by_cases hd0 : d = 0
    · simp [x, hd0]
      norm_num
    · simp only [x, hd0, if_false]
      have hdpos : (0 : ℝ) < d := by exact_mod_cast Nat.pos_of_ne_zero hd0
      exact (div_lt_one (by positivity)).mpr (by linarith)
  have hpx : (1 / 2 : ℝ) ^ (k - 1) ≤ x * (1 - x) ^ d := by
    by_cases hd0 : d = 0
    · subst d
      simp only [x, if_pos rfl, Nat.cast_zero, zero_add, pow_zero, mul_one]
      have he2 : (2 : ℝ) < Real.exp 1 := lt_trans (by norm_num) Real.exp_one_gt_d9
      have hinv : 1 / (2 : ℝ) ^ (k - 1) ≤ 1 / Real.exp 1 :=
        one_div_le_one_div_of_le (Real.exp_pos _) (by simpa using hkd)
      rw [← one_div_pow] at hinv
      have hhalf : 1 / Real.exp 1 < (1 / 2 : ℝ) :=
        one_div_lt_one_div_of_lt (by norm_num) he2
      exact le_trans hinv hhalf.le
    · simpa [x, hd0] using lll_numeric d (k - 1) hkd
  obtain ⟨c, hc⟩ := boolean_local_lemma supp bad hlocal d
    ((1 / 2 : ℝ) ^ (k - 1)) x
    (by positivity) hx0 hx1 hprob hdegree hpx
  refine ⟨c, ?_⟩
  intro i
  have hnb := hc i
  simp only [bad, not_or] at hnb
  constructor
  · have h := not_forall.mp hnb.2
    obtain ⟨v, h⟩ := h
    have hv := not_forall.mp h
    refine ⟨v, ?_, ?_⟩
    · simpa [supp] using hv.1
    · simpa using hv.2
  · have h := not_forall.mp hnb.1
    obtain ⟨v, h⟩ := h
    have hv := not_forall.mp h
    refine ⟨v, ?_, ?_⟩
    · simpa [supp] using hv.1
    · simpa using hv.2

theorem color_deg (n m k : Nat) (hk9 : 9 <= k) (I : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => I i v = true)).card = k)
    (hdeg : forall v, (Finset.univ.filter (fun i => I i v = true)).card <= k) :
    exists c : Fin n -> Bool, forall i,
      (exists v, I i v = true /\ c v = true) /\ (exists v, I i v = true /\ c v = false) := by
  classical
  have hpow_nat : ∀ t : ℕ, 9 ≤ t → 3 * (t ^ 2 + 1) ≤ 2 ^ (t - 1) := by
    intro t ht
    induction t, ht using Nat.le_induction with
    | base => norm_num
    | succ t ht ih =>
      calc
        3 * ((t + 1) ^ 2 + 1) ≤ 2 * (3 * (t ^ 2 + 1)) := by nlinarith
        _ ≤ 2 * 2 ^ (t - 1) := Nat.mul_le_mul_left 2 ih
        _ = 2 ^ (t + 1 - 1) := by
          rw [show t + 1 - 1 = (t - 1) + 1 by omega, pow_succ]
          ring
  have hd : ∀ i, (Finset.univ.filter (fun j => Not (j = i) /\
      exists v, I i v = true /\ I j v = true)).card ≤ k ^ 2 := by
    intro i
    let E : Finset (Fin n) := Finset.univ.filter (fun v => I i v = true)
    let D : Fin n → Finset (Fin m) := fun v =>
      Finset.univ.filter (fun j => I j v = true)
    calc
      (Finset.univ.filter (fun j => Not (j = i) /\
        exists v, I i v = true /\ I j v = true)).card ≤ (E.biUnion D).card := by
          apply Finset.card_le_card
          intro j hj
          obtain ⟨_, ⟨_, v, hiv, hjv⟩⟩ := Finset.mem_filter.mp hj
          exact Finset.mem_biUnion.mpr ⟨v, by simpa [E] using hiv,
            by simpa [D] using hjv⟩
      _ ≤ ∑ v ∈ E, (D v).card := Finset.card_biUnion_le
      _ ≤ ∑ _v ∈ E, k := by
        gcongr with v hv
        simpa [D] using hdeg v
      _ = k ^ 2 := by simp [E, hk i, pow_two]
  apply color_meet n m k (k ^ 2) I hk hd
  have he : Real.exp 1 < 3 := lt_trans Real.exp_one_lt_d9 (by norm_num)
  have hnat := hpow_nat k hk9
  calc
    Real.exp 1 * (((k ^ 2 : ℕ) : ℝ) + 1) ≤
        3 * (((k ^ 2 : ℕ) : ℝ) + 1) := by gcongr
    _ ≤ (2 : ℝ) ^ (k - 1) := by exact_mod_cast hnat

theorem sat_exists (n m k d : Nat) (V s : Fin m -> Fin n -> Bool)
    (hk : forall i, (Finset.univ.filter (fun v => V i v = true)).card = k)
    (hd : forall i, (Finset.univ.filter (fun j => Not (j = i) /\
      exists v, V i v = true /\ V j v = true)).card <= d)
    (hkd : Real.exp 1 * ((d : Real) + 1) <= 2 ^ k) :
    exists x : Fin n -> Bool, forall i, exists v, V i v = true /\ x v = s i v := by
  classical
  let supp : Fin m → Finset (Fin n) := fun i =>
    Finset.univ.filter (fun v => V i v = true)
  let bad : Fin m → (Fin n → Bool) → Prop := fun i x =>
    ∀ v ∈ supp i, x v ≠ s i v
  have hlocal : ∀ i x y, (∀ v ∈ supp i, x v = y v) → (bad i x ↔ bad i y) := by
    intro i x y heq
    constructor <;> intro h v hv
    · rw [← heq v hv]; exact h v hv
    · rw [heq v hv]; exact h v hv
  have hprob : ∀ i, (Measure.pi (fun _ : Fin n =>
      uniformOn (Set.univ : Set Bool))).real {w | bad i w} ≤
      (1 / 2 : ℝ) ^ k := by
    intro i
    have hevent : {w | bad i w} =
        {w | ∀ v ∈ supp i, w v = !(s i v)} := by
      ext w
      simp only [bad, mem_setOf_eq]
      constructor <;> intro h v hv
      · specialize h v hv
        revert h
        cases w v <;> cases s i v <;> simp
      · specialize h v hv
        revert h
        cases w v <;> cases s i v <;> simp
    rw [hevent, cylinder_prob_fun,
      show (supp i).card = k by simpa [supp] using hk i]
  have hdegree : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧
      ¬ Disjoint (supp i) (supp j))).card ≤ d := by
    intro i
    simpa only [supp, Finset.not_disjoint_iff, Finset.mem_filter, Finset.mem_univ,
      true_and] using hd i
  let x : ℝ := if d = 0 then 1 / 2 else 1 / ((d : ℝ) + 1)
  have hx0 : 0 ≤ x := by simp [x]; positivity
  have hx1 : x < 1 := by
    by_cases hd0 : d = 0
    · simp [x, hd0]
      norm_num
    · simp only [x, hd0, if_false]
      have hdpos : (0 : ℝ) < d := by exact_mod_cast Nat.pos_of_ne_zero hd0
      exact (div_lt_one (by positivity)).mpr (by linarith)
  have hpx : (1 / 2 : ℝ) ^ k ≤ x * (1 - x) ^ d := by
    by_cases hd0 : d = 0
    · subst d
      simp only [x, if_pos rfl, pow_zero, mul_one]
      have he2 : (2 : ℝ) < Real.exp 1 := lt_trans (by norm_num) Real.exp_one_gt_d9
      have hinv : 1 / (2 : ℝ) ^ k ≤ 1 / Real.exp 1 :=
        one_div_le_one_div_of_le (Real.exp_pos _) (by simpa using hkd)
      rw [← one_div_pow] at hinv
      exact le_trans hinv (one_div_lt_one_div_of_lt (by norm_num) he2).le
    · simpa [x, hd0] using lll_numeric d k hkd
  obtain ⟨xv, hxv⟩ := boolean_local_lemma supp bad hlocal d
    ((1 / 2 : ℝ) ^ k) x (by positivity) hx0 hx1 hprob hdegree hpx
  refine ⟨xv, ?_⟩
  intro i
  have hn := hxv i
  simp only [bad] at hn
  push Not at hn
  obtain ⟨v, hv, heq⟩ := hn
  exact ⟨v, by simpa [supp] using hv, heq⟩

private theorem color_family {ν ι : Type*} [Fintype ν] [Fintype ι]
    [DecidableEq ν] [DecidableEq ι] (supp : ι → Finset ν) (k d : ℕ)
    (hk : ∀ i, (supp i).card = k)
    (hd : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧
      ¬ Disjoint (supp i) (supp j))).card ≤ d)
    (hkd : Real.exp 1 * ((d : Real) + 1) ≤ 2 ^ (k - 1)) :
    ∃ c : ν → Bool, ∀ i, 2 ≤ ((supp i).image c).card := by
  classical
  have hkpos : 0 < k := by
    by_contra hn
    have hk0 : k = 0 := by omega
    have he : 1 < Real.exp 1 := Real.one_lt_exp_iff.mpr (by norm_num)
    rw [hk0] at hkd
    norm_num at hkd
    have hd0 : (0 : ℝ) ≤ d := by positivity
    nlinarith
  let bad : ι → (ν → Bool) → Prop := fun i c =>
    (∀ v ∈ supp i, c v = true) ∨ (∀ v ∈ supp i, c v = false)
  have hlocal : ∀ i x y, (∀ v ∈ supp i, x v = y v) → (bad i x ↔ bad i y) := by
    intro i x y heq
    simp only [bad]
    constructor <;> rintro (h | h)
    · left; intro v hv; rw [← heq v hv]; exact h v hv
    · right; intro v hv; rw [← heq v hv]; exact h v hv
    · left; intro v hv; rw [heq v hv]; exact h v hv
    · right; intro v hv; rw [heq v hv]; exact h v hv
  have hprob : ∀ i, (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
      {w | bad i w} ≤ (1 / 2 : ℝ) ^ (k - 1) := by
    intro i
    rw [show {w | bad i w} =
      {w | ∀ v ∈ supp i, w v = true} ∪ {w | ∀ v ∈ supp i, w v = false} by rfl]
    calc
      _ ≤ (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
            {w | ∀ v ∈ supp i, w v = true} +
          (Measure.pi (fun _ : ν => uniformOn (Set.univ : Set Bool))).real
            {w | ∀ v ∈ supp i, w v = false} := measureReal_union_le _ _
      _ = (1 / 2 : ℝ) ^ (supp i).card + (1 / 2 : ℝ) ^ (supp i).card := by
        rw [cylinder_prob, cylinder_prob]
      _ = (1 / 2 : ℝ) ^ (k - 1) := by
        rw [hk i]
        conv_lhs => rw [show k = (k - 1) + 1 by omega, pow_succ]
        ring
  let x : ℝ := if d = 0 then 1 / 2 else 1 / ((d : ℝ) + 1)
  have hx0 : 0 ≤ x := by simp [x]; positivity
  have hx1 : x < 1 := by
    by_cases hd0 : d = 0
    · simp [x, hd0]; norm_num
    · simp only [x, hd0, if_false]
      have hdpos : (0 : ℝ) < d := by exact_mod_cast Nat.pos_of_ne_zero hd0
      exact (div_lt_one (by positivity)).mpr (by linarith)
  have hpx : (1 / 2 : ℝ) ^ (k - 1) ≤ x * (1 - x) ^ d := by
    by_cases hd0 : d = 0
    · subst d
      simp only [x, if_pos rfl, pow_zero, mul_one]
      have he2 : (2 : ℝ) < Real.exp 1 := lt_trans (by norm_num) Real.exp_one_gt_d9
      have hinv : 1 / (2 : ℝ) ^ (k - 1) ≤ 1 / Real.exp 1 :=
        one_div_le_one_div_of_le (Real.exp_pos _) (by simpa using hkd)
      rw [← one_div_pow] at hinv
      exact le_trans hinv (one_div_lt_one_div_of_lt (by norm_num) he2).le
    · simpa [x, hd0] using lll_numeric d (k - 1) hkd
  obtain ⟨c, hc⟩ := boolean_local_lemma supp bad hlocal d
    ((1 / 2 : ℝ) ^ (k - 1)) x (by positivity) hx0 hx1 hprob hd hpx
  refine ⟨c, fun i => ?_⟩
  have hn := hc i
  simp only [bad, not_or] at hn
  have ht : true ∈ (supp i).image c := by
    have h := not_forall.mp hn.2
    obtain ⟨v, h⟩ := h
    have hv := not_forall.mp h
    apply Finset.mem_image.mpr
    refine ⟨v, hv.1, ?_⟩
    cases hcv : c v <;> simp_all
  have hf : false ∈ (supp i).image c := by
    have h := not_forall.mp hn.1
    obtain ⟨v, h⟩ := h
    have hv := not_forall.mp h
    apply Finset.mem_image.mpr
    refine ⟨v, hv.1, ?_⟩
    cases hcv : c v <;> simp_all
  calc
    2 = (Finset.univ : Finset Bool).card := by decide
    _ ≤ ((supp i).image c).card := Finset.card_le_card (by
      intro b hb
      cases b
      · exact hf
      · exact ht)

theorem ramsey_color (n k : Nat)
    (h : Real.exp 1 * (((Nat.choose k 2 * Nat.choose n (k - 2) : Nat) : Real) + 1)
      <= 2 ^ (Nat.choose k 2 - 1)) :
    exists c : Sym2 (Fin n) -> Bool, forall s : Finset (Fin n), s.card = k ->
      2 <= (s.offDiag.image (fun q => c (Sym2.mk q.1 q.2))).card := by
  classical
  let supp : {s : Finset (Fin n) // s.card = k} → Finset (Sym2 (Fin n)) :=
    fun s => s.1.offDiag.image (Function.uncurry Sym2.mk)
  have hsupp : ∀ s, (supp s).card = Nat.choose k 2 := by
    intro s
    simpa [supp, s.2] using Sym2.card_image_offDiag s.1
  have hverts : ∀ (s : {s : Finset (Fin n) // s.card = k})
      (q : Sym2 (Fin n)), q ∈ supp s → q.toFinset ⊆ s.1 := by
    intro s q hq
    obtain ⟨ab, hab, rfl⟩ := Finset.mem_image.mp hq
    change (Sym2.mk ab.1 ab.2).toFinset ⊆ s.1
    rw [Sym2.toFinset_mk_eq]
    have hp := Finset.mem_offDiag.mp hab
    intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl
    · exact hp.1
    · exact hp.2.1
  have hqcard : ∀ (s : {s : Finset (Fin n) // s.card = k})
      (q : Sym2 (Fin n)), q ∈ supp s → q.toFinset.card = 2 := by
    intro s q hq
    obtain ⟨ab, hab, rfl⟩ := Finset.mem_image.mp hq
    change (Sym2.mk ab.1 ab.2).toFinset.card = 2
    rw [Sym2.toFinset_mk_eq]
    have hp := Finset.mem_offDiag.mp hab
    simp [hp.2.2]
  have hdegree : ∀ i, (Finset.univ.filter (fun j => j ≠ i ∧
      ¬ Disjoint (supp i) (supp j))).card ≤ Nat.choose k 2 * Nat.choose n (k - 2) := by
    intro i
    let C : Sym2 (Fin n) → Finset {s : Finset (Fin n) // s.card = k} := fun q =>
      Finset.univ.filter (fun t => q.toFinset ⊆ t.1)
    have hC : ∀ q ∈ supp i, (C q).card ≤ Nat.choose n (k - 2) := by
      intro q hqi
      let F : {s : Finset (Fin n) // s.card = k} → Finset (Fin n) :=
        fun t => t.1 \ q.toFinset
      have hmap : Set.MapsTo F (↑(C q))
          (↑((Finset.univ : Finset (Fin n)).powersetCard (k - 2))) := by
        intro t ht
        have hqt : q.toFinset ⊆ t.1 := by simpa [C] using ht
        rw [Finset.mem_coe, Finset.mem_powersetCard]
        constructor
        · exact fun _ _ => Finset.mem_univ _
        · change (t.1 \ q.toFinset).card = k - 2
          rw [Finset.card_sdiff, Finset.inter_eq_left.mpr hqt, t.2,
            hqcard i q hqi]
      have hinj : Set.InjOn F (↑(C q)) := by
        intro t ht u hu heq
        apply Subtype.ext
        have hqt : q.toFinset ⊆ t.1 := by simpa [C] using ht
        have hqu : q.toFinset ⊆ u.1 := by simpa [C] using hu
        rw [← Finset.sdiff_union_of_subset hqt, ← Finset.sdiff_union_of_subset hqu]
        exact congrArg (fun z => z ∪ q.toFinset) heq
      calc
        (C q).card ≤ ((Finset.univ : Finset (Fin n)).powersetCard (k - 2)).card :=
          Finset.card_le_card_of_injOn F hmap hinj
        _ = Nat.choose n (k - 2) := by rw [Finset.card_powersetCard]; simp
    calc
      (Finset.univ.filter (fun j => j ≠ i ∧
        ¬ Disjoint (supp i) (supp j))).card ≤ ((supp i).biUnion C).card := by
          apply Finset.card_le_card
          intro j hj
          have hn := (Finset.mem_filter.mp hj).2.2
          obtain ⟨q, hqi, hqj⟩ := Finset.not_disjoint_iff.mp hn
          exact Finset.mem_biUnion.mpr ⟨q, hqi,
            Finset.mem_filter.mpr ⟨Finset.mem_univ _, hverts j q hqj⟩⟩
      _ ≤ ∑ q ∈ supp i, (C q).card := Finset.card_biUnion_le
      _ ≤ ∑ _q ∈ supp i, Nat.choose n (k - 2) := by
        gcongr with q hq
        exact hC q hq
      _ = Nat.choose k 2 * Nat.choose n (k - 2) := by simp [hsupp i]
  obtain ⟨c, hc⟩ := color_family supp (Nat.choose k 2)
    (Nat.choose k 2 * Nat.choose n (k - 2)) hsupp hdegree h
  refine ⟨c, ?_⟩
  intro s hs
  have hh := hc ⟨s, hs⟩
  simp only [supp, Finset.image_image] at hh
  rw [show (fun q => c (Sym2.mk q.1 q.2)) =
    c ∘ Function.uncurry Sym2.mk by rfl]
  exact hh

private def APIndex (N k : ℕ) :=
  {p : Fin N × Fin N // 1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N}

private noncomputable instance (N k : ℕ) : Fintype (APIndex N k) := by
  unfold APIndex
  exact Fintype.subtype
    (Finset.univ.filter (fun p : Fin N × Fin N =>
      1 ≤ p.2.1 ∧ p.1.1 + (k - 1) * p.2.1 < N)) (by simp)

private def apTerm {N k : ℕ} (p : APIndex N k) (j : Fin k) : Fin N := by
  refine ⟨p.1.1 + j.1 * p.1.2.1, ?_⟩
  have hj : j.1 ≤ k - 1 := by omega
  have hm := Nat.mul_le_mul_right p.1.2.1 hj
  exact lt_of_le_of_lt (Nat.add_le_add_left hm _) p.2.2

private lemma apTerm_injective {N k : ℕ} (p : APIndex N k) :
    Function.Injective (apTerm p) := by
  intro i j hij
  apply Fin.ext
  have hval := congrArg Fin.val hij
  simp only [apTerm] at hval
  have hmul : i.1 * p.1.2.1 = j.1 * p.1.2.1 := Nat.add_left_cancel hval
  exact Nat.mul_right_cancel (lt_of_lt_of_le Nat.zero_lt_one p.2.1) hmul

theorem ap_color (N k : Nat) (h : Real.exp 1 * (((k ^ 2 * N : Nat) : Real) + 1) <= 2 ^ (k - 1)) :
    exists c : Nat -> Bool, forall a r : Nat, 1 <= r -> a + (k - 1) * r < N ->
      2 <= ((Finset.range k).image (fun j => c (a + j * r))).card := by
  classical
  have hk2 : 2 ≤ k := by
    by_contra hn
    have hk : k ≤ 1 := by omega
    have hkpow : k - 1 = 0 := by omega
    rw [hkpow] at h
    norm_num at h
    have he : 1 < Real.exp 1 := Real.one_lt_exp_iff.mpr (by norm_num)
    have hnonneg : 0 ≤ (k : ℝ) ^ 2 * (N : ℝ) :=
      mul_nonneg (sq_nonneg _) (Nat.cast_nonneg _)
    nlinarith
  let supp : APIndex N k → Finset (Fin N) := fun p =>
    Finset.univ.image (apTerm p)
  have hsupp : ∀ p, (supp p).card = k := by
    intro p
    change (Finset.univ.image (apTerm p)).card = k
    rw [Finset.card_image_of_injective _ (apTerm_injective p)]
    simp
  have hdegree : ∀ i, (Finset.univ.filter (fun t => t ≠ i ∧
      ¬ Disjoint (supp i) (supp t))).card ≤ k ^ 2 * N := by
    intro i
    let D : Fin N → Fin k → Finset (APIndex N k) := fun x j =>
      Finset.univ.filter (fun t => apTerm t j = x)
    let C : Fin N → Finset (APIndex N k) := fun x =>
      Finset.univ.filter (fun t => x ∈ supp t)
    have hD : ∀ x j, (D x j).card ≤ N := by
      intro x j
      let F : APIndex N k → Fin N := fun t => t.1.2
      apply le_trans (Finset.card_le_card_of_injOn F (by
        intro t ht
        exact Finset.mem_univ _) (by
        intro t ht u hu heq
        apply Subtype.ext
        apply Prod.ext
        · apply Fin.ext
          have ht' : apTerm t j = x := by simpa [D] using ht
          have hu' : apTerm u j = x := by simpa [D] using hu
          have hv := congrArg Fin.val (ht'.trans hu'.symm)
          have hr := congrArg Fin.val heq
          simp only [apTerm] at hv
          simp only [F] at hr
          rw [hr] at hv
          exact Nat.add_right_cancel hv
        · exact heq)) (by simp)
    have hC : ∀ x, (C x).card ≤ k * N := by
      intro x
      calc
        (C x).card ≤ ((Finset.univ : Finset (Fin k)).biUnion (D x)).card := by
          apply Finset.card_le_card
          intro t ht
          have hxt : x ∈ supp t := by simpa [C] using ht
          obtain ⟨j, _, hj⟩ := Finset.mem_image.mp hxt
          exact Finset.mem_biUnion.mpr ⟨j, Finset.mem_univ _,
            Finset.mem_filter.mpr ⟨Finset.mem_univ _, hj⟩⟩
        _ ≤ ∑ j : Fin k, (D x j).card := by
          simpa using (Finset.card_biUnion_le :
            ((Finset.univ : Finset (Fin k)).biUnion (D x)).card ≤
              ∑ j ∈ (Finset.univ : Finset (Fin k)), (D x j).card)
        _ ≤ ∑ _j : Fin k, N := by gcongr with j; exact hD x j
        _ = k * N := by simp
    calc
      (Finset.univ.filter (fun t => t ≠ i ∧
        ¬ Disjoint (supp i) (supp t))).card ≤ ((supp i).biUnion C).card := by
          apply Finset.card_le_card
          intro t ht
          have hn := (Finset.mem_filter.mp ht).2.2
          obtain ⟨x, hxi, hxt⟩ := Finset.not_disjoint_iff.mp hn
          exact Finset.mem_biUnion.mpr ⟨x, hxi,
            Finset.mem_filter.mpr ⟨Finset.mem_univ _, hxt⟩⟩
      _ ≤ ∑ x ∈ supp i, (C x).card := Finset.card_biUnion_le
      _ ≤ ∑ _x ∈ supp i, k * N := by gcongr with x hx; exact hC x
      _ = k ^ 2 * N := by simp [hsupp i, pow_two]; ring
  obtain ⟨cf, hcf⟩ := color_family supp k (k ^ 2 * N) hsupp hdegree h
  let c : Nat → Bool := fun a => if ha : a < N then cf ⟨a, ha⟩ else false
  refine ⟨c, ?_⟩
  intro a r hr har
  have haN : a < N := lt_of_le_of_lt (Nat.le_add_right _ _) har
  have hrmul : r ≤ (k - 1) * r := Nat.le_mul_of_pos_left r (by omega)
  have hrN : r < N := lt_of_le_of_lt (le_trans hrmul (Nat.le_add_left _ _)) har
  let p : APIndex N k := ⟨(⟨a, haN⟩, ⟨r, hrN⟩), hr, har⟩
  have hp := hcf p
  rw [show supp p = Finset.univ.image (apTerm p) by rfl,
    Finset.image_image] at hp
  have heq : (Finset.range k).image (fun j => c (a + j * r)) =
      Finset.univ.image (fun j : Fin k => cf (apTerm p j)) := by
    ext b
    constructor
    · intro hb
      obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hb
      have hjk : j < k := Finset.mem_range.mp hj
      have hterm : a + j * r < N := by
        have hjle : j ≤ k - 1 := by omega
        have hm := Nat.mul_le_mul_right r hjle
        omega
      exact Finset.mem_image.mpr ⟨⟨j, hjk⟩, Finset.mem_univ _, by
        simp [c, hterm, apTerm, p]⟩
    · intro hb
      obtain ⟨j, _, rfl⟩ := Finset.mem_image.mp hb
      apply Finset.mem_image.mpr
      refine ⟨j.1, Finset.mem_range.mpr j.2, ?_⟩
      have hterm : a + j.1 * r < N := (apTerm p j).2
      simp [c, hterm, apTerm, p]
  rw [heq]
  exact hp

end TuringTask
