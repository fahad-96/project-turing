import TuringTask.Fib

/-!
# The rank of apparition and the exponent of a prime in `F n`

For a prime `p` dividing some `F k` (`k ≥ 1`), `rk p h` is the least such `k`; then
`p ∣ F k ↔ rk ∣ k`.  For odd `p` the exponent satisfies
`v_p (F (rk * e)) = v_p (F rk) + v_p e`; for `p = 2` the exponent of `F n` is `0`, `1` or
`v_2 n + 2` according to `3 ∤ n`, `n = 3 (mod 6)`, `6 ∣ n`.
-/

namespace TuringTask

/-- `p` divides some Fibonacci number with positive index. -/
def HasRank (p : ℕ) : Prop := ∃ k, 0 < k ∧ p ∣ Nat.fib k

/-- The rank of apparition. -/
noncomputable def rk (p : ℕ) (h : HasRank p) : ℕ := Nat.find h

theorem rk_pos (p : ℕ) (h : HasRank p) : 0 < rk p h := (Nat.find_spec h).1

theorem dvd_fib_rk (p : ℕ) (h : HasRank p) : p ∣ Nat.fib (rk p h) := (Nat.find_spec h).2

theorem rk_le (p : ℕ) (h : HasRank p) {k : ℕ} (hk : 0 < k) (hdvd : p ∣ Nat.fib k) :
    rk p h ≤ k :=
  Nat.find_min' h ⟨hk, hdvd⟩

/-- `p ∣ F k` iff the rank divides `k`. -/
theorem dvd_fib_iff (p : ℕ) (h : HasRank p) (k : ℕ) : p ∣ Nat.fib k ↔ rk p h ∣ k := by
  constructor
  · intro hk
    have hg : p ∣ Nat.fib (Nat.gcd k (rk p h)) := by
      rw [Nat.fib_gcd]
      exact Nat.dvd_gcd hk (dvd_fib_rk p h)
    have hpos : 0 < Nat.gcd k (rk p h) := Nat.gcd_pos_of_pos_right _ (rk_pos p h)
    have h1 := rk_le p h hpos hg
    have h2 : Nat.gcd k (rk p h) ≤ rk p h := Nat.gcd_le_right _ (rk_pos p h)
    have h3 : Nat.gcd k (rk p h) = rk p h := le_antisymm h2 h1
    rw [← h3]
    exact Nat.gcd_dvd_left _ _
  · intro hk
    exact (dvd_fib_rk p h).trans (Nat.fib_dvd _ _ hk)

theorem hasRank_of_dvd {p n : ℕ} (hn : 0 < n) (h : p ∣ Nat.fib n) : HasRank p := ⟨n, hn, h⟩

theorem rk_dvd_of_dvd (p : ℕ) (h : HasRank p) {n : ℕ} (hn : p ∣ Nat.fib n) : rk p h ∣ n :=
  (dvd_fib_iff p h n).mp hn

/-- The rank is `n` itself when `p ∣ F n` and `p` divides no earlier `F k`. -/
theorem rk_eq_of_primitive (p : ℕ) (h : HasRank p) {n : ℕ} (hn : 0 < n) (hdvd : p ∣ Nat.fib n)
    (hprim : ∀ k, 0 < k → k < n → ¬ p ∣ Nat.fib k) : rk p h = n := by
  have h1 := rk_le p h hn hdvd
  rcases lt_or_eq_of_le h1 with h2 | h2
  · exact absurd (dvd_fib_rk p h) (hprim _ (rk_pos p h) h2)
  · exact h2

theorem hasRank_two : HasRank 2 := ⟨3, by norm_num, by decide⟩

theorem rk_two : rk 2 hasRank_two = 3 := by
  apply rk_eq_of_primitive 2 hasRank_two (by norm_num) (by decide)
  intro k hk hk3
  interval_cases k <;> decide

theorem hasRank_three : HasRank 3 := ⟨4, by norm_num, by decide⟩

theorem rk_three : rk 3 hasRank_three = 4 := by
  apply rk_eq_of_primitive 3 hasRank_three (by norm_num) (by decide)
  intro k hk hk4
  interval_cases k <;> decide

theorem hasRank_five : HasRank 5 := ⟨5, by norm_num, by decide⟩

theorem rk_five : rk 5 hasRank_five = 5 := by
  apply rk_eq_of_primitive 5 hasRank_five (by norm_num) (by decide)
  intro k hk hk5
  interval_cases k <;> decide

/-- The rank of a prime `p ≠ 5` divides `p - 1` or `p + 1`. -/
theorem rk_dvd_pred_or_succ (p : ℕ) (hp : p.Prime) (h5 : p ≠ 5) (h : HasRank p) :
    rk p h ∣ p - 1 ∨ rk p h ∣ p + 1 := by
  rcases prime_dvd_fib_pred_or_succ p hp h5 with h1 | h1
  · exact Or.inl (rk_dvd_of_dvd p h h1)
  · exact Or.inr (rk_dvd_of_dvd p h h1)

/-- Every prime factor of the rank of an odd prime `p` is at most `p`. -/
theorem prime_dvd_rk_le (p : ℕ) (hp : p.Prime) (hp2 : p ≠ 2) (h : HasRank p) (ℓ : ℕ)
    (hℓ : ℓ.Prime) (hdvd : ℓ ∣ rk p h) : ℓ ≤ p := by
  by_cases h5 : p = 5
  · subst h5
    have : rk 5 h = 5 := by
      have e : h = hasRank_five := rfl
      rw [e, rk_five]
    rw [this] at hdvd
    exact Nat.le_of_dvd (by norm_num) hdvd
  · rcases rk_dvd_pred_or_succ p hp h5 h with h1 | h1
    · have hpos : 0 < p - 1 := by have := hp.two_le; omega
      have h2 : ℓ ≤ p - 1 := Nat.le_of_dvd hpos (hdvd.trans h1)
      omega
    · have hle := Nat.le_of_dvd (by omega) (hdvd.trans h1)
      by_contra hcon
      push Not at hcon
      have heq : ℓ = p + 1 := by omega
      -- `p + 1` is even and prime, so `p = 1`
      have hodd : Odd p := hp.odd_of_ne_two hp2
      have heven : Even ℓ := by rw [heq]; exact hodd.add_one
      have := (Nat.Prime.even_iff hℓ).mp heven
      have := hp.two_le
      omega

/-! ### Lifting the exponent for odd primes -/

theorem not_dvd_fib_succ_of_dvd_fib {p m : ℕ} (hp : p.Prime) (h : p ∣ Nat.fib m) :
    ¬ p ∣ Nat.fib (m + 1) := by
  intro h'
  have h1 := Nat.dvd_gcd h h'
  rw [Nat.Coprime.gcd_eq_one (Nat.fib_coprime_fib_succ m)] at h1
  exact hp.one_lt.ne' (Nat.dvd_one.mp h1)

theorem fib_mul_div_eq (m e : ℕ) :
    Nat.fib (e * m) / Nat.fib m * Nat.fib m = Nat.fib (e * m) :=
  Nat.div_mul_cancel (Nat.fib_dvd _ _ (Dvd.intro_left _ rfl))

/-- `v_p (F (e m)) = v_p (F m)` when `p ∣ F m`, `p ∤ e` and `p` is odd. -/
theorem padicValNat_fib_mul_of_not_dvd (p m e : ℕ) [hp : Fact p.Prime] (hm : 1 ≤ m)
    (he : 1 ≤ e) (hpm : p ∣ Nat.fib m) (hpe : ¬ p ∣ e) :
    padicValNat p (Nat.fib (e * m)) = padicValNat p (Nat.fib m) := by
  obtain ⟨s, hs⟩ := fib_mul_expand' m hm e he
  set G := Nat.fib (e * m) / Nat.fib m with hG
  have hGm : G * Nat.fib m = Nat.fib (e * m) := fib_mul_div_eq m e
  have hfm : 0 < Nat.fib m := fib_pos' (by omega)
  have hG0 : G ≠ 0 := by
    intro h0
    rw [h0, zero_mul] at hGm
    exact (fib_pos' (by positivity : 0 < e * m)).ne' hGm.symm
  have hGZ : (G : ℤ) = e * (Nat.fib (m + 1) : ℤ) ^ (e - 1) + Nat.fib m * s := by
    have h1 : (G : ℤ) * Nat.fib m = Nat.fib (e * m) := by exact_mod_cast hGm
    rw [hs] at h1
    have hfm' : (Nat.fib m : ℤ) ≠ 0 := by exact_mod_cast hfm.ne'
    have : ((G : ℤ) - (e * (Nat.fib (m + 1) : ℤ) ^ (e - 1) + Nat.fib m * s)) * Nat.fib m = 0 := by
      linear_combination h1
    rcases mul_eq_zero.mp this with h | h
    · linarith
    · exact absurd h hfm'
  have hpG : ¬ p ∣ G := by
    intro hdvd
    have h1 : (p : ℤ) ∣ (G : ℤ) := by exact_mod_cast hdvd
    rw [hGZ] at h1
    have h2 : (p : ℤ) ∣ (Nat.fib m : ℤ) * s := by
      exact (Int.natCast_dvd_natCast.mpr hpm).mul_right s
    have h3 : (p : ℤ) ∣ e * (Nat.fib (m + 1) : ℤ) ^ (e - 1) := (Int.dvd_add_left h2).mp h1
    have h4 : p ∣ e * Nat.fib (m + 1) ^ (e - 1) := by exact_mod_cast h3
    rcases (Nat.Prime.dvd_mul hp.out).mp h4 with h | h
    · exact hpe h
    · exact not_dvd_fib_succ_of_dvd_fib hp.out hpm (hp.out.dvd_of_dvd_pow h)
  rw [← hGm, padicValNat.mul hG0 hfm.ne', padicValNat.eq_zero_of_not_dvd hpG, zero_add]

/-- `v_p (F (p m)) = v_p (F m) + 1` when `p ∣ F m` and `p` is odd. -/
theorem padicValNat_fib_mul_self (p m : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) (hm : 1 ≤ m)
    (hpm : p ∣ Nat.fib m) :
    padicValNat p (Nat.fib (p * m)) = padicValNat p (Nat.fib m) + 1 := by
  have hp3 : 3 ≤ p := by
    have := hp.out.two_le
    omega
  obtain ⟨u, t, hA, -⟩ := fib_mul_expand m hm (p - 2)
  have hpq : p - 2 + 2 = p := by omega
  rw [hpq, Nat.cast_sub (by omega : 2 ≤ p)] at hA
  push_cast at hA
  set G := Nat.fib (p * m) / Nat.fib m with hG
  have hGm : G * Nat.fib m = Nat.fib (p * m) := fib_mul_div_eq m p
  have hfm : 0 < Nat.fib m := fib_pos' (by omega)
  have hG0 : G ≠ 0 := by
    intro h0
    rw [h0, zero_mul] at hGm
    exact (fib_pos' (by positivity : 0 < p * m)).ne' hGm.symm
  have hGZ : (G : ℤ) = p * (Nat.fib (m + 1) : ℤ) ^ (p - 2 + 1)
      - (Nat.choose p 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ (p - 2) * Nat.fib m
      + (Nat.fib m : ℤ) ^ 2 * u := by
    have h1 : (G : ℤ) * Nat.fib m = Nat.fib (p * m) := by exact_mod_cast hGm
    rw [hA] at h1
    have hfm' : (Nat.fib m : ℤ) ≠ 0 := by exact_mod_cast hfm.ne'
    have : ((G : ℤ) - (p * (Nat.fib (m + 1) : ℤ) ^ (p - 2 + 1)
        - (Nat.choose p 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ (p - 2) * Nat.fib m
        + (Nat.fib m : ℤ) ^ 2 * u)) * Nat.fib m = 0 := by
      linear_combination h1
    rcases mul_eq_zero.mp this with h | h
    · linarith
    · exact absurd h hfm'
  -- `p ∣ G` and `p ^ 2 ∤ G`
  have hpc : p ∣ Nat.choose p 2 := hp.out.dvd_choose_self (by norm_num) (by omega)
  have hpG : p ∣ G := by
    have h1 : (p : ℤ) ∣ (G : ℤ) := by
      rw [hGZ]
      have hpmZ : (p : ℤ) ∣ (Nat.fib m : ℤ) := Int.natCast_dvd_natCast.mpr hpm
      have hpcZ : (p : ℤ) ∣ (Nat.choose p 2 : ℤ) := Int.natCast_dvd_natCast.mpr hpc
      refine dvd_add (dvd_sub (dvd_mul_right _ _)
        (dvd_mul_of_dvd_left (dvd_mul_of_dvd_left hpcZ _) _)) ?_
      exact dvd_mul_of_dvd_left (dvd_pow hpmZ (by norm_num)) _
    exact_mod_cast h1
  have hp2G : ¬ p ^ 2 ∣ G := by
    intro hdvd
    have h1 : ((p : ℤ) ^ 2) ∣ (G : ℤ) := by exact_mod_cast hdvd
    rw [hGZ] at h1
    have h2 : ((p : ℤ) ^ 2) ∣
        (Nat.choose p 2 : ℤ) * (Nat.fib (m + 1) : ℤ) ^ (p - 2) * Nat.fib m := by
      rw [sq]
      exact mul_dvd_mul ((Int.natCast_dvd_natCast.mpr hpc).mul_right _)
        (Int.natCast_dvd_natCast.mpr hpm)
    have h3 : ((p : ℤ) ^ 2) ∣ (Nat.fib m : ℤ) ^ 2 * u :=
      (pow_dvd_pow_of_dvd (Int.natCast_dvd_natCast.mpr hpm) 2).mul_right u
    have h4 : ((p : ℤ) ^ 2) ∣ p * (Nat.fib (m + 1) : ℤ) ^ (p - 2 + 1) := by
      have h5 := (Int.dvd_add_left h3).mp h1
      have h6 := dvd_add h5 h2
      rwa [sub_add_cancel] at h6
    have h5 : p ^ 2 ∣ p * Nat.fib (m + 1) ^ (p - 2 + 1) := by exact_mod_cast h4
    rw [sq] at h5
    have h6 : p ∣ Nat.fib (m + 1) ^ (p - 2 + 1) :=
      (Nat.mul_dvd_mul_iff_left hp.out.pos).mp h5
    exact not_dvd_fib_succ_of_dvd_fib hp.out hpm (hp.out.dvd_of_dvd_pow h6)
  have hvG : padicValNat p G = 1 := by
    have h1 : 1 ≤ padicValNat p G := by
      rw [← padicValNat_dvd_iff_le hG0]; simpa using hpG
    have h2 : ¬ 2 ≤ padicValNat p G := by
      rw [← padicValNat_dvd_iff_le hG0]; exact hp2G
    omega
  rw [← hGm, padicValNat.mul hG0 hfm.ne', hvG, add_comm]

/-- `v_p (F (rk * e)) = v_p (F rk) + v_p e` for odd primes `p`. -/
theorem padicValNat_fib_rk_mul (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) (h : HasRank p)
    (e : ℕ) (he : 0 < e) :
    padicValNat p (Nat.fib (rk p h * e)) = padicValNat p (Nat.fib (rk p h)) + padicValNat p e := by
  obtain ⟨a, e', he', rfl⟩ := Nat.exists_eq_pow_mul_and_not_dvd he.ne' p hp.out.one_lt.ne'
  have he'0 : 0 < e' := by
    rcases Nat.eq_zero_or_pos e' with h0 | h0
    · simp [h0] at he
    · exact h0
  have hpow : ∀ a : ℕ, padicValNat p (Nat.fib (rk p h * p ^ a)) =
      padicValNat p (Nat.fib (rk p h)) + a := by
    intro a
    induction a with
    | zero => simp
    | succ a ih =>
      have : rk p h * p ^ (a + 1) = p * (rk p h * p ^ a) := by ring
      rw [this, padicValNat_fib_mul_self p _ hp2 (Nat.mul_pos (rk_pos p h) (pow_pos hp.out.pos a))
        ((dvd_fib_iff p h _).mpr (dvd_mul_right _ _)), ih]
      omega
  have h1 : rk p h * (p ^ a * e') = e' * (rk p h * p ^ a) := by ring
  rw [h1, padicValNat_fib_mul_of_not_dvd p _ e'
    (Nat.mul_pos (rk_pos p h) (pow_pos hp.out.pos a)) he'0
    ((dvd_fib_iff p h _).mpr (dvd_mul_right _ _)) he', hpow,
    padicValNat.mul (pow_ne_zero _ hp.out.ne_zero) he'0.ne', padicValNat.pow,
    padicValNat_self, padicValNat.eq_zero_of_not_dvd he']
  ring

/-- For an odd prime `p` with rank `r`: `v_p (F d) = v_p (F r) + v_p (d / r)` if `r ∣ d`,
and `0` otherwise. -/
theorem padicValNat_fib_eq (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) (h : HasRank p) (d : ℕ)
    (hd : 0 < d) :
    padicValNat p (Nat.fib d) =
      if rk p h ∣ d then padicValNat p (Nat.fib (rk p h)) + padicValNat p (d / rk p h) else 0 := by
  split_ifs with hr
  · obtain ⟨e, rfl⟩ := hr
    have he : 0 < e := by
      rcases Nat.eq_zero_or_pos e with h0 | h0
      · simp [h0] at hd
      · exact h0
    rw [Nat.mul_div_cancel_left _ (rk_pos p h)]
    exact padicValNat_fib_rk_mul p hp2 h e he
  · apply padicValNat.eq_zero_of_not_dvd
    rwa [dvd_fib_iff p h]

/-! ### The prime `2` -/

theorem two_dvd_fib_iff (n : ℕ) : 2 ∣ Nat.fib n ↔ 3 ∣ n := by
  rw [dvd_fib_iff 2 hasRank_two, rk_two]

/-- The Lucas numbers as natural numbers. -/
def lucN (n : ℕ) : ℕ := 2 * Nat.fib (n + 1) - Nat.fib n

theorem fib_le_two_mul_fib_succ (n : ℕ) : Nat.fib n ≤ 2 * Nat.fib (n + 1) := by
  have := Nat.fib_le_fib_succ (n := n); omega

theorem lucN_cast (n : ℕ) : (lucN n : ℤ) = luc n := by
  unfold lucN luc
  push_cast [fib_le_two_mul_fib_succ n]
  ring

theorem lucN_pos (n : ℕ) : 0 < lucN n := by
  unfold lucN
  have h1 : 0 < Nat.fib (n + 1) := fib_pos' (by omega)
  have h2 := Nat.fib_le_fib_succ (n := n)
  omega

theorem fib_two_mul_lucN (n : ℕ) : Nat.fib (2 * n) = Nat.fib n * lucN n := Nat.fib_two_mul n

theorem lucN_sq (n : ℕ) : (lucN n : ℤ) ^ 2 = 5 * (Nat.fib n : ℤ) ^ 2 + 4 * (-1) ^ n := by
  rw [lucN_cast]
  linear_combination luc_sq_sub n

theorem padicValNat_two_of_sq_eq_sixteen_mul {x y : ℕ} (hy : Odd y) (hx : x ^ 2 = 16 * y) :
    padicValNat 2 x = 2 := by
  have hy0 : y ≠ 0 := by rintro rfl; exact absurd hy (by decide)
  have hx0 : x ≠ 0 := by rintro rfl; rw [zero_pow (by norm_num)] at hx; omega
  have hy2 : ¬ 2 ∣ y := by rw [← even_iff_two_dvd]; exact Nat.not_even_iff_odd.mpr hy
  have h1 : padicValNat 2 (x ^ 2) = 2 * padicValNat 2 x := padicValNat.pow x 2
  have h2 : padicValNat 2 (16 * y) = 4 := by
    rw [padicValNat.mul (by norm_num) hy0, show (16 : ℕ) = 2 ^ 4 by norm_num,
      padicValNat.prime_pow, padicValNat.eq_zero_of_not_dvd hy2]
  rw [hx, h2] at h1
  omega

theorem padicValNat_two_of_sq_eq_four_mul {x y : ℕ} (hy : Odd y) (hx : x ^ 2 = 4 * y) :
    padicValNat 2 x = 1 := by
  have hy0 : y ≠ 0 := by rintro rfl; exact absurd hy (by decide)
  have hx0 : x ≠ 0 := by rintro rfl; rw [zero_pow (by norm_num)] at hx; omega
  have hy2 : ¬ 2 ∣ y := by rw [← even_iff_two_dvd]; exact Nat.not_even_iff_odd.mpr hy
  have h1 : padicValNat 2 (x ^ 2) = 2 * padicValNat 2 x := padicValNat.pow x 2
  have h2 : padicValNat 2 (4 * y) = 2 := by
    rw [padicValNat.mul (by norm_num) hy0, show (4 : ℕ) = 2 ^ 2 by norm_num,
      padicValNat.prime_pow, padicValNat.eq_zero_of_not_dvd hy2]
  rw [hx, h2] at h1
  omega

theorem padicValNat_two_fib_three_mul_odd (e : ℕ) (he : Odd e) :
    padicValNat 2 (Nat.fib (3 * e)) = 1 := by
  have he0 : 0 < e := by obtain ⟨c, rfl⟩ := he; omega
  obtain ⟨s, hs⟩ := fib_mul_expand' 3 (by norm_num) e he0
  have h4 : Nat.fib 4 = 3 := by decide
  have h3 : Nat.fib 3 = 2 := by decide
  rw [show 3 + 1 = 4 by rfl, h4, h3] at hs
  have hG : Nat.fib (e * 3) = 2 * (Nat.fib (e * 3) / 2) := by
    have : 2 ∣ Nat.fib (e * 3) := (two_dvd_fib_iff _).mpr (dvd_mul_left _ _)
    exact (Nat.mul_div_cancel' this).symm
  have hodd : ¬ 2 ∣ Nat.fib (e * 3) / 2 := by
    intro hdvd
    have h1 : (4 : ℤ) ∣ Nat.fib (e * 3) := by
      have : (4 : ℕ) ∣ Nat.fib (e * 3) := by
        rw [hG]; exact Nat.mul_dvd_mul_left 2 hdvd
      exact_mod_cast this
    rw [hs] at h1
    have h2 : (4 : ℤ) ∣ (2 : ℤ) ^ 2 * s := by norm_num
    have h3 : (4 : ℤ) ∣ e * (3 : ℤ) ^ (e - 1) * 2 := (Int.dvd_add_left h2).mp h1
    have h4 : (2 : ℤ) ∣ e * (3 : ℤ) ^ (e - 1) := by
      have : (2 : ℤ) * 2 ∣ (e * (3 : ℤ) ^ (e - 1)) * 2 := by simpa using h3
      exact (mul_dvd_mul_iff_right (by norm_num)).mp this
    have h5 : 2 ∣ e * 3 ^ (e - 1) := by exact_mod_cast h4
    rcases (Nat.Prime.dvd_mul Nat.prime_two).mp h5 with h | h
    · exact (Nat.not_even_iff_odd.mpr he) (even_iff_two_dvd.mpr h)
    · have := Nat.prime_two.dvd_of_dvd_pow h
      omega
  have hne : Nat.fib (e * 3) / 2 ≠ 0 := by
    intro h0; rw [h0, mul_zero] at hG; exact (fib_pos' (by positivity)).ne' hG
  rw [mul_comm 3 e, hG, padicValNat.mul (by norm_num) hne, padicValNat_self,
    padicValNat.eq_zero_of_not_dvd hodd]

/-- The exponent of `2` in `F n`: `0` if `3 ∤ n`, `1` if `n = 3 (mod 6)`, `v_2 n + 2` if `6 ∣ n`. -/
theorem padicValNat_two_fib (n : ℕ) (hn : 0 < n) :
    padicValNat 2 (Nat.fib n) =
      if 3 ∣ n then (if 6 ∣ n then padicValNat 2 n + 2 else 1) else 0 := by
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  by_cases h3 : 3 ∣ n
  · by_cases h6 : 6 ∣ n
    · simp only [h3, h6, if_true]
      obtain ⟨m, rfl⟩ : ∃ m, n = 2 * m := ⟨n / 2, by omega⟩
      have hm3 : 3 ∣ m := by omega
      have hm0 : 0 < m := by omega
      have hmlt : m < 2 * m := by omega
      have ihm := ih m hmlt hm0
      simp only [hm3, if_true] at ihm
      rw [fib_two_mul_lucN, padicValNat.mul (fib_pos' hm0).ne' (lucN_pos m).ne', ihm]
      have hsq := lucN_sq m
      have hv2 : padicValNat 2 (2 * m) = padicValNat 2 m + 1 := by
        rw [padicValNat.mul (by norm_num) hm0.ne', padicValNat_self]; ring
      by_cases h6m : 6 ∣ m
      · -- `8 ∣ F m`, so `L m ^ 2 = 4 (16 k + 1)` hmm: `5 F m ^ 2 + 4 = 4 (80 w ^ 2 + 1)`
        simp only [h6m, if_true] at ihm ⊢
        have h8 : 2 ^ 3 ∣ Nat.fib m := by
          have h1 : 1 ≤ padicValNat 2 m := one_le_padicValNat_of_dvd hm0.ne' (by omega)
          rw [padicValNat_dvd_iff_le (fib_pos' hm0).ne', ihm]; omega
        obtain ⟨w, hw⟩ := h8
        have heven : Even m := by obtain ⟨c, rfl⟩ := h6m; exact ⟨3 * c, by ring⟩
        rw [heven.neg_one_pow, hw] at hsq
        push_cast at hsq
        have hL : lucN m ^ 2 = 4 * (80 * w ^ 2 + 1) := by
          have : ((lucN m ^ 2 : ℕ) : ℤ) = ((4 * (80 * w ^ 2 + 1) : ℕ) : ℤ) := by
            push_cast; rw [hsq]; ring
          exact_mod_cast this
        rw [padicValNat_two_of_sq_eq_four_mul ⟨40 * w ^ 2, by ring⟩ hL, hv2]
      · -- `m` odd with `3 ∣ m`: `F m = 2 w`, `w` odd, and `L m ^ 2 = 16 (5 a (a+1) + 1)`
        simp only [h6m, if_false] at ihm ⊢
        have hmodd : Odd m := by
          rcases Nat.even_or_odd m with he | ho
          · exfalso; apply h6m
            obtain ⟨c, hc⟩ := he
            omega
          · exact ho
        have h2 : 2 ∣ Nat.fib m := (two_dvd_fib_iff m).mpr hm3
        obtain ⟨w, hw⟩ := h2
        have hwodd : Odd w := by
          by_contra hc
          have hev : Even w := Nat.not_odd_iff_even.mp hc
          have h4 : 2 ^ 2 ∣ Nat.fib m := by
            obtain ⟨c, rfl⟩ := hev; exact ⟨c, by rw [hw]; ring⟩
          rw [padicValNat_dvd_iff_le (fib_pos' hm0).ne', ihm] at h4
          omega
        obtain ⟨a, rfl⟩ := hwodd
        rw [hmodd.neg_one_pow, hw] at hsq
        push_cast at hsq
        have hev : Even (a * (a + 1)) := Nat.even_mul_succ_self a
        obtain ⟨b, hb⟩ := hev
        have hL : lucN m ^ 2 = 16 * (5 * (a * (a + 1)) + 1) := by
          have : ((lucN m ^ 2 : ℕ) : ℤ) = ((16 * (5 * (a * (a + 1)) + 1) : ℕ) : ℤ) := by
            push_cast; rw [hsq]; ring
          exact_mod_cast this
        have hy : Odd (5 * (a * (a + 1)) + 1) := ⟨5 * b, by rw [hb]; ring⟩
        rw [padicValNat_two_of_sq_eq_sixteen_mul hy hL, hv2]
        have : padicValNat 2 m = 0 := padicValNat.eq_zero_of_not_dvd (by
          rw [← even_iff_two_dvd]; exact Nat.not_even_iff_odd.mpr hmodd)
        omega
    · simp only [h3, h6, if_true, if_false]
      obtain ⟨e, rfl⟩ := h3
      have he : Odd e := by
        rcases Nat.even_or_odd e with ⟨c, hc⟩ | ho
        · exact absurd ⟨c, by omega⟩ h6
        · exact ho
      exact padicValNat_two_fib_three_mul_odd e he
  · simp only [h3, if_false]
    apply padicValNat.eq_zero_of_not_dvd
    rwa [two_dvd_fib_iff]

end TuringTask
