import TuringTask.Apps

/-!
# The five theorems of the task, in the form of the statement file
-/

namespace TuringTask

theorem fib_primitive (n : ℕ) (hn : 3 ≤ n) (h6 : ¬ n = 6) (h12 : ¬ n = 12) :
    ∃ q : ℕ, q.Prime ∧ Nat.fib n % q = 0 ∧ ∀ k : ℕ, 1 ≤ k → k < n → ¬ Nat.fib k % q = 0 := by
  obtain ⟨q, hq, hqd, hprim⟩ := exists_primitive_prime n hn h6 h12
  exact ⟨q, hq, Nat.mod_eq_zero_of_dvd hqd,
    fun k hk hkn hmod => hprim k hk hkn (Nat.dvd_of_mod_eq_zero hmod)⟩

theorem lucas_primitive_mod (n : ℕ) (hn : 2 ≤ n) (h6 : ¬ n = 6) :
    ∃ q : ℕ, q.Prime ∧ (Nat.fib (n - 1) + Nat.fib (n + 1)) % q = 0 ∧
      ∀ k : ℕ, 1 ≤ k → k < n → ¬ (Nat.fib (k - 1) + Nat.fib (k + 1)) % q = 0 := by
  obtain ⟨q, hq, hqd, hprim⟩ := lucas_primitive n hn h6
  refine ⟨q, hq, ?_, ?_⟩
  · rw [fib_pred_add_fib_succ n (by omega)]
    exact Nat.mod_eq_zero_of_dvd hqd
  · intro k hk hkn hmod
    rw [fib_pred_add_fib_succ k hk] at hmod
    exact hprim k hk hkn (Nat.dvd_of_mod_eq_zero hmod)

theorem divisors_card_le (n : ℕ) (hn : 1 ≤ n) :
    n.divisors.card ≤ (Nat.fib n).primeFactors.card + 4 :=
  card_divisors_le_card_primeFactors n hn

theorem primeFactors_eq (m n : ℕ) (hm : 3 ≤ m) (hmn : m < n)
    (h : (Nat.fib m).primeFactors = (Nat.fib n).primeFactors) : m = 3 ∧ n = 6 :=
  primeFactors_fib_eq_iff m n hm hmn h

theorem primitive_mod (n : ℕ) (hn : 3 ≤ n) (h5 : ¬ n = 5) (h6 : ¬ n = 6) (h12 : ¬ n = 12) :
    ∃ q : ℕ, q.Prime ∧ Nat.fib n % q = 0 ∧ (q % n = 1 ∨ q % n = n - 1) := by
  obtain ⟨q, hq, hqd, hmod⟩ := exists_primitive_prime_mod n hn h5 h6 h12
  exact ⟨q, hq, Nat.mod_eq_zero_of_dvd hqd, hmod⟩

end TuringTask
