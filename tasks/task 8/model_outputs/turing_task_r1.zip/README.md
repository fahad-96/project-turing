# TuringTask

This is a Lean 4 project implementing and proving the five theorems in `TuringTask/Basic.lean`.

## Environment Requirements

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib precompiled at commit `9944fe2973b8dc0b86949101ed98232c07cd54a0` located at `/opt/mathlib4`
- The supplied local Lean/Mathlib environment is required; the project uses a local path dependency to `/opt/mathlib4`.

## Offline Build Instructions

To build the project offline in the supplied environment:

1. Ensure `lean-toolchain` is present (specifying `leanprover/lean4:v4.33.0-rc1`).
2. Run `lean-offline-init` to seed `.lake/packages` with symlinks to `/opt/mathlib4` and its dependencies.
3. Build the project using:
   ```bash
   lake build
   ```
   Or directly compile the source file using:
   ```bash
   lean TuringTask/Basic.lean
   ```

## Axiom Verification

All five theorems rely solely on standard Lean foundational axioms:
- `propext`
- `Classical.choice`
- `Quot.sound`

No `sorry`, `admit`, `native_decide`, or custom axioms are used.
