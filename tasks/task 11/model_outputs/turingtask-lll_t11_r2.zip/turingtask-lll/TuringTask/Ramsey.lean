import TuringTask.Sat

/-!
# The Ramsey application: no monochromatic `K_k` in a 2-coloured `K_n`
-/

namespace TuringTask

open Finset

section Ramsey

variable {n k : ℕ}

/-- The index type of bad events: the `k`-subsets of `Fin n`. -/
abbrev KSet (n k : ℕ) := {s : Finset (Fin n) // s ∈ Finset.powersetCard k (univ : Finset (Fin n))}

/-- The edge set spanned by a `k`-set. -/
def eset (s : Finset (Fin n)) : Finset (Sym2 (Fin n)) :=
  s.offDiag.image (fun q => Sym2.mk q.1 q.2)

lemma toFinset_mk (a b : Fin n) : (Sym2.mk a b).toFinset = {a, b} :=
  Sym2.toFinset_mk_eq

/-- Every edge of `eset s` has its two endpoints in `s`. -/
lemma eset_edge {s : Finset (Fin n)} {e : Sym2 (Fin n)} (he : e ∈ eset s) :
    e.toFinset ⊆ s ∧ e.toFinset.card = 2 := by
  rw [eset, Finset.mem_image] at he
  obtain ⟨q, hq, rfl⟩ := he
  rw [Finset.mem_offDiag] at hq
  obtain ⟨h1, h2, h3⟩ := hq
  rw [toFinset_mk]
  refine ⟨?_, ?_⟩
  · intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl
    · exact h1
    · exact h2
  · rw [Finset.card_insert_of_notMem (by simpa using h3), Finset.card_singleton]

/-- `choose k 2 ≤ |eset s|` when `|s| = k`. -/
lemma card_eset {s : Finset (Fin n)} (hs : s.card = k) : Nat.choose k 2 ≤ (eset s).card := by
  classical
  have hsurj : Set.SurjOn (fun e : Sym2 (Fin n) => e.toFinset)
      (eset s : Set (Sym2 (Fin n))) ((Finset.powersetCard 2 s : Finset (Finset (Fin n)))) := by
    intro p hp
    simp only [Finset.coe_sort_coe, Finset.mem_coe, Finset.mem_powersetCard] at hp
    obtain ⟨hsub, hcard⟩ := hp
    obtain ⟨a, b, hab, rfl⟩ := Finset.card_eq_two.1 hcard
    refine ⟨Sym2.mk a b, ?_, ?_⟩
    · rw [Finset.mem_coe, eset, Finset.mem_image]
      refine ⟨(a, b), ?_, rfl⟩
      rw [Finset.mem_offDiag]
      exact ⟨hsub (by simp), hsub (by simp), hab⟩
    · exact toFinset_mk a b
  have := Finset.card_le_card_of_surjOn (fun e : Sym2 (Fin n) => e.toFinset) hsurj
  rwa [Finset.card_powersetCard, hs] at this

/-- Degree bound: a `k`-set shares an edge with at most `C(k,2)·C(n,k-2)` other `k`-sets. -/
lemma nbr_eset_le (hk : 2 ≤ k) (s : KSet n k) :
    (nbr (fun t : KSet n k => eset t.val) s).card
      ≤ Nat.choose k 2 * Nat.choose n (k - 2) := by
  classical
  set D : KSet n k → Finset (Sym2 (Fin n)) := fun t => eset t.val with hD
  have hcards : ∀ t : KSet n k, (t.val).card = k := by
    intro t
    exact (Finset.mem_powersetCard.1 t.property).2
  -- for each neighbour `t`, choose a common edge and record (its endpoints, the rest of `t`)
  set P : KSet n k → Finset (Fin n) := fun t =>
    if h : (D s ∩ D t).Nonempty then h.choose.toFinset else ∅ with hP
  set f : KSet n k → Finset (Fin n) × Finset (Fin n) := fun t => (P t, t.val \ P t) with hf
  have hkey : ∀ t ∈ nbr D s, P t ⊆ s.val ∧ P t ⊆ t.val ∧ (P t).card = 2 := by
    intro t ht
    simp only [nbr, Finset.mem_filter, Finset.mem_univ, true_and, ne_eq] at ht
    have h : (D s ∩ D t).Nonempty := ht.2
    have hspec := h.choose_spec
    rw [Finset.mem_inter] at hspec
    have h1 := eset_edge hspec.1
    have h2 := eset_edge hspec.2
    rw [hP]
    simp only [dif_pos h]
    exact ⟨h1.1, h2.1, h1.2⟩
  set TGT : Finset (Finset (Fin n) × Finset (Fin n)) :=
    (Finset.powersetCard 2 s.val) ×ˢ (Finset.powersetCard (k - 2) (univ : Finset (Fin n)))
    with hTGT
  refine le_trans (Finset.card_le_card_of_injOn (t := TGT) f ?_ ?_) ?_
  · -- maps into the target product
    intro t ht
    rw [Finset.mem_coe] at ht
    obtain ⟨hPs, hPt, hP2⟩ := hkey t ht
    rw [Finset.mem_coe, hTGT, hf, Finset.mem_product, Finset.mem_powersetCard,
      Finset.mem_powersetCard]
    refine ⟨⟨hPs, hP2⟩, Finset.subset_univ _, ?_⟩
    have : (P t ∩ t.val) = P t := Finset.inter_eq_left.2 hPt
    rw [Finset.card_sdiff, this, hcards t, hP2]
  · -- injective on neighbours
    intro t1 ht1 t2 ht2 heq
    rw [Finset.mem_coe] at ht1 ht2
    obtain ⟨_, hP1, _⟩ := hkey t1 ht1
    obtain ⟨_, hP2, _⟩ := hkey t2 ht2
    rw [hf] at heq
    simp only [Prod.mk.injEq] at heq
    have hv : t1.val = t2.val := by
      have e1 : t1.val = P t1 ∪ (t1.val \ P t1) := by
        rw [Finset.union_sdiff_of_subset hP1]
      have e2 : t2.val = P t2 ∪ (t2.val \ P t2) := by
        rw [Finset.union_sdiff_of_subset hP2]
      calc t1.val = P t1 ∪ (t1.val \ P t1) := e1
        _ = P t2 ∪ (t2.val \ P t2) := by rw [heq.2, heq.1]
        _ = t2.val := e2.symm
    exact Subtype.ext hv
  · -- cardinality of the target
    rw [hTGT, Finset.card_product, Finset.card_powersetCard, Finset.card_powersetCard, hcards s,
      Finset.card_univ, Fintype.card_fin]

/-- Main Ramsey statement (general `k`): there is an edge colouring of `K_n`
with no monochromatic `K_k`. -/
theorem ramsey_main (hk : 2 ≤ k)
    (h : Real.exp 1 * (((Nat.choose k 2 * Nat.choose n (k - 2) : ℕ) : ℝ) + 1)
      ≤ 2 ^ (Nat.choose k 2 - 1)) :
    ∃ c : Sym2 (Fin n) → Bool, ∀ s : Finset (Fin n), s.card = k →
      2 ≤ ((eset s).image c).card := by
  classical
  by_cases hne : Nonempty (KSet n k)
  · obtain ⟨ω, hω⟩ := two_color_hypergraph (ι := KSet n k) (fun t => eset t.val)
      (Nat.choose k 2) (Nat.choose k 2 * Nat.choose n (k - 2))
      (fun t => card_eset (Finset.mem_powersetCard.1 t.property).2)
      (fun t => nbr_eset_le hk t) h
    refine ⟨ω, fun s hs => ?_⟩
    have hmem : s ∈ Finset.powersetCard k (univ : Finset (Fin n)) :=
      Finset.mem_powersetCard.2 ⟨Finset.subset_univ s, hs⟩
    obtain ⟨ht, hf⟩ := hω ⟨s, hmem⟩
    exact two_le_card_image _ ω ht hf
  · -- no `k`-subsets at all: the conclusion is vacuous
    refine ⟨fun _ => true, fun s hs => ?_⟩
    exact absurd ⟨⟨s, Finset.mem_powersetCard.2 ⟨Finset.subset_univ s, hs⟩⟩⟩ hne

/-- For `k < 2` the hypothesis of `ramsey_main` is contradictory. -/
lemma ramsey_small (hk : k < 2)
    (h : Real.exp 1 * (((Nat.choose k 2 * Nat.choose n (k - 2) : ℕ) : ℝ) + 1)
      ≤ 2 ^ (Nat.choose k 2 - 1)) : False := by
  have hc : Nat.choose k 2 = 0 := Nat.choose_eq_zero_of_lt hk
  rw [hc] at h
  simp only [Nat.zero_mul, Nat.zero_sub, pow_zero, Nat.cast_zero, zero_add, mul_one] at h
  have := Real.exp_one_gt_d9
  norm_num at this
  linarith

/-- Image rewriting: the colouring image over `offDiag` equals the image over `eset`. -/
lemma image_offDiag (c : Sym2 (Fin n) → Bool) (s : Finset (Fin n)) :
    s.offDiag.image (fun q => c (Sym2.mk q.1 q.2)) = (eset s).image c := by
  rw [eset, Finset.image_image]
  rfl

end Ramsey

end TuringTask
