import Mathlib

/-!
# Cubic characters on `ZMod p` and the number of cube roots

For a prime `p` with `p % 3 = 1` we fix a multiplicative character `χ : ZMod p → ℂ` of order 3.
The main results of this file are

* `cube_count_eq`: the number of `u` with `u ^ 3 = c` equals `1 + χ c + χ⁻¹ c` (in `ℂ`);
* `isCube_iff`: `c` is a cube iff `c = 0` or `χ c = 1`;
* `sum_over_cubes`: `∑ x, f (x ^ 3) = ∑ c, (1 + χ c + χ⁻¹ c) * f c`.
-/

open Finset

namespace TuringTask

variable {p : ℕ} [Fact p.Prime]

/-- `3` divides `#(ZMod p) - 1` when `p % 3 = 1`. -/
theorem three_dvd_card_sub_one (hp : p % 3 = 1) : 3 ∣ Fintype.card (ZMod p) - 1 := by
  rw [ZMod.card]
  exact ⟨(p - 1) / 3, by omega⟩

/-- A multiplicative character of order 3 on `ZMod p` with complex values. -/
theorem exists_order_three_char (hp : p % 3 = 1) :
    ∃ χ : MulChar (ZMod p) ℂ, orderOf χ = 3 :=
  MulChar.exists_mulChar_orderOf (ZMod p) (three_dvd_card_sub_one hp)
    (Complex.isPrimitiveRoot_exp 3 (by norm_num))

/-- For a cube root of unity `z ≠ 1`, `1 + z + z ^ 2 = 0`. -/
theorem one_add_add_sq_eq_zero {z : ℂ} (hz : z ^ 3 = 1) (h1 : z ≠ 1) : 1 + z + z ^ 2 = 0 := by
  have h : (z - 1) * (1 + z + z ^ 2) = 0 := by linear_combination hz
  rcases mul_eq_zero.mp h with h | h
  · exact absurd (sub_eq_zero.mp h) h1
  · exact h

section order3

variable {χ : MulChar (ZMod p) ℂ} (hχ : orderOf χ = 3)
include hχ

omit [Fact p.Prime] in
theorem o3_pow_three : χ ^ 3 = 1 := by
  rw [← hχ]
  exact pow_orderOf_eq_one χ

omit [Fact p.Prime] in
theorem o3_ne_one : χ ≠ 1 := by
  intro h
  rw [h, orderOf_one] at hχ
  omega

omit [Fact p.Prime] in
theorem o3_sq_ne_one : χ ^ 2 ≠ 1 :=
  pow_ne_one_of_lt_orderOf (by norm_num) (by omega)

omit [Fact p.Prime] in
theorem o3_inv_ne_one : χ⁻¹ ≠ 1 :=
  inv_ne_one.mpr (o3_ne_one hχ)

omit [Fact p.Prime] in
theorem o3_orderOf_inv : orderOf χ⁻¹ = 3 := by
  rw [orderOf_inv]
  exact hχ

omit [Fact p.Prime] in
theorem o3_inv_eq_sq : χ⁻¹ = χ ^ 2 := by
  refine inv_eq_of_mul_eq_one_right ?_
  have h : χ ^ 3 = χ * χ ^ 2 := pow_succ' χ 2
  rw [← h]
  exact o3_pow_three hχ

omit [Fact p.Prime] in
/-- The value of `χ⁻¹` is the square of the value of `χ`. -/
theorem o3_inv_apply (x : ZMod p) : χ⁻¹ x = χ x ^ 2 := by
  rw [o3_inv_eq_sq hχ, MulChar.pow_apply' χ (n := 2) (by norm_num)]

/-- Nonzero values of `χ` are cube roots of unity. -/
theorem o3_apply_pow_three {x : ZMod p} (hx : x ≠ 0) : χ x ^ 3 = 1 := by
  rw [← MulChar.pow_apply' χ (n := 3) (by norm_num), o3_pow_three hχ, MulChar.one_apply hx.isUnit]

theorem o3_apply_neg_one : χ (-1) = 1 := by
  have h : χ (-1) ^ 3 = 1 := o3_apply_pow_three hχ (neg_ne_zero.mpr one_ne_zero)
  calc χ (-1) = χ ((-1) ^ 3) := by norm_num
    _ = χ (-1) ^ 3 := by rw [map_pow]
    _ = 1 := h

theorem o3_apply_neg (x : ZMod p) : χ (-x) = χ x := by
  rw [neg_eq_neg_one_mul, map_mul, o3_apply_neg_one hχ, one_mul]

end order3

/-- The number of cube roots of `c` in `ZMod p`. -/
def cubeCount (c : ZMod p) : ℕ := #{u : ZMod p | u ^ 3 = c}

open Classical in
/-- The expected number of cube roots of `c`: `1` for `c = 0`, `3` if `χ c = 1`, else `0`. -/
noncomputable def cubeGuess (χ : MulChar (ZMod p) ℂ) (c : ZMod p) : ℕ :=
  if c = 0 then 1 else if χ c = 1 then 3 else 0

section count

variable {χ : MulChar (ZMod p) ℂ} (hχ : orderOf χ = 3)
include hχ

theorem cubeGuess_cast (c : ZMod p) : ((cubeGuess χ c : ℕ) : ℂ) = 1 + χ c + χ⁻¹ c := by
  unfold cubeGuess
  rw [o3_inv_apply hχ]
  by_cases hc : c = 0
  · rw [if_pos hc, hc, MulChar.map_zero]
    norm_num
  · rw [if_neg hc]
    by_cases h1 : χ c = 1
    · rw [if_pos h1, h1]
      norm_num
    · rw [if_neg h1, one_add_add_sq_eq_zero (o3_apply_pow_three hχ hc) h1]
      norm_num

theorem cubeCount_le (c : ZMod p) : cubeCount c ≤ cubeGuess χ c := by
  unfold cubeCount cubeGuess
  by_cases hc : c = 0
  · rw [if_pos hc]
    refine Finset.card_le_one.mpr (fun a ha b hb => ?_)
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at ha hb
    rw [hc, pow_eq_zero_iff (n := 3) (by norm_num)] at ha hb
    rw [ha, hb]
  · rw [if_neg hc]
    by_cases h1 : χ c = 1
    · rw [if_pos h1]
      calc #{u : ZMod p | u ^ 3 = c} ≤ #(Polynomial.nthRootsFinset 3 c) := by
            refine Finset.card_le_card (fun u hu => ?_)
            simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hu
            exact (Polynomial.mem_nthRootsFinset (by norm_num) c).mpr hu
        _ ≤ 3 := by
            rw [Polynomial.nthRootsFinset_def]
            exact (Multiset.toFinset_card_le _).trans (Polynomial.card_nthRoots 3 c)
    · rw [if_neg h1, Nat.le_zero, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
      intro u _ hu
      apply h1
      have hu0 : u ≠ 0 := by
        rintro rfl
        apply hc
        rw [← hu]
        ring
      rw [← hu, map_pow, o3_apply_pow_three hχ hu0]

omit hχ in
theorem sum_cubeCount : ∑ c : ZMod p, cubeCount c = p := by
  have h : ∑ c : ZMod p, ∑ x ∈ (univ : Finset (ZMod p)) with x ^ 3 = c, (1 : ℕ) =
      ∑ x : ZMod p, (1 : ℕ) := Finset.sum_fiberwise _ _ _
  simp only [Finset.sum_const, smul_eq_mul, mul_one, Finset.card_univ, ZMod.card] at h
  exact h

theorem cubeCount_eq_guess (c : ZMod p) : cubeCount c = cubeGuess χ c := by
  have hsum : ∑ c : ZMod p, cubeCount c = ∑ c : ZMod p, cubeGuess χ c := by
    rw [sum_cubeCount]
    apply Nat.cast_injective (R := ℂ)
    push_cast
    simp_rw [cubeGuess_cast hχ]
    rw [Finset.sum_add_distrib, Finset.sum_add_distrib,
      MulChar.sum_eq_zero_of_ne_one (o3_ne_one hχ),
      MulChar.sum_eq_zero_of_ne_one (o3_inv_ne_one hχ)]
    simp [ZMod.card]
  exact (Finset.sum_eq_sum_iff_of_le (fun c _ => cubeCount_le hχ c)).mp hsum c (Finset.mem_univ c)

/-- The number of cube roots of `c`, as a complex number. -/
theorem cube_count_eq (c : ZMod p) : ((cubeCount c : ℕ) : ℂ) = 1 + χ c + χ⁻¹ c := by
  rw [cubeCount_eq_guess hχ c, cubeGuess_cast hχ]

/-- `c` is a cube iff `c = 0` or `χ c = 1`. -/
theorem isCube_iff (c : ZMod p) : (∃ u : ZMod p, u ^ 3 = c) ↔ (c = 0 ∨ χ c = 1) := by
  constructor
  · rintro ⟨u, rfl⟩
    by_cases hu : u = 0
    · left
      rw [hu]
      ring
    · right
      rw [map_pow, o3_apply_pow_three hχ hu]
  · rintro (h | h)
    · exact ⟨0, by rw [h]; ring⟩
    · have hc : c ≠ 0 := by
        rintro rfl
        rw [MulChar.map_zero] at h
        exact zero_ne_one h
      have h3 : cubeCount c = 3 := by
        rw [cubeCount_eq_guess hχ c]
        unfold cubeGuess
        rw [if_neg hc, if_pos h]
      have hne : ({u : ZMod p | u ^ 3 = c} : Finset (ZMod p)).Nonempty := by
        rw [← Finset.card_pos]
        unfold cubeCount at h3
        omega
      obtain ⟨u, hu⟩ := hne
      exact ⟨u, (Finset.mem_filter.mp hu).2⟩

/-- Summing over cubes: `∑ x, f (x ^ 3) = ∑ c, (1 + χ c + χ⁻¹ c) * f c`. -/
theorem sum_over_cubes (f : ZMod p → ℂ) :
    ∑ x : ZMod p, f (x ^ 3) = ∑ c : ZMod p, (1 + χ c + χ⁻¹ c) * f c := by
  have h : ∑ c : ZMod p, ∑ x ∈ (univ : Finset (ZMod p)) with x ^ 3 = c, f (x ^ 3) =
      ∑ x : ZMod p, f (x ^ 3) := Finset.sum_fiberwise _ _ _
  rw [← h]
  refine Finset.sum_congr rfl (fun c _ => ?_)
  calc ∑ x ∈ (univ : Finset (ZMod p)) with x ^ 3 = c, f (x ^ 3)
      = ∑ x ∈ (univ : Finset (ZMod p)) with x ^ 3 = c, f c :=
        Finset.sum_congr rfl (fun x hx => by rw [(Finset.mem_filter.mp hx).2])
    _ = ((cubeCount c : ℕ) : ℂ) * f c := by
        rw [Finset.sum_const, nsmul_eq_mul]
        rfl
    _ = (1 + χ c + χ⁻¹ c) * f c := by rw [cube_count_eq hχ c]

end count

end TuringTask
