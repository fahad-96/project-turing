import Mathlib
import TuringTask.Zsig

/-!
# Consequences of Zsigmondy's theorem

The version for `a ^ n + b ^ n`, the bound on the number of divisors of `n`, the equation
`a ^ n - 1 = q ^ m`, and equal sets of prime factors of `a ^ m - 1` and `a ^ n - 1`.
-/

open Polynomial Finset

namespace TuringTask

/-! ### Consequences -/

/-- Zsigmondy's theorem for `a ^ n + b ^ n`. -/
theorem zsigmondy_add (a b n : ℕ) (hba : b < a) (hb : 1 ≤ b) (hcop : Nat.Coprime a b)
    (hn : 2 ≤ n) (h3 : ¬ (a = 2 ∧ b = 1 ∧ n = 3)) :
    ∃ q : ℕ, q.Prime ∧ q ∣ a ^ n + b ^ n ∧
      ∀ k : ℕ, 1 ≤ k → k < n → ¬ q ∣ a ^ k + b ^ k := by
  obtain ⟨q, hq, hdvd, hprim⟩ := zsigmondy a b (2 * n) hba hb hcop (by omega)
    (by rintro ⟨h, -⟩; omega) (by rintro ⟨h1, h2, h3'⟩; exact h3 ⟨h1, h2, by omega⟩)
  have hfac : ∀ k, a ^ (2 * k) - b ^ (2 * k) = (a ^ k + b ^ k) * (a ^ k - b ^ k) := by
    intro k
    have hle : b ^ k ≤ a ^ k := Nat.pow_le_pow_left hba.le k
    have hle2 : b ^ (2 * k) ≤ a ^ (2 * k) := Nat.pow_le_pow_left hba.le _
    zify [hle, hle2]
    ring
  refine ⟨q, hq, ?_, ?_⟩
  · rw [hfac] at hdvd
    rcases (Nat.Prime.dvd_mul hq).mp hdvd with h | h
    · exact h
    · exact absurd h (hprim n (by omega) (by omega))
  · intro k hk1 hkn hk
    apply hprim (2 * k) (by omega) (by omega)
    rw [hfac]
    exact Dvd.dvd.mul_right hk _

/-- `q` is a primitive prime divisor of `a ^ d - 1`. -/
def IsPrim (a d q : ℕ) : Prop :=
  q.Prime ∧ q ∣ a ^ d - 1 ∧ ∀ k : ℕ, 1 ≤ k → k < d → ¬ q ∣ a ^ k - 1

theorem prim_unique {a d e q : ℕ} (hd : IsPrim a d q) (he : IsPrim a e q) (hd1 : 1 ≤ d)
    (he1 : 1 ≤ e) : d = e := by
  rcases lt_trichotomy d e with h | h | h
  · exact absurd hd.2.1 (he.2.2 d hd1 h)
  · exact h
  · exact absurd he.2.1 (hd.2.2 e he1 h)

theorem exists_prim (a d : ℕ) (ha : 2 ≤ a) (hd : 1 ≤ d) (hne : ¬ (d = 1 ∧ a = 2))
    (h2 : ¬ (d = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t)) (h6 : ¬ (a = 2 ∧ d = 6)) :
    ∃ q, IsPrim a d q := by
  rcases Nat.lt_or_ge d 2 with hd1 | hd2
  · obtain rfl : d = 1 := by omega
    have ha3 : a ≠ 2 := fun h => hne ⟨rfl, h⟩
    obtain ⟨q, hq, hqd⟩ := Nat.exists_prime_and_dvd (show a ^ 1 - 1 ≠ 1 by
      rw [pow_one]
      omega)
    exact ⟨q, hq, hqd, fun k hk1 hk2 => absurd hk2 (by omega)⟩
  · obtain ⟨q, hq, hdvd, hprim⟩ := zsigmondy a 1 d (by omega) le_rfl (Nat.coprime_one_right a)
      hd2 h2 (by rintro ⟨h1, -, h3⟩; exact h6 ⟨h1, h3⟩)
    refine ⟨q, hq, by simpa using hdvd, fun k hk1 hk2 => by simpa using hprim k hk1 hk2⟩

theorem card_divisors_bound (a n : ℕ) (ha : 2 ≤ a) (hn : 1 ≤ n) :
    n.divisors.card ≤ (a ^ n - 1).primeFactors.card + 2 := by
  classical
  let G := n.divisors.filter (fun d => ∃ q, IsPrim a d q)
  have hGsub : G ⊆ n.divisors := Finset.filter_subset _ _
  have hrest : (n.divisors \ G).card ≤ 2 := by
    have hsub : n.divisors \ G ⊆ (if a = 2 then ({1, 6} : Finset ℕ) else {2}) := by
      intro d hd
      rw [Finset.mem_sdiff] at hd
      obtain ⟨hdn, hnot⟩ := hd
      have hd1 : 1 ≤ d := Nat.pos_of_mem_divisors hdn
      by_contra hout
      apply hnot
      refine Finset.mem_filter.mpr ⟨hdn, exists_prim a d ha hd1 ?_ ?_ ?_⟩
      · rintro ⟨hd1', ha2⟩
        rw [if_pos ha2, hd1'] at hout
        simp at hout
      · rintro ⟨hd2', t, ht⟩
        by_cases ha2 : a = 2
        · rw [ha2] at ht
          rcases t with _ | _ | t
          · simp at ht
          · simp at ht
          · rw [pow_succ, pow_succ] at ht
            omega
        · rw [if_neg ha2, hd2'] at hout
          simp at hout
      · rintro ⟨ha2, hd6⟩
        rw [if_pos ha2, hd6] at hout
        simp at hout
    calc (n.divisors \ G).card
        ≤ (if a = 2 then ({1, 6} : Finset ℕ) else {2}).card := Finset.card_le_card hsub
      _ ≤ 2 := by split_ifs <;> simp
  have hGcard : G.card ≤ (a ^ n - 1).primeFactors.card := by
    let f : ℕ → ℕ := fun d => if h : ∃ q, IsPrim a d q then Classical.choose h else 0
    have hf : ∀ d ∈ G, IsPrim a d (f d) := by
      intro d hd
      have h : ∃ q, IsPrim a d q := (Finset.mem_filter.mp hd).2
      simp only [f, dif_pos h]
      exact Classical.choose_spec h
    have hpow : a ≤ a ^ n := Nat.le_self_pow (by omega) a
    apply Finset.card_le_card_of_injOn f
    · intro d hd
      have hd' : d ∈ G := Finset.mem_coe.mp hd
      have hdn : d ∣ n := Nat.dvd_of_mem_divisors (hGsub hd')
      have hp := hf d hd'
      rw [Finset.mem_coe, Nat.mem_primeFactors]
      exact ⟨hp.1, hp.2.1.trans (Nat.pow_sub_one_dvd_pow_sub_one a hdn), by omega⟩
    · intro d hd e he hde
      have hd' : d ∈ G := Finset.mem_coe.mp hd
      have he' : e ∈ G := Finset.mem_coe.mp he
      have hd1 : 1 ≤ d := Nat.pos_of_mem_divisors (hGsub hd')
      have he1 : 1 ≤ e := Nat.pos_of_mem_divisors (hGsub he')
      have h1 := hf d hd'
      have h2 := hf e he'
      rw [hde] at h1
      exact prim_unique h1 h2 hd1 he1
  have hsplit := Finset.card_sdiff_add_card_eq_card hGsub
  omega

theorem prime_pow_eq (a n q m : ℕ) (ha : 2 ≤ a) (hn : 2 ≤ n) (hq : q.Prime) (hm : 2 ≤ m)
    (h : a ^ n - 1 = q ^ m) : a = 3 ∧ n = 2 ∧ q = 2 ∧ m = 3 := by
  by_cases hex2 : n = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t
  · obtain ⟨rfl, t, ht⟩ := hex2
    have ht2 : 2 ≤ t := by
      rcases t with _ | _ | t
      · simp at ht
        omega
      · simp at ht
        omega
      · omega
    have h2t : 2 ∣ 2 ^ t := dvd_pow_self 2 (by omega)
    have hodd : a % 2 = 1 := by omega
    have h1 : 1 ≤ a ^ 2 := Nat.one_le_pow _ _ (by omega)
    have hfac : a ^ 2 - 1 = (a - 1) * (a + 1) := by
      zify [h1, (by omega : 1 ≤ a)]
      ring
    have hq2 : q = 2 := by
      have h2 : 2 ∣ q ^ m := by
        rw [← h, hfac, ht]
        exact Dvd.dvd.mul_left h2t _
      exact ((Nat.prime_dvd_prime_iff_eq Nat.prime_two hq).mp
        (Nat.prime_two.dvd_of_dvd_pow h2)).symm
    subst hq2
    obtain ⟨i, hi, hai⟩ := (Nat.dvd_prime_pow Nat.prime_two).mp
      (show a - 1 ∣ 2 ^ m by
        rw [← h, hfac]
        exact dvd_mul_right _ _)
    have ha3 : a = 3 := by
      rcases Nat.lt_or_ge i 2 with hi2 | hi2
      · interval_cases i <;> simp at hai <;> omega
      · have h4i : 4 ∣ 2 ^ i := by
          obtain ⟨c, rfl⟩ : ∃ c, i = c + 2 := ⟨i - 2, by omega⟩
          exact ⟨2 ^ c, by ring⟩
        have h4t : 4 ∣ 2 ^ t := by
          obtain ⟨c, rfl⟩ : ∃ c, t = c + 2 := ⟨t - 2, by omega⟩
          exact ⟨2 ^ c, by ring⟩
        omega
    subst ha3
    refine ⟨rfl, rfl, rfl, ?_⟩
    exact Nat.pow_right_injective le_rfl (h.symm.trans (by norm_num : 3 ^ 2 - 1 = 2 ^ 3))
  by_cases hex6 : a = 2 ∧ n = 6
  · exfalso
    obtain ⟨rfl, rfl⟩ := hex6
    have h63 : q ^ m = 63 := by
      norm_num at h
      omega
    have h7 : 7 ∣ q ^ m := by rw [h63]; norm_num
    have hq7 : q = 7 := ((Nat.prime_dvd_prime_iff_eq (by norm_num) hq).mp
      ((Nat.Prime.dvd_of_dvd_pow (by norm_num) h7))).symm
    subst hq7
    have h49 : 7 ^ 2 ∣ 7 ^ m := pow_dvd_pow 7 hm
    rw [h63] at h49
    norm_num at h49
  obtain ⟨p, hp, hpdvd, hprim⟩ := zsigmondy a 1 n (by omega) le_rfl (Nat.coprime_one_right a) hn
    hex2 (by rintro ⟨h1, -, h3⟩; exact hex6 ⟨h1, h3⟩)
  simp only [one_pow] at hpdvd hprim
  rw [h] at hpdvd
  have hpq : p = q := (Nat.prime_dvd_prime_iff_eq hp hq).mp (hp.dvd_of_dvd_pow hpdvd)
  subst hpq
  have ha2 : a = 2 := by
    by_contra hne
    obtain ⟨r, hr, hra⟩ := Nat.exists_prime_and_dvd (show a - 1 ≠ 1 by omega)
    have hr' : r ∣ p ^ m := by
      rw [← h]
      exact hra.trans (Nat.sub_one_dvd_pow_sub_one a n)
    have hrp : r = p := (Nat.prime_dvd_prime_iff_eq hr hp).mp (hr.dvd_of_dvd_pow hr')
    subst hrp
    exact hprim 1 le_rfl (by omega) (by simpa using hra)
  subst ha2
  have h1n : 1 ≤ 2 ^ n := Nat.one_le_two_pow
  have hpodd : ¬ 2 ∣ p := by
    intro h2
    have h2a : 2 ∣ 2 ^ n - 1 := by
      rw [h]
      exact h2.trans (dvd_pow_self p (by omega))
    have h2b : 2 ∣ 2 ^ n := dvd_pow_self 2 (by omega)
    omega
  have hp3 : 3 ≤ p := by
    have := hp.two_le
    have : p ≠ 2 := by
      intro h2
      subst h2
      exact hpodd (dvd_refl 2)
    omega
  obtain ⟨r, hr, hrdvd, hrprim⟩ := zsigmondy_add p 1 m (by omega) le_rfl
    (Nat.coprime_one_right p) hm (by rintro ⟨h1, -, -⟩; omega)
  simp only [one_pow] at hrdvd hrprim
  have hsum : p ^ m + 1 = 2 ^ n := by omega
  rw [hsum] at hrdvd
  have hr2 : r = 2 := (Nat.prime_dvd_prime_iff_eq hr Nat.prime_two).mp (hr.dvd_of_dvd_pow hrdvd)
  subst hr2
  exact absurd (by rw [pow_one]; omega) (hrprim 1 le_rfl (by omega))

theorem same_prime_factors (a m n : ℕ) (ha : 2 ≤ a) (hm : 1 ≤ m) (hmn : m < n)
    (h : (a ^ m - 1).primeFactors = (a ^ n - 1).primeFactors) :
    m = 1 ∧ n = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t := by
  by_cases hex2 : n = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t
  · obtain ⟨hn2, ht⟩ := hex2
    exact ⟨by omega, hn2, ht⟩
  by_cases hex6 : a = 2 ∧ n = 6
  · exfalso
    obtain ⟨rfl, rfl⟩ := hex6
    have h3 : 3 ∈ (2 ^ m - 1).primeFactors := by
      rw [h, Nat.mem_primeFactors]
      norm_num
    have h7 : 7 ∈ (2 ^ m - 1).primeFactors := by
      rw [h, Nat.mem_primeFactors]
      norm_num
    rw [Nat.mem_primeFactors] at h3 h7
    interval_cases m <;> revert h3 h7 <;> norm_num
  obtain ⟨q, hq, hqdvd, hprim⟩ := zsigmondy a 1 n (by omega) le_rfl (Nat.coprime_one_right a)
    (by omega) hex2 (by rintro ⟨h1, -, h3⟩; exact hex6 ⟨h1, h3⟩)
  simp only [one_pow] at hqdvd hprim
  have hpow : a ≤ a ^ n := Nat.le_self_pow (by omega) a
  have hmem : q ∈ (a ^ n - 1).primeFactors := by
    rw [Nat.mem_primeFactors]
    exact ⟨hq, hqdvd, by omega⟩
  rw [← h, Nat.mem_primeFactors] at hmem
  exact absurd hmem.2.1 (hprim m hm hmn)

end TuringTask
