# TuringTask

This project uses the Lean 4 and Mathlib versions supplied by the task environment.
Its Lake configuration intentionally refers to the local `/opt/mathlib4`; the archive
is not self-contained on a machine without that supplied installation.

Build offline with:

```sh
lean-offline-init
lake build
```

To check the equidistribution result directly:

```sh
lake env lean TuringTask/Equidistribution.lean
```

The project intentionally uses the local Mathlib dependency at `/opt/mathlib4`
provided by the task environment.
