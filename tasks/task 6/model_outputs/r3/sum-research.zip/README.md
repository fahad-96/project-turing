# Lean sum theorem research

This project records compiling proofs for the standard interpretations of
`sum_sq` and `sum_tri`. The supplied workspace did not contain their exact
statements: `Query.lean` only contains unrelated `gaussSum` queries. Therefore
`Answer.lean` covers the common `range (n + 1)`, `range n`, `Icc 1 n`, scaled,
natural-division, real-valued, and sum-of-triangular-numbers variants.

## Installed declarations found

```lean
Finset.sum_range_id (n : ℕ) :
  ∑ i ∈ Finset.range n, i = n * (n - 1) / 2

Finset.sum_range_succ {M} [AddCommMonoid M] (f : ℕ → M) (n : ℕ) :
  ∑ x ∈ Finset.range (n + 1), f x = ∑ x ∈ Finset.range n, f x + f n

Finset.sum_subset {s₁ s₂ : Finset ι} [AddCommMonoid M] {f : ι → M}
  (h : s₁ ⊆ s₂) (hf : ∀ x ∈ s₂, x ∉ s₁ → f x = 0) :
  ∑ x ∈ s₁, f x = ∑ x ∈ s₂, f x

Nat.even_mul_succ_self (n : ℕ) : Even (n * (n + 1))
Nat.even_iff {n : ℕ} : Even n ↔ n % 2 = 0
Nat.dvd_iff_mod_eq_zero {m n : ℕ} : m ∣ n ↔ n % m = 0
Nat.div_mul_cancel {n m : ℕ} (H : n ∣ m) : m / n * n = m
```

Targeted `#find (∑ i ∈ Finset.range _, i) = _` found only
`Finset.sum_range_id`. Targeted `#find` for `i ^ 2` found no declaration.
Likewise, `#check` confirmed that likely names such as `Nat.sum_range_sq`,
`Finset.sum_range_sq`, and `Finset.sum_range_pow` do not exist in this installed
Mathlib. Induction via `Finset.sum_range_succ` is therefore the reliable proof.

## Offline checking

In the supplied pinned Lean/Mathlib environment:

```sh
lean Answer.lean
```

For Lake, first run `lean-offline-init` in this directory, then `lake build`.
The project deliberately uses the local `/opt/mathlib4` dependency and is not
self-contained on arbitrary machines.
