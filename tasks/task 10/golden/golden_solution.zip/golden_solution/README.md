# Project Turing - Task 10 golden answer

Lean 4 project with complete proofs of Zsigmondy's theorem for `a^n - b^n` and `a^n + b^n` and
of three consequences (number of divisors, `a^n - 1 = q^m`, equal prime factors). The required
file is `TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The seven source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Hcyc.lean`: homogeneous cyclotomic values `b^phi(n) * Phi_n(a/b)`, product formula,
  bounds, identities from `expand`
- `TuringTask/Prim.lean`: prime divisors of the cyclotomic value (primitive primes; primes
  dividing `n` and their multiplicity)
- `TuringTask/Size.lean`: the size bound
- `TuringTask/Zsig.lean`: Zsigmondy's theorem for `a^n - b^n`
- `TuringTask/Apps.lean`: the version for `a^n + b^n` and the three consequences
- `TuringTask/Main.lean`: the five statements of the prompt, proved
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof in `Main.lean`
