import TuringTask.Ramsey

/-!
# The van der Waerden-type application: no monochromatic `k`-term AP in `{0,…,N-1}`
-/

namespace TuringTask

open Finset

section AP

variable {N k : ℕ}

/-- Index type: valid arithmetic progressions `(a, r)` with `k` terms inside `{0,…,N-1}`. -/
abbrev APIdx (N k : ℕ) :=
  {p : Fin N × Fin N // 1 ≤ (p.2 : ℕ) ∧ (p.1 : ℕ) + (k - 1) * (p.2 : ℕ) < N}

lemma N_pos (p : APIdx N k) : 0 < N := Nat.lt_of_le_of_lt (Nat.zero_le _) p.val.1.isLt

/-- The vertex set of the progression `p`. -/
def apset (k : ℕ) (p : APIdx N k) : Finset (Fin N) :=
  univ.filter (fun v => ∃ j < k, (v : ℕ) = (p.val.1 : ℕ) + j * (p.val.2 : ℕ))

lemma mem_apset {p : APIdx N k} {v : Fin N} :
    v ∈ apset k p ↔ ∃ j < k, (v : ℕ) = (p.val.1 : ℕ) + j * (p.val.2 : ℕ) := by
  simp [apset]

/-- Every term of a valid progression lies below `N`. -/
lemma ap_term_lt (p : APIdx N k) {j : ℕ} (hj : j < k) :
    (p.val.1 : ℕ) + j * (p.val.2 : ℕ) < N := by
  have h := p.property.2
  have : j ≤ k - 1 := by omega
  have hm : j * (p.val.2 : ℕ) ≤ (k - 1) * (p.val.2 : ℕ) := Nat.mul_le_mul_right _ this
  omega

/-- A valid progression has exactly `k` terms (we only need `k ≤`). -/
lemma card_apset (p : APIdx N k) : k ≤ (apset k p).card := by
  classical
  have hN : 0 < N := N_pos p
  set a : ℕ := (p.val.1 : ℕ)
  set r : ℕ := (p.val.2 : ℕ)
  have hr : 1 ≤ r := p.property.1
  set f : ℕ → Fin N := fun j => ⟨(a + j * r) % N, Nat.mod_lt _ hN⟩ with hf
  have hmaps : Set.MapsTo f (Finset.range k : Set ℕ) (apset k p : Set (Fin N)) := by
    intro j hj
    rw [Finset.mem_coe, Finset.mem_range] at hj
    rw [Finset.mem_coe, mem_apset]
    refine ⟨j, hj, ?_⟩
    rw [hf]
    simp only
    rw [Nat.mod_eq_of_lt (ap_term_lt p hj)]
  have hinj : Set.InjOn f (Finset.range k : Set ℕ) := by
    intro j1 h1 j2 h2 heq
    rw [Finset.mem_coe, Finset.mem_range] at h1 h2
    rw [hf] at heq
    simp only [Fin.mk.injEq] at heq
    rw [Nat.mod_eq_of_lt (ap_term_lt p h1), Nat.mod_eq_of_lt (ap_term_lt p h2)] at heq
    have hmul : j1 * r = j2 * r := Nat.add_left_cancel heq
    exact Nat.eq_of_mul_eq_mul_right hr hmul
  have := Finset.card_le_card_of_injOn f hmaps hinj
  rwa [Finset.card_range] at this

/-- Degree bound for progressions: at most `k² N` progressions meet a given one. -/
lemma nbr_apset_le (hk : 2 ≤ k) (p : APIdx N k) :
    (nbr (apset k) p).card ≤ k ^ 2 * N := by
  classical
  -- every neighbour contains some vertex of `p`
  have hcover : nbr (apset k) p ⊆
      (apset k p).biUnion (fun v => univ.filter (fun q : APIdx N k => v ∈ apset k q)) := by
    intro q hq
    simp only [nbr, Finset.mem_filter, Finset.mem_univ, true_and, ne_eq] at hq
    obtain ⟨hne, hex⟩ := hq
    obtain ⟨v, hv⟩ := hex
    rw [Finset.mem_inter] at hv
    exact Finset.mem_biUnion.2 ⟨v, hv.1, Finset.mem_filter.2 ⟨Finset.mem_univ _, hv.2⟩⟩
  -- at most `k * N` progressions contain a given vertex
  have hpoint : ∀ v : Fin N,
      (univ.filter (fun q : APIdx N k => v ∈ apset k q)).card ≤ k * N := by
    intro v
    set g : APIdx N k → ℕ × ℕ := fun q =>
      (if h : ∃ j < k, (v : ℕ) = (q.val.1 : ℕ) + j * (q.val.2 : ℕ) then h.choose else 0,
        (q.val.2 : ℕ)) with hg
    have hspec : ∀ q ∈ univ.filter (fun q : APIdx N k => v ∈ apset k q),
        (g q).1 < k ∧ (v : ℕ) = (q.val.1 : ℕ) + (g q).1 * (q.val.2 : ℕ) := by
      intro q hq
      rw [Finset.mem_filter] at hq
      have h : ∃ j < k, (v : ℕ) = (q.val.1 : ℕ) + j * (q.val.2 : ℕ) := mem_apset.1 hq.2
      rw [hg]
      simp only [dif_pos h]
      exact h.choose_spec
    have hrlt : ∀ q : APIdx N k, (q.val.2 : ℕ) < N := by
      intro q
      exact q.val.2.isLt
    set TGT2 : Finset (ℕ × ℕ) := (Finset.range k) ×ˢ (Finset.range N) with hTGT2
    refine le_trans (Finset.card_le_card_of_injOn (t := TGT2) g ?_ ?_) ?_
    · intro q hq
      rw [Finset.mem_coe] at hq
      rw [Finset.mem_coe, hTGT2, Finset.mem_product, Finset.mem_range, Finset.mem_range]
      exact ⟨(hspec q hq).1, hrlt q⟩
    · intro q1 hq1 q2 hq2 heq
      rw [Finset.mem_coe] at hq1 hq2
      obtain ⟨-, he1⟩ := hspec q1 hq1
      obtain ⟨-, he2⟩ := hspec q2 hq2
      rw [Prod.ext_iff] at heq
      have hr : (q1.val.2 : ℕ) = (q2.val.2 : ℕ) := heq.2
      have ha : (q1.val.1 : ℕ) = (q2.val.1 : ℕ) := by
        rw [heq.1, hr] at he1
        omega
      refine Subtype.ext (Prod.ext ?_ ?_)
      · exact Fin.ext ha
      · exact Fin.ext hr
    · rw [hTGT2, Finset.card_product, Finset.card_range, Finset.card_range]
  -- combine
  refine le_trans (Finset.card_le_card hcover) ?_
  refine le_trans Finset.card_biUnion_le ?_
  refine le_trans (Finset.sum_le_sum (fun v _ => hpoint v)) ?_
  rw [Finset.sum_const, smul_eq_mul]
  have hcard : (apset k p).card ≤ k := by
    classical
    have hsub : apset k p ⊆ (Finset.range k).image
        (fun j => (⟨((p.val.1 : ℕ) + j * (p.val.2 : ℕ)) % N, Nat.mod_lt _ (N_pos p)⟩ : Fin N)) := by
      intro v hv
      obtain ⟨j, hj, hval⟩ := mem_apset.1 hv
      refine Finset.mem_image.2 ⟨j, Finset.mem_range.2 hj, ?_⟩
      refine Fin.ext ?_
      simp only
      rw [Nat.mod_eq_of_lt (ap_term_lt p hj), ← hval]
    refine le_trans (Finset.card_le_card hsub) ?_
    exact le_trans Finset.card_image_le (le_of_eq (Finset.card_range k))
  calc (apset k p).card * (k * N) ≤ k * (k * N) := Nat.mul_le_mul_right _ hcard
    _ = k ^ 2 * N := by ring

/-- Main AP theorem for `k ≥ 2`: a colouring of `Fin N` with no monochromatic `k`-term AP. -/
theorem ap_main (hk : 2 ≤ k) (h : Real.exp 1 * (((k ^ 2 * N : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1)) :
    ∃ c : Fin N → Bool, ∀ p : APIdx N k,
      (∃ v ∈ apset k p, c v = true) ∧ (∃ v ∈ apset k p, c v = false) :=
  two_color_hypergraph (apset k) k (k ^ 2 * N) card_apset (nbr_apset_le hk) h

/-- For `k < 2` the hypothesis is contradictory. -/
lemma ap_small (hk : k < 2)
    (h : Real.exp 1 * (((k ^ 2 * N : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1)) : False := by
  have he : (2:ℝ) < Real.exp 1 := by
    have := Real.exp_one_gt_d9; norm_num at this ⊢; linarith
  have hpow : (2:ℝ) ^ (k - 1) = 1 := by
    have : k - 1 = 0 := by omega
    rw [this, pow_zero]
  rw [hpow] at h
  have hnn : (0:ℝ) ≤ ((k ^ 2 * N : ℕ) : ℝ) := Nat.cast_nonneg _
  nlinarith [h, he, hnn]

/-- Final form of the AP theorem over `Nat`. -/
theorem ap_final (h : Real.exp 1 * (((k ^ 2 * N : ℕ) : ℝ) + 1) ≤ 2 ^ (k - 1)) :
    ∃ c : Nat → Bool, ∀ a r : Nat, 1 ≤ r → a + (k - 1) * r < N →
      2 ≤ ((Finset.range k).image (fun j => c (a + j * r))).card := by
  classical
  by_cases hk : 2 ≤ k
  · obtain ⟨c, hc⟩ := ap_main hk h
    -- transport `c : Fin N → Bool` to `Nat → Bool`
    refine ⟨fun x => if hx : x < N then c ⟨x, hx⟩ else true, fun a r hr hlt => ?_⟩
    have hN : 0 < N := Nat.lt_of_le_of_lt (Nat.zero_le _) hlt
    have haN : a < N := by
      have : 0 ≤ (k - 1) * r := Nat.zero_le _
      omega
    have hrN : r < N := by
      have h1 : 1 * r ≤ (k - 1) * r := Nat.mul_le_mul_right _ (by omega)
      omega
    set p : APIdx N k := ⟨(⟨a, haN⟩, ⟨r, hrN⟩), ⟨hr, by simpa using hlt⟩⟩ with hp
    obtain ⟨⟨v, hv, hvt⟩, ⟨w, hw, hwf⟩⟩ := hc p
    -- pull back `v` and `w` to indices `j < k`
    have hpull : ∀ u : Fin N, u ∈ apset k p → ∃ j < k,
        (if hx : a + j * r < N then c ⟨a + j * r, hx⟩ else true) = c u := by
      intro u hu
      obtain ⟨j, hj, hval⟩ := mem_apset.1 hu
      refine ⟨j, hj, ?_⟩
      simp only [hp] at hval
      have hlt2 : a + j * r < N := by rw [← hval]; exact u.isLt
      rw [dif_pos hlt2]
      congr 1
      exact Fin.ext hval.symm
    obtain ⟨j1, hj1, he1⟩ := hpull v hv
    obtain ⟨j2, hj2, he2⟩ := hpull w hw
    refine two_le_card_image _ _ ⟨j1, Finset.mem_range.2 hj1, ?_⟩ ⟨j2, Finset.mem_range.2 hj2, ?_⟩
    · simp only; rw [he1]; exact hvt
    · simp only; rw [he2]; exact hwf
  · exact absurd h (fun hh => (ap_small (by omega) hh).elim)

end AP

end TuringTask
