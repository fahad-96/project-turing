import TuringTask.Prim

/-!
# Consequences of the primitive divisor theorem

Lucas numbers, the number of divisors of `n` against the number of prime factors of `F n`,
equality of prime factor sets, and the congruence `q = ±1 (mod n)` for a primitive prime `q`.
-/

namespace TuringTask

/-- The Lucas number in the form used by the task. -/
theorem fib_pred_add_fib_succ (n : ℕ) (hn : 1 ≤ n) :
    Nat.fib (n - 1) + Nat.fib (n + 1) = lucN n := by
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  unfold lucN
  rw [Nat.add_sub_cancel, Nat.fib_add_two]
  have := Nat.fib_le_fib_succ (n := m)
  omega

theorem fib_pos_of_pos {n : ℕ} (hn : 0 < n) : 0 < Nat.fib n := fib_pos' hn

/-- A primitive prime of `F (2n)` is a primitive prime of the Lucas number `L n`. -/
theorem lucas_primitive (n : ℕ) (hn : 2 ≤ n) (h6 : n ≠ 6) :
    ∃ q, q.Prime ∧ q ∣ lucN n ∧ ∀ k, 0 < k → k < n → ¬ q ∣ lucN k := by
  by_cases h3 : n = 3
  · subst h3
    refine ⟨2, Nat.prime_two, by decide, ?_⟩
    intro k hk hk3
    interval_cases k <;> decide
  · have h2n : 3 ≤ 2 * n := by omega
    have h2n6 : 2 * n ≠ 6 := by omega
    have h2n12 : 2 * n ≠ 12 := by omega
    obtain ⟨q, hq, hqd, hprim⟩ := exists_primitive_prime (2 * n) h2n h2n6 h2n12
    rw [fib_two_mul_lucN] at hqd
    have hqn : ¬ q ∣ Nat.fib n := hprim n (by omega) (by omega)
    refine ⟨q, hq, ?_, ?_⟩
    · rcases (Nat.Prime.dvd_mul hq).mp hqd with h | h
      · exact absurd h hqn
      · exact h
    · intro k hk hkn hqk
      apply hprim (2 * k) (by omega) (by omega)
      rw [fib_two_mul_lucN]
      exact dvd_mul_of_dvd_right hqk _

/-! ### Distinct divisors have distinct primitive primes -/

open Classical in
/-- A chosen primitive prime of `F d` (junk value `0` when the theorem does not apply). -/
noncomputable def primPrime (d : ℕ) : ℕ :=
  if h : 3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12 then
    Classical.choose (exists_primitive_prime d h.1 h.2.1 h.2.2) else 0

theorem primPrime_spec (d : ℕ) (hd : 3 ≤ d) (h6 : d ≠ 6) (h12 : d ≠ 12) :
    (primPrime d).Prime ∧ primPrime d ∣ Nat.fib d ∧
      ∀ k, 0 < k → k < d → ¬ primPrime d ∣ Nat.fib k := by
  unfold primPrime
  rw [dif_pos ⟨hd, h6, h12⟩]
  exact Classical.choose_spec (exists_primitive_prime d hd h6 h12)

theorem primPrime_inj {d d' : ℕ} (hd : 3 ≤ d) (h6 : d ≠ 6) (h12 : d ≠ 12) (hd' : 3 ≤ d')
    (h6' : d' ≠ 6) (h12' : d' ≠ 12) (heq : primPrime d = primPrime d') : d = d' := by
  obtain ⟨hp, hdvd, hprim⟩ := primPrime_spec d hd h6 h12
  obtain ⟨-, hdvd', hprim'⟩ := primPrime_spec d' hd' h6' h12'
  rw [← heq] at hdvd' hprim'
  have h : HasRank (primPrime d) := hasRank_of_dvd (by omega) hdvd
  have e1 := rk_eq_of_primitive _ h (by omega : 0 < d) hdvd hprim
  have e2 := rk_eq_of_primitive _ h (by omega : 0 < d') hdvd' hprim'
  omega

/-- `#divisors n ≤ ω(F n) + 4`. -/
theorem card_divisors_le_card_primeFactors (n : ℕ) (hn : 1 ≤ n) :
    n.divisors.card ≤ (Nat.fib n).primeFactors.card + 4 := by
  classical
  set S := n.divisors.filter (fun d => 3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12) with hS
  have hfib : Nat.fib n ≠ 0 := (fib_pos_of_pos (by omega)).ne'
  have h1 : S.card ≤ (Nat.fib n).primeFactors.card := by
    apply Finset.card_le_card_of_injOn primPrime
    · intro d hd
      rw [hS, Finset.mem_coe, Finset.mem_filter, Nat.mem_divisors] at hd
      obtain ⟨⟨hdn, -⟩, hd3, hd6, hd12⟩ := hd
      obtain ⟨hp, hdvd, -⟩ := primPrime_spec d hd3 hd6 hd12
      rw [Finset.mem_coe, Nat.mem_primeFactors]
      exact ⟨hp, hdvd.trans (Nat.fib_dvd _ _ hdn), hfib⟩
    · intro d hd d' hd' heq
      rw [hS, Finset.mem_coe, Finset.mem_filter] at hd hd'
      exact primPrime_inj hd.2.1 hd.2.2.1 hd.2.2.2 hd'.2.1 hd'.2.2.1 hd'.2.2.2 heq
  have h2 : (n.divisors.filter (fun d => ¬ (3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12))).card ≤ 4 := by
    have hsub : n.divisors.filter (fun d => ¬ (3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12)) ⊆ {1, 2, 6, 12} := by
      intro d hd
      rw [Finset.mem_filter, Nat.mem_divisors] at hd
      obtain ⟨⟨hdn, -⟩, hneg⟩ := hd
      have hd0 : 0 < d := Nat.pos_of_dvd_of_pos hdn (by omega)
      simp only [Finset.mem_insert, Finset.mem_singleton]
      omega
    exact (Finset.card_le_card hsub).trans (by decide)
  have h3 := Finset.card_filter_add_card_filter_not (s := n.divisors)
    (fun d => 3 ≤ d ∧ d ≠ 6 ∧ d ≠ 12)
  rw [hS] at h1
  omega

/-! ### Equal prime factor sets -/

theorem primeFactors_ne_of_dvd {a b p : ℕ} (hp : p.Prime) (hpb : p ∣ b) (hb : b ≠ 0)
    (hpa : ¬ p ∣ a) : a.primeFactors ≠ b.primeFactors := by
  intro h
  have : p ∈ b.primeFactors := Nat.mem_primeFactors.mpr ⟨hp, hpb, hb⟩
  rw [← h, Nat.mem_primeFactors] at this
  exact hpa this.2.1

theorem fib_values : Nat.fib 3 = 2 ∧ Nat.fib 4 = 3 ∧ Nat.fib 5 = 5 ∧ Nat.fib 6 = 8 ∧
    Nat.fib 7 = 13 ∧ Nat.fib 8 = 21 ∧ Nat.fib 9 = 34 ∧ Nat.fib 10 = 55 ∧ Nat.fib 11 = 89 ∧
    Nat.fib 12 = 144 := by decide

/-- `F m` and `F n` (`3 ≤ m < n`) have the same prime factors only for `(m, n) = (3, 6)`. -/
theorem primeFactors_fib_eq_iff (m n : ℕ) (hm : 3 ≤ m) (hmn : m < n)
    (h : (Nat.fib m).primeFactors = (Nat.fib n).primeFactors) : m = 3 ∧ n = 6 := by
  obtain ⟨f3, f4, f5, f6, f7, f8, f9, f10, f11, f12⟩ := fib_values
  by_cases h6 : n = 6
  · subst h6
    refine ⟨?_, rfl⟩
    interval_cases m
    · rfl
    · exact absurd h (primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f6]; norm_num)
        (by rw [f6]; norm_num) (by rw [f4]; norm_num))
    · exact absurd h (primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f6]; norm_num)
        (by rw [f6]; norm_num) (by rw [f5]; norm_num))
  · by_cases h12 : n = 12
    · subst h12
      exfalso
      interval_cases m
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 3) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f3]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f4]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f5]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 3) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f6]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f7]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f8]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 3) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f9]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f10]; norm_num) h
      · exact primeFactors_ne_of_dvd (by norm_num : Nat.Prime 2) (by rw [f12]; norm_num)
          (by rw [f12]; norm_num) (by rw [f11]; norm_num) h
    · exfalso
      obtain ⟨q, hq, hqd, hprim⟩ := exists_primitive_prime n (by omega) h6 h12
      have hfib : Nat.fib n ≠ 0 := (fib_pos_of_pos (by omega)).ne'
      exact primeFactors_ne_of_dvd hq hqd hfib (hprim m (by omega) hmn) h

/-! ### The congruence `q = ±1 (mod n)` -/

theorem mod_eq_one_of_dvd_sub_one {q n : ℕ} (hn : 2 ≤ n) (hq : 1 ≤ q) (h : n ∣ q - 1) :
    q % n = 1 := by
  obtain ⟨t, ht⟩ := h
  have : q = 1 + n * t := by omega
  rw [this, Nat.add_mul_mod_self_left]
  exact Nat.mod_eq_of_lt (by omega)

theorem mod_eq_sub_one_of_dvd_add_one {q n : ℕ} (hn : 2 ≤ n) (h : n ∣ q + 1) :
    q % n = n - 1 := by
  obtain ⟨t, ht⟩ := h
  have ht1 : 1 ≤ t := by
    rcases Nat.eq_zero_or_pos t with rfl | h
    · omega
    · exact h
  have : q = (n - 1) + n * (t - 1) := by
    zify [ht1, (by omega : 1 ≤ n)] at ht ⊢
    linear_combination ht
  rw [this, Nat.add_mul_mod_self_left]
  exact Nat.mod_eq_of_lt (by omega)

/-- A primitive prime `q` of `F n` satisfies `q = ±1 (mod n)` when `n ≠ 5`. -/
theorem exists_primitive_prime_mod (n : ℕ) (hn : 3 ≤ n) (h5 : n ≠ 5) (h6 : n ≠ 6)
    (h12 : n ≠ 12) :
    ∃ q, q.Prime ∧ q ∣ Nat.fib n ∧ (q % n = 1 ∨ q % n = n - 1) := by
  obtain ⟨q, hq, hqd, hprim⟩ := exists_primitive_prime n hn h6 h12
  refine ⟨q, hq, hqd, ?_⟩
  have h : HasRank q := hasRank_of_dvd (by omega) hqd
  have hrk : rk q h = n := rk_eq_of_primitive q h (by omega) hqd hprim
  have hq5 : q ≠ 5 := by
    rintro rfl
    have : rk 5 h = 5 := by rw [rk_eq_rk 5 h hasRank_five, rk_five]
    omega
  rcases rk_dvd_pred_or_succ q hq hq5 h with h1 | h1
  · rw [hrk] at h1
    exact Or.inl (mod_eq_one_of_dvd_sub_one (by omega) hq.one_lt.le h1)
  · rw [hrk] at h1
    exact Or.inr (mod_eq_sub_one_of_dvd_add_one (by omega) h1)

end TuringTask
