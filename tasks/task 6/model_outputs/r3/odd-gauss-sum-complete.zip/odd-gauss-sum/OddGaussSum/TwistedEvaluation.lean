import OddGaussSum.Twisted

namespace OddGaussSum

noncomputable section

private theorem trace_one_of_data (q : ℕ)
    (A : Matrix (ZMod (4 * q + 1)) (ZMod (4 * q + 1)) ℂ)
    (hfour : A ^ 4 = 1)
    (hsqA : (A * A).trace = 1)
    (hdetA : A.det = Complex.I ^ ((4 * q + 1) * (2 * q)))
    (hnormA : ‖A.trace‖ = 1) : A.trace = 1 := by
  let n := 4 * q + 1
  let b := Pi.basisFun ℂ (ZMod n)
  let f : Module.End ℂ (ZMod n → ℂ) := Matrix.toLin b b A
  have htm : (LinearMap.toMatrix b b) f = A := by
    change (Matrix.toLin b b).symm ((Matrix.toLin b b) A) = A
    exact (Matrix.toLin b b).symm_apply_apply A
  have hf4 : f ^ 4 = 1 := by
    calc
      f ^ 4 = Matrix.toLin b b (A ^ 4) := (Matrix.toLin_pow b A 4).symm
      _ = Matrix.toLin b b 1 := by rw [hfour]
      _ = 1 := by rw [Matrix.toLin_one]; rfl
  obtain ⟨a, c, d, e, hcard, htrace, hsq, hdet⟩ :=
    fourthPowerEndData (ZMod n → ℂ) f hf4
  have hcard' : a + c + d + e = 4 * q + 1 := by
    rw [← hcard]
    simp [n, ZMod.card]
  have htrace' : A.trace = (((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I := by
    rw [← htrace, LinearMap.trace_eq_matrix_trace ℂ b f, htm]
  have hsq' : (a : ℤ) + c - d - e = 1 := by
    have hsqC : (((a : ℤ) + c - d - e : ℤ) : ℂ) = 1 := by
      rw [← hsq, LinearMap.trace_eq_matrix_trace ℂ b (f ^ 2)]
      have hm : (LinearMap.toMatrix b b) (f ^ 2) = A * A := by
        rw [show f ^ 2 = f * f by rfl, LinearMap.toMatrix_mul, htm]
      rw [hm, hsqA]
    exact_mod_cast hsqC
  have hdet' : ((-1 : ℂ) ^ c) * Complex.I ^ d * (-Complex.I) ^ e =
      Complex.I ^ ((4 * q + 1) * (2 * q)) := by
    rw [← hdet]
    have hlin : LinearMap.det f = A.det := by
      rw [← LinearMap.det_toMatrix b f, htm]
    rw [hlin, hdetA]
  rw [htrace']
  exact fourthSpectrum_one_mod_four q a c d e hcard' hsq' hdet' (by
    rw [← htrace']; exact hnormA)

private theorem trace_I_of_data (q : ℕ)
    (A : Matrix (ZMod (4 * q + 3)) (ZMod (4 * q + 3)) ℂ)
    (hfour : A ^ 4 = 1)
    (hsqA : (A * A).trace = 1)
    (hdetA : A.det = Complex.I ^ ((4 * q + 3) * (2 * q + 1)))
    (hnormA : ‖A.trace‖ = 1) : A.trace = Complex.I := by
  let n := 4 * q + 3
  let b := Pi.basisFun ℂ (ZMod n)
  let f : Module.End ℂ (ZMod n → ℂ) := Matrix.toLin b b A
  have htm : (LinearMap.toMatrix b b) f = A := by
    change (Matrix.toLin b b).symm ((Matrix.toLin b b) A) = A
    exact (Matrix.toLin b b).symm_apply_apply A
  have hf4 : f ^ 4 = 1 := by
    calc
      f ^ 4 = Matrix.toLin b b (A ^ 4) := (Matrix.toLin_pow b A 4).symm
      _ = Matrix.toLin b b 1 := by rw [hfour]
      _ = 1 := by rw [Matrix.toLin_one]; rfl
  obtain ⟨a, c, d, e, hcard, htrace, hsq, hdet⟩ :=
    fourthPowerEndData (ZMod n → ℂ) f hf4
  have hcard' : a + c + d + e = 4 * q + 3 := by
    rw [← hcard]
    simp [n, ZMod.card]
  have htrace' : A.trace = (((a : ℤ) - c : ℤ) : ℂ) +
      (((d : ℤ) - e : ℤ) : ℂ) * Complex.I := by
    rw [← htrace, LinearMap.trace_eq_matrix_trace ℂ b f, htm]
  have hsq' : (a : ℤ) + c - d - e = 1 := by
    have hsqC : (((a : ℤ) + c - d - e : ℤ) : ℂ) = 1 := by
      rw [← hsq, LinearMap.trace_eq_matrix_trace ℂ b (f ^ 2)]
      have hm : (LinearMap.toMatrix b b) (f ^ 2) = A * A := by
        rw [show f ^ 2 = f * f by rfl, LinearMap.toMatrix_mul, htm]
      rw [hm, hsqA]
    exact_mod_cast hsqC
  have hdet' : ((-1 : ℂ) ^ c) * Complex.I ^ d * (-Complex.I) ^ e =
      Complex.I ^ ((4 * q + 3) * (2 * q + 1)) := by
    rw [← hdet]
    have hlin : LinearMap.det f = A.det := by
      rw [← LinearMap.det_toMatrix b f, htm]
    rw [hlin, hdetA]
  rw [htrace']
  exact fourthSpectrum_three_mod_four q a c d e hcard' hsq' hdet' (by
    rw [← htrace']; exact hnormA)

theorem twisted_normalized_trace (n : ℕ) [NeZero n] (hodd : Odd n)
    (u : (ZMod n)ˣ) :
    (twistedNormalizedFourierMatrix n u).trace =
      ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℂ) *
        (if n % 4 = 1 then 1 else Complex.I) := by
  let s : ℂ := ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℂ)
  have hsZ : ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℤ) = 1 ∨
      ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℤ) = -1 := by
    rcases Int.units_eq_one_or (Equiv.Perm.sign (Units.mulLeft u)) with h | h
    · left; rw [h]; rfl
    · right; rw [h]; rfl
  have hs2 : s ^ 2 = 1 := by
    rcases hsZ with h | h <;> simp [s, h]
  let A := twistedNormalizedFourierMatrix n u
  let B : Matrix (ZMod n) (ZMod n) ℂ := s • A
  have hBfour : B ^ 4 = 1 := by
    have hA := twistedNormalizedFourierMatrix_fourth n u
    change (s • A) ^ 4 = 1
    rw [smul_pow]
    rw [hA, show s ^ 4 = 1 by rw [show s ^ 4 = (s ^ 2) ^ 2 by ring, hs2]; simp]
    simp
  have hBsq : (B * B).trace = 1 := by
    change ((s • A) * (s • A)).trace = 1
    rw [Matrix.smul_mul, Matrix.mul_smul, smul_smul,
      show s * s = s ^ 2 by simp [pow_two], hs2, one_smul,
      twistedNormalizedFourierMatrix_sq, trace_negMatrix_of_odd n hodd]
  have hBnorm : ‖B.trace‖ = 1 := by
    change ‖(s • A).trace‖ = 1
    rw [Matrix.trace_smul, norm_smul, twistedNormalized_trace_norm n hodd u]
    have hsabs : ‖s‖ = 1 := by rcases hsZ with h | h <;> simp [s, h]
    simp [hsabs]
  have hBdet : B.det = (normalizedFourierMatrix n).det := by
    change (s • A).det = _
    rw [Matrix.det_smul, twistedNormalized_det]
    rw [ZMod.card]
    change s ^ n * (s * (normalizedFourierMatrix n).det) = _
    have hnodd : Odd n := hodd
    obtain ⟨m, rfl⟩ := hnodd
    rw [show s ^ (2 * m + 1) = s by
      rw [pow_add, pow_mul, hs2]
      simp]
    rw [← mul_assoc, ← pow_two, hs2, one_mul]
  by_cases hmod : n % 4 = 1
  · obtain ⟨q, hq⟩ : ∃ q, n = 4 * q + 1 := by
      refine ⟨n / 4, ?_⟩
      have hd := Nat.mod_add_div n 4
      omega
    subst n
    have ht : B.trace = 1 := trace_one_of_data q B hBfour hBsq (by
      rw [hBdet]
      exact normalizedFourierMatrix_det_of_eq (4 * q + 1) (2 * q) (by omega)) hBnorm
    change (s • A).trace = 1 at ht
    rw [Matrix.trace_smul] at ht
    simp only [smul_eq_mul] at ht
    rw [if_pos hmod]
    calc
      A.trace = s ^ 2 * A.trace := by rw [hs2, one_mul]
      _ = s * (s * A.trace) := by ring
      _ = s := by rw [ht, mul_one]
      _ = ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℂ) * 1 := by
        simp [s]
  · have hmod3 : n % 4 = 3 := by
      rcases hodd with ⟨k, hk⟩
      omega
    obtain ⟨q, hq⟩ : ∃ q, n = 4 * q + 3 := by
      refine ⟨n / 4, ?_⟩
      have hd := Nat.mod_add_div n 4
      omega
    subst n
    have ht : B.trace = Complex.I := trace_I_of_data q B hBfour hBsq (by
      rw [hBdet]
      exact normalizedFourierMatrix_det_of_eq (4 * q + 3) (2 * q + 1) (by omega)) hBnorm
    change (s • A).trace = Complex.I at ht
    rw [Matrix.trace_smul] at ht
    simp only [smul_eq_mul] at ht
    rw [if_neg hmod]
    calc
      A.trace = s ^ 2 * A.trace := by rw [hs2, one_mul]
      _ = s * (s * A.trace) := by ring
      _ = s * Complex.I := by rw [ht]
      _ = ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℂ) * Complex.I := by
        rfl

end

end OddGaussSum
