import OddGaussSum.TwistedEvaluation

namespace OddGaussSum

private theorem two_coprime_odd (q : ℕ) : Nat.Coprime 2 (2 * q + 1) := by
  rw [Nat.coprime_comm]
  exact (show Odd (2 * q + 1) from ⟨q, by omega⟩).coprime_two_right

def doubleUnit (q : ℕ) : (ZMod (2 * q + 1))ˣ :=
  ZMod.unitOfCoprime 2 (two_coprime_odd q)

def doublePerm (q : ℕ) : Equiv.Perm (Fin (2 * q + 1)) :=
  (ZMod.finEquiv (2 * q + 1)).toEquiv.symm.permCongr
    (Units.mulLeft (doubleUnit q))

private theorem doublePerm_val (q : ℕ) (i : Fin (2 * q + 1)) :
    (doublePerm q i).val = (2 * i.val) % (2 * q + 1) := by
  change ((ZMod.finEquiv (2 * q + 1)).symm
    ((doubleUnit q : ZMod (2 * q + 1)) * ZMod.finEquiv (2 * q + 1) i)).val = _
  have hinv (z : ZMod (2 * q + 1)) :
      ((ZMod.finEquiv (2 * q + 1)).symm z).val = z.val := rfl
  have hfwd : ZMod.finEquiv (2 * q + 1) i = (i.val : ZMod (2 * q + 1)) := by
    have hv : (ZMod.finEquiv (2 * q + 1) i).val = i.val := rfl
    symm
    rw [← hv, ZMod.natCast_zmod_val]
  have hcast : (doubleUnit q : ZMod (2 * q + 1)) = 2 := by
    rfl
  rw [hinv, hfwd]
  rw [hcast, ZMod.val_mul, ZMod.val_two_eq_two_mod, ZMod.val_natCast]
  rw [← Nat.mul_mod]

private theorem doublePerm_inversion_iff (q : ℕ)
    (i j : Fin (2 * q + 1)) (hij : i < j) :
    ¬doublePerm q i < doublePerm q j ↔
      i.val ≤ q ∧ q < j.val ∧ j.val ≤ q + i.val := by
  rw [show doublePerm q i < doublePerm q j ↔
      (doublePerm q i).val < (doublePerm q j).val by rfl,
    doublePerm_val, doublePerm_val]
  by_cases hi : i.val ≤ q
  · have himod : (2 * i.val) % (2 * q + 1) = 2 * i.val :=
      Nat.mod_eq_of_lt (by omega)
    rw [himod]
    by_cases hj : j.val ≤ q
    · have hjmod : (2 * j.val) % (2 * q + 1) = 2 * j.val :=
        Nat.mod_eq_of_lt (by omega)
      rw [hjmod]
      omega
    · have hjlo : 2 * q + 1 ≤ 2 * j.val := by omega
      have hjhi : 2 * j.val - (2 * q + 1) < 2 * q + 1 := by
        have := j.isLt
        omega
      rw [Nat.mod_eq_sub_mod hjlo, Nat.mod_eq_of_lt hjhi]
      omega
  · have hjq : q < j.val := by omega
    have hilo : 2 * q + 1 ≤ 2 * i.val := by omega
    have hjlo : 2 * q + 1 ≤ 2 * j.val := by omega
    have hihi : 2 * i.val - (2 * q + 1) < 2 * q + 1 := by
      have := i.isLt
      omega
    have hjhi : 2 * j.val - (2 * q + 1) < 2 * q + 1 := by
      have := j.isLt
      omega
    rw [Nat.mod_eq_sub_mod hilo, Nat.mod_eq_of_lt hihi,
      Nat.mod_eq_sub_mod hjlo, Nat.mod_eq_of_lt hjhi]
    omega

private theorem inversion_card (q : ℕ) (i : Fin (2 * q + 1)) :
    ((Finset.Ioi i).filter (fun j => ¬doublePerm q i < doublePerm q j)).card =
      if i.val ≤ q then i.val else 0 := by
  by_cases hi : i.val ≤ q
  · let lo : Fin (2 * q + 1) := ⟨q, by omega⟩
    let hi' : Fin (2 * q + 1) := ⟨q + i.val, by omega⟩
    have heq : (Finset.Ioi i).filter
        (fun j => ¬doublePerm q i < doublePerm q j) = Finset.Ioc lo hi' := by
      ext j
      simp only [Finset.mem_filter, Finset.mem_Ioi, Finset.mem_Ioc]
      constructor
      · rintro ⟨hij, hinv⟩
        have h := (doublePerm_inversion_iff q i j hij).mp hinv
        change q < j.val ∧ j.val ≤ q + i.val
        omega
      · rintro ⟨hlo, hhi⟩
        have hij : i < j := by
          change i.val < j.val
          change q < j.val at hlo
          omega
        refine ⟨hij, (doublePerm_inversion_iff q i j hij).mpr ?_⟩
        change q < j.val at hlo
        change j.val ≤ q + i.val at hhi
        omega
    rw [heq]
    simp [hi, lo, hi']
  · have heq : (Finset.Ioi i).filter
        (fun j => ¬doublePerm q i < doublePerm q j) = ∅ := by
      ext j
      simp only [Finset.mem_filter, Finset.mem_Ioi]
      constructor
      · rintro ⟨hij, hinv⟩
        exact (hi ((doublePerm_inversion_iff q i j hij).mp hinv).1).elim
      · intro h
        simpa using h
    rw [heq]
    simp [hi]

theorem sign_doubleUnit (q : ℕ) :
    Equiv.Perm.sign (Units.mulLeft (doubleUnit q)) =
      (-1 : ℤˣ) ^ (q * (q + 1) / 2) := by
  rw [← Equiv.Perm.sign_permCongr
    (ZMod.finEquiv (2 * q + 1)).toEquiv.symm
    (Units.mulLeft (doubleUnit q))]
  change Equiv.Perm.sign (doublePerm q) = _
  rw [Equiv.Perm.sign_eq_prod_prod_Ioi]
  have hinner (i : Fin (2 * q + 1)) :
      (∏ j ∈ Finset.Ioi i,
        if doublePerm q i < doublePerm q j then (1 : ℤˣ) else -1) =
      (-1 : ℤˣ) ^ (if i.val ≤ q then i.val else 0) := by
    rw [Finset.prod_ite]
    simp only [Finset.prod_const_one, one_mul, Finset.prod_const]
    have hc := inversion_card q i
    exact congrArg (fun k : ℕ => (-1 : ℤˣ) ^ k) hc
  simp_rw [hinner]
  have hp := Finset.prod_pow_eq_pow_sum
    (Finset.univ : Finset (Fin (2 * q + 1)))
    (fun i => if i.val ≤ q then i.val else 0) (-1 : ℤˣ)
  change (∏ i : Fin (2 * q + 1),
    (-1 : ℤˣ) ^ (if i.val ≤ q then i.val else 0)) = _
  have hsum : (∑ k ∈ Finset.range (2 * q + 1),
      if k ≤ q then k else 0) = q * (q + 1) / 2 := by
    rw [show 2 * q + 1 = (q + 1) + q by omega, Finset.sum_range_add]
    have hfirst : (∑ x ∈ Finset.range (q + 1), if x ≤ q then x else 0) =
        ∑ x ∈ Finset.range (q + 1), x := by
      apply Finset.sum_congr rfl
      intro x hx
      simp only [Finset.mem_range] at hx
      simp [show x ≤ q by omega]
    have hsecond : (∑ x ∈ Finset.range q,
        if q + 1 + x ≤ q then q + 1 + x else 0) = 0 := by
      apply Finset.sum_eq_zero
      intro x hx
      simp [show ¬q + 1 + x ≤ q by omega]
    rw [hfirst, hsecond, add_zero, Finset.sum_range_id]
    rw [show q + 1 - 1 = q by omega, Nat.mul_comm]
  have hsumFin : (∑ i : Fin (2 * q + 1),
      if i.val ≤ q then i.val else 0) = q * (q + 1) / 2 := by
    calc
      _ = ∑ k ∈ Finset.range (2 * q + 1), if k ≤ q then k else 0 := by
        simpa using Fin.sum_univ_eq_sum_range
          (fun k => if k ≤ q then k else 0) (2 * q + 1)
      _ = _ := hsum
  exact hp.trans (congrArg (fun k : ℕ => (-1 : ℤˣ) ^ k) hsumFin)

end OddGaussSum
