# TuringTask status

This offline project records a kernel-checked reduction relevant to the requested
five theorems. It is **not a completed solution**: the pinned Mathlib revision
does not provide Bang--Zsigmondy's primitive-prime-divisor theorem, and that
substantial existence and exception-classification proof has not been
formalized here.

No `sorry`, `admit`, `native_decide`, or new axiom is used. The project uses the
supplied local Mathlib path and can be checked in that environment with:

```sh
lean TuringTask/Basic.lean
lake build
```

The verified lemmas prove that a prime not dividing `b * n` for which `a / b`
is a root of the `n`th cyclotomic polynomial gives exactly the primitive prime
divisor required in theorem 1. The unresolved obligation is proving that such a
prime exists outside the two stated exceptional cases. The other requested
results depend on that obligation.
