import Mathlib

open scoped BigOperators ComplexConjugate

namespace GaussSumAnswer

noncomputable section

/-- The standard complex quadratic exponential sum over `ZMod p`. -/
def quadraticGaussSum (p : ℕ) [NeZero p] (a : ZMod p) : ℂ :=
  ∑ x : ZMod p, ZMod.stdAddChar (a * x ^ 2)

/-- `quadraticGaussSum` written as the usual complex exponential. -/
theorem quadraticGaussSum_eq_exp (p : ℕ) [NeZero p] (a : ZMod p) :
    quadraticGaussSum p a =
      ∑ x : ZMod p,
        Complex.exp
          (2 * (Real.pi : ℂ) * Complex.I * ((a * x ^ 2).val : ℂ) / (p : ℂ)) := by
  simp only [quadraticGaussSum, ZMod.stdAddChar_apply, ZMod.toCircle_apply]

private theorem odd_prime_ringChar_ne_two (p : ℕ) [hp : Fact p.Prime]
    (hodd : p ≠ 2) : ringChar (ZMod p) ≠ 2 := by
  rw [ZMod.ringChar_zmod_n]
  exact hodd

private theorem sum_quadraticChar (p : ℕ) [hp : Fact p.Prime] (hodd : p ≠ 2) :
    quadraticGaussSum p 1 =
      ∑ y : ZMod p, ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ZMod.stdAddChar y := by
  let ψ : AddChar (ZMod p) ℂ := ZMod.stdAddChar
  have hchar : ringChar (ZMod p) ≠ 2 := odd_prime_ringChar_ne_two p hodd
  have hsumψ : ∑ y : ZMod p, ψ y = 0 := by
    have h := AddChar.sum_mulShift (ψ := ψ) 1 (ZMod.isPrimitive_stdAddChar p)
    simpa using h
  calc
    quadraticGaussSum p 1 = ∑ x : ZMod p, ψ (x ^ 2) := by
      simp [quadraticGaussSum, ψ]
    _ = ∑ y : ZMod p, ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (x ^ 2) := by
      symm
      exact Finset.sum_fiberwise Finset.univ (fun x : ZMod p => x ^ 2)
        (fun x => ψ (x ^ 2))
    _ = ∑ y : ZMod p,
        (((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ y + ψ y) := by
      apply Finset.sum_congr rfl
      intro y _
      calc
        ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (x ^ 2) =
            ∑ x ∈ Finset.univ with x ^ 2 = y, ψ y := by
          apply Finset.sum_congr rfl
          intro x hx
          simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hx
          rw [hx]
        _ = ({x : ZMod p | x ^ 2 = y}.toFinset.card : ℂ) * ψ y := by
          simp [Finset.sum_const, nsmul_eq_mul]
        _ = ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ y + ψ y := by
          have hroots := quadraticChar_card_sqrts hchar y
          have hrootsC : ({x : ZMod p | x ^ 2 = y}.toFinset.card : ℂ) =
              ((quadraticChar (ZMod p) y : ℤ) : ℂ) + 1 := by
            exact_mod_cast hroots
          rw [hrootsC]
          ring
    _ = ∑ y : ZMod p, ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ y := by
      rw [Finset.sum_add_distrib, hsumψ, add_zero]

/-- A quadratic exponential sum is the Gauss sum weighted by the Legendre
symbol. Both sides are written as genuine complex exponentials. -/
theorem sum_legendre (p : ℕ) [hp : Fact p.Prime] (hodd : p ≠ 2) :
    quadraticGaussSum p 1 =
      ∑ y : ZMod p, (legendreSym p (y.val : ℤ) : ℂ) *
        Complex.exp
          (2 * (Real.pi : ℂ) * Complex.I * (y.val : ℂ) / (p : ℂ)) := by
  rw [sum_quadraticChar p hodd]
  apply Finset.sum_congr rfl
  intro y _
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply]
  have hy : ((y.val : ℤ) : ZMod p) = y := by
    exact_mod_cast ZMod.natCast_zmod_val y
  simp only [legendreSym, hy]

private theorem quadraticGaussSum_eq_weighted (p : ℕ) [hp : Fact p.Prime]
    (hodd : p ≠ 2) (a : ZMod p) (ha : a ≠ 0) :
    quadraticGaussSum p a =
      ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ZMod.stdAddChar (a * y) := by
  let ψ : AddChar (ZMod p) ℂ := ZMod.stdAddChar
  have hchar : ringChar (ZMod p) ≠ 2 := odd_prime_ringChar_ne_two p hodd
  have hsumψ : ∑ y : ZMod p, ψ (a * y) = 0 := by
    have h := AddChar.sum_mulShift (ψ := ψ) a (ZMod.isPrimitive_stdAddChar p)
    simpa [mul_comm, ha] using h
  calc
    quadraticGaussSum p a = ∑ x : ZMod p, ψ (a * x ^ 2) := by
      rfl
    _ = ∑ y : ZMod p, ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * x ^ 2) := by
      symm
      exact Finset.sum_fiberwise Finset.univ (fun x : ZMod p => x ^ 2)
        (fun x => ψ (a * x ^ 2))
    _ = ∑ y : ZMod p,
        (((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ (a * y) + ψ (a * y)) := by
      apply Finset.sum_congr rfl
      intro y _
      calc
        ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * x ^ 2) =
            ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * y) := by
          apply Finset.sum_congr rfl
          intro x hx
          simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hx
          rw [hx]
        _ = ({x : ZMod p | x ^ 2 = y}.toFinset.card : ℂ) * ψ (a * y) := by
          simp [Finset.sum_const, nsmul_eq_mul]
        _ = ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ (a * y) + ψ (a * y) := by
          have hroots := quadraticChar_card_sqrts hchar y
          have hrootsC : ({x : ZMod p | x ^ 2 = y}.toFinset.card : ℂ) =
              ((quadraticChar (ZMod p) y : ℤ) : ℂ) + 1 := by
            exact_mod_cast hroots
          rw [hrootsC]
          ring
    _ = ∑ y : ZMod p, ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ψ (a * y) := by
      rw [Finset.sum_add_distrib, hsumψ, add_zero]
    _ = ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : ℤ) : ℂ) * ZMod.stdAddChar (a * y) := by
      rfl

private theorem sum_sq_mul_zmod (p : ℕ) [hp : Fact p.Prime] (hodd : p ≠ 2)
    (a : ZMod p) (ha : a ≠ 0) :
    quadraticGaussSum p a =
      ((quadraticChar (ZMod p) a : ℤ) : ℂ) * quadraticGaussSum p 1 := by
  let ψ : AddChar (ZMod p) ℂ := ZMod.stdAddChar
  let χ : MulChar (ZMod p) ℤ := quadraticChar (ZMod p)
  have hχsq : ((χ a : ℤ) : ℂ) * ((χ a : ℤ) : ℂ) = 1 := by
    have h := quadraticChar_sq_one (F := ZMod p) ha
    change χ a ^ 2 = 1 at h
    have h' : χ a * χ a = 1 := by simpa [pow_two] using h
    exact_mod_cast h'
  have hperm :
      (∑ y : ZMod p, ((χ (a * y) : ℤ) : ℂ) * ψ (a * y)) =
        ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ y := by
    simpa using (Equiv.sum_comp (Equiv.mulLeft₀ a ha)
      (fun y : ZMod p => ((χ y : ℤ) : ℂ) * ψ y))
  have hmul :
      ((χ a : ℤ) : ℂ) *
          (∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y)) =
        ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ y := by
    rw [Finset.mul_sum]
    calc
      ∑ y : ZMod p, ((χ a : ℤ) : ℂ) * (((χ y : ℤ) : ℂ) * ψ (a * y)) =
          ∑ y : ZMod p, ((χ (a * y) : ℤ) : ℂ) * ψ (a * y) := by
        apply Finset.sum_congr rfl
        intro y _
        rw [map_mul χ a y]
        push_cast
        ring
      _ = ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ y := hperm
  rw [quadraticGaussSum_eq_weighted p hodd a ha,
    quadraticGaussSum_eq_weighted p hodd 1 one_ne_zero]
  change (∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y)) =
    ((χ a : ℤ) : ℂ) * ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (1 * y)
  simp only [one_mul]
  calc
    ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y) =
        1 * ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y) := by rw [one_mul]
    _ = (((χ a : ℤ) : ℂ) * ((χ a : ℤ) : ℂ)) *
          ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y) := by rw [hχsq]
    _ = ((χ a : ℤ) : ℂ) *
          (((χ a : ℤ) : ℂ) *
            ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ (a * y)) := by ring
    _ = ((χ a : ℤ) : ℂ) *
          ∑ y : ZMod p, ((χ y : ℤ) : ℂ) * ψ y := by rw [hmul]

/-- Multiplying the square in a quadratic exponential sum by a nonzero integer
multiplies the sum by that integer's Legendre symbol. -/
theorem sum_sq_mul (p : ℕ) [hp : Fact p.Prime] (hodd : p ≠ 2)
    (a : ℤ) (ha : ¬ (p : ℤ) ∣ a) :
    (∑ x : ZMod p,
        Complex.exp
          (2 * (Real.pi : ℂ) * Complex.I * ((((a : ZMod p) * x ^ 2).val : ℕ) : ℂ) /
            (p : ℂ))) =
      (legendreSym p a : ℂ) *
        ∑ x : ZMod p,
          Complex.exp
            (2 * (Real.pi : ℂ) * Complex.I * ((x ^ 2).val : ℂ) / (p : ℂ)) := by
  have ha0 : (a : ZMod p) ≠ 0 := by
    rw [ne_eq, ZMod.intCast_zmod_eq_zero_iff_dvd]
    exact ha
  have h1 :
      (∑ x : ZMod p,
        Complex.exp
          (2 * (Real.pi : ℂ) * Complex.I * ((x ^ 2).val : ℂ) / (p : ℂ))) =
        quadraticGaussSum p 1 := by
    simpa using (quadraticGaussSum_eq_exp p 1).symm
  rw [← quadraticGaussSum_eq_exp p (a : ZMod p), h1]
  simpa only [legendreSym] using sum_sq_mul_zmod p hodd (a : ZMod p) ha0

end

end GaussSumAnswer
