# Character-sum proofs

This project contains kernel-checked Lean 4/Mathlib proofs of the exact
statements `TuringTask.csum_sq_of_sq` and `TuringTask.csum_one_emod`, together
with the prerequisite `TuringTask.csum_sq_add_sq`, in `Answer/Basic.lean`.

The mod-8 proof pairs `x` with `-x`, evaluates the product of the remaining
half-range character signs, and uses Wilson's theorem and Euler's criterion.
The square proof changes variables for square parameters and applies a proved
uniqueness lemma for the odd coordinate in representations of a prime as two
squares.

It is configured for the supplied offline environment, with Mathlib at
`/opt/mathlib4`. Build it there with:

```sh
lean-offline-init
lake build
lake env lean Answer/Basic.lean
```

The local `/opt/mathlib4` dependency means the archive requires the supplied
Lean/Mathlib environment; it is not self-contained on an arbitrary machine.
No network access is required for these commands.
