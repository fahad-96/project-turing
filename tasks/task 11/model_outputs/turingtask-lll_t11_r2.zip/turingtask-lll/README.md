# TuringTask — Lovász Local Lemma and five combinatorial applications

A complete Lean 4 formalisation of the symmetric Lovász Local Lemma (LLL) together with
the five requested theorems, proved from scratch with no `sorry`.

## Requirements (offline)

This project is **not** self-contained. It requires the supplied container image providing:

* Lean toolchain `leanprover/lean4:v4.33.0-rc1`
* a prebuilt Mathlib at `/opt/mathlib4` (commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`)
* the wrappers `lean`, `lake` and the helper `lean-offline-init`

`lakefile.toml` uses a **local path dependency** on `/opt/mathlib4`. No network access is
needed or attempted.

## Offline build instructions

```sh
cd <project root>
lean-offline-init     # seeds .lake/packages with links to the installed deps (local only)
lake build            # must finish with "Build completed successfully"
```

To re-check the axiom footprint:

```sh
cat > /tmp/ax.lean <<'EOF'
import TuringTask
#print axioms TuringTask.color_meet
#print axioms TuringTask.color_deg
#print axioms TuringTask.sat_exists
#print axioms TuringTask.ramsey_color
#print axioms TuringTask.ap_color
EOF
lake env lean /tmp/ax.lean
```

Each line must read `[propext, Classical.choice, Quot.sound]`.

## File layout

| File | Contents |
| --- | --- |
| `TuringTask/LLL.lean` | The probabilistic core: the uniform measure `pr` on `V → Bool`, the support predicate `Meas`, exact independence of events with disjoint supports, the induction `chain`/`key`, and the symmetric LLL `LLL_sym`. |
| `TuringTask/Hyper.lean` | The generic hypergraph 2-colouring theorem `two_color_hypergraph`. |
| `TuringTask/Apps.lean` | Bridging `Fin`-indexed Boolean incidence functions to `Finset` supports. |
| `TuringTask/Deg.lean` | The numeric inequality `e(k(k−1)+1) ≤ 2^{k−1}` for `k ≥ 9`, and the degree bound. |
| `TuringTask/Sat.lean` | The generic k-SAT theorem `sat_generic`. |
| `TuringTask/Ramsey.lean` | Edge sets of `k`-cliques, the `C(k,2)·C(n,k−2)` degree bound, `ramsey_main`. |
| `TuringTask/AP.lean` | Arithmetic progressions, the `k²N` degree bound, `ap_final`. |
| `TuringTask/Basic.lean` | **The five required theorems**, statements verbatim as specified. |

## Mathematical outline

### The probability space

Everything happens in the finite space `V → Bool` with the uniform measure
`pr A = |A| / 2^|V|`. An event `A` is `Meas T A` when membership depends only on the
coordinates in `T`. The crucial fact (`pr_inter`) is genuine *independence*:

> if `Meas T A` and `Meas Tᶜ C` then `pr (A ∩ C) = pr A * pr C`.

This is proved by an exact counting bijection (`card_inter_mul`): the map
`(α, β) ↦ (v ↦ if v ∈ T then α v else β v)` from `A ×ˢ C` onto `A ∩ C` has all fibres of
size exactly `2^|V|`. No measure theory is imported; the argument is pure finite
combinatorics, so it is fully kernel-checkable.

### The local lemma

`nbr D i` is the set of `j ≠ i` whose support meets that of `i`. The standard proof is
formalised in two interlocking inductions:

* `chain` — for disjoint `T`, `U`, `(1−x)^{|T|} · pr(Good U) ≤ pr(Good (T ∪ U))`,
  by induction on `T` using `Good (insert j S) = Good S \ A j` and `pr_sdiff`.
* `key` — `pr(A i ∩ Good S) ≤ x · pr(Good S)`, by strong induction on `|S|`. The set `S`
  is split into the part inside `nbr D i` (bounded in size by `d`) and the part outside
  (independent of `A i`, handled by `pr_indep`).

`LLL_core` then takes `S = univ` to get `pr(Good univ) ≥ (1−x)^{|ι|} > 0`, hence a point
avoiding every bad event. `LLL_sym` specialises with the optimal `x = 1/(d+2)`, where the
hypothesis `e·p·(d+1) ≤ 1` is converted using `1 + 1/y ≤ exp(1/y)`, giving
`(y+1)^{d+1} ≤ e·y^{d+1}` with `y = d+1`.

### The five applications

1. **`color_meet`** — bad event: edge `i` is monochromatic. It is contained in the union of
   two patterns on `E_i`, so `p ≤ 2/2^k = 1/2^{k−1}`. Apply `LLL_sym`.
2. **`color_deg`** — each edge meets at most `k(k−1)` others (a biUnion over its `k` vertices
   of the ≤ `k` edges through each, minus itself). The numeric inequality
   `e(k(k−1)+1) ≤ 2^{k−1}` for `k ≥ 9` is proved by induction after substituting `k = j+9`:
   the base case uses `Real.exp_one_lt_d9` (`73e ≤ 256`), and the step holds because the
   left side at most doubles while the right side exactly doubles.
3. **`sat_exists`** — bad event: clause `i` is unsatisfied, which pins all `k` variables to
   the negations of their signs — a *single* pattern, so `p ≤ 1/2^k`.
4. **`ramsey_color`** — index set is the `k`-subsets of `Fin n`; the vertex set of the
   probability space is `Sym2 (Fin n)`. A `k`-set spans at least `C(k,2)` edges
   (`Finset.card_le_card_of_surjOn` onto `powersetCard 2 s` via `Sym2.toFinset`). Two
   `k`-sets interact only if they share an edge, and a neighbour is determined by the shared
   edge together with its remaining `k−2` vertices, giving the `C(k,2)·C(n,k−2)` bound. For
   `k < 2` the hypothesis is contradictory (`e·1 ≤ 1` is false).
5. **`ap_color`** — index set is the valid progressions `(a, r)` with `r ≥ 1` and
   `a + (k−1)r < N`. Each has exactly `k` distinct terms. A progression is determined by one
   of its `k` points, that point's position, and the common difference `r < N`; summing over
   the `k` points of a fixed progression gives the degree bound `k·(k·N) = k²N`. The
   `Fin N`-indexed colouring is transported to `Nat → Bool` by `fun x => if x < N then …`.
   For `k < 2` the hypothesis is again contradictory.

In 1, 2, 4 and 5 the conclusion "both colours appear" is converted to the cardinality form
`2 ≤ |image|` by `two_le_card_image`.
