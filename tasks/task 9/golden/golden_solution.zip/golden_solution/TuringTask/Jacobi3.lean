import Mathlib
import TuringTask.Cubes

/-!
# The cubic Jacobi sum and the representation `4 p = L ^ 2 + 27 M ^ 2`

For a character `χ` of order 3 on `ZMod p` we write `J = jacobiSum χ χ`. Mathlib gives
`J = -1 + z * (μ - 1) ^ 2` with `z ∈ ℤ[μ]` (`μ` a primitive cube root of unity) and
`J * J(χ⁻¹, χ⁻¹) = p`. From this we get integers `L, M` with `4 p = L ^ 2 + 27 M ^ 2`,
`L % 3 = 1` and `J + J(χ⁻¹, χ⁻¹) = L` (`jacobi_trace_rep`). The integer `L` is unique
(`rep_eq_of_rep`), so every such `L` equals the trace of `J` (`jacobi_trace_eq`).
-/

open Finset

namespace TuringTask

/-- If `4 p = x ^ 2 + 27 y ^ 2 = u ^ 2 + 27 v ^ 2` and `p ∣ x v - u y`, then `x = u` or
`x = -u`. -/
theorem rep_sign_aux {p : ℕ} (hp : p.Prime) {x y u v : ℤ}
    (hxy : 4 * (p : ℤ) = x ^ 2 + 27 * y ^ 2) (huv : 4 * (p : ℤ) = u ^ 2 + 27 * v ^ 2)
    (hdiv : (p : ℤ) ∣ x * v - u * y) : x = u ∨ x = -u := by
  obtain ⟨k, hk⟩ := hdiv
  have hpos : (0 : ℤ) < p := by exact_mod_cast hp.pos
  -- the product formula for `x ^ 2 + 27 y ^ 2`
  have hbr : (x * u + 27 * y * v) ^ 2 + 27 * (x * v - u * y) ^ 2 = (4 * (p : ℤ)) ^ 2 := by
    linear_combination (-(u ^ 2 + 27 * v ^ 2)) * hxy - 4 * (p : ℤ) * huv
  -- `x v - u y` is a multiple of `p` of size less than `p`, hence zero
  have hk0 : k = 0 := by
    by_contra hne
    have hk2 : 1 ≤ k ^ 2 := by
      rcases lt_or_gt_of_ne hne with h | h <;> nlinarith
    rw [hk] at hbr
    nlinarith [sq_nonneg (x * u + 27 * y * v),
      mul_le_mul_of_nonneg_left hk2 (sq_nonneg (p : ℤ)), mul_pos hpos hpos]
  have hzero : x * v - u * y = 0 := by rw [hk, hk0, mul_zero]
  have hsq : (x * u + 27 * y * v) ^ 2 = (4 * (p : ℤ)) ^ 2 := by
    linear_combination hbr - 27 * (x * v - u * y) * hzero
  have hlin : u * (x * u + 27 * y * v) = 4 * (p : ℤ) * x := by
    linear_combination (-x) * huv + (-27 * v) * hzero
  rcases sq_eq_sq_iff_eq_or_eq_neg.mp hsq with h | h
  · have h4 : 4 * (p : ℤ) * (x - u) = 0 := by linear_combination (-1 : ℤ) * hlin + u * h
    rcases mul_eq_zero.mp h4 with h5 | h5
    · omega
    · left
      linarith
  · have h4 : 4 * (p : ℤ) * (x + u) = 0 := by linear_combination (-1 : ℤ) * hlin + u * h
    rcases mul_eq_zero.mp h4 with h5 | h5
    · omega
    · right
      linarith

/-- Uniqueness of `L` in `4 p = L ^ 2 + 27 M ^ 2` with `L % 3 = 1`. -/
theorem rep_eq_of_rep {p : ℕ} (hp : p.Prime) (L M L' M' : ℤ)
    (h1 : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2) (h2 : 4 * (p : ℤ) = L' ^ 2 + 27 * M' ^ 2)
    (hL : L % 3 = 1) (hL' : L' % 3 = 1) : L = L' := by
  have hpZ := Nat.prime_iff_prime_int.mp hp
  -- `L ^ 2 M' ^ 2 - L' ^ 2 M ^ 2` is a multiple of `p`
  have hprod : (p : ℤ) ∣ (L * M' - L' * M) * (L * (-M') - L' * M) :=
    ⟨4 * M ^ 2 - 4 * M' ^ 2, by linear_combination M' ^ 2 * h1 - M ^ 2 * h2⟩
  have hsign : L = L' ∨ L = -L' := by
    rcases hpZ.dvd_or_dvd hprod with h | h
    · exact rep_sign_aux hp h1 h2 h
    · exact rep_sign_aux hp h1 (by rw [h2]; ring) h
  rcases hsign with h | h
  · exact h
  · omega

/-- A primitive cube root of unity satisfies `μ ^ 2 + μ + 1 = 0`. -/
theorem prim3_rel {μ : ℂ} (hμ : IsPrimitiveRoot μ 3) : μ ^ 2 + μ + 1 = 0 := by
  have h := one_add_add_sq_eq_zero hμ.pow_eq_one (hμ.ne_one (by norm_num))
  linear_combination h

/-- The complex conjugate of a primitive cube root of unity is its square. -/
theorem prim3_star {μ : ℂ} (hμ : IsPrimitiveRoot μ 3) : star μ = μ ^ 2 := by
  have hn : ‖μ‖ = 1 := hμ.norm'_eq_one (by norm_num)
  rw [Complex.star_def, ← Complex.inv_eq_conj hn]
  refine inv_eq_of_mul_eq_one_right ?_
  have h : μ ^ 3 = μ * μ ^ 2 := pow_succ' μ 2
  rw [← h]
  exact hμ.pow_eq_one

/-- Elements of `ℤ[μ]` have the form `c + d μ` when `μ ^ 2 + μ + 1 = 0`. -/
theorem adjoin_two_coords {μ : ℂ} (hμ : μ ^ 2 + μ + 1 = 0) {z : ℂ}
    (hz : z ∈ Algebra.adjoin ℤ {μ}) : ∃ c d : ℤ, z = c + d * μ := by
  rw [Algebra.adjoin_singleton_eq_range_aeval] at hz
  obtain ⟨q, rfl⟩ := (AlgHom.mem_range _).mp hz
  clear hz
  induction q using Polynomial.induction_on with
  | C a => exact ⟨a, 0, by simp⟩
  | add q r hq hr =>
    obtain ⟨c₁, d₁, h₁⟩ := hq
    obtain ⟨c₂, d₂, h₂⟩ := hr
    exact ⟨c₁ + c₂, d₁ + d₂, by rw [map_add, h₁, h₂]; push_cast; ring⟩
  | monomial n a ih =>
    obtain ⟨c, d, h⟩ := ih
    refine ⟨-d, c - d, ?_⟩
    rw [pow_succ, ← mul_assoc, map_mul, Polynomial.aeval_X, h]
    push_cast
    linear_combination d * hμ

variable {p : ℕ} [Fact p.Prime]

/-- Conjugating the cubic Jacobi sum gives the Jacobi sum of the inverse character. -/
theorem jacobi_inv_eq_star (χ : MulChar (ZMod p) ℂ) :
    jacobiSum χ⁻¹ χ⁻¹ = star (jacobiSum χ χ) := by
  unfold jacobiSum
  rw [star_sum]
  refine Finset.sum_congr rfl (fun x _ => ?_)
  rw [star_mul', MulChar.star_apply', MulChar.star_apply']

/-- The cubic Jacobi sum gives a representation `4 p = L ^ 2 + 27 M ^ 2` with `L % 3 = 1`
and `L = J(χ, χ) + J(χ⁻¹, χ⁻¹)`. -/
theorem jacobi_trace_rep (hp : p % 3 = 1) {χ : MulChar (ZMod p) ℂ} (hχ : orderOf χ = 3) :
    ∃ L M : ℤ, 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2 ∧ L % 3 = 1 ∧
      jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = (L : ℂ) := by
  obtain ⟨μ, hμ⟩ : ∃ μ : ℂ, IsPrimitiveRoot μ 3 :=
    ⟨_, Complex.isPrimitiveRoot_exp 3 (by norm_num)⟩
  have hrel : μ ^ 2 + μ + 1 = 0 := prim3_rel hμ
  have hst : star μ = μ ^ 2 := prim3_star hμ
  have h3 : χ ^ 3 = 1 := o3_pow_three hχ
  have hdvd : 3 ∣ Fintype.card (ZMod p) - 1 := three_dvd_card_sub_one hp
  -- Mathlib: `J = -1 + w (μ - 1) ^ 2` with `w ∈ ℤ[μ]`
  obtain ⟨w, hw, hJw⟩ := exists_jacobiSum_eq_neg_one_add (n := 3) (μ := μ) (χ := χ)
    (ψ := χ) (F := ZMod p) (R := ℂ) (by norm_num) h3 h3 hdvd hμ
  obtain ⟨c, d, rfl⟩ := adjoin_two_coords hrel hw
  -- `J = A + B μ` with `A = 3 d - 1`, `B = 3 d - 3 c`
  have hJ' : jacobiSum χ χ = ((3 * d - 1 : ℤ) : ℂ) + ((3 * d - 3 * c : ℤ) : ℂ) * μ := by
    rw [hJw]
    push_cast
    linear_combination (d * μ + (c - 3 * d)) * hrel
  have hJ2 : jacobiSum χ⁻¹ χ⁻¹ =
      ((3 * d - 1 - (3 * d - 3 * c) : ℤ) : ℂ) - ((3 * d - 3 * c : ℤ) : ℂ) * μ := by
    rw [jacobi_inv_eq_star, hJ', star_add, star_mul', hst]
    simp only [star_intCast]
    push_cast
    linear_combination (3 * (d : ℂ) - 3 * c) * hrel
  have hring : ringChar ℂ ≠ ringChar (ZMod p) := by
    intro h
    rw [ZMod.ringChar_zmod_n, ringChar.eq_zero (R := ℂ)] at h
    exact (Fact.out : p.Prime).ne_zero h.symm
  have hsq : χ * χ ≠ 1 := by
    rw [← sq]
    exact o3_sq_ne_one hχ
  have hnorm : jacobiSum χ χ * jacobiSum χ⁻¹ χ⁻¹ = (p : ℂ) := by
    rw [jacobiSum_mul_jacobiSum_inv hring (o3_ne_one hχ) (o3_ne_one hχ) hsq, ZMod.card]
  have hint :
      (3 * d - 1) ^ 2 - (3 * d - 1) * (3 * d - 3 * c) + (3 * d - 3 * c) ^ 2 = (p : ℤ) := by
    have h : (((3 * d - 1) ^ 2 - (3 * d - 1) * (3 * d - 3 * c) + (3 * d - 3 * c) ^ 2 : ℤ) : ℂ) =
        ((p : ℤ) : ℂ) := by
      rw [Int.cast_natCast, ← hnorm, hJ', hJ2]
      push_cast
      linear_combination (3 * (d : ℂ) - 3 * c) ^ 2 * hrel
    exact_mod_cast h
  refine ⟨3 * c + 3 * d - 2, d - c, ?_, ?_, ?_⟩
  · linear_combination (-4 : ℤ) * hint
  · omega
  · rw [hJ', hJ2]
    push_cast
    ring

/-- Every `L` with `4 p = L ^ 2 + 27 M ^ 2` and `L % 3 = 1` is `J(χ, χ) + J(χ⁻¹, χ⁻¹)`. -/
theorem jacobi_trace_eq (hp : p % 3 = 1) {χ : MulChar (ZMod p) ℂ} (hχ : orderOf χ = 3)
    (L M : ℤ) (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    jacobiSum χ χ + jacobiSum χ⁻¹ χ⁻¹ = (L : ℂ) := by
  obtain ⟨L', M', h', hL', htr⟩ := jacobi_trace_rep hp hχ
  rw [htr, rep_eq_of_rep Fact.out L' M' L M h' hLM hL' hL]

/-- Some `L, M` with `4 p = L ^ 2 + 27 M ^ 2` and `L % 3 = 1` exist. -/
theorem exists_rep (hp : p % 3 = 1) :
    ∃ L M : ℤ, L % 3 = 1 ∧ 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2 := by
  obtain ⟨χ, hχ⟩ := exists_order_three_char hp
  obtain ⟨L, M, h, hL, -⟩ := jacobi_trace_rep hp hχ
  exact ⟨L, M, hL, h⟩

end TuringTask
