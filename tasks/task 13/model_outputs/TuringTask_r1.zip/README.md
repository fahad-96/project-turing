# TuringTask Lean 4 Project

This project formalizes and proves five fundamental theorems regarding the resultants, discriminants, and coprimality of cyclotomic polynomials in Lean 4.

## Theorems in `TuringTask/Basic.lean`

1. `resultant_cyclotomic_eq_one`: If $1 \le n < m$ and $m$ is not of the form $n p^k$ with $p$ prime, then $\operatorname{Res}(\Phi_m, \Phi_n) = 1$.
2. `resultant_cyclotomic_mul_prime_pow`: If $n \ge 1, p$ is prime, $k \ge 1$, and $(n, p, k) \ne (1, 2, 1)$, then $\operatorname{Res}(\Phi_{n p^k}, \Phi_n) = p^{\varphi(n)}$.
3. `discr_cyclotomic`: If $n \ge 1$, then $\operatorname{disc}(\Phi_n) \cdot \prod_{p \mid n} p^{\varphi(n)/(p-1)} = (-1)^{\varphi(n)/2} n^{\varphi(n)}$.
4. `isCoprime_cyclotomic_iff`: If $1 \le n < m$, then $\Phi_m$ and $\Phi_n$ are coprime in $\mathbb{Z}[X]$ if and only if $m$ is not of the form $n p^k$ with $p$ prime.
5. `resultant_cyclotomic_X_pow_sub_one`: If $n \ge 3, m \ge 1$, and $n \nmid m$, then $\operatorname{Res}(\Phi_n, X^m - 1) = \Phi_k(1)^{\varphi(n)/\varphi(k)}$ where $k = n / \gcd(n, m)$.

## Environment and Offline Build Instructions

This project requires the pinned Lean toolchain `leanprover/lean4:v4.33.0-rc1` and the precompiled Mathlib provided in the local environment (located at `/opt/mathlib4`).

To build the project offline:

```bash
# If needed, initialize local package symlinks
lean-offline-init

# Build the project
lake build
```
