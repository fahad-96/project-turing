import TuringTask.LLL
import TuringTask.Hyper
import TuringTask.Apps
import TuringTask.Deg
import TuringTask.Sat
import TuringTask.Ramsey
import TuringTask.AP
import TuringTask.Basic
