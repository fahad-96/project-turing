import TuringTask.Basic

#print axioms TuringTask.card_squarefree_sub_le
#print axioms TuringTask.card_coprime_sub_le
#print axioms TuringTask.sum_totient_sub_le
#print axioms TuringTask.sum_totient_div_sub_le
#print axioms TuringTask.tendsto_card_squarefree_div
