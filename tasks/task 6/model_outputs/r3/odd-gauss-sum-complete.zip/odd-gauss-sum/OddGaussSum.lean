import OddGaussSum.Evaluation

open scoped BigOperators

namespace OddGaussSum

noncomputable section

private theorem finEquiv_eq_natCast (n : ℕ) [NeZero n] (i : Fin n) :
    ZMod.finEquiv n i = (i.val : ZMod n) := by
  have hv : (ZMod.finEquiv n i).val = i.val := by
    cases n with
    | zero => exact (NeZero.ne 0 rfl).elim
    | succ n => rfl
  symm
  rw [← hv, ZMod.natCast_zmod_val]

private theorem exp_sq_eq_char (n k : ℕ) [NeZero n] (hn : 1 < n) :
    Complex.exp
        (2 * Real.pi * Complex.I * ((((k : ℝ) ^ 2 / n) : ℝ) : ℂ)) =
      ZMod.stdAddChar ((k : ZMod n) ^ 2) := by
  letI : Fact (1 < n) := ⟨hn⟩
  have hnC : (n : ℂ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt (lt_trans Nat.zero_lt_one hn))
  have hbase : ZMod.stdAddChar (1 : ZMod n) =
      Complex.exp (2 * (Real.pi : ℂ) * Complex.I / n) := by
    rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply, ZMod.val_one]
    congr 1
    ring
  rw [show ((k : ZMod n) ^ 2) = k ^ 2 • (1 : ZMod n) by
    push_cast
    simp [nsmul_eq_mul]
    ]
  rw [AddChar.map_nsmul_eq_pow, hbase, ← Complex.exp_nat_mul]
  congr 1
  push_cast
  field_simp

private theorem range_sum_eq_zmod (n : ℕ) [NeZero n] (hn : 1 < n) :
    (∑ k ∈ Finset.range n,
      Complex.exp
        (2 * Real.pi * Complex.I * ((((k : ℝ) ^ 2 / n) : ℝ) : ℂ))) =
      quadraticSumZMod n := by
  rw [← Fin.sum_univ_eq_sum_range]
  calc
    (∑ k : Fin n, Complex.exp
        (2 * Real.pi * Complex.I * ((((k.val : ℝ) ^ 2 / n) : ℝ) : ℂ))) =
        ∑ k : Fin n, ZMod.stdAddChar ((ZMod.finEquiv n k) ^ 2) := by
      apply Finset.sum_congr rfl
      intro k _
      rw [finEquiv_eq_natCast]
      exact exp_sq_eq_char n k.val hn
    _ = quadraticSumZMod n := by
      simpa [quadraticSumZMod] using
        Equiv.sum_comp (ZMod.finEquiv n).toEquiv
          (fun x : ZMod n => ZMod.stdAddChar (x ^ 2))

private theorem quadraticSum_one_mod_four (q : ℕ) :
    quadraticSumZMod (4 * q + 1) =
      (Real.sqrt ((4 * q + 1 : ℕ) : ℝ) : ℂ) := by
  let r : ℂ := Real.sqrt ((4 * q + 1 : ℕ) : ℝ)
  have hs : r ≠ 0 := by
    dsimp only [r]
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.2 (by positivity :
      (0 : ℝ) < (4 * q + 1 : ℕ))))
  have h := normalized_trace_one_mod_four q
  rw [normalizedFourierMatrix, Matrix.trace_smul, trace_fourierMatrix] at h
  simp only [smul_eq_mul] at h
  change quadraticSumZMod (4 * q + 1) = r
  calc
    quadraticSumZMod (4 * q + 1) = r * (r⁻¹ * quadraticSumZMod (4 * q + 1)) := by
      field_simp
    _ = r := by rw [h, mul_one]

private theorem quadraticSum_three_mod_four (q : ℕ) :
    quadraticSumZMod (4 * q + 3) =
      Complex.I * (Real.sqrt ((4 * q + 3 : ℕ) : ℝ) : ℂ) := by
  let r : ℂ := Real.sqrt ((4 * q + 3 : ℕ) : ℝ)
  have hs : r ≠ 0 := by
    dsimp only [r]
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.2 (by positivity :
      (0 : ℝ) < (4 * q + 3 : ℕ))))
  have h := normalized_trace_three_mod_four q
  rw [normalizedFourierMatrix, Matrix.trace_smul, trace_fourierMatrix] at h
  simp only [smul_eq_mul] at h
  change quadraticSumZMod (4 * q + 3) = Complex.I * r
  calc
    quadraticSumZMod (4 * q + 3) = r * (r⁻¹ * quadraticSumZMod (4 * q + 3)) := by
      field_simp
    _ = r * Complex.I := by rw [h]
    _ = Complex.I * r := by ring

/-- The exact quadratic Gauss sum evaluation for every odd natural modulus. -/
theorem sum_sq (n : ℕ) (hodd : Odd n) :
    (∑ k ∈ Finset.range n,
      Complex.exp
        (2 * Real.pi * Complex.I * ((((k : ℝ) ^ 2 / n) : ℝ) : ℂ))) =
      if n % 4 = 1 then (Real.sqrt n : ℂ)
      else Complex.I * Real.sqrt n := by
  by_cases hn1 : n = 1
  · subst n
    norm_num
  have hn : 1 < n := by
    rcases hodd with ⟨k, hk⟩
    omega
  letI : NeZero n := ⟨by omega⟩
  rw [range_sum_eq_zmod n hn]
  by_cases hmod : n % 4 = 1
  · rw [if_pos hmod]
    obtain ⟨q, hq⟩ : ∃ q, n = 4 * q + 1 := by
      refine ⟨n / 4, ?_⟩
      have hd := Nat.mod_add_div n 4
      omega
    subst n
    exact quadraticSum_one_mod_four q
  · rw [if_neg hmod]
    have hmod3 : n % 4 = 3 := by
      rcases hodd with ⟨k, hk⟩
      omega
    obtain ⟨q, hq⟩ : ∃ q, n = 4 * q + 3 := by
      refine ⟨n / 4, ?_⟩
      have hd := Nat.mod_add_div n 4
      omega
    subst n
    exact quadraticSum_three_mod_four q

end

end OddGaussSum
