# Project Turing - Task 29 golden answer

Lean 4 project with complete proofs of five results on signs of arithmetic permutations: the
sign of `x -> a x` on `ZMod n` is `J(a | n)` for odd `n` (Zolotarev, Frobenius) and follows
Lerch's rule for even `n`, the sign of `u -> a u` on the unit group, the sign of a bijective
power map modulo a prime, and the sign of the transposition of an `m x n` array.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the local checkout at `/opt/mathlib4`, commit
  `9944fe2973b8dc0b86949101ed98232c07cd54a0` (required in `lakefile.toml` with
  `path = "/opt/mathlib4"`; `lake-manifest.json` lists it as a path package)

## Build and check (offline, no edits needed)

```
lake build
lake env lean StatementAndAxiomsCheck.lean
```

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

`StatementAndAxiomsCheck.lean` restates the five theorems of the task exactly (so it fails if a
statement was changed) and prints `#print axioms` for each of them; every list must be
`[propext, Classical.choice, Quot.sound]`.

## Files

- `TuringTask/Regular.lean`: the sign of left multiplication in a finite commutative group.
- `TuringTask/Units.lean`: the unit group of `ZMod n` and theorem 3.
- `TuringTask/Layers.lean`: invariant pieces of `x -> a x` on `ZMod n` and the Chinese
  remainder theorem.
- `TuringTask/Zolotarev.lean`: theorems 1 and 2.
- `TuringTask/Power.lean`: theorem 4.
- `TuringTask/Transpose.lean`: theorem 5, by counting inversions.
- `TuringTask/Main.lean`: the five statements under own names.
- `TuringTask/Basic.lean`: the file of the task; each theorem is one `exact` of `Main.lean`.
- `TuringTask.lean`: the root module, `import TuringTask.Basic`.
