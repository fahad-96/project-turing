import TuringTask.InternalBasic

namespace TuringTask.Internal

open scoped BigOperators

lemma sum_zmod_pow_eq_zero (p m : Nat) [Fact p.Prime]
    (hm : ¬p - 1 ∣ m) : (∑ x : ZMod p, x ^ m) = 0 := by
  obtain ⟨g, hg⟩ := IsCyclic.exists_ofOrder_eq_natCard (α := (ZMod p)ˣ)
  have horder : orderOf g = p - 1 := by
    rw [Nat.card_eq_fintype_card, ZMod.card_units] at hg
    exact hg
  have hgpow_units : g ^ m ≠ 1 := by
    intro h
    apply hm
    rw [← horder]
    exact orderOf_dvd_iff_pow_eq_one.mpr h
  have hgpow : ((g : ZMod p) ^ m) ≠ 1 := by
    intro h
    apply hgpow_units
    apply Units.ext
    simpa using h
  let e : ZMod p ≃ ZMod p := Equiv.mulLeft₀ (g : ZMod p) g.ne_zero
  have hreindex : (∑ x : ZMod p, x ^ m) = ∑ x : ZMod p, (e x) ^ m := by
    symm
    exact Fintype.sum_equiv e _ _ (fun _ => rfl)
  have hscaled : (∑ x : ZMod p, (e x) ^ m) =
      (g : ZMod p) ^ m * ∑ x : ZMod p, x ^ m := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x _
    simp only [e, Equiv.mulLeft₀_apply, mul_pow]
  have heq : (∑ x : ZMod p, x ^ m) =
      (g : ZMod p) ^ m * ∑ x : ZMod p, x ^ m := hreindex.trans hscaled
  have hzero : (1 - (g : ZMod p) ^ m) * (∑ x : ZMod p, x ^ m) = 0 := by
    linear_combination heq
  rcases mul_eq_zero.mp hzero with h | h
  · exact (hgpow (sub_eq_zero.mp h).symm).elim
  · exact h

lemma sum_zmod_pow_card_sub_one (p : Nat) [Fact p.Prime] :
    (∑ x : ZMod p, x ^ (p - 1)) = -1 := by
  simp_rw [ZMod.pow_card_sub_one]
  rw [show (∑ x : ZMod p, if x ≠ 0 then (1 : ZMod p) else 0) =
      ((Fintype.card (ZMod p) - 1 : Nat) : ZMod p) by
    calc
      _ = ((Finset.univ.filter (fun x : ZMod p => x ≠ 0)).card : ZMod p) :=
        Finset.sum_boole (fun x : ZMod p => x ≠ 0) Finset.univ
      _ = _ := by
        congr 1
        rw [show Finset.univ.filter (fun x : ZMod p => x ≠ 0) =
            Finset.univ.erase 0 by ext x; simp]
        rw [Finset.card_erase_of_mem (Finset.mem_univ 0), Finset.card_univ, ZMod.card]]
  rw [ZMod.card]
  have hp0 : 0 < p := (Fact.out : p.Prime).pos
  have hadd : ((p - 1 : Nat) : ZMod p) + 1 = 0 := by
    rw [Nat.cast_sub (by omega), ZMod.natCast_self]
    ring
  linear_combination hadd

lemma quadraticChar_cast_eq_pow (p : Nat) [Fact p.Prime] (hp : p % 4 = 1)
    (x : ZMod p) :
    ((quadraticChar (ZMod p) x : Int) : ZMod p) = x ^ (p / 2) := by
  have hp2 : p ≠ 2 := by omega
  have hpform : p - 1 = 2 * (p / 2) := by
    have hodd := (Fact.out : p.Prime).odd_of_ne_two hp2
    omega
  by_cases hx : x = 0
  · subst x
    have hpge := (Fact.out : p.Prime).two_le
    have hnpos : 0 < p / 2 := by omega
    rw [quadraticChar_zero, Int.cast_zero, zero_pow (Nat.ne_of_gt hnpos)]
  by_cases hs : IsSquare x
  · have he := (ZMod.euler_criterion p hx).mp hs
    rw [he]
    simp [quadraticChar, quadraticCharFun, hx, hs]
  · have hne : x ^ (p / 2) ≠ 1 := by
      intro h
      exact hs ((ZMod.euler_criterion p hx).mpr h)
    have hsq : (x ^ (p / 2)) ^ 2 = 1 := by
      rw [← pow_mul, mul_comm (p / 2) 2, ← hpform,
        ZMod.pow_card_sub_one, if_pos hx]
    rcases sq_eq_one_iff.mp hsq with h | h
    · exact (hne h).elim
    · rw [h]
      simp [quadraticChar, quadraticCharFun, hx, hs]

lemma csum_one_cast (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    ((csum p 1 : Int) : ZMod p) =
      ∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2) := by
  have hp2 : p ≠ 2 := by omega
  rw [csum_eq_curveSum p hp2]
  rw [CharacterProof.curveSum]
  push_cast
  apply Finset.sum_congr rfl
  intro x _
  rw [quadraticChar_cast_eq_pow p hp]
  norm_num

lemma curve_power_sum (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    (∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2)) =
      (-1 : ZMod p) ^ (p / 4 + 1) * (Nat.choose (p / 2) (p / 4) : ZMod p) := by
  let n := p / 2
  let k := p / 4
  have hp2 : p ≠ 2 := by omega
  have hpform : p = 2 * n + 1 := by
    have hodd := (Fact.out : p.Prime).odd_of_ne_two hp2
    dsimp [n]
    omega
  have hn : n = 2 * k := by
    dsimp [n, k]
    omega
  have hnpos : 0 < n := by
    have hpge := (Fact.out : p.Prime).two_le
    omega
  have hexpand (x : ZMod p) :
      (x ^ 3 - x) ^ n = ∑ j ∈ Finset.range (n + 1),
        (-1 : ZMod p) ^ (j + n) * (Nat.choose n j : ZMod p) * x ^ (n + 2 * j) := by
    rw [show x ^ 3 - x = x * (x ^ 2 - 1) by ring, mul_pow, sub_pow]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j hj
    rw [one_pow, mul_one, ← pow_mul x 2 j]
    calc
      _ = (-1 : ZMod p) ^ (j + n) * (Nat.choose n j : ZMod p) *
          (x ^ n * x ^ (2 * j)) := by ring
      _ = _ := by rw [← pow_add]
  rw [show (∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2)) =
      ∑ x : ZMod p, (x ^ 3 - x) ^ n by rfl]
  simp_rw [hexpand]
  rw [Finset.sum_comm]
  simp_rw [← Finset.mul_sum]
  calc
    (∑ j ∈ Finset.range (n + 1),
      (-1 : ZMod p) ^ (j + n) * (Nat.choose n j : ZMod p) *
        ∑ x : ZMod p, x ^ (n + 2 * j)) =
        (-1 : ZMod p) ^ (k + n) * (Nat.choose n k : ZMod p) *
          ∑ x : ZMod p, x ^ (n + 2 * k) := by
      apply Finset.sum_eq_single k
      · intro j hj hjk
        simp only [Finset.mem_range] at hj
        have hnotdvd : ¬p - 1 ∣ n + 2 * j := by
          intro hdvd
          have hpm1 : p - 1 = 2 * n := by omega
          rw [hpm1] at hdvd
          obtain ⟨q, hq⟩ := hdvd
          have hqpos : 0 < q := by
            by_contra h
            have hqzero : q = 0 := Nat.eq_zero_of_not_pos h
            rw [hqzero, mul_zero] at hq
            omega
          have hqle : q ≤ 1 := by
            by_contra h
            have hq2 : 2 ≤ q := by omega
            have hmul := Nat.mul_le_mul_left (2 * n) hq2
            omega
          have hqone : q = 1 := by omega
          rw [hqone, mul_one] at hq
          omega
        rw [sum_zmod_pow_eq_zero p (n + 2 * j) hnotdvd, mul_zero]
      · intro hk
        have : k < n + 1 := by omega
        exact (hk (Finset.mem_range.mpr this)).elim
    _ = (-1 : ZMod p) ^ (p / 4 + 1) *
        (Nat.choose (p / 2) (p / 4) : ZMod p) := by
      rw [show n + 2 * k = p - 1 by omega, sum_zmod_pow_card_sub_one]
      have hneven : Even n := ⟨k, by omega⟩
      rw [show (-1 : ZMod p) ^ (k + n) = (-1 : ZMod p) ^ k by
        rw [pow_add, hneven.neg_one_pow, mul_one]]
      rw [show (-1 : ZMod p) ^ (k + 1) = -((-1 : ZMod p) ^ k) by
        rw [pow_succ]
        ring]
      dsimp [n, k]
      ring

lemma csum_one_eq_signed (p : Nat) [Fact p.Prime] (hp : p % 4 = 1)
    (a b : Int) (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    csum p 1 = -2 * (-1 : Int) ^ (p / 4) * a := by
  have ha2 : a % 2 = 1 := by omega
  have hs := csum_sq_of_sq p hp a b 1 hab ha2 (by simp)
  have hs' : csum p 1 ^ 2 = (2 * a) ^ 2 := by nlinarith
  have hmod := csum_one_emod p hp
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases sq_eq_sq_iff_eq_or_eq_neg.mp hs' with hpos | hneg
  · rcases hp8 with hp8 | hp8
    · rw [if_neg (by omega)] at hmod
      exfalso
      omega
    · have hkodd : Odd (p / 4) := ⟨p / 8, by omega⟩
      rw [hkodd.neg_one_pow]
      nlinarith
  · rcases hp8 with hp8 | hp8
    · have hkeven : Even (p / 4) := ⟨p / 8, by omega⟩
      rw [hkeven.neg_one_pow]
      nlinarith
    · rw [if_pos hp8] at hmod
      exfalso
      omega

theorem choose_modEq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    Int.ModEq (p : Int) ((Nat.choose (p / 2) (p / 4) : Nat) : Int) (2 * a) := by
  rw [Int.modEq_iff_dvd]
  apply (ZMod.intCast_zmod_eq_zero_iff_dvd (2 * a - (Nat.choose (p / 2) (p / 4) : Int)) p).mp
  push_cast
  have hcast := csum_one_cast p hp
  rw [curve_power_sum p hp, csum_one_eq_signed p hp a b hab ha] at hcast
  let s : ZMod p := (-1 : ZMod p) ^ (p / 4 + 1)
  have hs : s ≠ 0 := pow_ne_zero _ (by norm_num)
  have heq : s * (Nat.choose (p / 2) (p / 4) : ZMod p) =
      s * ((2 : ZMod p) * a) := by
    dsimp [s]
    rw [← hcast]
    push_cast
    rw [pow_succ]
    ring
  have hchoose : (Nat.choose (p / 2) (p / 4) : ZMod p) = (2 : ZMod p) * a :=
    mul_left_cancel₀ hs heq
  rw [hchoose, sub_self]

lemma card_curve_eq_p_add_csum (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) =>
      q.2 ^ 2 = q.1 ^ 3 - q.1)).card : Int) = (p : Int) + csum p 1 := by
  have hp2 : p ≠ 2 := by omega
  have hpchar : ringChar (ZMod p) ≠ 2 := by
    rw [ZMod.ringChar_zmod_n]
    exact hp2
  rw [Finset.card_filter]
  push_cast
  rw [Fintype.sum_prod_type]
  have hfiber (x : ZMod p) :
      (∑ y : ZMod p, if y ^ 2 = x ^ 3 - x then (1 : Int) else 0) =
        quadraticChar (ZMod p) (x ^ 3 - x) + 1 := by
    rw [← quadraticChar_card_sqrts hpchar]
    simp
  simp_rw [hfiber]
  rw [Finset.sum_add_distrib]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mul_one, ZMod.card]
  have hc := csum_eq_curveSum p hp2 1
  rw [hc]
  rw [CharacterProof.curveSum]
  norm_num
  ring

theorem card_curve (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card : Int) =
      (p : Int) - 2 * (-1) ^ (p / 4) * a := by
  rw [card_curve_eq_p_add_csum p hp, csum_one_eq_signed p hp a b hab ha]
  ring

end TuringTask.Internal
