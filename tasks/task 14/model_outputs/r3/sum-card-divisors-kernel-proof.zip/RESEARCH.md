# Research notes for the first two theorems

## Status

`TuringTask/Basic.lean` was not edited. `TuringTask/Research.lean` contains the
kernel-checked reduction to finite sums below the hyperbola and the sharp
harmonic-number estimate. `TuringTask/First.lean` now supplies a compile-tested
proof of the exact first theorem statement, including the finite hyperbola
partition and explicit constant `4`. These proof modules contain no `sorry`,
`admit`, `native_decide`, or added axioms. The second quantitative theorem is
outside the scope of this artifact.

## Compile-tested declarations

The file proves:

```lean
biUnion_divisorsAntidiagonal
pairwiseDisjoint_divisorsAntidiagonal
sum_divisors_eq_sum_lattice
sum_lattice_eq_sum_div
card_divisors_eq_sum_antidiagonal
sum_card_divisors_eq_card_lattice
sum_card_divisors_eq_sum_div
sum_card_divisors_div_eq_sum_lattice
harmonic_real_eq_sum_Icc
sum_card_divisors_div_eq_harmonic_sum
harmonic_sub_log_bounds
harmonic_error_nonneg
harmonic_error_le_log_one_add_inv
abs_harmonic_error_le_inv
```

In mathematical notation, the central exact identities are

```text
sum_{n=1}^N d(n) = sum_{a=1}^N floor(N/a),

sum_{n=1}^N d(n)/n = sum_{a=1}^N H_{floor(N/a)}/a,

0 <= H_n - log n - gamma <= log(1 + 1/n) <= 1/n.
```

The finite-set proof does not use an informal rearrangement of a series. It
forms `latticePoints N`, proves that it is the pairwise-disjoint union of
`n.divisorsAntidiagonal` for `1 <= n <= N`, and then slices the same finite set
by its first coordinate.

## First target: implemented hyperbola estimate

Set `m = Nat.sqrt N`, `H = harmonic m`, `L = log m`, and
`gamma = Real.eulerMascheroniConstant`. Partition the lattice points into the
parts with first coordinate at most `m` and second coordinate at most `m`.
Since `m^2 <= N < (m+1)^2`, every point is in at least one part and their
intersection is the `m` by `m` square. This gives the exact identity

```text
D(N) = 2 * sum_{a=1}^m floor(N/a) - m^2.
```

Write

```text
sum_{a=1}^m floor(N/a) = N * H + rho,
-m < rho <= 0,
delta = H - L - gamma,
0 <= delta <= 1/m.
```

Then the target error is exactly

```text
2*rho + 2*N*delta
  + N*(1 - log (N/m^2)) - m^2.
```

The final geometric term is nonpositive. Its absolute value is at most `2`
from `N <= m^2 + 2*m` and

```text
r * log r - r + 1 <= (r - 1)^2 / 2       (1 <= r <= 3).
```

The formal proof retains the quadratic geometric loss and combines it with the
floor loss. Their sum is at most `2*N/m`, and `N/m <= 2*sqrt N`; this proves the
bound uniformly without separate small cases.

## Second target: remaining hyperbola estimate

The symmetric hyperbola partition gives

```text
A(N) = 2 * sum_{a=1}^m H_{floor(N/a)}/a - H_m^2.
```

For `a <= m`, put `k = floor(N/a)`. The two Euler--Mascheroni approximants
proved in `harmonic_sub_log_bounds`, together with `k <= N/a < k+1`, give

```text
abs (H_k - log(N/a) - gamma) <= 1/k <= 1/m.
```

Thus replacing every inner harmonic number by `log(N/a)+gamma` costs at most
`2*H_m/m <= 2`.

For

```text
S_m = sum_{a=1}^m log(a)/a,
u = log N - 2*log m,
delta = H_m - log m - gamma,
```

direct ring normalization leaves

```text
(log(m)^2 - 2*S_m + gamma^2)
  + 2*(log(m)+u)*delta - delta^2 - u^2/2.
```

The required uniform bound follows from a one-interval integral comparison for
`log x / x`, the already proved `0 <= delta <= 1/m`, and
`0 <= u <= log(1+2/m)`. Small values of `m` can be discharged separately.
This is the only genuinely new analytic estimate still needed for the second
constant `4`.

## Offline commands used

```sh
lean TuringTask/Research.lean
lake build TuringTask.First
```

No network command is needed. Declaration discovery was performed by compiling
temporary Lean commands that iterate over the already loaded local environment.
