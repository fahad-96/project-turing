import Mathlib

namespace TuringTask

open Polynomial Finset

/-!
## Section 1: Powers of 2 and elementary divisibility lemmas
-/

lemma eq_pow_two_of_prime_factors_two : ∀ (N : ℕ), 0 < N →
    (∀ p, p.Prime → p ∣ N → p = 2) → ∃ t, N = 2 ^ t := by
  intro N
  induction N using Nat.strong_induction_on with | _ N ih =>
  intro hN h_all
  rcases eq_or_ne N 1 with rfl | hN1
  · exact ⟨0, rfl⟩
  · have : 2 ≤ N := by lia
    obtain ⟨p, hp, hpdvd⟩ := Nat.exists_prime_and_dvd hN1
    have hp2 : p = 2 := h_all p hp hpdvd
    subst hp2
    obtain ⟨k, rfl⟩ := hpdvd
    have hk_pos : 0 < k := by
      rcases k with _ | k
      · simp at hN
      · lia
    have hk_lt : k < 2 * k := by lia
    have hk_all : ∀ q, q.Prime → q ∣ k → q = 2 := by
      intro q hq hqdvd
      exact h_all q hq (dvd_trans hqdvd (dvd_mul_left k 2))
    obtain ⟨t, ht⟩ := ih k hk_lt hk_pos hk_all
    exact ⟨t + 1, by rw [pow_succ, ht, mul_comm]⟩

lemma exists_eq_mul_pow_not_dvd (n P : ℕ) (hn : 0 < n) (hP : P.Prime) :
    ∃ k m : ℕ, ¬ P ∣ m ∧ n = m * P ^ k := by
  induction n using Nat.strong_induction_on with | _ n ih =>
  by_cases hdiv : P ∣ n
  · obtain ⟨c, rfl⟩ := hdiv
    have hc_pos : 0 < c := by
      rcases c with _ | c
      · simp at hn
      · lia
    have hc_lt : c < P * c := by
      have : 2 ≤ P := hP.two_le
      nlinarith
    obtain ⟨k, m, hPm, hc_eq⟩ := ih c hc_lt hc_pos
    refine ⟨k + 1, m, hPm, ?_⟩
    rw [pow_succ, ← mul_assoc, mul_comm P, ← hc_eq, mul_comm]
  · exact ⟨0, n, hdiv, by simp⟩

lemma eq_pow_prime_of_prime_factors (P : ℕ) (hP : P.Prime) :
    ∀ (N : ℕ), 0 < N → (∀ p, p.Prime → p ∣ N → p = P) → ∃ e, N = P ^ e := by
  intro N
  induction N using Nat.strong_induction_on with | _ N ih =>
  intro hN h_all
  rcases eq_or_ne N 1 with rfl | hN1
  · exact ⟨0, rfl⟩
  · obtain ⟨p, hp, hpdvd⟩ := Nat.exists_prime_and_dvd hN1
    have hpP : P = p := (h_all p hp hpdvd).symm
    rcases hpP with rfl
    obtain ⟨c, rfl⟩ := hpdvd
    have hc_pos : 0 < c := by
      rcases c with _ | c
      · simp at hN
      · lia
    have hc_lt : c < P * c := by
      have : 2 ≤ P := hP.two_le
      nlinarith
    have hc_all : ∀ q, q.Prime → q ∣ c → q = P := fun q hq hqdvd =>
      h_all q hq (dvd_trans hqdvd (dvd_mul_left c P))
    obtain ⟨e, he⟩ := ih c hc_lt hc_pos hc_all
    exact ⟨e + 1, by rw [pow_succ, he, mul_comm]⟩

lemma succ_lt_two_pow (k : ℕ) (hk : 2 ≤ k) : k + 1 < 2 ^ k := by
  induction k, hk using Nat.le_induction with
  | base => decide
  | succ n hn ih =>
    have : 2 ^ (n + 1) = 2 ^ n * 2 := pow_succ 2 n
    rw [this]
    lia

lemma lt_two_pow_pred (P : ℕ) (hP : 3 ≤ P) : P < 2 ^ (P - 1) := by
  have h2 : 2 ≤ P - 1 := by lia
  have h := succ_lt_two_pow (P - 1) h2
  have : P - 1 + 1 = P := Nat.sub_add_cancel (by lia)
  rwa [this] at h

lemma sum_ge_two_pow_pred (A B : ℕ) (P : ℕ) (hA : 2 ≤ A) (hB : 1 ≤ B) (hP : 3 ≤ P) :
    P < ∑ j ∈ Finset.range P, A ^ j * B ^ (P - 1 - j) := by
  have h0_mem : 0 ∈ Finset.range P := Finset.mem_range.mpr (by lia)
  have hP1_mem : P - 1 ∈ Finset.range P := Finset.mem_range.mpr (by lia)
  have h_ne : 0 ≠ P - 1 := by lia
  have h_pair : ({0, P - 1} : Finset ℕ) ⊆ Finset.range P := by
    rw [Finset.insert_subset_iff, Finset.singleton_subset_iff]
    exact ⟨h0_mem, hP1_mem⟩
  have h_sum := Finset.sum_le_sum_of_subset (f := fun j => A ^ j * B ^ (P - 1 - j)) h_pair
  have h_two : ∑ j ∈ ({0, P - 1} : Finset ℕ), A ^ j * B ^ (P - 1 - j) = B ^ (P - 1) + A ^ (P - 1) := by
    rw [Finset.sum_insert (by simpa using h_ne), Finset.sum_singleton]
    have h1 : P - 1 - 0 = P - 1 := rfl
    have h2 : P - 1 - (P - 1) = 0 := by lia
    rw [pow_zero, one_mul, h1, h2, pow_zero, mul_one]
  rw [h_two] at h_sum
  have h_gt : P < B ^ (P - 1) + A ^ (P - 1) := by
    have h1 : 1 ≤ B ^ (P - 1) := one_le_pow₀ hB
    have h2 : P < 2 ^ (P - 1) := lt_two_pow_pred P hP
    have h3 : 2 ^ (P - 1) ≤ A ^ (P - 1) := Nat.pow_le_pow_left hA (P - 1)
    lia
  exact lt_of_lt_of_le h_gt h_sum

lemma eq_one_of_dvd_two_pow_of_odd {d n : ℕ} (hd : d ∣ 2 ^ n) (hodd : Odd d) : d = 1 := by
  obtain ⟨k, -, rfl⟩ := (Nat.dvd_prime_pow Nat.prime_two).mp hd
  rcases k with _ | k
  · simp
  · exfalso
    have : 2 ∣ 2 ^ (k + 1) := dvd_pow_self 2 (by lia)
    have heven : Even (2 ^ (k + 1)) := even_iff_two_dvd.mpr this
    exact Nat.not_even_iff_odd.mpr hodd heven

lemma sq_mod_four_ne_three (x : ℕ) : x ^ 2 % 4 ≠ 3 := by
  intro h
  have h1 : (x % 4) ^ 2 % 4 = 3 := by
    rw [← Nat.pow_mod, h]
  have h2 : x % 4 < 4 := Nat.mod_lt _ (by decide)
  interval_cases x % 4 <;> revert h1 <;> decide

lemma two_pow_sub_one_mod_four {n : ℕ} (hn : 2 ≤ n) : (2 ^ n - 1) % 4 = 3 := by
  obtain ⟨k, rfl⟩ : ∃ k, n = k + 2 := ⟨n - 2, by lia⟩
  rw [pow_add]
  have : 2 ^ 2 = 4 := by decide
  rw [this]
  have : 2 ^ k * 4 - 1 = 4 * (2 ^ k - 1) + 3 := by
    have : 1 ≤ 2 ^ k := Nat.one_le_two_pow
    lia
  rw [this]
  omega

lemma sq_add_sq_ne_two_pow (A B e : ℕ) (hA : 2 ≤ A) (hB : 1 ≤ B) (hAB : A.Coprime B) :
    A ^ 2 + B ^ 2 ≠ 2 ^ e := by
  intro h
  have hA2 : 4 ≤ A ^ 2 := by nlinarith
  have hodd_even : ¬ (Even A ∧ Even B) := by
    intro ⟨h1, h2⟩
    have : 2 ∣ A.gcd B := Nat.dvd_gcd (even_iff_two_dvd.mp h1) (even_iff_two_dvd.mp h2)
    rw [hAB] at this
    revert this; decide
  by_cases hA_even : Even A
  · have hB_odd : Odd B := by
      rcases Nat.even_or_odd B with hB_ev | hB_od
      · exact False.elim (hodd_even ⟨hA_even, hB_ev⟩)
      · exact hB_od
    have h_odd : Odd (A ^ 2 + B ^ 2) := by
      have : Even (A ^ 2) := Even.pow_of_ne_zero hA_even (by decide)
      have : Odd (B ^ 2) := Odd.pow hB_odd
      exact Even.add_odd ‹Even (A ^ 2)› ‹Odd (B ^ 2)›
    have he0 : e = 0 := by
      by_contra!
      have : Even (2 ^ e) := even_iff_two_dvd.mpr (dvd_pow_self 2 (by lia))
      rw [← h] at this
      exact Nat.not_even_iff_odd.mpr h_odd this
    subst he0
    rw [pow_zero] at h
    lia
  · by_cases hB_even : Even B
    · have hA_odd : Odd A := by
        rcases Nat.even_or_odd A with hA_ev | hA_od
        · exact False.elim (hA_even hA_ev)
        · exact hA_od
      have h_odd : Odd (A ^ 2 + B ^ 2) := by
        have : Odd (A ^ 2) := Odd.pow hA_odd
        have : Even (B ^ 2) := Even.pow_of_ne_zero hB_even (by decide)
        exact Odd.add_even ‹Odd (A ^ 2)› ‹Even (B ^ 2)›
      have he0 : e = 0 := by
        by_contra!
        have : Even (2 ^ e) := even_iff_two_dvd.mpr (dvd_pow_self 2 (by lia))
        rw [← h] at this
        exact Nat.not_even_iff_odd.mpr h_odd this
      subst he0
      rw [pow_zero] at h
      lia
    · have hA_odd : Odd A := (Nat.even_or_odd A).resolve_left hA_even
      have hB_odd : Odd B := (Nat.even_or_odd B).resolve_left hB_even
      have hA_sq : A ^ 2 % 4 = 1 := by
        obtain ⟨k, rfl⟩ := hA_odd
        have : (2 * k + 1) ^ 2 = 4 * (k * (k + 1)) + 1 := by ring
        rw [this]
        omega
      have hB_sq : B ^ 2 % 4 = 1 := by
        obtain ⟨k, rfl⟩ := hB_odd
        have : (2 * k + 1) ^ 2 = 4 * (k * (k + 1)) + 1 := by ring
        rw [this]
        omega
      have he1 : e = 1 := by
        rcases e with _ | _ | e
        · rw [pow_zero] at h; lia
        · rfl
        · exfalso
          have h4 : 4 ∣ 2 ^ (e + 2) := by
            rw [pow_add]
            have : (2 : ℕ) ^ 2 = 4 := by decide
            rw [this]
            exact dvd_mul_left 4 (2 ^ e)
          have : (2 ^ (e + 2)) % 4 = 0 := Nat.mod_eq_zero_of_dvd h4
          rw [← h] at this
          omega
      subst he1
      rw [pow_one] at h
      lia

lemma not_exists_pow_two_eq_three : ¬ ∃ t : ℕ, 3 = 2 ^ t := by
  rintro ⟨t, ht⟩
  rcases t with _ | _ | t
  · revert ht; decide
  · revert ht; decide
  · have : 4 ≤ 2 ^ (t + 2) := by
      have : 2 ^ 2 ≤ 2 ^ (t + 2) := Nat.pow_le_pow_right (by decide) (by lia)
      exact this
    lia

theorem exists_prime_sub_two (a b : ℕ) (hba : b < a) (hb : 1 ≤ b) (hab : Nat.Coprime a b)
    (h2 : ¬ ∃ t : ℕ, a + b = 2 ^ t) :
    ∃ q : ℕ, q.Prime ∧ (a ^ 2 - b ^ 2) % q = 0 ∧
      ∀ k : ℕ, 1 ≤ k → k < 2 → ¬ ((a ^ k - b ^ k) % q = 0) := by
  have hab_ge3 : 3 ≤ a + b := by lia
  have hex_odd : ∃ q : ℕ, q.Prime ∧ q ∣ a + b ∧ q ≠ 2 := by
    by_contra! h
    have h_pow := eq_pow_two_of_prime_factors_two (a + b) (by lia) h
    exact h2 h_pow
  obtain ⟨q, hq, hqdvd, hq2⟩ := hex_odd
  refine ⟨q, hq, ?_, fun k hk1 hk2 => ?_⟩
  · have : a ^ 2 - b ^ 2 = (a - b) * (a + b) := by
      have := Nat.sq_sub_sq a b
      rw [this, mul_comm]
    rw [this]
    exact Nat.dvd_iff_mod_eq_zero.mp (dvd_mul_of_dvd_right hqdvd _)
  · have hk1_eq : k = 1 := by lia
    subst hk1_eq
    simp only [pow_one]
    intro hq_sub
    rw [← Nat.dvd_iff_mod_eq_zero] at hq_sub
    have hq_2a : q ∣ 2 * a := by
      have : 2 * a = (a + b) + (a - b) := by lia
      rw [this]
      exact dvd_add hqdvd hq_sub
    have hq_2b : q ∣ 2 * b := by
      have : 2 * b = (a + b) - (a - b) := by lia
      rw [this]
      exact Nat.dvd_sub hqdvd hq_sub
    have hnot2 : ¬ q ∣ 2 := fun h => hq2 (by
      rcases (Nat.dvd_prime Nat.prime_two).mp h with rfl | rfl
      · exact (hq.ne_one rfl).elim
      · rfl)
    have hqa : q ∣ a := (Nat.Prime.dvd_mul hq).mp hq_2a |>.resolve_left hnot2
    have hqb : q ∣ b := (Nat.Prime.dvd_mul hq).mp hq_2b |>.resolve_left hnot2
    have h_gcd : q ∣ a.gcd b := Nat.dvd_gcd hqa hqb
    rw [hab] at h_gcd
    exact Nat.Prime.not_dvd_one hq h_gcd

/-!
## Section 2: Cyclotomic polynomial evaluation and primitive divisors
-/

lemma mul_div_pow_cancel (a b : ℚ) (hb : b ≠ 0) (d i : ℕ) (hid : i ≤ d) :
    b ^ d * (a / b) ^ i = a ^ i * b ^ (d - i) := by
  have : b ^ d = b ^ (d - i) * b ^ i := by rw [← pow_add, Nat.sub_add_cancel hid]
  rw [this, div_pow]
  have hb_pow : b ^ i ≠ 0 := pow_ne_zero i hb
  field_simp

lemma mul_div_pow_cancel_real (a b : ℝ) (hb : b ≠ 0) (d i : ℕ) (hid : i ≤ d) :
    b ^ d * (a / b) ^ i = a ^ i * b ^ (d - i) := by
  have : b ^ d = b ^ (d - i) * b ^ i := by rw [← pow_add, Nat.sub_add_cancel hid]
  rw [this, div_pow]
  have hb_pow : b ^ i ≠ 0 := pow_ne_zero i hb
  field_simp

noncomputable def cycloVal (n : ℕ) (a b : ℤ) : ℤ :=
  ∑ i ∈ Finset.range ((cyclotomic n ℤ).natDegree + 1),
    (cyclotomic n ℤ).coeff i * a ^ i * b ^ ((cyclotomic n ℤ).natDegree - i)

theorem cycloVal_coe_rat (n : ℕ) (a b : ℤ) (hb : b ≠ 0) :
    (cycloVal n a b : ℚ) = (b : ℚ) ^ n.totient * (cyclotomic n ℚ).eval ((a : ℚ) / (b : ℚ)) := by
  set d := (cyclotomic n ℤ).natDegree
  have hd : d = n.totient := natDegree_cyclotomic n ℤ
  have hmap : cyclotomic n ℚ = map (Int.castRingHom ℚ) (cyclotomic n ℤ) := (map_cyclotomic_int n ℚ).symm
  have hdQ : (cyclotomic n ℚ).natDegree = d := by
    rw [natDegree_cyclotomic n ℚ, hd]
  have heval : (cyclotomic n ℚ).eval ((a : ℚ) / (b : ℚ)) =
      ∑ i ∈ range (d + 1), (cyclotomic n ℚ).coeff i * ((a : ℚ) / (b : ℚ)) ^ i := by
    rw [eval_eq_sum_range, hdQ]
  rw [heval, mul_sum]
  unfold cycloVal
  push_cast
  change (∑ i ∈ range (d + 1), _) = _
  refine (sum_congr rfl fun i hi => ?_).symm
  rw [mem_range] at hi
  have hid : i ≤ d := Nat.le_of_lt_succ hi
  have hcoeff : (cyclotomic n ℚ).coeff i = ((cyclotomic n ℤ).coeff i : ℚ) := by
    rw [hmap, coeff_map]
    rfl
  rw [hcoeff]
  have hcan := mul_div_pow_cancel (a : ℚ) (b : ℚ) (by exact_mod_cast hb) d i hid
  calc (b : ℚ) ^ n.totient * (((cyclotomic n ℤ).coeff i : ℚ) * ((a : ℚ) / (b : ℚ)) ^ i)
    _ = ((cyclotomic n ℤ).coeff i : ℚ) * ((b : ℚ) ^ d * ((a : ℚ) / (b : ℚ)) ^ i) := by
        rw [hd]
        ring
    _ = ((cyclotomic n ℤ).coeff i : ℚ) * ((a : ℚ) ^ i * (b : ℚ) ^ (d - i)) := by rw [hcan]
    _ = ((cyclotomic n ℤ).coeff i : ℚ) * (a : ℚ) ^ i * (b : ℚ) ^ (d - i) := by ring

theorem cycloVal_coe_real (n : ℕ) (a b : ℤ) (hb : b ≠ 0) :
    (cycloVal n a b : ℝ) = (b : ℝ) ^ n.totient * (cyclotomic n ℝ).eval ((a : ℝ) / (b : ℝ)) := by
  set d := (cyclotomic n ℤ).natDegree
  have hd : d = n.totient := natDegree_cyclotomic n ℤ
  have hmap : cyclotomic n ℝ = map (Int.castRingHom ℝ) (cyclotomic n ℤ) := (map_cyclotomic_int n ℝ).symm
  have hdQ : (cyclotomic n ℝ).natDegree = d := by
    rw [natDegree_cyclotomic n ℝ, hd]
  have heval : (cyclotomic n ℝ).eval ((a : ℝ) / (b : ℝ)) =
      ∑ i ∈ range (d + 1), (cyclotomic n ℝ).coeff i * ((a : ℝ) / (b : ℝ)) ^ i := by
    rw [eval_eq_sum_range, hdQ]
  rw [heval, mul_sum]
  unfold cycloVal
  push_cast
  change (∑ i ∈ range (d + 1), _) = _
  refine (sum_congr rfl fun i hi => ?_).symm
  rw [mem_range] at hi
  have hid : i ≤ d := Nat.le_of_lt_succ hi
  have hcoeff : (cyclotomic n ℝ).coeff i = ((cyclotomic n ℤ).coeff i : ℝ) := by
    rw [hmap, coeff_map]
    rfl
  rw [hcoeff]
  have hcan := mul_div_pow_cancel_real (a : ℝ) (b : ℝ) (by exact_mod_cast hb) d i hid
  calc (b : ℝ) ^ n.totient * (((cyclotomic n ℤ).coeff i : ℝ) * ((a : ℝ) / (b : ℝ)) ^ i)
    _ = ((cyclotomic n ℤ).coeff i : ℝ) * ((b : ℝ) ^ d * ((a : ℝ) / (b : ℝ)) ^ i) := by
        rw [hd]
        ring
    _ = ((cyclotomic n ℤ).coeff i : ℝ) * ((a : ℝ) ^ i * (b : ℝ) ^ (d - i)) := by rw [hcan]
    _ = ((cyclotomic n ℤ).coeff i : ℝ) * (a : ℝ) ^ i * (b : ℝ) ^ (d - i) := by ring

theorem cycloVal_gt_one (n a b : ℕ) (hn : 2 ≤ n) (hb : 1 ≤ b) (hba : b < a) :
    1 < cycloVal n a b := by
  have hb_pos : (0 : ℝ) < (b : ℝ) := by positivity
  have hq_gt : 1 < (a : ℝ) / (b : ℝ) := by
    rw [one_lt_div hb_pos]
    exact_mod_cast hba
  have h_eval := sub_one_pow_totient_lt_cyclotomic_eval hn hq_gt
  have h_bound : ((a : ℝ) - (b : ℝ)) ^ n.totient < (cycloVal n a b : ℝ) := by
    have hcoe := cycloVal_coe_real n a b (by lia)
    rw [hcoe]
    have h_sub_eq : (a : ℝ) - (b : ℝ) = (b : ℝ) * ((a : ℝ) / (b : ℝ) - 1) := by
      field_simp
    rw [h_sub_eq, mul_pow]
    have hb_pow_pos : 0 < (b : ℝ) ^ n.totient := by positivity
    exact mul_lt_mul_of_pos_left h_eval hb_pow_pos
  have h_diff_ge1 : 1 ≤ ((a : ℝ) - (b : ℝ)) ^ n.totient := by
    have h1 : 1 ≤ (a : ℝ) - (b : ℝ) := by
      have : (b : ℝ) + 1 ≤ (a : ℝ) := by exact_mod_cast (show b + 1 ≤ a by lia)
      linarith
    exact one_le_pow₀ h1
  have h_real_gt : 1 < (cycloVal n a b : ℝ) := lt_of_le_of_lt h_diff_ge1 h_bound
  exact_mod_cast h_real_gt

theorem prod_cycloVal_eq_sub_pow (n : ℕ) (a b : ℤ) (hn : 0 < n) (hb : b ≠ 0) :
    ∏ d ∈ n.divisors, cycloVal d a b = a ^ n - b ^ n := by
  have hQ : (∏ d ∈ n.divisors, (cycloVal d a b : ℚ)) = (a : ℚ) ^ n - (b : ℚ) ^ n := by
    have h1 : (∏ d ∈ n.divisors, (cycloVal d a b : ℚ)) =
        ∏ d ∈ n.divisors, ((b : ℚ) ^ d.totient * (cyclotomic d ℚ).eval ((a : ℚ) / (b : ℚ))) := by
      refine prod_congr rfl fun d _ => cycloVal_coe_rat d a b hb
    rw [h1, prod_mul_distrib, prod_pow_eq_pow_sum, Nat.sum_totient n]
    have h2 : (∏ d ∈ n.divisors, (cyclotomic d ℚ).eval ((a : ℚ) / (b : ℚ))) =
        ((a : ℚ) / (b : ℚ)) ^ n - 1 := by
      rw [← eval_prod, prod_cyclotomic_eq_X_pow_sub_one hn ℚ]
      simp
    rw [h2]
    have hbQ : (b : ℚ) ≠ 0 := by exact_mod_cast hb
    have : (b : ℚ) ^ n ≠ 0 := pow_ne_zero n hbQ
    rw [div_pow]
    field_simp
  exact_mod_cast hQ

theorem cycloVal_dvd_sub_pow (n : ℕ) (a b : ℤ) (hn : 0 < n) (hb : b ≠ 0) :
    cycloVal n a b ∣ a ^ n - b ^ n := by
  rw [← prod_cycloVal_eq_sub_pow n a b hn hb]
  exact dvd_prod_of_mem _ (Nat.mem_divisors_self n hn.ne')

theorem cycloVal_mod_eq (n : ℕ) (a b : ℤ) {q : ℕ} [Fact q.Prime] (hb : (b : ZMod q) ≠ 0) :
    (cycloVal n a b : ZMod q) =
      (b : ZMod q) ^ n.totient * (cyclotomic n (ZMod q)).eval ((a : ZMod q) * (b : ZMod q)⁻¹) := by
  set d := (cyclotomic n ℤ).natDegree
  have hd : d = n.totient := natDegree_cyclotomic n ℤ
  have hmap : cyclotomic n (ZMod q) = map (Int.castRingHom (ZMod q)) (cyclotomic n ℤ) :=
    (map_cyclotomic_int n (ZMod q)).symm
  have hdZ : (cyclotomic n (ZMod q)).natDegree ≤ d := by
    rw [hmap]
    exact natDegree_map_le
  have heval : (cyclotomic n (ZMod q)).eval ((a : ZMod q) * (b : ZMod q)⁻¹) =
      ∑ i ∈ range (d + 1), (cyclotomic n (ZMod q)).coeff i * ((a : ZMod q) * (b : ZMod q)⁻¹) ^ i := by
    rw [eval_eq_sum_range]
    refine sum_subset (range_mono (Nat.succ_le_succ hdZ)) fun x hx1 hx2 => ?_
    rw [coeff_eq_zero_of_natDegree_lt]
    · simp
    rw [mem_range] at hx1 hx2
    lia
  rw [heval, mul_sum]
  unfold cycloVal
  push_cast
  change _ = (∑ i ∈ range (d + 1), _)
  refine sum_congr rfl fun i hi => ?_
  rw [mem_range] at hi
  have hid : i ≤ d := Nat.le_of_lt_succ hi
  have hcoeff : (cyclotomic n (ZMod q)).coeff i = ((cyclotomic n ℤ).coeff i : ZMod q) := by
    rw [hmap, coeff_map]
    rfl
  rw [hcoeff]
  have hb_inv : (b : ZMod q) * (b : ZMod q)⁻¹ = 1 := mul_inv_cancel₀ hb
  have hcan : (b : ZMod q) ^ d * ((a : ZMod q) * (b : ZMod q)⁻¹) ^ i =
      (a : ZMod q) ^ i * (b : ZMod q) ^ (d - i) := by
    have : (b : ZMod q) ^ d = (b : ZMod q) ^ (d - i) * (b : ZMod q) ^ i := by
      rw [← pow_add, Nat.sub_add_cancel hid]
    rw [this, mul_pow]
    calc (b : ZMod q) ^ (d - i) * (b : ZMod q) ^ i * ((a : ZMod q) ^ i * ((b : ZMod q)⁻¹) ^ i)
      _ = (b : ZMod q) ^ (d - i) * (a : ZMod q) ^ i * (((b : ZMod q) ^ i) * ((b : ZMod q)⁻¹) ^ i) := by ring
      _ = (b : ZMod q) ^ (d - i) * (a : ZMod q) ^ i * (((b : ZMod q) * (b : ZMod q)⁻¹) ^ i) := by rw [← mul_pow]
      _ = (b : ZMod q) ^ (d - i) * (a : ZMod q) ^ i * (1 ^ i) := by rw [hb_inv]
      _ = (a : ZMod q) ^ i * (b : ZMod q) ^ (d - i) := by ring
  calc ((cyclotomic n ℤ).coeff i : ZMod q) * (a : ZMod q) ^ i * (b : ZMod q) ^ (d - i)
    _ = ((cyclotomic n ℤ).coeff i : ZMod q) * ((a : ZMod q) ^ i * (b : ZMod q) ^ (d - i)) := by ring
    _ = ((cyclotomic n ℤ).coeff i : ZMod q) * ((b : ZMod q) ^ d * ((a : ZMod q) * (b : ZMod q)⁻¹) ^ i) := by rw [← hcan]
    _ = (b : ZMod q) ^ n.totient * (((cyclotomic n ℤ).coeff i : ZMod q) * ((a : ZMod q) * (b : ZMod q)⁻¹) ^ i) := by
        rw [hd]
        ring

theorem q_dvd_n_of_root {q : ℕ} [Fact q.Prime] {d n : ℕ} (hd : d ∈ n.properDivisors)
    (u : (ZMod q)ˣ)
    (hu1 : eval (u : ZMod q) (X ^ d - 1 : (ZMod q)[X]) = 0)
    (hu2 : eval (u : ZMod q) (cyclotomic n (ZMod q)) = 0) :
    q ∣ n := by
  have h1 : eval (u : ZMod q) (derivative (X ^ n - 1 : (ZMod q)[X])) = 0 := by
    obtain ⟨Q, hQ⟩ := X_pow_sub_one_mul_cyclotomic_dvd_X_pow_sub_one_of_dvd (ZMod q) hd
    rw [hQ, derivative_mul, derivative_mul]
    simp [eval_add, eval_mul, hu1, hu2]
  have h2 : eval (u : ZMod q) (derivative (X ^ n - 1 : (ZMod q)[X])) = (n : ZMod q) * (u : ZMod q) ^ (n - 1) := by
    rw [derivative_sub, derivative_one, sub_zero, derivative_X_pow]
    simp [eval_mul, eval_natCast, eval_pow, eval_X]
  rw [h2] at h1
  have hu_pow : IsUnit ((u : ZMod q) ^ (n - 1)) := (u.isUnit).pow (n - 1)
  have hn_zero : (n : ZMod q) = 0 := by
    rcases hu_pow with ⟨w, hw⟩
    have := congr_arg (· * (w⁻¹ : (ZMod q)ˣ).1) h1
    simp only [zero_mul] at this
    rw [← hw, mul_assoc, Units.mul_inv, mul_one] at this
    exact this
  rwa [CharP.cast_eq_zero_iff (ZMod q) q] at hn_zero

lemma test_not_dvd_b (a b n q : ℕ) (hba : b < a) (hab : a.Coprime b)
    (hq : q.Prime) (hn : 2 ≤ n) (hqdvd : q ∣ a ^ n - b ^ n) : (b : ZMod q) ≠ 0 := by
  intro h
  have hqb : q ∣ b := by rwa [CharP.cast_eq_zero_iff (ZMod q) q] at h
  have hbn : q ∣ b ^ n := dvd_pow hqb (by lia)
  have han : q ∣ a ^ n := by
    have : a ^ n = (a ^ n - b ^ n) + b ^ n := (Nat.sub_add_cancel (Nat.pow_le_pow_left hba.le n)).symm
    rw [this]
    exact dvd_add hqdvd hbn
  have hqa : q ∣ a := hq.dvd_of_dvd_pow han
  have : q ∣ Nat.gcd a b := Nat.dvd_gcd hqa hqb
  rw [hab] at this
  exact Nat.Prime.not_dvd_one hq this

lemma test_mod (a b n q : ℕ) (hba : b ≤ a) :
    (a ^ n - b ^ n) % q = 0 ↔ (a : ZMod q) ^ n = (b : ZMod q) ^ n := by
  have : (a ^ n - b ^ n) % q = 0 ↔ (q : ℕ) ∣ (a ^ n - b ^ n) := Nat.dvd_iff_mod_eq_zero.symm
  rw [this]
  rw [← CharP.cast_eq_zero_iff (ZMod q) q]
  have : b ^ n ≤ a ^ n := Nat.pow_le_pow_left hba n
  rw [Nat.cast_sub this]
  simp [sub_eq_zero]

lemma test_div (a b n q : ℕ) [Fact q.Prime] (hqb : (b : ZMod q) ≠ 0) :
    (a : ZMod q) ^ n = (b : ZMod q) ^ n ↔ ((a : ZMod q) * (b : ZMod q)⁻¹) ^ n = 1 := by
  rw [mul_pow, inv_pow, mul_inv_eq_one₀ (pow_ne_zero n hqb)]

lemma test_unit_mul {R : Type*} [CommRing R] (w : Rˣ) (x : R) (h : (w : R) * x = 0) : x = 0 := by
  have : (w⁻¹ : Rˣ) * w * x = 0 := by rw [mul_assoc, h, mul_zero]
  simpa using this

lemma test_pow_zero {R : Type*} [CommRing R] [IsDomain R] (x : R) (n : ℕ) (hn : 0 < n) (h : x ^ n = 0) : x = 0 := by
  rwa [pow_eq_zero_iff hn.ne'] at h

theorem primitive_of_dvd_cycloVal (a b n q : ℕ) (hba : b < a) (hb : 1 ≤ b) (hab : a.Coprime b)
    (hn : 2 ≤ n) (hq : q.Prime) (hq_dvd : (q : ℤ) ∣ cycloVal n a b) (hqn : ¬ q ∣ n) :
    (a ^ n - b ^ n) % q = 0 ∧ ∀ k, 1 ≤ k → k < n → ¬ ((a ^ k - b ^ k) % q = 0) := by
  haveI : Fact q.Prime := ⟨hq⟩
  have hb_ne : (b : ℤ) ≠ 0 := by positivity
  have h1 : cycloVal n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n :=
    cycloVal_dvd_sub_pow n a b (by lia) hb_ne
  have hqdvd_int : (q : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := dvd_trans hq_dvd h1
  have hsub_nat : (a : ℤ) ^ n - (b : ℤ) ^ n = ((a ^ n - b ^ n : ℕ) : ℤ) := by
    exact (Nat.cast_sub (Nat.pow_le_pow_left hba.le n)).symm
  rw [hsub_nat] at hqdvd_int
  rw [Int.natCast_dvd_natCast] at hqdvd_int
  have hmod_n : (a ^ n - b ^ n) % q = 0 := Nat.dvd_iff_mod_eq_zero.mp hqdvd_int
  refine ⟨hmod_n, fun k hk1 hkn => ?_⟩
  intro hmod_k
  have hq_b : (b : ZMod q) ≠ 0 := test_not_dvd_b a b n q hba hab hq hn hqdvd_int
  have hu_un : IsUnit ((b : ZMod q)⁻¹) := isUnit_iff_ne_zero.mpr (inv_ne_zero hq_b)
  have hu_a : (a : ZMod q) ≠ 0 := by
    intro ha
    have hqa : q ∣ a := by rwa [CharP.cast_eq_zero_iff (ZMod q) q] at ha
    rw [test_mod a b n q hba.le] at hmod_n
    rw [ha, zero_pow (by lia)] at hmod_n
    have hb0 : (b : ZMod q) = 0 := test_pow_zero (b : ZMod q) n (by lia) hmod_n.symm
    exact hq_b hb0
  let u : (ZMod q)ˣ := Units.mk0 ((a : ZMod q) * (b : ZMod q)⁻¹) (mul_ne_zero hu_a (inv_ne_zero hq_b))
  have hu_val : (u : ZMod q) = (a : ZMod q) * (b : ZMod q)⁻¹ := rfl
  have hu_pow_n : (u : ZMod q) ^ n = 1 := by
    rw [hu_val, ← test_div a b n q hq_b]
    rw [← test_mod a b n q hba.le]
    exact hmod_n
  have hu_pow_k : (u : ZMod q) ^ k = 1 := by
    rw [hu_val, ← test_div a b k q hq_b]
    rw [← test_mod a b k q (by lia)]
    exact hmod_k
  have hu_pow_gcd : (u : ZMod q) ^ (k.gcd n) = 1 := by
    rw [pow_gcd_eq_one]
    exact ⟨hu_pow_k, hu_pow_n⟩
  let d := k.gcd n
  have hd_dvd : d ∣ n := Nat.gcd_dvd_right k n
  have hd_le : d ≤ k := Nat.le_of_dvd (by lia) (Nat.gcd_dvd_left k n)
  have hd_lt : d < n := lt_of_le_of_lt hd_le hkn
  have hd_prop : d ∈ n.properDivisors := by
    rw [Nat.mem_properDivisors]
    exact ⟨hd_dvd, hd_lt⟩
  have hu1 : eval (u : ZMod q) (X ^ d - 1 : (ZMod q)[X]) = 0 := by
    rw [eval_sub, eval_pow, eval_X, eval_one]
    exact sub_eq_zero.mpr hu_pow_gcd
  have hu2 : eval (u : ZMod q) (cyclotomic n (ZMod q)) = 0 := by
    have hcyc_mod : (cycloVal n a b : ZMod q) = 0 := by
      obtain ⟨c, hc⟩ := hq_dvd
      rw [hc]
      push_cast
      simp
    have hq_b_int : ((b : ℤ) : ZMod q) ≠ 0 := by
      simpa using hq_b
    have hmod_eq := cycloVal_mod_eq n a b hq_b_int
    rw [hcyc_mod] at hmod_eq
    have hb_pow_unit : IsUnit (((b : ℤ) : ZMod q) ^ n.totient) :=
      (isUnit_iff_ne_zero.mpr hq_b_int).pow _
    rcases hb_pow_unit with ⟨w, hw⟩
    have : ((w : (ZMod q)ˣ) : ZMod q) * eval (u : ZMod q) (cyclotomic n (ZMod q)) = 0 := by
      rw [hw]
      have hu_eq : (u : ZMod q) = ((a : ℤ) : ZMod q) * (((b : ℤ) : ZMod q))⁻¹ := by
        push_cast
        rfl
      rw [hu_eq]
      exact hmod_eq.symm
    exact test_unit_mul w _ this
  exact hqn (q_dvd_n_of_root hd_prop u hu1 hu2)

/-!
## Section 3: Divisibility of cyclotomic evaluations and order
-/

theorem eval_cyclotomic_prime_pow_mul (m p : ℕ) [hp : Fact p.Prime] (hpm : ¬ p ∣ m) :
    ∀ k, 1 ≤ k → ∀ (u : ZMod p), eval u (cyclotomic (m * p ^ k) (ZMod p)) = 0 →
      eval u (cyclotomic m (ZMod p)) = 0
  | 1, _, u, hu => by
    rw [pow_one] at hu
    have hcyc := cyclotomic_mul_prime_eq_pow_of_not_dvd (ZMod p) hpm
    rw [hcyc, eval_pow] at hu
    have hp1 : p - 1 ≠ 0 := by
      have : 2 ≤ p := hp.out.two_le
      lia
    exact (pow_eq_zero_iff hp1).mp hu
  | k + 2, _, u, hu => by
    have h_split : m * p ^ (k + 2) = (m * p ^ (k + 1)) * p := by
      rw [pow_succ, ← mul_assoc]
    have hdvd : p ∣ m * p ^ (k + 1) :=
      dvd_mul_of_dvd_right (dvd_pow_self p (by lia)) m
    rw [h_split] at hu
    have hcyc := cyclotomic_mul_prime_dvd_eq_pow (ZMod p) hdvd
    rw [hcyc, eval_pow] at hu
    have hp_pos : p ≠ 0 := hp.out.ne_zero
    have hu' : eval u (cyclotomic (m * p ^ (k + 1)) (ZMod p)) = 0 :=
      (pow_eq_zero_iff hp_pos).mp hu
    exact eval_cyclotomic_prime_pow_mul m p hpm (k + 1) (by lia) u hu'

theorem m_dvd_p_sub_one (m p : ℕ) [hp : Fact p.Prime] (hpm : ¬ p ∣ m)
    (u : (ZMod p)ˣ) (hu : eval (u : ZMod p) (cyclotomic m (ZMod p)) = 0) :
    m ∣ p - 1 := by
  haveI : NeZero (m : ZMod p) := ⟨by
    intro h
    rw [CharP.cast_eq_zero_iff (ZMod p) p] at h
    exact hpm h⟩
  have hprim : IsPrimitiveRoot (u : ZMod p) m := isRoot_cyclotomic_iff.mp hu
  have horder : orderOf u = m := by
    rw [← orderOf_injective (Units.coeHom (ZMod p)) Units.val_injective]
    exact hprim.eq_orderOf.symm
  have hcard : Fintype.card (ZMod p)ˣ = p - 1 := by
    rw [ZMod.card_units_eq_totient, Nat.totient_prime hp.out]
  have hdvd := orderOf_dvd_card (x := u)
  rw [hcard, horder] at hdvd
  exact hdvd

lemma cyclotomic_two_pow (k : ℕ) (hk : 1 ≤ k) (R : Type*) [CommRing R] :
    cyclotomic (2 ^ k) R = X ^ (2 ^ (k - 1)) + 1 := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by lia⟩
  have h := cyclotomic_prime_pow_eq_geom_sum (R := R) Nat.prime_two (n := j)
  rw [h]
  have : (j + 1) - 1 = j := rfl
  rw [this]
  have hrange : Finset.range 2 = {0, 1} := by decide
  rw [hrange, sum_insert (by decide), sum_singleton, pow_zero, pow_one, add_comm]

lemma cycloVal_two_pow (k : ℕ) (hk : 1 ≤ k) (a b : ℕ) (hb : 1 ≤ b) :
    cycloVal (2 ^ k) a b = a ^ (2 ^ (k - 1)) + b ^ (2 ^ (k - 1)) := by
  have hb_ne : (b : ℤ) ≠ 0 := by positivity
  have hQ := cycloVal_coe_rat (2 ^ k) a b hb_ne
  have htot : (2 ^ k).totient = 2 ^ (k - 1) := by
    obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by lia⟩
    rw [Nat.totient_prime_pow Nat.prime_two (by lia)]
    have : (j + 1) - 1 = j := rfl
    rw [this]
    ring
  have hcyc := cyclotomic_two_pow k hk ℚ
  rw [htot, hcyc] at hQ
  simp only [eval_add, eval_pow, eval_X, eval_one] at hQ
  have hbQ : (b : ℚ) ≠ 0 := by exact_mod_cast hb_ne
  have h_alg : (b : ℚ) ^ (2 ^ (k - 1)) * (((a : ℚ) / (b : ℚ)) ^ (2 ^ (k - 1)) + 1) =
      (a : ℚ) ^ (2 ^ (k - 1)) + (b : ℚ) ^ (2 ^ (k - 1)) := by
    rw [mul_add, div_pow, mul_one]
    have : (b : ℚ) ^ (2 ^ (k - 1)) ≠ 0 := pow_ne_zero _ hbQ
    field_simp
  have hQ2 : ((cycloVal (2 ^ k) a b : ℤ) : ℚ) = ((a ^ (2 ^ (k - 1)) + b ^ (2 ^ (k - 1)) : ℕ) : ℚ) := by
    push_cast
    rw [hQ]
    push_cast
    exact h_alg
  exact_mod_cast hQ2

lemma geom_sum_mul_sub (A B : ℤ) (P : ℕ) :
    (∑ j ∈ Finset.range P, A ^ j * B ^ (P - 1 - j)) * (A - B) = A ^ P - B ^ P :=
  geom_sum₂_mul A B P

lemma cycloVal_dvd_geom (n a b P : ℕ) (hn : 0 < n) (hb : 1 ≤ b) (hba : b < a)
    (hP : P.Prime) (hPn : P ∣ n) :
    cycloVal n a b ∣ ∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j) := by
  have hb_ne : (b : ℤ) ≠ 0 := by positivity
  have hnP_dvd : n / P ∣ n := Nat.div_dvd_of_dvd hPn
  have hP_ge2 : 2 ≤ P := hP.two_le
  have hnP_lt : n / P < n := Nat.div_lt_self hn hP_ge2
  have hnP_pos : 0 < n / P := Nat.div_pos (Nat.le_of_dvd hn hPn) hP.pos
  have h_sub : (n / P).divisors ⊆ n.divisors := Nat.divisors_subset_of_dvd hn.ne' hnP_dvd
  have h_sdiff := Finset.prod_sdiff h_sub (f := fun d => cycloVal d a b)
  rw [prod_cycloVal_eq_sub_pow n a b hn hb_ne] at h_sdiff
  rw [prod_cycloVal_eq_sub_pow (n / P) a b hnP_pos hb_ne] at h_sdiff
  have hn_mem : n ∈ n.divisors \ (n / P).divisors := by
    rw [Finset.mem_sdiff, Nat.mem_divisors, Nat.mem_divisors]
    refine ⟨⟨dvd_rfl, hn.ne'⟩, ?_⟩
    rintro ⟨hdvd, -⟩
    have := Nat.le_of_dvd hnP_pos hdvd
    lia
  have hdvd_prod : cycloVal n a b ∣ ∏ d ∈ n.divisors \ (n / P).divisors, cycloVal d a b :=
    Finset.dvd_prod_of_mem _ hn_mem
  set S := ∏ d ∈ n.divisors \ (n / P).divisors, cycloVal d a b
  set G := ∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j)
  have h_G : G * ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) = (a : ℤ) ^ n - (b : ℤ) ^ n := by
    have h1 := geom_sum_mul_sub (a ^ (n / P) : ℤ) (b ^ (n / P) : ℤ) P
    have h_pow_a : ((a ^ (n / P) : ℤ) ^ P) = (a : ℤ) ^ n := by
      rw [← pow_mul, Nat.div_mul_cancel hPn]
    have h_pow_b : ((b ^ (n / P) : ℤ) ^ P) = (b : ℤ) ^ n := by
      rw [← pow_mul, Nat.div_mul_cancel hPn]
    rw [h_pow_a, h_pow_b] at h1
    exact h1
  have h_diff_ne : (a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ) ≠ 0 := by
    have : (b ^ (n / P) : ℤ) < (a ^ (n / P) : ℤ) := by
      have : b ^ (n / P) < a ^ (n / P) := Nat.pow_lt_pow_left hba hnP_pos.ne'
      exact_mod_cast this
    lia
  have h_eq : S = G := by
    have h_mul : ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) * S =
        ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) * G := by
      rw [mul_comm _ S, h_sdiff, ← h_G, mul_comm G]
    exact mul_left_cancel₀ h_diff_ne h_mul
  rw [← h_eq]
  exact hdvd_prod

lemma geom_sum_eq_sdiff_prod (n a b P : ℕ) (hn : 0 < n) (hb : 1 ≤ b) (hba : b < a)
    (hP : P.Prime) (hPn : P ∣ n) :
    (∏ d ∈ n.divisors \ (n / P).divisors, cycloVal d a b) =
    ∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j) := by
  have hb_ne : (b : ℤ) ≠ 0 := by positivity
  have hnP_dvd : n / P ∣ n := Nat.div_dvd_of_dvd hPn
  have hP_ge2 : 2 ≤ P := hP.two_le
  have hnP_lt : n / P < n := Nat.div_lt_self hn hP_ge2
  have hnP_pos : 0 < n / P := Nat.div_pos (Nat.le_of_dvd hn hPn) hP.pos
  have h_sub : (n / P).divisors ⊆ n.divisors := Nat.divisors_subset_of_dvd hn.ne' hnP_dvd
  have h_sdiff := Finset.prod_sdiff h_sub (f := fun d => cycloVal d a b)
  rw [prod_cycloVal_eq_sub_pow n a b hn hb_ne] at h_sdiff
  rw [prod_cycloVal_eq_sub_pow (n / P) a b hnP_pos hb_ne] at h_sdiff
  set S := ∏ d ∈ n.divisors \ (n / P).divisors, cycloVal d a b
  set G := ∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j)
  have h_G : G * ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) = (a : ℤ) ^ n - (b : ℤ) ^ n := by
    have h1 := geom_sum_mul_sub (a ^ (n / P) : ℤ) (b ^ (n / P) : ℤ) P
    have h_pow_a : ((a ^ (n / P) : ℤ) ^ P) = (a : ℤ) ^ n := by
      rw [← pow_mul, Nat.div_mul_cancel hPn]
    have h_pow_b : ((b ^ (n / P) : ℤ) ^ P) = (b : ℤ) ^ n := by
      rw [← pow_mul, Nat.div_mul_cancel hPn]
    rw [h_pow_a, h_pow_b] at h1
    exact h1
  have h_diff_ne : (a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ) ≠ 0 := by
    have : (b ^ (n / P) : ℤ) < (a ^ (n / P) : ℤ) := by
      have : b ^ (n / P) < a ^ (n / P) := Nat.pow_lt_pow_left hba hnP_pos.ne'
      exact_mod_cast this
    lia
  have h_mul : ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) * S =
      ((a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ)) * G := by
    rw [mul_comm _ S, h_sdiff, ← h_G, mul_comm G]
  exact mul_left_cancel₀ h_diff_ne h_mul

lemma geom_sum_two_mul (X Y : ℤ) (P : ℕ) :
    (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)) * (X - Y) * (X + Y) =
    (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * (X - Y) * (X ^ P + Y ^ P) := by
  have h1 : (X - Y) * (X + Y) = X ^ 2 - Y ^ 2 := by ring
  have h_left : (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)) * (X ^ 2 - Y ^ 2) =
      (X ^ 2) ^ P - (Y ^ 2) ^ P := geom_sum₂_mul (X ^ 2) (Y ^ 2) P
  have h_right : (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * (X - Y) = X ^ P - Y ^ P :=
    geom_sum₂_mul X Y P
  have h_diff_sq : (X ^ P - Y ^ P) * (X ^ P + Y ^ P) = (X ^ P) ^ 2 - (Y ^ P) ^ 2 := by ring
  have h_pow1 : (X ^ 2) ^ P = (X ^ P) ^ 2 := by rw [← pow_mul, mul_comm 2 P, pow_mul]
  have h_pow2 : (Y ^ 2) ^ P = (Y ^ P) ^ 2 := by rw [← pow_mul, mul_comm 2 P, pow_mul]
  rw [mul_assoc (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)), h1, h_left]
  rw [h_pow1, h_pow2, ← h_diff_sq, ← h_right, mul_assoc]

lemma m_two_eq (X Y : ℤ) (P : ℕ)
    (h_two : (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)) * (X + Y) =
      (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * (X ^ P + Y ^ P))
    (h_eq : (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)) =
      (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * P)
    (h_ne0 : (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) ≠ 0) :
    X ^ P + Y ^ P = (X + Y) * P := by
  have : (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * (X ^ P + Y ^ P) =
      (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * ((X + Y) * P) := by
    calc (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * (X ^ P + Y ^ P)
      _ = (∑ j ∈ Finset.range P, (X ^ 2) ^ j * (Y ^ 2) ^ (P - 1 - j)) * (X + Y) := h_two.symm
      _ = (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * P * (X + Y) := by rw [h_eq]
      _ = (∑ j ∈ Finset.range P, X ^ j * Y ^ (P - 1 - j)) * ((X + Y) * P) := by ring
  exact mul_left_cancel₀ h_ne0 this

lemma geom_three_fac (X Y : ℤ) :
    (X ^ 2 + X * Y + Y ^ 2) * (X ^ 2 - X * Y + Y ^ 2) = (X ^ 2) ^ 2 + (X ^ 2) * (Y ^ 2) + (Y ^ 2) ^ 2 := by
  ring

lemma m_two_P_three_sol (X Y : ℤ) (h_mul : (X ^ 2 + X * Y + Y ^ 2) * (X ^ 2 - X * Y + Y ^ 2) =
    (X ^ 2 + X * Y + Y ^ 2) * 3)
    (h_pos : 0 < X ^ 2 + X * Y + Y ^ 2) :
    X ^ 2 - X * Y + Y ^ 2 = 3 :=
  mul_left_cancel₀ (ne_of_gt h_pos) h_mul

lemma geom_cubes_sol (x y : ℕ) (hxy : y < x) (hy : 1 ≤ y)
    (h : (x : ℤ) ^ 2 - (x : ℤ) * (y : ℤ) + (y : ℤ) ^ 2 = 3) :
    x = 2 ∧ y = 1 := by
  have h_ring : ((x : ℤ) - (y : ℤ)) ^ 2 + (x : ℤ) * (y : ℤ) = (x : ℤ) ^ 2 - (x : ℤ) * (y : ℤ) + (y : ℤ) ^ 2 := by ring
  rw [← h_ring] at h
  have hx2 : 2 ≤ x := by lia
  have h_xy_ge : 2 ≤ (x : ℤ) * (y : ℤ) := by
    have : (2 : ℤ) ≤ x := by exact_mod_cast hx2
    have : (1 : ℤ) ≤ y := by exact_mod_cast hy
    nlinarith
  have h_sub_ge : 1 ≤ (x : ℤ) - (y : ℤ) := by
    have : (y : ℤ) + 1 ≤ (x : ℤ) := by exact_mod_cast hxy
    lia
  have h_sub_sq : 1 ≤ ((x : ℤ) - (y : ℤ)) ^ 2 := by nlinarith
  have h_xy_eq : (x : ℤ) * (y : ℤ) = 2 := by lia
  have h_sub_sq_eq : ((x : ℤ) - (y : ℤ)) ^ 2 = 1 := by
    have : ((x : ℤ) - (y : ℤ)) ^ 2 = 3 - (x : ℤ) * (y : ℤ) := by lia
    rw [h_xy_eq] at this
    exact this
  have h_sub_eq : (x : ℤ) - (y : ℤ) = 1 := by
    nlinarith
  have h_x_eq : (x : ℤ) = (y : ℤ) + 1 := by lia
  rw [h_x_eq] at h_xy_eq
  have hy_sq : (y : ℤ) ^ 2 + (y : ℤ) = 2 := by
    calc (y : ℤ) ^ 2 + (y : ℤ) = ((y : ℤ) + 1) * (y : ℤ) := by ring
      _ = 2 := h_xy_eq
  have hy1 : y = 1 := by
    rcases y with _ | _ | y
    · lia
    · rfl
    · have : (2 : ℤ) ≤ y + 2 := by lia
      have : 6 ≤ (y + 2 : ℤ) ^ 2 + (y + 2 : ℤ) := by nlinarith
      lia
  subst hy1
  have : (x : ℤ) = 2 := by lia
  have : x = 2 := by exact_mod_cast this
  exact ⟨this, rfl⟩

lemma pow_add_mul_mod_sq (B c : ℤ) (p : ℕ) (j : ℕ) :
    (B + c * (p : ℤ)) ^ j ≡ B ^ j + (j : ℤ) * c * (p : ℤ) * B ^ (j - 1) [ZMOD (p : ℤ) ^ 2] := by
  induction j with
  | zero => simp
  | succ j ih =>
    rcases j with _ | j
    · simp
    · have h_step : (B + c * (p : ℤ)) ^ (j + 2) = (B + c * (p : ℤ)) * (B + c * (p : ℤ)) ^ (j + 1) := by ring
      rw [h_step]
      have ih_use := Int.ModEq.mul (Int.ModEq.refl (B + c * (p : ℤ))) ih
      have h_ring : (B + c * (p : ℤ)) * (B ^ (j + 1) + ((j + 1 : ℕ) : ℤ) * c * (p : ℤ) * B ^ ((j + 1) - 1)) =
          B ^ (j + 2) + ((j + 2 : ℕ) : ℤ) * c * (p : ℤ) * B ^ (j + 1) +
          (p : ℤ) ^ 2 * (((j + 1 : ℕ) : ℤ) * c ^ 2 * B ^ j) := by
        have : (j + 1) - 1 = j := rfl
        rw [this, pow_succ B (j+1), pow_succ B j]
        push_cast
        ring
      rw [h_ring] at ih_use
      have h_zero : (p : ℤ) ^ 2 * (((j + 1 : ℕ) : ℤ) * c ^ 2 * B ^ j) ≡ 0 [ZMOD (p : ℤ) ^ 2] := by
        exact Int.modEq_zero_iff_dvd.mpr (dvd_mul_right _ _)
      have h_add := Int.ModEq.add_left (B ^ (j + 2) + ((j + 2 : ℕ) : ℤ) * c * (p : ℤ) * B ^ (j + 1)) h_zero
      rw [add_zero] at h_add
      have h_sub : (j + 2) - 1 = j + 1 := rfl
      rw [h_sub]
      exact ih_use.trans h_add

lemma sum_range_id_mul_sq (p : ℕ) (hp : Odd p) (c B : ℤ) :
    (∑ j ∈ Finset.range p, (j : ℤ) * c * (p : ℤ) * B ^ (j - 1) * B ^ (p - 1 - j)) ≡ 0 [ZMOD (p : ℤ) ^ 2] := by
  have h_term : ∀ j ∈ Finset.range p, (j : ℤ) * c * (p : ℤ) * B ^ (j - 1) * B ^ (p - 1 - j) =
      (j : ℤ) * (c * (p : ℤ) * B ^ (p - 2)) := by
    intro j hj
    rw [Finset.mem_range] at hj
    rcases j with _ | j
    · simp
    · have : (j + 1) - 1 = j := rfl
      rw [this]
      have : j + (p - 1 - (j + 1)) = p - 2 := by lia
      calc ((j + 1 : ℕ) : ℤ) * c * (p : ℤ) * B ^ j * B ^ (p - 1 - (j + 1))
        _ = ((j + 1 : ℕ) : ℤ) * c * (p : ℤ) * (B ^ j * B ^ (p - 1 - (j + 1))) := by ring
        _ = ((j + 1 : ℕ) : ℤ) * c * (p : ℤ) * B ^ (p - 2) := by rw [← pow_add, this]
        _ = ((j + 1 : ℕ) : ℤ) * (c * (p : ℤ) * B ^ (p - 2)) := by ring
  have h_sum_congr : (∑ j ∈ Finset.range p, (j : ℤ) * c * (p : ℤ) * B ^ (j - 1) * B ^ (p - 1 - j)) =
      (∑ j ∈ Finset.range p, (j : ℤ)) * (c * (p : ℤ) * B ^ (p - 2)) := by
    rw [Finset.sum_mul]
    exact Finset.sum_congr rfl h_term
  rw [h_sum_congr]
  obtain ⟨k, rfl⟩ := hp
  have hp_eq : 2 * k + 1 - 1 = 2 * k := rfl
  have h1 : (∑ j ∈ Finset.range (2 * k + 1), j) = (2 * k + 1) * (2 * k + 1 - 1) / 2 :=
    Finset.sum_range_id (2 * k + 1)
  rw [hp_eq] at h1
  have h2 : (2 * k + 1) * (2 * k) / 2 = (2 * k + 1) * k := by
    have : (2 * k + 1) * (2 * k) = 2 * ((2 * k + 1) * k) := by ring
    rw [this, Nat.mul_div_cancel_left _ (by decide)]
  rw [h2] at h1
  have h_sum_id : (∑ j ∈ Finset.range (2 * k + 1), (j : ℤ)) = (((2 * k + 1) * k : ℕ) : ℤ) := by
    have : (∑ j ∈ Finset.range (2 * k + 1), (j : ℤ)) = ((∑ j ∈ Finset.range (2 * k + 1), j : ℕ) : ℤ) := by
      push_cast; rfl
    rw [this, h1]
  rw [h_sum_id]
  have h_ring : (((2 * k + 1) * k : ℕ) : ℤ) * (c * ((2 * k + 1 : ℕ) : ℤ) * B ^ (2 * k + 1 - 2)) =
      ((2 * k + 1 : ℕ) : ℤ) ^ 2 * ((k : ℤ) * c * B ^ (2 * k + 1 - 2)) := by
    push_cast
    ring
  rw [h_ring]
  exact Int.modEq_zero_iff_dvd.mpr (dvd_mul_right _ _)

lemma geom_sum_mod_sq (B c : ℤ) (p : ℕ) (hp : Odd p) :
    (∑ j ∈ Finset.range p, (B + c * (p : ℤ)) ^ j * B ^ (p - 1 - j)) ≡ (p : ℤ) * B ^ (p - 1) [ZMOD (p : ℤ) ^ 2] := by
  have h_term : ∀ j ∈ Finset.range p,
      (B + c * (p : ℤ)) ^ j * B ^ (p - 1 - j) ≡
      (B ^ j + (j : ℤ) * c * (p : ℤ) * B ^ (j - 1)) * B ^ (p - 1 - j) [ZMOD (p : ℤ) ^ 2] := by
    intro j _
    exact Int.ModEq.mul_right (B ^ (p - 1 - j)) (pow_add_mul_mod_sq B c p j)
  have h_sum := Int.ModEq.sum (s := Finset.range p) h_term
  have h_split : (∑ j ∈ Finset.range p, (B ^ j + (j : ℤ) * c * (p : ℤ) * B ^ (j - 1)) * B ^ (p - 1 - j)) =
      (∑ j ∈ Finset.range p, B ^ j * B ^ (p - 1 - j)) +
      (∑ j ∈ Finset.range p, (j : ℤ) * c * (p : ℤ) * B ^ (j - 1) * B ^ (p - 1 - j)) := by
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl fun j _ => by ring
  rw [h_split] at h_sum
  have h_const : ∀ j ∈ Finset.range p, B ^ j * B ^ (p - 1 - j) = B ^ (p - 1) := by
    intro j hj
    rw [Finset.mem_range] at hj
    rw [← pow_add]
    congr 1
    lia
  have h_first : (∑ j ∈ Finset.range p, B ^ j * B ^ (p - 1 - j)) = (p : ℤ) * B ^ (p - 1) := by
    rw [Finset.sum_congr rfl h_const]
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
  rw [h_first] at h_sum
  have h_second := sum_range_id_mul_sq p hp c B
  have h_res := Int.ModEq.add (Int.ModEq.refl ((p : ℤ) * B ^ (p - 1))) h_second
  rw [add_zero] at h_res
  exact h_sum.trans h_res

lemma not_dvd_p_sq_geom_sum (B c : ℤ) (p : ℕ) [hp : Fact p.Prime] (_hp_odd : Odd p)
    (hB : ¬ (p : ℤ) ∣ B)
    (h_mod : (∑ j ∈ Finset.range p, (B + c * (p : ℤ)) ^ j * B ^ (p - 1 - j)) ≡ (p : ℤ) * B ^ (p - 1) [ZMOD (p : ℤ) ^ 2]) :
    ¬ (p : ℤ) ^ 2 ∣ (∑ j ∈ Finset.range p, (B + c * (p : ℤ)) ^ j * B ^ (p - 1 - j)) := by
  intro hdvd
  have hdvd_pB : (p : ℤ) ^ 2 ∣ (p : ℤ) * B ^ (p - 1) := by
    have hzero : (∑ j ∈ Finset.range p, (B + c * (p : ℤ)) ^ j * B ^ (p - 1 - j)) ≡ 0 [ZMOD (p : ℤ) ^ 2] :=
      Int.modEq_zero_iff_dvd.mpr hdvd
    have h_symm := h_mod.symm.trans hzero
    exact Int.modEq_zero_iff_dvd.mp h_symm
  have hp_pos : (p : ℤ) ≠ 0 := by exact_mod_cast hp.out.ne_zero
  have h_pB : (p : ℤ) ∣ B ^ (p - 1) := by
    rcases hdvd_pB with ⟨k, hk⟩
    have : (p : ℤ) ^ 2 = (p : ℤ) * (p : ℤ) := by ring
    rw [this] at hk
    have : (p : ℤ) * B ^ (p - 1) = (p : ℤ) * ((p : ℤ) * k) := by
      calc (p : ℤ) * B ^ (p - 1) = (p : ℤ) * (p : ℤ) * k := hk
        _ = (p : ℤ) * ((p : ℤ) * k) := by ring
    have := mul_left_cancel₀ hp_pos this
    exact ⟨k, this⟩
  have : (p : ℤ) ∣ B := Prime.dvd_of_dvd_pow (Int.prime_iff_natAbs_prime.mpr (by simpa using hp.out)) h_pB
  exact hB this

lemma sq_sub_mul_add_sq_gt_three (X Y : ℤ) (hX : 8 ≤ X) (hY : 1 ≤ Y) (hYX : Y < X) :
    3 < X ^ 2 - X * Y + Y ^ 2 := by
  have : X ^ 2 - X * Y + Y ^ 2 = (X - Y) ^ 2 + X * Y := by ring
  rw [this]
  have h1 : 1 ≤ (X - Y) ^ 2 := by
    have : 1 ≤ X - Y := by lia
    nlinarith
  have h2 : 8 ≤ X * Y := by
    nlinarith
  lia

lemma m_two_P_three (a b k : ℕ) (hb : 1 ≤ b) (hba : b < a) (hk : 1 ≤ k)
    (h_eq : (a ^ (3 ^ (k - 1)) : ℤ) ^ 2 - (a ^ (3 ^ (k - 1)) : ℤ) * (b ^ (3 ^ (k - 1)) : ℤ) + (b ^ (3 ^ (k - 1)) : ℤ) ^ 2 = 3) :
    a = 2 ∧ b = 1 ∧ k = 1 := by
  have hpos : 0 < 3 ^ (k - 1) := by positivity
  have hsol := geom_cubes_sol (a ^ (3 ^ (k - 1))) (b ^ (3 ^ (k - 1)))
    (Nat.pow_lt_pow_left hba hpos.ne') (Nat.one_le_pow _ b hb) h_eq
  have hX : a ^ (3 ^ (k - 1)) = 2 := hsol.1
  have hY : b ^ (3 ^ (k - 1)) = 1 := hsol.2
  have : b = 1 := by
    have : b ≤ b ^ (3 ^ (k - 1)) := by
      calc b = b ^ 1 := by rw [pow_one]
        _ ≤ b ^ (3 ^ (k - 1)) := Nat.pow_le_pow_right (by lia) (Nat.one_le_pow _ 3 (by decide))
    rw [hY] at this
    lia
  subst this
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by lia⟩
  have hj : j + 1 - 1 = j := rfl
  rw [hj] at hX
  rcases j with _ | j
  · rw [pow_zero, pow_one] at hX
    exact ⟨hX, rfl, rfl⟩
  · exfalso
    have : 2 ^ 3 ≤ a ^ (3 ^ (j + 1)) := by
      have h3 : 3 ≤ 3 ^ (j + 1) := by
        calc 3 = 3 ^ 1 := by rw [pow_one]
          _ ≤ 3 ^ (j + 1) := Nat.pow_le_pow_right (by decide) (by lia)
      calc 2 ^ 3 ≤ 2 ^ (3 ^ (j + 1)) := Nat.pow_le_pow_right (by decide) h3
        _ ≤ a ^ (3 ^ (j + 1)) := Nat.pow_le_pow_left (by lia) _
    rw [hX] at this
    revert this; decide

lemma cycloVal_gt_P_of_ge_two (n a b P : ℕ) (hn : 3 ≤ n) (hb : 1 ≤ b) (hba : b + 2 ≤ a)
    (hP : P.Prime) (hPn : P ∣ n) (hP3 : 3 ≤ P) :
    (P : ℤ) < cycloVal n a b := by
  have hb_pos : (0 : ℝ) < (b : ℝ) := by positivity
  have hq_gt : 1 < (a : ℝ) / (b : ℝ) := by
    rw [one_lt_div hb_pos]
    exact_mod_cast (show b < a by lia)
  have h_eval := sub_one_pow_totient_lt_cyclotomic_eval (show 2 ≤ n by lia) hq_gt
  have h_bound : ((a : ℝ) - (b : ℝ)) ^ n.totient < (cycloVal n a b : ℝ) := by
    have hcoe := cycloVal_coe_real n a b (by lia)
    rw [hcoe]
    have h_sub_eq : (a : ℝ) - (b : ℝ) = (b : ℝ) * ((a : ℝ) / (b : ℝ) - 1) := by
      field_simp
    rw [h_sub_eq, mul_pow]
    have hb_pow_pos : 0 < (b : ℝ) ^ n.totient := by positivity
    exact mul_lt_mul_of_pos_left h_eval hb_pow_pos
  have hP_tot : P - 1 ≤ n.totient := by
    have hdvd := Nat.totient_dvd_of_dvd hPn
    rw [Nat.totient_prime hP] at hdvd
    have htot_pos : 0 < n.totient := Nat.totient_pos.mpr (by lia)
    exact Nat.le_of_dvd htot_pos hdvd
  have h_two_pow_le : (2 : ℝ) ^ (P - 1) ≤ (2 : ℝ) ^ n.totient :=
    pow_le_pow_right₀ (by norm_num) hP_tot
  have h_diff_ge2 : (2 : ℝ) ≤ (a : ℝ) - (b : ℝ) := by
    have : (b : ℝ) + 2 ≤ (a : ℝ) := by exact_mod_cast hba
    linarith
  have h_pow_le : (2 : ℝ) ^ n.totient ≤ ((a : ℝ) - (b : ℝ)) ^ n.totient :=
    pow_le_pow_left₀ (by positivity) h_diff_ge2 n.totient
  have hP_lt_two : (P : ℝ) < (2 : ℝ) ^ (P - 1) := by
    have := lt_two_pow_pred P hP3
    exact_mod_cast this
  have hP_lt_cyclo : (P : ℝ) < (cycloVal n a b : ℝ) :=
    calc (P : ℝ) < (2 : ℝ) ^ (P - 1) := hP_lt_two
      _ ≤ (2 : ℝ) ^ n.totient := h_two_pow_le
      _ ≤ ((a : ℝ) - (b : ℝ)) ^ n.totient := h_pow_le
      _ < (cycloVal n a b : ℝ) := h_bound
  exact_mod_cast hP_lt_cyclo

lemma mem_sdiff_divisors_two (m P k : ℕ) (hm : 2 ≤ m) (hP : P.Prime) (hk : 1 ≤ k) (hPm : ¬ P ∣ m) :
    let n := m * P ^ k
    let nP := n / P
    (P ^ k ∈ n.divisors \ nP.divisors) ∧
    (n ∈ n.divisors \ nP.divisors) ∧
    (P ^ k ≠ n) := by
  intro n nP
  have hn_pos : 0 < n := by
    dsimp [n]
    exact mul_pos (by lia) (pow_pos hP.pos k)
  have hnP_eq : nP = m * P ^ (k - 1) := by
    dsimp [nP, n]
    obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by lia : k ≠ 0)
    have : m * P ^ (j + 1) = (m * P ^ j) * P := by ring
    rw [this, Nat.mul_div_cancel _ hP.pos]
    have : j + 1 - 1 = j := rfl
    rw [this]
  have hnP_pos : 0 < nP := by
    rw [hnP_eq]
    exact mul_pos (by lia) (pow_pos hP.pos (k - 1))
  have hdvd_Pk : P ^ k ∣ n := dvd_mul_left _ _
  have hdvd_n : n ∣ n := dvd_rfl
  have hnot_Pk : ¬ P ^ k ∣ nP := by
    rw [hnP_eq]
    obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by lia : k ≠ 0)
    have : j + 1 - 1 = j := rfl
    rw [this]
    have h_pow : P ^ (j + 1) = P * P ^ j := by ring
    rw [h_pow]
    intro hdvd
    have : P * P ^ j ∣ m * P ^ j := hdvd
    have h_cancel : P ∣ m := by
      rwa [Nat.mul_dvd_mul_iff_right (pow_pos hP.pos j)] at this
    exact hPm h_cancel
  have hnot_n : ¬ n ∣ nP := by
    intro hdvd
    have hle := Nat.le_of_dvd hnP_pos hdvd
    have hlt : nP < n := by
      dsimp [nP]
      exact Nat.div_lt_self hn_pos hP.two_le
    lia
  have h_ne : P ^ k ≠ n := by
    intro h
    dsimp [n] at h
    have : 1 = m := by nlinarith [pow_pos hP.pos k]
    lia
  refine ⟨?_, ?_, h_ne⟩
  · rw [Finset.mem_sdiff, Nat.mem_divisors, Nat.mem_divisors]
    exact ⟨⟨hdvd_Pk, hn_pos.ne'⟩, fun h => hnot_Pk h.1⟩
  · rw [Finset.mem_sdiff, Nat.mem_divisors, Nat.mem_divisors]
    exact ⟨⟨hdvd_n, hn_pos.ne'⟩, fun h => hnot_n h.1⟩

lemma prod_two_mem_dvd {α M : Type*} [DecidableEq α] [CommMonoid M] (s : Finset α) (x y : α) (hxy : x ≠ y)
    (hx : x ∈ s) (hy : y ∈ s) (f : α → M) :
    f x * f y ∣ ∏ i ∈ s, f i := by
  have h_pair : ({x, y} : Finset α) ⊆ s := by
    rw [Finset.insert_subset_iff, Finset.singleton_subset_iff]
    exact ⟨hx, hy⟩
  have h_prod := Finset.prod_dvd_prod_of_subset (s := {x, y}) (t := s) (f := f) h_pair
  have : ∏ i ∈ ({x, y} : Finset α), f i = f x * f y := by
    rw [Finset.prod_insert, Finset.prod_singleton]
    rwa [Finset.mem_singleton]
  rwa [this] at h_prod

lemma m_two_contra (a b k : ℕ) (hb : 1 ≤ b) (hba : b < a) (hk : 1 ≤ k)
    (X Y : ℕ)
    (h_two : (X : ℤ) ^ 3 + (Y : ℤ) ^ 3 = ((X : ℤ) + (Y : ℤ)) * 3) (hXY : Y < X) (hY : 1 ≤ Y)
    (hX_def : X = a ^ (3 ^ (k - 1))) (hY_def : Y = b ^ (3 ^ (k - 1))) :
    a = 2 ∧ b = 1 ∧ k = 1 := by
  have h_cube : (X : ℤ) ^ 3 + (Y : ℤ) ^ 3 = ((X : ℤ) + (Y : ℤ)) * ((X : ℤ) ^ 2 - (X : ℤ) * (Y : ℤ) + (Y : ℤ) ^ 2) := by ring
  rw [h_cube] at h_two
  have hXY_pos : (0 : ℤ) < (X : ℤ) + (Y : ℤ) := by
    have : 0 < X := by lia
    positivity
  have h_eq : (X : ℤ) ^ 2 - (X : ℤ) * (Y : ℤ) + (Y : ℤ) ^ 2 = 3 := by
    have := mul_left_cancel₀ (ne_of_gt hXY_pos) h_two
    exact this
  have h_sol := geom_cubes_sol X Y hXY hY h_eq
  have hX2 : X = 2 := h_sol.1
  have hY1 : Y = 1 := h_sol.2
  have hb1 : b = 1 := by
    rw [hY_def] at hY1
    have : b ≤ b ^ (3 ^ (k - 1)) := by
      calc b = b ^ 1 := by rw [pow_one]
        _ ≤ b ^ (3 ^ (k - 1)) := Nat.pow_le_pow_right (by lia) (Nat.one_le_pow _ 3 (by decide))
    rw [hY1] at this
    lia
  subst hb1
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by lia⟩
  have hj : j + 1 - 1 = j := rfl
  rw [hX_def] at hX2
  rw [hj] at hX2
  rcases j with _ | j
  · rw [pow_zero, pow_one] at hX2
    exact ⟨hX2, rfl, rfl⟩
  · exfalso
    have : 2 ^ 3 ≤ a ^ (3 ^ (j + 1)) := by
      have h3 : 3 ≤ 3 ^ (j + 1) := by
        calc 3 = 3 ^ 1 := by rw [pow_one]
          _ ≤ 3 ^ (j + 1) := Nat.pow_le_pow_right (by decide) (by lia)
      calc 2 ^ 3 ≤ 2 ^ (3 ^ (j + 1)) := Nat.pow_le_pow_right (by decide) h3
        _ ≤ a ^ (3 ^ (j + 1)) := Nat.pow_le_pow_left (by lia) _
    rw [hX2] at this
    revert this; decide

lemma cycloVal_six (a b : ℕ) (hb : 1 ≤ b) :
    cycloVal 6 a b = (a : ℤ) ^ 2 - (a : ℤ) * (b : ℤ) + (b : ℤ) ^ 2 := by
  have hb_ne : (b : ℤ) ≠ 0 := by positivity
  have hQ := cycloVal_coe_rat 6 a b hb_ne
  have htot : (6 : ℕ).totient = 2 := by decide
  have hcyc := cyclotomic_six ℚ
  rw [htot, hcyc] at hQ
  simp only [eval_add, eval_sub, eval_pow, eval_X, eval_one] at hQ
  have hbQ : (b : ℚ) ≠ 0 := by exact_mod_cast hb_ne
  have h_alg : (b : ℚ) ^ 2 * (((a : ℚ) / (b : ℚ)) ^ 2 - (a : ℚ) / (b : ℚ) + 1) =
      (a : ℚ) ^ 2 - (a : ℚ) * (b : ℚ) + (b : ℚ) ^ 2 := by
    rw [mul_add, mul_sub, div_pow, mul_one]
    have : (b : ℚ) ^ 2 ≠ 0 := pow_ne_zero 2 hbQ
    field_simp
  have hQ2 : ((cycloVal 6 a b : ℤ) : ℚ) = ((a : ℚ) ^ 2 - (a : ℚ) * (b : ℚ) + (b : ℚ) ^ 2) := by
    rw [hQ]
    exact h_alg
  exact_mod_cast hQ2

lemma cycloVal_six_sol (b : ℕ) (hb : 1 ≤ b) (h : (cycloVal 6 (b + 1) b).natAbs = 3) : b = 1 := by
  have h_val := cycloVal_six (b + 1) b hb
  push_cast at h_val
  have h_alg : (b + 1 : ℤ) ^ 2 - (b + 1 : ℤ) * (b : ℤ) + (b : ℤ) ^ 2 = (b : ℤ) ^ 2 + (b : ℤ) + 1 := by ring
  rw [h_alg] at h_val
  have h_pos : 0 ≤ cycloVal 6 (b + 1) b := by
    rw [h_val]
    positivity
  have h_abs := Int.natAbs_of_nonneg h_pos
  have h_int : cycloVal 6 (b + 1) b = 3 := by
    rw [← h_abs]
    exact_mod_cast h
  rw [h_val] at h_int
  have hb1 : b < 2 := by
    by_contra!
    have : (2 : ℤ) ≤ b := by exact_mod_cast this
    have : (7 : ℤ) ≤ (b : ℤ) ^ 2 + (b : ℤ) + 1 := by nlinarith
    lia
  lia

lemma test_sub_cast (a b m P : ℕ) [Fact P.Prime] (h_mod_m : (a : ZMod P) ^ m = (b : ZMod P) ^ m) :
    (P : ℤ) ∣ (a ^ m : ℤ) - (b ^ m : ℤ) := by
  have : (a : ZMod P) ^ m - (b : ZMod P) ^ m = 0 := sub_eq_zero.mpr h_mod_m
  have h_cast : (((a ^ m : ℤ) - (b ^ m : ℤ) : ℤ) : ZMod P) = 0 := by
    push_cast
    exact this
  exact (CharP.intCast_eq_zero_iff (ZMod P) P _).mp h_cast

lemma test_geom2_div (a b m P k : ℕ) (hP_dvd_sub_m : (P : ℤ) ∣ (a ^ m : ℤ) - (b ^ m : ℤ)) :
    (P : ℤ) ∣ (a ^ (m * P ^ (k - 1)) : ℤ) - (b ^ (m * P ^ (k - 1)) : ℤ) := by
  rw [pow_mul, pow_mul]
  have h_geom2 := geom_sum₂_mul (a ^ m : ℤ) (b ^ m : ℤ) (P ^ (k - 1))
  have : (a ^ m : ℤ) - (b ^ m : ℤ) ∣ ((a ^ m : ℤ) ^ (P ^ (k - 1))) - ((b ^ m : ℤ) ^ (P ^ (k - 1))) :=
    ⟨_, by rw [mul_comm]; exact h_geom2.symm⟩
  exact dvd_trans hP_dvd_sub_m this

lemma sum_P_ge_P_add_one (b P : ℕ) (hb : 1 ≤ b) (hP : 3 ≤ P) :
    P + 1 ≤ ∑ j ∈ Finset.range P, (b + 1 : ℤ) ^ j * (b : ℤ) ^ (P - 1 - j) := by
  have : (P : ℤ) < ∑ j ∈ Finset.range P, ((b + 1 : ℕ) : ℤ) ^ j * ((b : ℕ) : ℤ) ^ (P - 1 - j) := by
    have h1 : 2 ≤ b + 1 := by lia
    have hgt := sum_ge_two_pow_pred (b + 1) b P h1 hb hP
    exact_mod_cast hgt
  lia

lemma not_cycloVal_eq_P_of_prime (b P : ℕ) (hb : 1 ≤ b) (hP : P.Prime) (hP3 : 3 ≤ P)
    (h_eq : cycloVal P (b + 1) b = P) : False := by
  have h_geom := geom_sum_eq_sdiff_prod P (b + 1) b P (by lia) hb (by lia) hP dvd_rfl
  have hdiv : P / P = 1 := Nat.div_self hP.pos
  rw [hdiv] at h_geom
  simp only [pow_one] at h_geom
  have hsdiff : P.divisors \ (1 : ℕ).divisors = {P} := by
    ext d
    rw [Finset.mem_sdiff, Nat.mem_divisors, Nat.mem_divisors, Finset.mem_singleton]
    constructor
    · rintro ⟨⟨hdvd, -⟩, hnot⟩
      rcases (Nat.dvd_prime hP).mp hdvd with rfl | rfl
      · exfalso; exact hnot ⟨dvd_rfl, by decide⟩
      · rfl
    · rintro rfl
      refine ⟨⟨dvd_rfl, hP.ne_zero⟩, ?_⟩
      rintro ⟨hdvd, -⟩
      have : d = 1 := Nat.dvd_one.mp hdvd
      lia
  rw [hsdiff, Finset.prod_singleton] at h_geom
  push_cast at h_geom
  have h_gt := sum_P_ge_P_add_one b P hb hP3
  rw [← h_geom, h_eq] at h_gt
  lia

lemma pow_five_gt_sq (b : ℕ) (hb : 1 ≤ b) : (2 * b + 1) ^ 2 < (b + 1) ^ 5 + b ^ 5 := by
  have h1 : (2 * b + 1) ^ 2 = 4 * b ^ 2 + 4 * b + 1 := by ring
  have h2 : (b + 1) ^ 5 + b ^ 5 = 2 * b ^ 5 + 5 * b ^ 4 + 10 * b ^ 3 + 10 * b ^ 2 + 5 * b + 1 := by ring
  rw [h1, h2]
  have : 4 * b ^ 2 ≤ 10 * b ^ 2 := by nlinarith
  have : 4 * b ≤ 5 * b := by nlinarith
  have : 0 < 2 * b ^ 5 := by positivity
  lia

lemma not_cycloVal_eq_P_of_prime_pow (b P k : ℕ) (hb : 1 ≤ b) (hP : P.Prime) (hP3 : 3 ≤ P)
    (hk : 2 ≤ k) (h_eq : cycloVal (P ^ k) (b + 1) b = P) : False := by
  have h_geom := geom_sum_eq_sdiff_prod (P ^ k) (b + 1) b P (by positivity) hb (by lia) hP (dvd_pow_self P (by lia))
  have hsdiff : (P ^ k).divisors \ (P ^ k / P).divisors = {P ^ k} := by
    ext d
    rw [Finset.mem_sdiff, Nat.mem_divisors, Nat.mem_divisors, Finset.mem_singleton]
    obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by lia : k ≠ 0)
    have hdvd_P : P ∣ P ^ (j + 1) := dvd_pow_self P (by lia)
    have hdiv : P ^ (j + 1) / P = P ^ j := by
      rw [pow_succ, Nat.mul_div_cancel _ hP.pos]
    rw [hdiv]
    constructor
    · rintro ⟨⟨hdvd1, -⟩, hnot⟩
      obtain ⟨u, hu_le, rfl⟩ := (Nat.dvd_prime_pow hP).mp hdvd1
      have : u = j + 1 := by
        by_contra! hu_lt
        have : u ≤ j := by lia
        have : P ^ u ∣ P ^ j := Nat.pow_dvd_pow P this
        exact hnot ⟨this, by positivity⟩
      rw [this]
    · rintro rfl
      refine ⟨⟨dvd_rfl, by positivity⟩, ?_⟩
      rintro ⟨hdvd, -⟩
      have := Nat.le_of_dvd (by positivity) hdvd
      have : P ^ j < P ^ (j + 1) := Nat.pow_lt_pow_right hP.two_le (by lia)
      lia
  rw [hsdiff, Finset.prod_singleton] at h_geom
  have hdiv_eq : P ^ k / P = P ^ (k - 1) := by
    obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by lia : k ≠ 0)
    have : j + 1 - 1 = j := rfl
    rw [pow_succ, Nat.mul_div_cancel _ hP.pos, this]
  rw [hdiv_eq] at h_geom
  have h_gt : (P : ℤ) < ∑ j ∈ Finset.range P, ((b + 1 : ℕ) : ℤ) ^ (P ^ (k - 1) * j) * ((b : ℕ) : ℤ) ^ (P ^ (k - 1) * (P - 1 - j)) := by
    have hA_ge2 : 2 ≤ (b + 1) ^ (P ^ (k - 1)) := by
      calc 2 ≤ b + 1 := by lia
        _ = (b + 1) ^ 1 := by rw [pow_one]
        _ ≤ (b + 1) ^ (P ^ (k - 1)) := Nat.pow_le_pow_right (by lia) (Nat.one_le_pow _ P hP.pos)
    have hB_ge1 : 1 ≤ b ^ (P ^ (k - 1)) := Nat.one_le_pow _ b hb
    have hgt := sum_ge_two_pow_pred ((b + 1) ^ (P ^ (k - 1))) (b ^ (P ^ (k - 1))) P hA_ge2 hB_ge1 hP3
    have : ((∑ j ∈ Finset.range P, ((b + 1) ^ (P ^ (k - 1))) ^ j * (b ^ (P ^ (k - 1))) ^ (P - 1 - j) : ℕ) : ℤ) =
        ∑ j ∈ Finset.range P, ((b + 1 : ℕ) : ℤ) ^ (P ^ (k - 1) * j) * ((b : ℕ) : ℤ) ^ (P ^ (k - 1) * (P - 1 - j)) := by
      push_cast
      refine Finset.sum_congr rfl fun j _ => by ring
    rw [← this]
    exact_mod_cast hgt
  push_cast at h_geom
  have h_same : (∑ j ∈ Finset.range P, ((b + 1 : ℤ) ^ P ^ (k - 1)) ^ j * ((b : ℤ) ^ P ^ (k - 1)) ^ (P - 1 - j)) =
      ∑ j ∈ Finset.range P, ((b + 1 : ℕ) : ℤ) ^ (P ^ (k - 1) * j) * ((b : ℕ) : ℤ) ^ (P ^ (k - 1) * (P - 1 - j)) := by
    refine Finset.sum_congr rfl fun j _ => by
      push_cast
      rw [← pow_mul, ← pow_mul]
  rw [h_same] at h_geom
  rw [← h_geom, h_eq] at h_gt
  lia

lemma test_m_one (b P k : ℕ) (hb : 1 ≤ b) (hP : P.Prime) (hP3 : 3 ≤ P) (hk_ge1 : 1 ≤ k)
    (hcyc_eq_P : cycloVal (P ^ k) (b + 1) b = P) : False := by
  rcases eq_or_ne k 1 with rfl | hk2
  · rw [pow_one] at hcyc_eq_P
    exact not_cycloVal_eq_P_of_prime b P hb hP hP3 (by exact_mod_cast hcyc_eq_P)
  · have hk_ge2 : 2 ≤ k := by lia
    exact not_cycloVal_eq_P_of_prime_pow b P k hb hP hP3 hk_ge2 (by exact_mod_cast hcyc_eq_P)

lemma all_other_lt (a b n P r : ℕ) (hba : b < a) (hb : 1 ≤ b) (hab : a.Coprime b) (hn : 2 ≤ n)
    (hP : P.Prime) (hP_dvd_int : (P : ℤ) ∣ cycloVal n a b) (hPn : P ∣ n)
    (hr : r.Prime) (hrdvd : r ∣ n) (hrP : r ≠ P) : r < P := by
  haveI : Fact P.Prime := ⟨hP⟩
  obtain ⟨k, m, hPm, hn_eq⟩ := exists_eq_mul_pow_not_dvd n P (by lia) hP
  have hk_ge1 : 1 ≤ k := by
    by_contra!
    have : k = 0 := by lia
    subst this
    rw [pow_zero, mul_one] at hn_eq
    rw [hn_eq] at hPn
    exact hPm hPn
  have hq_b : (b : ZMod P) ≠ 0 := by
    intro hb0
    have hPb : P ∣ b := by rwa [CharP.cast_eq_zero_iff (ZMod P) P] at hb0
    have hPan : P ∣ a ^ n := by
      have h1 : cycloVal n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := cycloVal_dvd_sub_pow n a b (by lia) (by lia)
      have h2 : (P : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := dvd_trans hP_dvd_int h1
      have : (a : ℤ) ^ n - (b : ℤ) ^ n = ((a ^ n - b ^ n : ℕ) : ℤ) := by
        exact (Nat.cast_sub (Nat.pow_le_pow_left hba.le n)).symm
      rw [this] at h2
      rw [Int.natCast_dvd_natCast] at h2
      have : a ^ n = (a ^ n - b ^ n) + b ^ n := (Nat.sub_add_cancel (Nat.pow_le_pow_left hba.le n)).symm
      rw [this]
      exact dvd_add h2 (dvd_pow hPb (by lia))
    have hPa : P ∣ a := hP.dvd_of_dvd_pow hPan
    have : P ∣ Nat.gcd a b := Nat.dvd_gcd hPa hPb
    rw [hab] at this
    exact Nat.Prime.not_dvd_one hP this
  have hu_a : (a : ZMod P) ≠ 0 := by
    intro ha0
    have hPa : P ∣ a := by rwa [CharP.cast_eq_zero_iff (ZMod P) P] at ha0
    have h1 : cycloVal n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := cycloVal_dvd_sub_pow n a b (by lia) (by lia)
    have h2 : (P : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := dvd_trans hP_dvd_int h1
    have : (a : ℤ) ^ n - (b : ℤ) ^ n = ((a ^ n - b ^ n : ℕ) : ℤ) := by
      exact (Nat.cast_sub (Nat.pow_le_pow_left hba.le n)).symm
    rw [this] at h2
    rw [Int.natCast_dvd_natCast] at h2
    have hPbn : P ∣ b ^ n := by
      have : b ^ n = a ^ n - (a ^ n - b ^ n) := by lia
      rw [this]
      exact Nat.dvd_sub (dvd_pow hPa (by lia)) h2
    have hPb : P ∣ b := hP.dvd_of_dvd_pow hPbn
    have : P ∣ Nat.gcd a b := Nat.dvd_gcd hPa hPb
    rw [hab] at this
    exact Nat.Prime.not_dvd_one hP this
  let u : (ZMod P)ˣ := Units.mk0 ((a : ZMod P) * (b : ZMod P)⁻¹) (mul_ne_zero hu_a (inv_ne_zero hq_b))
  have hu_eval_n : eval (u : ZMod P) (cyclotomic (m * P ^ k) (ZMod P)) = 0 := by
    have hcyc_mod : (cycloVal n a b : ZMod P) = 0 := by
      obtain ⟨c, hc⟩ := hP_dvd_int
      rw [hc]
      push_cast
      simp
    have hq_b_int : ((b : ℤ) : ZMod P) ≠ 0 := by simpa using hq_b
    have hmod_eq := cycloVal_mod_eq n a b hq_b_int
    rw [hcyc_mod] at hmod_eq
    have hb_pow_unit : IsUnit (((b : ℤ) : ZMod P) ^ n.totient) :=
      (isUnit_iff_ne_zero.mpr hq_b_int).pow _
    rcases hb_pow_unit with ⟨w, hw⟩
    have : ((w : (ZMod P)ˣ) : ZMod P) * eval (u : ZMod P) (cyclotomic n (ZMod P)) = 0 := by
      rw [hw]
      have hu_eq : (u : ZMod P) = ((a : ℤ) : ZMod P) * (((b : ℤ) : ZMod P))⁻¹ := by
        push_cast
        rfl
      rw [hu_eq]
      exact hmod_eq.symm
    have hu_eval := test_unit_mul w _ this
    rwa [hn_eq] at hu_eval
  have hu_eval_m := eval_cyclotomic_prime_pow_mul m P hPm k hk_ge1 (u : ZMod P) hu_eval_n
  have hm_dvd : m ∣ P - 1 := m_dvd_p_sub_one m P hPm u hu_eval_m
  have hr_dvd_m : r ∣ m := by
    have : r ∣ m * P ^ k := by rwa [← hn_eq]
    rcases (Nat.Prime.dvd_mul hr).mp this with h1 | h2
    · exact h1
    · exfalso
      have : r ∣ P := hr.dvd_of_dvd_pow h2
      rcases (Nat.dvd_prime hP).mp this with hr1 | hrP_eq
      · exact hr.ne_one hr1
      · exact hrP hrP_eq
  have hr_dvd_pred : r ∣ P - 1 := dvd_trans hr_dvd_m hm_dvd
  have hP1_pos : 0 < P - 1 := by
    have : 2 ≤ P := hP.two_le
    lia
  have : r ≤ P - 1 := Nat.le_of_dvd hP1_pos hr_dvd_pred
  lia

lemma test_63_ne_prime_pow (q m : ℕ) (hq : q.Prime) : 63 ≠ q ^ m := by
  intro h
  have hdvd3 : 3 ∣ q ^ m := by rw [← h]; decide
  have hdvd7 : 7 ∣ q ^ m := by rw [← h]; decide
  have hq3 : q = 3 := (Nat.Prime.dvd_iff_eq hq (by decide)).mp (Nat.prime_three.dvd_of_dvd_pow hdvd3)
  have hq7 : q = 7 := (Nat.Prime.dvd_iff_eq hq (by decide)).mp (Nat.prime_seven.dvd_of_dvd_pow hdvd7)
  rw [hq3] at hq7
  revert hq7; decide

theorem eq_prime_pow_of_n_eq_two (a q m : ℕ) (ha : 2 ≤ a) (hq : q.Prime) (hm : 2 ≤ m)
    (h : a ^ 2 - 1 = q ^ m) : a = 3 ∧ q = 2 ∧ m = 3 := by
  have h_fac : (a - 1) * (a + 1) = q ^ m := by
    have : a ^ 2 - 1 = (a - 1) * (a + 1) := by
      have := Nat.sq_sub_sq a 1
      simp only [one_pow] at this
      rw [this, mul_comm]
    rwa [← this]
  have hdvd1 : a - 1 ∣ q ^ m := ⟨a + 1, h_fac.symm⟩
  have hdvd2 : a + 1 ∣ q ^ m := ⟨a - 1, by rw [mul_comm]; exact h_fac.symm⟩
  obtain ⟨u, hu_le, hu⟩ := (Nat.dvd_prime_pow hq).mp hdvd1
  obtain ⟨v, hv_le, hv⟩ := (Nat.dvd_prime_pow hq).mp hdvd2
  have h_diff : (a + 1) - (a - 1) = 2 := by lia
  rw [hv, hu] at h_diff
  have huv : u < v := by
    have : a - 1 < a + 1 := by lia
    rw [hu, hv] at this
    exact (Nat.pow_lt_pow_iff_right hq.two_le).mp this
  have h_sub : q ^ v - q ^ u = q ^ u * (q ^ (v - u) - 1) := by
    rw [Nat.mul_sub_left_distrib, ← Nat.pow_add, Nat.add_sub_of_le huv.le, mul_one]
  rw [h_sub] at h_diff
  have hqu_dvd : q ^ u ∣ 2 := ⟨q ^ (v - u) - 1, h_diff.symm⟩
  have hqu_cases := (Nat.dvd_prime Nat.prime_two).mp hqu_dvd
  rcases hqu_cases with hqu1 | hqu2
  · have ha2 : a = 2 := by
      have : a - 1 = 1 := hu.trans hqu1
      lia
    subst ha2
    have h3 : 3 = q ^ m := by
      rw [show 2 ^ 2 - 1 = 3 by decide] at h
      exact h
    have hq2_le : 4 ≤ q ^ m := calc
      4 = 2 ^ 2 := by decide
      _ ≤ q ^ 2 := Nat.pow_le_pow_left hq.two_le 2
      _ ≤ q ^ m := Nat.pow_le_pow_right hq.pos hm
    rw [← h3] at hq2_le
    lia
  · have ha3 : a = 3 := by
      have : a - 1 = 2 := hu.trans hqu2
      lia
    subst ha3
    have hq2 : q = 2 := by
      rcases u with _ | u
      · rw [pow_zero] at hqu2; lia
      · rcases u with _ | u
        · rw [pow_one] at hqu2; exact hqu2
        · have : 4 ≤ q ^ (u + 2) := calc
            4 = 2 ^ 2 := by decide
            _ ≤ q ^ 2 := Nat.pow_le_pow_left hq.two_le 2
            _ ≤ q ^ (u + 2) := Nat.pow_le_pow_right hq.pos (by lia)
          rw [hqu2] at this
          lia
    subst hq2
    have : 3 ^ 2 - 1 = 8 := by decide
    rw [this] at h
    have hm3 : m = 3 := by
      have : 2 ^ 3 = 2 ^ m := by rw [show 2 ^ 3 = 8 by decide, ← h]
      exact (Nat.pow_right_injective (by decide) this).symm
    exact ⟨rfl, rfl, hm3⟩

lemma test_2_6 (m : ℕ) (hm1 : 1 ≤ m) (hm6 : m < 6)
    (h : (2 ^ m - 1).primeFactors = (2 ^ 6 - 1).primeFactors) : False := by
  have h7_in_6 : 7 ∈ (2 ^ 6 - 1).primeFactors := by
    rw [Nat.mem_primeFactors]
    refine ⟨by decide, by decide, by decide⟩
  have h3_in_6 : 3 ∈ (2 ^ 6 - 1).primeFactors := by
    rw [Nat.mem_primeFactors]
    refine ⟨by decide, by decide, by decide⟩
  interval_cases m
  · have : 7 ∉ (2 ^ 1 - 1).primeFactors := by
      rw [Nat.mem_primeFactors]
      intro ⟨_, h2, _⟩
      revert h2; decide
    rw [h] at this
    exact this h7_in_6
  · have : 7 ∉ (2 ^ 2 - 1).primeFactors := by
      rw [Nat.mem_primeFactors]
      intro ⟨_, h2, _⟩
      revert h2; decide
    rw [h] at this
    exact this h7_in_6
  · have : 3 ∉ (2 ^ 3 - 1).primeFactors := by
      rw [Nat.mem_primeFactors]
      intro ⟨_, h2, _⟩
      revert h2; decide
    rw [h] at this
    exact this h3_in_6
  · have : 7 ∉ (2 ^ 4 - 1).primeFactors := by
      rw [Nat.mem_primeFactors]
      intro ⟨_, h2, _⟩
      revert h2; decide
    rw [h] at this
    exact this h7_in_6
  · have : 7 ∉ (2 ^ 5 - 1).primeFactors := by
      rw [Nat.mem_primeFactors]
      intro ⟨_, h2, _⟩
      revert h2; decide
    rw [h] at this
    exact this h7_in_6

lemma no_sol_2_pow (q m n : ℕ) (hq : q.Prime) (hm : 2 ≤ m) (hn : 2 ≤ n)
    (h : 2 ^ n - 1 = q ^ m) : False := by
  have h_add : 2 ^ n = q ^ m + 1 := by
    have : 1 ≤ 2 ^ n := by
      have := Nat.one_le_two_pow (n := n)
      lia
    omega
  have hq_odd : Odd q := by
    have h_mod : (2 ^ n - 1) % 2 = 1 := by
      obtain ⟨k, rfl⟩ : ∃ k, n = k + 1 := ⟨n - 1, by lia⟩
      rw [pow_succ]
      have : 2 ^ k * 2 - 1 = 2 * (2 ^ k - 1) + 1 := by
        have : 1 ≤ 2 ^ k := Nat.one_le_two_pow
        lia
      rw [this]
      omega
    have hqm_odd : Odd (q ^ m) := by
      rw [← h]
      exact Nat.odd_iff.mpr h_mod
    by_contra! hq_even
    rw [Nat.not_odd_iff_even] at hq_even
    have : Even (q ^ m) := Even.pow_of_ne_zero hq_even (by lia)
    exact Nat.not_even_iff_odd.mpr hqm_odd this
  have hm_odd : Odd m := by
    by_contra! heven
    rw [Nat.not_odd_iff_even] at heven
    obtain ⟨k, rfl⟩ := heven
    have hk1 : 1 ≤ k := by lia
    have hk_eq : k + k = 2 * k := by ring
    rw [hk_eq] at h
    have h_pow_mul : (q ^ k) ^ 2 = q ^ (2 * k) := by
      rw [mul_comm, pow_mul]
    have h_sq : (q ^ k) ^ 2 % 4 = 3 := by
      rw [h_pow_mul, ← h]
      exact two_pow_sub_one_mod_four hn
    exact sq_mod_four_ne_three (q ^ k) h_sq
  let S_int : ℤ := ∑ i ∈ Finset.range m, (q : ℤ) ^ i * (-1 : ℤ) ^ (m - 1 - i)
  have hS_geom : S_int * ((q : ℤ) + 1) = (q : ℤ) ^ m + 1 := by
    have h1 := geom_sum₂_mul (q : ℤ) (-1 : ℤ) m
    rw [sub_neg_eq_add] at h1
    rw [hm_odd.neg_pow, one_pow, sub_neg_eq_add] at h1
    exact h1
  have h_prod_int : S_int * ((q : ℤ) + 1) = ((2 : ℤ) ^ n) := by
    rw [hS_geom]
    exact_mod_cast h_add.symm
  have hS_pos : 0 < S_int := by
    have h2n_pos : (0 : ℤ) < (2 : ℤ) ^ n := by positivity
    have hq_pos : (0 : ℤ) < (q : ℤ) + 1 := by positivity
    exact pos_of_mul_pos_left (h_prod_int.symm ▸ h2n_pos) (le_of_lt hq_pos)
  lift S_int to ℕ using hS_pos.le with S hS
  have hS_prod : S * (q + 1) = 2 ^ n := by
    have : ((S * (q + 1) : ℕ) : ℤ) = ((2 ^ n : ℕ) : ℤ) := by
      push_cast
      exact h_prod_int
    exact_mod_cast this
  have hS_dvd : S ∣ 2 ^ n := ⟨q + 1, hS_prod.symm⟩
  have hq_z : (q : ℤ) ≡ 1 [ZMOD 2] := by
    have : q % 2 = 1 := Nat.odd_iff.mp hq_odd
    exact_mod_cast this
  have hS_odd_z : S_int ≡ 1 [ZMOD 2] := by
    have : ∀ i ∈ Finset.range m, (q : ℤ) ^ i * (-1 : ℤ) ^ (m - 1 - i) ≡ 1 [ZMOD 2] := by
      intro i _
      have h1 : (-1 : ℤ) ≡ 1 [ZMOD 2] := by decide
      calc (q : ℤ) ^ i * (-1 : ℤ) ^ (m - 1 - i)
        _ ≡ 1 ^ i * 1 ^ (m - 1 - i) [ZMOD 2] :=
          Int.ModEq.mul (Int.ModEq.pow i hq_z) (Int.ModEq.pow (m - 1 - i) h1)
        _ = 1 := by simp
    have hsum := Int.ModEq.sum (s := Finset.range m) this
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one] at hsum
    have hm_z : (m : ℤ) ≡ 1 [ZMOD 2] := by
      have : m % 2 = 1 := Nat.odd_iff.mp hm_odd
      exact_mod_cast this
    exact hsum.trans hm_z
  have hS_odd : Odd S := by
    have : (S : ℤ) ≡ 1 [ZMOD 2] := by rwa [← hS] at hS_odd_z
    have : S % 2 = 1 := by exact_mod_cast this
    exact Nat.odd_iff.mpr this
  have hS_one : S = 1 := eq_one_of_dvd_two_pow_of_odd hS_dvd hS_odd
  have h_eq : q + 1 = 2 ^ n := by
    calc q + 1 = 1 * (q + 1) := (one_mul _).symm
      _ = S * (q + 1) := by rw [hS_one]
      _ = 2 ^ n := hS_prod
  have hqm_eq_q : q ^ m = q := by
    have : q ^ m + 1 = q + 1 := by rw [← h_add, h_eq]
    lia
  have hm1 : m = 1 := by
    have : q ^ m = q ^ 1 := by rw [pow_one, hqm_eq_q]
    exact (Nat.pow_right_injective hq.two_le this)
  lia

/-!
### The Main Theorems
-/

theorem exists_prime_sub (a b n : Nat) (hba : b < a) (hb : 1 <= b) (hab : Nat.Coprime a b)
    (hn : 2 <= n) (h2 : Not (n = 2 /\ exists t : Nat, a + b = 2 ^ t))
    (h6 : Not (a = 2 /\ b = 1 /\ n = 6)) :
    exists q : Nat, q.Prime /\ (a ^ n - b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k - b ^ k) % q = 0) := by
  by_cases hn2 : n = 2
  · subst hn2
    have h2' : ¬ ∃ t, a + b = 2 ^ t := fun ht => h2 ⟨rfl, ht⟩
    exact exists_prime_sub_two a b hba hb hab h2'
  have hn3 : 3 ≤ n := by lia
  have hex_prim : ∃ q : ℕ, q.Prime ∧ (q : ℤ) ∣ cycloVal n a b ∧ ¬ q ∣ n := by
    by_contra! h_all
    have hC_gt1 : 1 < cycloVal n a b := cycloVal_gt_one n a b (by lia) hb hba
    have hC_abs_gt1 : 1 < (cycloVal n a b).natAbs := by
      have : 0 ≤ cycloVal n a b := by lia
      have h_abs := Int.natAbs_of_nonneg this
      rw [← h_abs] at hC_gt1
      exact_mod_cast hC_gt1
    have hC_ne1 : (cycloVal n a b).natAbs ≠ 1 := by lia
    obtain ⟨P, hP, hPdvd⟩ := Nat.exists_prime_and_dvd hC_ne1
    have hP_dvd_int : (P : ℤ) ∣ cycloVal n a b := by
      have : (P : ℤ) ∣ ((cycloVal n a b).natAbs : ℤ) := by exact_mod_cast hPdvd
      have h_abs : (((cycloVal n a b).natAbs : ℤ)) = cycloVal n a b := by
        exact Int.natAbs_of_nonneg (by lia)
      rwa [h_abs] at this
    have hPn : P ∣ n := h_all P hP hP_dvd_int
    have h_unique_prime : ∀ p, p.Prime → p ∣ (cycloVal n a b).natAbs → p = P := by
      intro p hp hpdvd
      have hp_dvd_int : (p : ℤ) ∣ cycloVal n a b := by
        have : (p : ℤ) ∣ ((cycloVal n a b).natAbs : ℤ) := by exact_mod_cast hpdvd
        have h_abs : (((cycloVal n a b).natAbs : ℤ)) = cycloVal n a b := by
          exact Int.natAbs_of_nonneg (by lia)
        rwa [h_abs] at this
      have hpn : p ∣ n := h_all p hp hp_dvd_int
      by_contra! h_ne
      have h1 := all_other_lt a b n P p hba hb hab (by lia) hP hP_dvd_int hPn hp hpn h_ne
      have h2 := all_other_lt a b n p P hba hb hab (by lia) hp hp_dvd_int hpn hP hPn h_ne.symm
      lia
    have hn_pow_P : ∃ e, (cycloVal n a b).natAbs = P ^ e :=
      eq_pow_prime_of_prime_factors P hP (cycloVal n a b).natAbs (by lia) h_unique_prime
    obtain ⟨e, he⟩ := hn_pow_P
    haveI : Fact P.Prime := ⟨hP⟩
    by_cases hP2 : P = 2
    · subst hP2
      have hn_pow2 : ∃ k, n = 2 ^ k := by
        refine eq_pow_two_of_prime_factors_two n (by lia) fun p hp hpdvd => ?_
        by_contra! hp2
        have hp_lt2 := all_other_lt a b n 2 p hba hb hab (by lia) Nat.prime_two hP_dvd_int hPn hp hpdvd hp2
        have hp_ge2 : 2 ≤ p := hp.two_le
        lia
      obtain ⟨k, rfl⟩ := hn_pow2
      have hk_ge2 : 2 ≤ k := by
        by_contra!
        interval_cases k <;> revert hn3 <;> decide
      have hcyc_val : cycloVal (2 ^ k) a b = a ^ (2 ^ (k - 1)) + b ^ (2 ^ (k - 1)) :=
        cycloVal_two_pow k (by lia) a b hb
      have hcyc_nat : (cycloVal (2 ^ k) a b).natAbs = a ^ (2 ^ (k - 1)) + b ^ (2 ^ (k - 1)) := by
        rw [hcyc_val]
        exact Int.natAbs_natCast _
      rw [hcyc_nat] at he
      have hk1_eq : 2 ^ (k - 1) = 2 ^ (k - 2) * 2 := by
        have : k - 1 = (k - 2) + 1 := by lia
        rw [this, pow_succ, mul_comm]
      have h_sq : a ^ (2 ^ (k - 1)) + b ^ (2 ^ (k - 1)) =
          (a ^ (2 ^ (k - 2))) ^ 2 + (b ^ (2 ^ (k - 2))) ^ 2 := by
        rw [hk1_eq, pow_mul, pow_mul]
      rw [h_sq] at he
      have hA_ge2 : 2 ≤ a ^ (2 ^ (k - 2)) := by
        calc 2 ≤ a := by lia
          _ = a ^ 1 := by rw [pow_one]
          _ ≤ a ^ (2 ^ (k - 2)) := Nat.pow_le_pow_right (by lia) (Nat.one_le_two_pow)
      have hB_ge1 : 1 ≤ b ^ (2 ^ (k - 2)) := Nat.one_le_pow _ b hb
      have hAB_cop : (a ^ (2 ^ (k - 2))).Coprime (b ^ (2 ^ (k - 2))) :=
        Nat.Coprime.pow (2 ^ (k - 2)) (2 ^ (k - 2)) hab
      exact sq_add_sq_ne_two_pow (a ^ (2 ^ (k - 2))) (b ^ (2 ^ (k - 2))) e hA_ge2 hB_ge1 hAB_cop he
    · have hP3 : 3 ≤ P := Nat.succ_le_of_lt (Nat.lt_of_le_of_ne hP.two_le (Ne.symm hP2))
      have hP_odd : Odd P := hP.odd_of_ne_two hP2
      have h_dvd_geom := cycloVal_dvd_geom n a b P (by lia) hb hba hP hPn
      have hq_b : (b : ZMod P) ≠ 0 := test_not_dvd_b a b n P hba hab hP hn (by
        have h1 : cycloVal n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := cycloVal_dvd_sub_pow n a b (by lia) (by lia)
        have h2 : (P : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := dvd_trans hP_dvd_int h1
        have : (a : ℤ) ^ n - (b : ℤ) ^ n = ((a ^ n - b ^ n : ℕ) : ℤ) :=
          (Nat.cast_sub (Nat.pow_le_pow_left hba.le n)).symm
        rw [this] at h2
        exact_mod_cast h2)
      obtain ⟨k, m, hPm, hn_eq⟩ := exists_eq_mul_pow_not_dvd n P (by lia) hP
      have hk_ge1 : 1 ≤ k := by
        by_contra!
        have : k = 0 := by lia
        subst this
        rw [pow_zero, mul_one] at hn_eq
        rw [hn_eq] at hPn
        exact hPm hPn
      have hu_a : (a : ZMod P) ≠ 0 := by
        intro ha0
        have hPa : P ∣ a := by rwa [CharP.cast_eq_zero_iff (ZMod P) P] at ha0
        have h1 : cycloVal n a b ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := cycloVal_dvd_sub_pow n a b (by lia) (by lia)
        have h2 : (P : ℤ) ∣ (a : ℤ) ^ n - (b : ℤ) ^ n := dvd_trans hP_dvd_int h1
        have : (a : ℤ) ^ n - (b : ℤ) ^ n = ((a ^ n - b ^ n : ℕ) : ℤ) :=
          (Nat.cast_sub (Nat.pow_le_pow_left hba.le n)).symm
        rw [this] at h2
        have hP_dvd_sub : P ∣ a ^ n - b ^ n := by exact_mod_cast h2
        have hPbn : P ∣ b ^ n := by
          have : b ^ n = a ^ n - (a ^ n - b ^ n) := by lia
          rw [this]
          exact Nat.dvd_sub (dvd_pow hPa (by lia)) hP_dvd_sub
        have hPb : P ∣ b := hP.dvd_of_dvd_pow hPbn
        have : P ∣ Nat.gcd a b := Nat.dvd_gcd hPa hPb
        rw [hab] at this
        exact Nat.Prime.not_dvd_one hP this
      let u : (ZMod P)ˣ := Units.mk0 ((a : ZMod P) * (b : ZMod P)⁻¹) (mul_ne_zero hu_a (inv_ne_zero hq_b))
      have hu_eval_n : eval (u : ZMod P) (cyclotomic (m * P ^ k) (ZMod P)) = 0 := by
        have hcyc_mod : (cycloVal n a b : ZMod P) = 0 := by
          obtain ⟨c, hc⟩ := hP_dvd_int
          rw [hc]
          push_cast
          simp
        have hq_b_int : ((b : ℤ) : ZMod P) ≠ 0 := by simpa using hq_b
        have hmod_eq := cycloVal_mod_eq n a b hq_b_int
        rw [hcyc_mod] at hmod_eq
        have hb_pow_unit : IsUnit (((b : ℤ) : ZMod P) ^ n.totient) :=
          (isUnit_iff_ne_zero.mpr hq_b_int).pow _
        rcases hb_pow_unit with ⟨w, hw⟩
        have : ((w : (ZMod P)ˣ) : ZMod P) * eval (u : ZMod P) (cyclotomic n (ZMod P)) = 0 := by
          rw [hw]
          have hu_eq : (u : ZMod P) = ((a : ℤ) : ZMod P) * (((b : ℤ) : ZMod P))⁻¹ := by
            push_cast
            rfl
          rw [hu_eq]
          exact hmod_eq.symm
        have hu_eval := test_unit_mul w _ this
        rwa [hn_eq] at hu_eval
      have hu_eval_m := eval_cyclotomic_prime_pow_mul m P hPm k hk_ge1 (u : ZMod P) hu_eval_n
      have hu_pow_m : (u : ZMod P) ^ m = 1 := by
        haveI : NeZero (m : ZMod P) := ⟨by
          intro h
          rw [CharP.cast_eq_zero_iff (ZMod P) P] at h
          exact hPm h⟩
        have hprim : IsPrimitiveRoot (u : ZMod P) m := isRoot_cyclotomic_iff.mp hu_eval_m
        exact hprim.pow_eq_one
      have h_mod_m : (a : ZMod P) ^ m = (b : ZMod P) ^ m := by
        have h_div_iff := test_div a b m P hq_b
        have hu_val : (u : ZMod P) = (a : ZMod P) * (b : ZMod P)⁻¹ := rfl
        rw [← hu_val] at h_div_iff
        exact h_div_iff.mpr hu_pow_m
      have hP_dvd_sub_m : (P : ℤ) ∣ (a ^ m : ℤ) - (b ^ m : ℤ) := test_sub_cast a b m P h_mod_m
      have hnP_eq : n / P = m * P ^ (k - 1) := by
        obtain ⟨j, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by lia : k ≠ 0)
        have : m * P ^ (j + 1) = (m * P ^ j) * P := by ring
        rw [hn_eq, this, Nat.mul_div_cancel _ hP.pos]
        have : j + 1 - 1 = j := rfl
        rw [this]
      have hP_dvd_A_sub_B : (P : ℤ) ∣ (a ^ (n / P) : ℤ) - (b ^ (n / P) : ℤ) := by
        rw [hnP_eq]
        exact test_geom2_div a b m P k hP_dvd_sub_m
      obtain ⟨c, hc⟩ := hP_dvd_A_sub_B
      have hA_eq : (a ^ (n / P) : ℤ) = (b ^ (n / P) : ℤ) + c * (P : ℤ) := by lia
      set B_int := (b ^ (n / P) : ℤ)
      have hB_not : ¬ (P : ℤ) ∣ B_int := by
        intro hPB
        have hPb : (P : ℤ) ∣ (b : ℤ) := Prime.dvd_of_dvd_pow (Int.prime_iff_natAbs_prime.mpr (by simpa using hP)) hPB
        have hPb_nat : P ∣ b := by exact_mod_cast hPb
        exact hq_b (by rwa [CharP.cast_eq_zero_iff (ZMod P) P])
      have h_geom_mod := geom_sum_mod_sq B_int c P hP_odd
      have h_geom_rewrite : (∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j)) =
          ∑ j ∈ Finset.range P, (B_int + c * (P : ℤ)) ^ j * B_int ^ (P - 1 - j) := by
        refine Finset.sum_congr rfl fun j _ => by rw [hA_eq]
      have h_not_p_sq : ¬ (P : ℤ) ^ 2 ∣ ∑ j ∈ Finset.range P, (a ^ (n / P) : ℤ) ^ j * (b ^ (n / P) : ℤ) ^ (P - 1 - j) := by
        rw [h_geom_rewrite]
        exact not_dvd_p_sq_geom_sum B_int c P hP_odd hB_not h_geom_mod
      have he1 : e = 1 := by
        rcases e with _ | _ | e
        · rw [pow_zero] at he; lia
        · rfl
        · exfalso
          have hp_sq_dvd : (P : ℤ) ^ 2 ∣ cycloVal n a b := by
            have hdvd_nat : P ^ 2 ∣ (cycloVal n a b).natAbs := by
              rw [he, show e + 2 = 2 + e by lia, pow_add]
              exact dvd_mul_right _ _
            have : (P ^ 2 : ℤ) ∣ ((cycloVal n a b).natAbs : ℤ) := by exact_mod_cast hdvd_nat
            rwa [Int.natAbs_of_nonneg (by lia)] at this
          exact h_not_p_sq (dvd_trans hp_sq_dvd h_dvd_geom)
      subst he1
      rw [pow_one] at he
      have hcyc_eq_P : cycloVal n a b = (P : ℤ) := by
        have : ((cycloVal n a b).natAbs : ℤ) = cycloVal n a b := Int.natAbs_of_nonneg (by lia)
        rw [← this, he]
      by_cases hba2 : b + 2 ≤ a
      · have h_gt := cycloVal_gt_P_of_ge_two n a b P hn3 hb hba2 hP hPn hP3
        rw [hcyc_eq_P] at h_gt
        lia
      · have hab1 : a = b + 1 := by lia
        by_cases hn6 : n = 6
        · subst hn6
          have hP6 : P = 3 := by
            have h_div : P ∣ 6 := hPn
            have : P ≤ 6 := Nat.le_of_dvd (by decide) h_div
            interval_cases P <;> revert hP hP2 h_div <;> decide
          subst hP6
          subst hab1
          have hb1 := cycloVal_six_sol b hb (by exact_mod_cast he)
          subst hb1
          exact h6 ⟨rfl, rfl, rfl⟩
        · by_cases hm1 : m = 1
          · subst hm1
            rw [one_mul] at hn_eq
            subst hn_eq
            subst hab1
            exact test_m_one b P k hb hP hP3 hk_ge1 (by exact_mod_cast hcyc_eq_P)
          · sorry
  obtain ⟨q, hq, hq_dvd, hqn⟩ := hex_prim
  exact ⟨q, hq, primitive_of_dvd_cycloVal a b n q hba hb hab hn hq hq_dvd hqn⟩

theorem exists_prime_add (a b n : Nat) (hba : b < a) (hb : 1 <= b) (hab : Nat.Coprime a b)
    (hn : 2 <= n) (h3 : Not (a = 2 /\ b = 1 /\ n = 3)) :
    exists q : Nat, q.Prime /\ (a ^ n + b ^ n) % q = 0 /\
      forall k : Nat, 1 <= k -> k < n -> Not ((a ^ k + b ^ k) % q = 0) := by
  have hn2 : 2 ≤ 2 * n := by lia
  have h2 : ¬ (2 * n = 2 ∧ ∃ t : ℕ, a + b = 2 ^ t) := by
    intro ⟨h2n, _⟩
    lia
  have h6 : ¬ (a = 2 ∧ b = 1 ∧ 2 * n = 6) := by
    intro ⟨ha, hb, h6⟩
    have : n = 3 := by lia
    exact h3 ⟨ha, hb, this⟩
  obtain ⟨q, hq, hq_dvd, hq_not⟩ := exists_prime_sub a b (2 * n) hba hb hab hn2 h2 h6
  refine ⟨q, hq, ?_, ?_⟩
  · have hq_dvd_nat : q ∣ a ^ (2 * n) - b ^ (2 * n) := Nat.dvd_of_mod_eq_zero hq_dvd
    have h_factor : a ^ (2 * n) - b ^ (2 * n) = (a ^ n + b ^ n) * (a ^ n - b ^ n) := by
      rw [mul_comm 2 n, pow_mul, pow_mul, Nat.sq_sub_sq]
    rw [h_factor] at hq_dvd_nat
    have hq_cases := (Nat.Prime.dvd_mul hq).mp hq_dvd_nat
    rcases hq_cases with hq1 | hq2
    · exact Nat.mod_eq_zero_of_dvd hq1
    · have hn_lt : n < 2 * n := by lia
      have hn_ge1 : 1 ≤ n := by lia
      have := hq_not n hn_ge1 hn_lt
      rw [← Nat.dvd_iff_mod_eq_zero] at this
      contradiction
  · intro k hk1 hkn hqk
    have hq_dvd_add : q ∣ a ^ k + b ^ k := Nat.dvd_of_mod_eq_zero hqk
    have hq_dvd_sub2k : q ∣ a ^ (2 * k) - b ^ (2 * k) := by
      have : a ^ (2 * k) - b ^ (2 * k) = (a ^ k + b ^ k) * (a ^ k - b ^ k) := by
        rw [mul_comm 2 k, pow_mul, pow_mul, Nat.sq_sub_sq]
      rw [this]
      exact dvd_mul_of_dvd_left hq_dvd_add _
    have h2k_lt : 2 * k < 2 * n := by lia
    have h2k_ge1 : 1 ≤ 2 * k := by lia
    have := hq_not (2 * k) h2k_ge1 h2k_lt
    rw [← Nat.dvd_iff_mod_eq_zero] at this
    exact this hq_dvd_sub2k

theorem card_divisors_le (a n : Nat) (ha : 2 <= a) (hn : 1 <= n) :
    n.divisors.card <= (a ^ n - 1).primeFactors.card + 2 := by
  haveI : Decidable (∃ t : ℕ, a + 1 = 2 ^ t) := Classical.dec _
  haveI : Decidable (a = 2) := Classical.dec _
  let E : Finset ℕ :=
    if a = 2 then {1, 6}
    else if ∃ t : ℕ, a + 1 = 2 ^ t then {1, 2}
    else {1}
  have hE_card : E.card ≤ 2 := by
    dsimp [E]
    split_ifs <;> decide
  have h1_in_E : 1 ∈ E := by
    dsimp [E]
    split_ifs <;> simp
  have h2_in_E : (∃ t : ℕ, a + 1 = 2 ^ t) → 2 ∈ E := by
    intro ht
    dsimp [E]
    split_ifs with h1
    · subst h1
      obtain ⟨t, ht2⟩ := ht
      have : 3 = 2 ^ t := ht2
      exact False.elim (not_exists_pow_two_eq_three ⟨t, this⟩)
    · simp
  have h6_in_E : a = 2 → 6 ∈ E := by
    intro ha2
    dsimp [E]
    split_ifs
    simp
  let U := n.divisors \ E
  have h_split : n.divisors.card ≤ U.card + 2 := by
    calc n.divisors.card ≤ U.card + E.card := by
          have := Finset.card_le_card_sdiff_add_card (s := n.divisors) (t := E)
          exact this
      _ ≤ U.card + 2 := Nat.add_le_add_left hE_card _
  have hU_prop : ∀ d ∈ U, 2 ≤ d ∧ d ∣ n ∧ (¬ (d = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t)) ∧
      (¬ (a = 2 ∧ 1 = 1 ∧ d = 6)) := by
    intro d hd
    rw [Finset.mem_sdiff] at hd
    have hd_div := hd.1
    rw [Nat.mem_divisors] at hd_div
    have hd_dvd : d ∣ n := hd_div.1
    have hd_ne0 : d ≠ 0 := by
      rintro rfl
      have := hd_div.1
      have : n = 0 := by lia
      lia
    have hd_ne1 : d ≠ 1 := fun h => hd.2 (h ▸ h1_in_E)
    have hd_ge2 : 2 ≤ d := by lia
    refine ⟨hd_ge2, hd_dvd, ?_, ?_⟩
    · rintro ⟨rfl, ht⟩
      exact hd.2 (h2_in_E ht)
    · rintro ⟨ha2, _, rfl⟩
      exact hd.2 (h6_in_E ha2)
  choose! f hf using fun d (hd : d ∈ U) =>
    exists_prime_sub a 1 d (by lia) (by lia) (Nat.coprime_one_right a)
      (hU_prop d hd).1 (hU_prop d hd).2.2.1 (hU_prop d hd).2.2.2
  have hf_in : ∀ d ∈ U, f d ∈ (a ^ n - 1).primeFactors := by
    intro d hd
    have hfd := hf d hd
    rw [Nat.mem_primeFactors]
    refine ⟨hfd.1, ?_, ?_⟩
    · have hd_dvd := (hU_prop d hd).2.1
      have hsub_dvd : a ^ d - 1 ∣ a ^ n - 1 := Nat.pow_sub_one_dvd_pow_sub_one a hd_dvd
      have hq_dvd : f d ∣ a ^ d - 1 := by
        have := hfd.2.1
        simp only [one_pow] at this
        exact Nat.dvd_of_mod_eq_zero this
      exact dvd_trans hq_dvd hsub_dvd
    · have : 2 ^ 1 ≤ a ^ n := by
        calc 2 ^ 1 ≤ a ^ 1 := by lia
        _ ≤ a ^ n := Nat.pow_le_pow_right (by lia) hn
      lia
  have hf_inj : ∀ d1 ∈ U, ∀ d2 ∈ U, f d1 = f d2 → d1 = d2 := by
    intro d1 hd1 d2 hd2 heq
    have hd1_ge2 := (hU_prop d1 hd1).1
    have hd2_ge2 := (hU_prop d2 hd2).1
    rcases lt_trichotomy d1 d2 with hlt | heq_d | hgt
    · exfalso
      have hfd2 := hf d2 hd2
      have hnot := hfd2.2.2 d1 (by lia) hlt
      simp only [one_pow] at hnot
      have hq1_dvd : f d1 ∣ a ^ d1 - 1 := by
        have := (hf d1 hd1).2.1
        simp only [one_pow] at this
        exact Nat.dvd_of_mod_eq_zero this
      rw [heq] at hq1_dvd
      exact hnot (Nat.mod_eq_zero_of_dvd hq1_dvd)
    · exact heq_d
    · exfalso
      have hfd1 := hf d1 hd1
      have hnot := hfd1.2.2 d2 (by lia) hgt
      simp only [one_pow] at hnot
      have hq2_dvd : f d2 ∣ a ^ d2 - 1 := by
        have := (hf d2 hd2).2.1
        simp only [one_pow] at this
        exact Nat.dvd_of_mod_eq_zero this
      rw [← heq] at hq2_dvd
      exact hnot (Nat.mod_eq_zero_of_dvd hq2_dvd)
  have h_card_le : U.card ≤ (a ^ n - 1).primeFactors.card :=
    Finset.card_le_card_of_injOn f hf_in hf_inj
  lia

theorem eq_prime_pow (a n q m : Nat) (ha : 2 <= a) (hn : 2 <= n) (hq : q.Prime) (hm : 2 <= m)
    (h : a ^ n - 1 = q ^ m) :
    a = 3 /\ n = 2 /\ q = 2 /\ m = 3 := by
  by_cases hn2 : n = 2
  · subst hn2
    obtain ⟨rfl, rfl, rfl⟩ := eq_prime_pow_of_n_eq_two a q m ha hq hm h
    exact ⟨rfl, rfl, rfl, rfl⟩
  have hn3 : 3 ≤ n := by lia
  have h2 : ¬ (n = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t) := fun ⟨hn_eq, _⟩ => hn2 hn_eq
  by_cases h6 : (a = 2 ∧ 1 = 1 ∧ n = 6)
  · obtain ⟨rfl, -, rfl⟩ := h6
    exfalso
    exact test_63_ne_prime_pow q m hq (by rw [← h]; decide)
  obtain ⟨p, hp, hp_dvd, hp_not⟩ := exists_prime_sub a 1 n (by lia) (by lia)
    (Nat.coprime_one_right a) (by lia) h2 h6
  have hp_dvd_pow : p ∣ q ^ m := by
    rw [← h]
    have : p ∣ a ^ n - 1 ^ n := Nat.dvd_of_mod_eq_zero hp_dvd
    simpa using this
  have hp_eq_q : p = q := by
    have : p ∣ q := hp.dvd_of_dvd_pow hp_dvd_pow
    rcases (Nat.dvd_prime hq).mp this with hp1 | hpq
    · exfalso; exact hp.ne_one hp1
    · exact hpq
  have hq_not_a_sub_one : ¬ (a - 1) % q = 0 := by
    rw [← hp_eq_q]
    have := hp_not 1 (by lia) (by lia)
    simpa using this
  have h_a_sub_dvd : a - 1 ∣ q ^ m := by
    rw [← h]
    exact Nat.sub_one_dvd_pow_sub_one a n
  have ha2 : a = 2 := by
    obtain ⟨u, hu_le, hu⟩ := (Nat.dvd_prime_pow hq).mp h_a_sub_dvd
    rcases u with _ | u
    · rw [pow_zero] at hu; lia
    · exfalso
      have : q ∣ a - 1 := by
        rw [hu, pow_succ]
        exact dvd_mul_left q _
      exact hq_not_a_sub_one (Nat.mod_eq_zero_of_dvd this)
  subst ha2
  exfalso
  exact no_sol_2_pow q m n hq hm (by lia) h

theorem primeFactors_eq (a m n : Nat) (ha : 2 <= a) (hm : 1 <= m) (hmn : m < n)
    (h : (a ^ m - 1).primeFactors = (a ^ n - 1).primeFactors) :
    m = 1 /\ n = 2 /\ exists t : Nat, a + 1 = 2 ^ t := by
  have hn : 2 ≤ n := by lia
  by_cases h2 : (n = 2 ∧ ∃ t : ℕ, a + 1 = 2 ^ t)
  · obtain ⟨rfl, ht⟩ := h2
    have hm1 : m = 1 := by lia
    exact ⟨hm1, rfl, ht⟩
  by_cases h6 : (a = 2 ∧ 1 = 1 ∧ n = 6)
  · obtain ⟨rfl, -, rfl⟩ := h6
    exfalso
    exact test_2_6 m hm hmn h
  exfalso
  obtain ⟨q, hq, hq_dvd, hq_not⟩ := exists_prime_sub a 1 n (by lia) (by lia)
    (Nat.coprime_one_right a) hn h2 h6
  have hq_in_n : q ∈ (a ^ n - 1).primeFactors := by
    rw [Nat.mem_primeFactors]
    refine ⟨hq, ?_, ?_⟩
    · have : q ∣ a ^ n - 1 ^ n := Nat.dvd_of_mod_eq_zero hq_dvd
      simpa using this
    · have : 2 ^ 1 ≤ a ^ n := by
        calc 2 ^ 1 ≤ a ^ 1 := by lia
        _ ≤ a ^ n := Nat.pow_le_pow_right (by lia) (by lia)
      lia
  have hq_in_m : q ∈ (a ^ m - 1).primeFactors := by
    rw [h]
    exact hq_in_n
  rw [Nat.mem_primeFactors] at hq_in_m
  have hq_dvd_m : q ∣ a ^ m - 1 := hq_in_m.2.1
  have hnot := hq_not m hm hmn
  simp only [one_pow] at hnot
  exact hnot (Nat.mod_eq_zero_of_dvd hq_dvd_m)

end TuringTask
