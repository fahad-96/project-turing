import Mathlib

open Lean Elab Command
elab "#names_containing " s:str : command => do
  let env ← getEnv
  for (n, _) in env.constants.toList do
    if (n.toString.splitOn s.getString).length > 1 then logInfo m!"{n}"

#names_containing "squarefreePart"
#names_containing "squarePart"
#names_containing "sq_mul"
#names_containing "squarefree_of_pos"
#names_containing "factorization_prod"
#names_containing "prod_factorization"
