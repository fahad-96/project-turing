# Cyclotomic polynomial discriminant investigation

`TuringTask/Basic.lean` was not modified. No `sorry`, `admit`, `native_decide`,
or added axioms are used.

## Result

The exact requested theorem was not completed. The checked file
`CyclotomicAttempt.lean` proves that the theorem follows from the missing
polynomial-discriminant formula. In particular, all coercions and the final
integer division cancellation are discharged there.

The remaining goal is exactly:

```lean
Polynomial.discr (Polynomial.cyclotomic n Int) =
  (-1) ^ (n.totient / 2) *
    ((n : Int) ^ n.totient /
      n.primeFactors.prod
        (fun p => (p : Int) ^ (n.totient / (p - 1))))
```

## Concrete blocker

`IsCyclotomicExtension.Rat.discr` computes `NumberField.discr K`, not
`Polynomial.discr (Polynomial.cyclotomic n Int)`. Mathlib provides the
integral cyclotomic power basis and identifies the number-field discriminant
with the algebra discriminant of any integral basis. However, environment
searches found no declaration identifying the algebra discriminant of a
power basis with the polynomial discriminant of its defining polynomial.

The tempting generic statement

```lean
Algebra.discr R pb.basis = Polynomial.discr pb.minpolyGen
```

is not true by `rfl`. The available `Algebra.discr_powerBasis_eq_norm` only
applies over fields and expresses the left side using the norm of the
derivative of `minpoly`; a further norm/resultant argument and an integral to
rational base-change argument would still be required. No named
norm/resultant bridge was found by declaration-name introspection.

## Relevant checked declarations

```lean
IsCyclotomicExtension.Rat.discr :
  forall (n : Nat) (K : Type u) [Field K] [CharZero K] [NeZero n]
    [IsCyclotomicExtension {n} Rat K],
    NumberField.discr K =
      (-1) ^ (n.totient / 2) *
        ((n : Int) ^ n.totient /
          (n.primeFactors.prod
            (fun p => p ^ (n.totient / (p - 1))) : Nat))

NumberField.discr_eq_discr :
  forall (K : Type u) [Field K] [NumberField K] (b : Module.Basis i Int
    (NumberField.RingOfIntegers K)),
    Algebra.discr Int b = NumberField.discr K

IsPrimitiveRoot.integralPowerBasis :
  IsPrimitiveRoot zeta n ->
    PowerBasis Int (NumberField.RingOfIntegers K)

IsPrimitiveRoot.minpoly_eq_cyclotomic_of_irreducible :
  IsPrimitiveRoot mu n -> Irreducible (Polynomial.cyclotomic n K) ->
    Polynomial.cyclotomic n K = minpoly K mu

Algebra.discr_powerBasis_eq_norm :
  Algebra.discr K pb.basis =
    (-1) ^ (Module.finrank K L * (Module.finrank K L - 1) / 2) *
      Algebra.norm K (Polynomial.aeval pb.gen
        (Polynomial.derivative (minpoly K pb.gen)))

Nat.prod_primeFactors_pow_totient_ediv_dvd :
  0 < n ->
    n.primeFactors.prod (fun p => p ^ (n.totient / (p - 1))) |
      n ^ n.totient

Int.ediv_mul_cancel : b | a -> a / b * b = a
```

The compiler output in `CyclotomicAttempt.lean` gives the fully elaborated
types from the installed Mathlib version.

## Offline verification

The following commands succeeded using only the supplied local Lean/Mathlib
environment:

```sh
lean TuringTask/Basic.lean
lean CyclotomicAttempt.lean
```

No network request was attempted and no dependency or cache was fetched.
