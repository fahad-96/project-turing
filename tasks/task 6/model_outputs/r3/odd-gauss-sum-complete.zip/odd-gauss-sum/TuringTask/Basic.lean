import OddGaussSum.Triangular
import OddGaussSum

open scoped BigOperators

namespace TuringTask

noncomputable def ex (x : Real) : Complex :=
  Complex.exp (2 * (Real.pi : Complex) * Complex.I * (x : Complex))

noncomputable def rt (n : Nat) : Complex :=
  if n % 4 = 1 then ((Real.sqrt (n : Real) : Real) : Complex)
  else Complex.I * ((Real.sqrt (n : Real) : Real) : Complex)

/-- Exact theorem 1 from the task, discharged by the spectral odd-modulus
quadratic Gauss sum development in `OddGaussSum`. -/
theorem sum_sq (n : Nat) (hn : n % 2 = 1) :
    Finset.sum (Finset.range n) (fun k : Nat => ex ((k : Real) ^ 2 / (n : Real))) = rt n := by
  have hodd : Odd n := Nat.odd_iff.mpr hn
  simpa [ex, rt, div_eq_mul_inv, mul_assoc] using OddGaussSum.sum_sq n hodd

theorem sum_tri (n : Nat) (hn : n % 2 = 1) :
    Finset.sum (Finset.range n) (fun k : Nat =>
        ex ((k : Real) * ((k : Real) + 1) / (2 * (n : Real)))) =
      ex (((n : Real) - 1) / (8 * (n : Real))) *
        ((Real.sqrt (n : Real) : Real) : Complex) := by
  have hodd : Odd n := Nat.odd_iff.mpr hn
  obtain ⟨q, hq⟩ := hodd
  subst n
  simpa [ex] using OddGaussSum.sum_tri_exp q

private noncomputable def quadraticGaussSum (p : Nat) [NeZero p]
    (a : ZMod p) : Complex :=
  ∑ x : ZMod p, ZMod.stdAddChar (a * x ^ 2)

private theorem odd_prime_ringChar_ne_two (p : Nat) [Fact p.Prime]
    (hodd : p ≠ 2) : ringChar (ZMod p) ≠ 2 := by
  rw [ZMod.ringChar_zmod_n]
  exact hodd

private theorem quadraticGaussSum_eq_weighted (p : Nat) [Fact p.Prime]
    (hodd : p ≠ 2) (a : ZMod p) (ha : a ≠ 0) :
    quadraticGaussSum p a =
      ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : Int) : Complex) * ZMod.stdAddChar (a * y) := by
  let ψ : AddChar (ZMod p) Complex := ZMod.stdAddChar
  have hchar : ringChar (ZMod p) ≠ 2 := odd_prime_ringChar_ne_two p hodd
  have hsumψ : ∑ y : ZMod p, ψ (a * y) = 0 := by
    have h := AddChar.sum_mulShift (ψ := ψ) a (ZMod.isPrimitive_stdAddChar p)
    simpa [mul_comm, ha] using h
  calc
    quadraticGaussSum p a = ∑ x : ZMod p, ψ (a * x ^ 2) := by rfl
    _ = ∑ y : ZMod p, ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * x ^ 2) := by
      symm
      exact Finset.sum_fiberwise Finset.univ (fun x : ZMod p => x ^ 2)
        (fun x => ψ (a * x ^ 2))
    _ = ∑ y : ZMod p,
        (((quadraticChar (ZMod p) y : Int) : Complex) * ψ (a * y) + ψ (a * y)) := by
      apply Finset.sum_congr rfl
      intro y _
      calc
        ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * x ^ 2) =
            ∑ x ∈ Finset.univ with x ^ 2 = y, ψ (a * y) := by
          apply Finset.sum_congr rfl
          intro x hx
          simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hx
          rw [hx]
        _ = ({x : ZMod p | x ^ 2 = y}.toFinset.card : Complex) * ψ (a * y) := by
          simp [Finset.sum_const, nsmul_eq_mul]
        _ = ((quadraticChar (ZMod p) y : Int) : Complex) * ψ (a * y) + ψ (a * y) := by
          have hroots := quadraticChar_card_sqrts hchar y
          have hrootsC : ({x : ZMod p | x ^ 2 = y}.toFinset.card : Complex) =
              ((quadraticChar (ZMod p) y : Int) : Complex) + 1 := by
            exact_mod_cast hroots
          rw [hrootsC]
          ring
    _ = ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : Int) : Complex) * ψ (a * y) := by
      rw [Finset.sum_add_distrib, hsumψ, add_zero]
    _ = ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : Int) : Complex) * ZMod.stdAddChar (a * y) := by
      rfl

private theorem sum_sq_mul_zmod (p : Nat) [Fact p.Prime] (hodd : p ≠ 2)
    (a : ZMod p) (ha : a ≠ 0) :
    quadraticGaussSum p a =
      ((quadraticChar (ZMod p) a : Int) : Complex) * quadraticGaussSum p 1 := by
  let ψ : AddChar (ZMod p) Complex := ZMod.stdAddChar
  let χ : MulChar (ZMod p) Int := quadraticChar (ZMod p)
  have hχsq : ((χ a : Int) : Complex) * ((χ a : Int) : Complex) = 1 := by
    have h := quadraticChar_sq_one (F := ZMod p) ha
    change χ a ^ 2 = 1 at h
    have h' : χ a * χ a = 1 := by simpa [pow_two] using h
    exact_mod_cast h'
  have hperm :
      (∑ y : ZMod p, ((χ (a * y) : Int) : Complex) * ψ (a * y)) =
        ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ y := by
    simpa using (Equiv.sum_comp (Equiv.mulLeft₀ a ha)
      (fun y : ZMod p => ((χ y : Int) : Complex) * ψ y))
  have hmul :
      ((χ a : Int) : Complex) *
          (∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y)) =
        ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ y := by
    rw [Finset.mul_sum]
    calc
      ∑ y : ZMod p, ((χ a : Int) : Complex) * (((χ y : Int) : Complex) * ψ (a * y)) =
          ∑ y : ZMod p, ((χ (a * y) : Int) : Complex) * ψ (a * y) := by
        apply Finset.sum_congr rfl
        intro y _
        rw [map_mul χ a y]
        push_cast
        ring
      _ = ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ y := hperm
  rw [quadraticGaussSum_eq_weighted p hodd a ha,
    quadraticGaussSum_eq_weighted p hodd 1 one_ne_zero]
  change (∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y)) =
    ((χ a : Int) : Complex) * ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (1 * y)
  simp only [one_mul]
  calc
    ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y) =
        1 * ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y) := by rw [one_mul]
    _ = (((χ a : Int) : Complex) * ((χ a : Int) : Complex)) *
          ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y) := by rw [hχsq]
    _ = ((χ a : Int) : Complex) *
          (((χ a : Int) : Complex) *
            ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ (a * y)) := by ring
    _ = ((χ a : Int) : Complex) *
          ∑ y : ZMod p, ((χ y : Int) : Complex) * ψ y := by rw [hmul]

private theorem finEquiv_eq_natCast (n : Nat) [NeZero n] (i : Fin n) :
    ZMod.finEquiv n i = (i.val : ZMod n) := by
  have hv : (ZMod.finEquiv n i).val = i.val := by
    cases n with
    | zero => exact (NeZero.ne 0 rfl).elim
    | succ n => rfl
  symm
  rw [← hv, ZMod.natCast_zmod_val]

private theorem ex_nat_div_eq_char (p k : Nat) [NeZero p] (hk : k < p) :
    ex ((k : Real) / (p : Real)) = ZMod.stdAddChar (k : ZMod p) := by
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply, ZMod.val_natCast_of_lt hk]
  simp only [ex]
  congr 1
  push_cast
  ring

private theorem ex_int_mul_eq_char (p k : Nat) [NeZero p] (hk : k < p)
    (a : Int) :
    ex ((a : Real) * (k : Real) / (p : Real)) =
      ZMod.stdAddChar ((a : ZMod p) * (k : ZMod p)) := by
  rw [show ((a : ZMod p) * (k : ZMod p)) = a • (k : ZMod p) by
    simp [zsmul_eq_mul]]
  rw [AddChar.map_zsmul_eq_zpow, ← ex_nat_div_eq_char p k hk]
  simp only [ex]
  rw [← Complex.exp_int_mul]
  congr 1
  push_cast
  ring

private theorem ex_int_mul_sq_eq_char (p k : Nat) [NeZero p] (hp : 1 < p)
    (a : Int) :
    ex ((a : Real) * (k : Real) ^ 2 / (p : Real)) =
      ZMod.stdAddChar ((a : ZMod p) * (k : ZMod p) ^ 2) := by
  have hsq :
      ex ((k : Real) ^ 2 / (p : Real)) = ZMod.stdAddChar ((k : ZMod p) ^ 2) := by
    simp only [ex]
    letI : Fact (1 < p) := ⟨hp⟩
    have hpC : (p : Complex) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt (lt_trans Nat.zero_lt_one hp))
    have hbase : ZMod.stdAddChar (1 : ZMod p) =
        Complex.exp (2 * (Real.pi : Complex) * Complex.I / p) := by
      rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply, ZMod.val_one]
      congr 1
      ring
    rw [show ((k : ZMod p) ^ 2) = k ^ 2 • (1 : ZMod p) by
      push_cast
      simp [nsmul_eq_mul]]
    rw [AddChar.map_nsmul_eq_pow, hbase, ← Complex.exp_nat_mul]
    congr 1
    push_cast
    field_simp
  rw [show ((a : ZMod p) * (k : ZMod p) ^ 2) = a • ((k : ZMod p) ^ 2) by
    simp [zsmul_eq_mul]]
  rw [AddChar.map_zsmul_eq_zpow, ← hsq]
  simp only [ex]
  rw [← Complex.exp_int_mul]
  congr 1
  push_cast
  ring

private theorem range_sum_sq_mul_eq_zmod (p : Nat) [Fact p.Prime] (a : Int) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        ex ((a : Real) * (k : Real) ^ 2 / (p : Real))) =
      quadraticGaussSum p (a : ZMod p) := by
  have hp : 1 < p := Fact.out
  rw [← Fin.sum_univ_eq_sum_range]
  calc
    (∑ k : Fin p, ex ((a : Real) * (k.val : Real) ^ 2 / (p : Real))) =
        ∑ k : Fin p, ZMod.stdAddChar ((a : ZMod p) * (ZMod.finEquiv p k) ^ 2) := by
      apply Finset.sum_congr rfl
      intro k _
      rw [finEquiv_eq_natCast]
      exact ex_int_mul_sq_eq_char p k.val hp a
    _ = quadraticGaussSum p (a : ZMod p) := by
      simpa [quadraticGaussSum] using
        Equiv.sum_comp (ZMod.finEquiv p).toEquiv
          (fun x : ZMod p => ZMod.stdAddChar ((a : ZMod p) * x ^ 2))

private theorem range_sum_legendre_eq_zmod (p : Nat) [Fact p.Prime] (a : Int) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        (legendreSym p (k : Int) : Complex) *
          ex ((a : Real) * (k : Real) / (p : Real))) =
      ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : Int) : Complex) *
          ZMod.stdAddChar ((a : ZMod p) * y) := by
  rw [← Fin.sum_univ_eq_sum_range]
  calc
    (∑ k : Fin p,
        (legendreSym p (k.val : Int) : Complex) *
          ex ((a : Real) * (k.val : Real) / (p : Real))) =
        ∑ k : Fin p,
          ((quadraticChar (ZMod p) (ZMod.finEquiv p k) : Int) : Complex) *
            ZMod.stdAddChar ((a : ZMod p) * ZMod.finEquiv p k) := by
      apply Finset.sum_congr rfl
      intro k _
      rw [finEquiv_eq_natCast, ex_int_mul_eq_char p k.val k.isLt a]
      have hk : (((k.val : Int) : ZMod p)) = (k.val : ZMod p) := by norm_num
      simp only [legendreSym, hk]
    _ = ∑ y : ZMod p,
        ((quadraticChar (ZMod p) y : Int) : Complex) *
          ZMod.stdAddChar ((a : ZMod p) * y) := by
      exact Equiv.sum_comp (ZMod.finEquiv p).toEquiv
        (fun y : ZMod p =>
          ((quadraticChar (ZMod p) y : Int) : Complex) *
            ZMod.stdAddChar ((a : ZMod p) * y))

private theorem sum_legendre_one_eval (p : Nat) [hp : Fact p.Prime] (hodd : p ≠ 2) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        (legendreSym p (k : Int) : Complex) * ex ((k : Real) / (p : Real))) = rt p := by
  have hp0 : (1 : ZMod p) ≠ 0 := one_ne_zero
  have hrange := range_sum_legendre_eq_zmod p (1 : Int)
  simp only [Int.cast_one, one_mul, Int.cast_natCast] at hrange
  rw [hrange]
  have hweighted :
      (∑ y : ZMod p,
          ((quadraticChar (ZMod p) y : Int) : Complex) * ZMod.stdAddChar y) =
        quadraticGaussSum p 1 := by
    simpa using (quadraticGaussSum_eq_weighted p hodd 1 hp0).symm
  rw [hweighted]
  have h1 : quadraticGaussSum p 1 =
      Finset.sum (Finset.range p) (fun k : Nat =>
        ex ((k : Real) ^ 2 / (p : Real))) := by
    simpa using (range_sum_sq_mul_eq_zmod p (1 : Int)).symm
  rw [h1]
  have hpodd : Odd p := hp.out.odd_of_ne_two hodd
  simpa using sum_sq p (Nat.odd_iff.mp hpodd)

private theorem sum_sq_mul_unit_eval (p : Nat) [hp : Fact p.Prime] (hodd : p ≠ 2)
    (a : Int) (ha : ¬ (p : Int) ∣ a) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        ex ((a : Real) * (k : Real) ^ 2 / (p : Real))) =
      (legendreSym p a : Complex) * rt p := by
  have ha0 : (a : ZMod p) ≠ 0 := by
    rw [ne_eq, ZMod.intCast_zmod_eq_zero_iff_dvd]
    exact ha
  rw [range_sum_sq_mul_eq_zmod p a, sum_sq_mul_zmod p hodd (a : ZMod p) ha0]
  have hpodd : Odd p := hp.out.odd_of_ne_two hodd
  have h1 : quadraticGaussSum p 1 =
      Finset.sum (Finset.range p) (fun k : Nat =>
        ex ((k : Real) ^ 2 / (p : Real))) := by
    simpa using (range_sum_sq_mul_eq_zmod p (1 : Int)).symm
  rw [h1, sum_sq p (Nat.odd_iff.mp hpodd)]
  simp only [legendreSym]

/-- The exact scaled Legendre sum for an odd prime, including the case in
which the scale vanishes modulo the prime. -/
theorem sum_legendre (p : Nat) [Fact p.Prime] (hp : p % 2 = 1) (a : Int) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        (legendreSym p (k : Int) : Complex) *
          ex ((a : Real) * (k : Real) / (p : Real))) =
      (legendreSym p a : Complex) * rt p := by
  have hp2 : p ≠ 2 := by omega
  rw [range_sum_legendre_eq_zmod p a]
  by_cases ha0 : (a : ZMod p) = 0
  · have hchar : ringChar (ZMod p) ≠ 2 := odd_prime_ringChar_ne_two p hp2
    have hsumZ : ∑ y : ZMod p, quadraticChar (ZMod p) y = 0 :=
      quadraticChar_sum_zero hchar
    have hsumC :
        ∑ y : ZMod p, ((quadraticChar (ZMod p) y : Int) : Complex) = 0 := by
      exact_mod_cast hsumZ
    have haLeg : legendreSym p a = 0 := by
      simp only [legendreSym]
      rw [ha0]
      exact quadraticChar_zero
    rw [haLeg]
    simp only [Int.cast_zero, zero_mul]
    rw [ha0]
    simp only [zero_mul, AddChar.map_zero_eq_one, mul_one]
    exact hsumC
  · have hweighted := quadraticGaussSum_eq_weighted p hp2 (a : ZMod p) ha0
    rw [← hweighted]
    have ha : ¬ (p : Int) ∣ a := by
      simpa [ZMod.intCast_zmod_eq_zero_iff_dvd] using ha0
    rw [← range_sum_sq_mul_eq_zmod p a]
    exact sum_sq_mul_unit_eval p hp2 a ha

private theorem odd_prime_not_dvd (p q : Nat) [Fact p.Prime] [Fact q.Prime]
    (hpq : p ≠ q) : ¬ (p : Int) ∣ (q : Int) := by
  norm_cast
  intro h
  rcases (Nat.dvd_prime (Fact.out : q.Prime)).mp h with hp1 | hpq'
  · exact (Fact.out : p.Prime).ne_one hp1
  · exact hpq hpq'

private theorem rt_reciprocity (p q : Nat) [Fact p.Prime] [Fact q.Prime]
    (hp : p % 2 = 1) (hq : q % 2 = 1) (hpq : p ≠ q) :
    ((legendreSym p (q : Int) : Complex) * rt p) *
        ((legendreSym q (p : Int) : Complex) * rt q) = rt (p * q) := by
  have hp2 : p ≠ 2 := by omega
  have hq2 : q ≠ 2 := by omega
  have hqp0 : ((q : Int) : ZMod p) ≠ 0 := by
    rw [ne_eq, ZMod.intCast_zmod_eq_zero_iff_dvd]
    exact odd_prime_not_dvd p q hpq
  have hpq0 : ((p : Int) : ZMod q) ≠ 0 := by
    rw [ne_eq, ZMod.intCast_zmod_eq_zero_iff_dvd]
    exact odd_prime_not_dvd q p hpq.symm
  have hpsqZ : legendreSym p (q : Int) ^ 2 = 1 := legendreSym.sq_one p hqp0
  have hqsqZ : legendreSym q (p : Int) ^ 2 = 1 := legendreSym.sq_one q hpq0
  have hpsq :
      (legendreSym p (q : Int) : Complex) *
          (legendreSym p (q : Int) : Complex) = 1 := by
    exact_mod_cast (show legendreSym p (q : Int) * legendreSym p (q : Int) = 1 by
      simpa [pow_two] using hpsqZ)
  have hqsq :
      (legendreSym q (p : Int) : Complex) *
          (legendreSym q (p : Int) : Complex) = 1 := by
    exact_mod_cast (show legendreSym q (p : Int) * legendreSym q (p : Int) = 1 by
      simpa [pow_two] using hqsqZ)
  have hpsqPow : (legendreSym p (q : Int) : Complex) ^ 2 = 1 := by
    simpa [pow_two] using hpsq
  have hqsqPow : (legendreSym q (p : Int) : Complex) ^ 2 = 1 := by
    simpa [pow_two] using hqsq
  have hsqrtR : Real.sqrt ((p * q : Nat) : Real) =
      Real.sqrt (p : Real) * Real.sqrt (q : Real) := by
    rw [Nat.cast_mul, Real.sqrt_mul (by positivity)]
  have hsqrt : ((Real.sqrt ((p * q : Nat) : Real) : Real) : Complex) =
      ((Real.sqrt (p : Real) : Real) : Complex) *
        ((Real.sqrt (q : Real) : Real) : Complex) := by
    simpa using congrArg (fun x : Real => (x : Complex)) hsqrtR
  have hp4 : p % 4 = 1 ∨ p % 4 = 3 := by omega
  have hq4 : q % 4 = 1 ∨ q % 4 = 3 := by omega
  rcases hp4 with hp4 | hp4 <;> rcases hq4 with hq4 | hq4
  · have hpq4 : (p * q) % 4 = 1 := by norm_num [Nat.mul_mod, hp4, hq4]
    have hrecZ := legendreSym.quadratic_reciprocity_one_mod_four hp4 hq2
    have hrec : (legendreSym q (p : Int) : Complex) =
        (legendreSym p (q : Int) : Complex) := by exact_mod_cast hrecZ
    simp [rt, hp4, hq4, hpq4]
    rw [hrec]
    ring_nf
    rw [hpsqPow]
    ring
  · have hpq4 : (p * q) % 4 = 3 := by norm_num [Nat.mul_mod, hp4, hq4]
    have hrecZ := legendreSym.quadratic_reciprocity_one_mod_four hp4 hq2
    have hrec : (legendreSym q (p : Int) : Complex) =
        (legendreSym p (q : Int) : Complex) := by exact_mod_cast hrecZ
    simp [rt, hp4, hq4, hpq4]
    rw [hrec]
    ring_nf
    rw [hpsqPow]
    ring
  · have hpq4 : (p * q) % 4 = 3 := by norm_num [Nat.mul_mod, hp4, hq4]
    have hrecZ := legendreSym.quadratic_reciprocity_one_mod_four hq4 hp2
    have hrec : (legendreSym p (q : Int) : Complex) =
        (legendreSym q (p : Int) : Complex) := by exact_mod_cast hrecZ
    simp [rt, hp4, hq4, hpq4]
    rw [hrec]
    ring_nf
    rw [hqsqPow]
    ring
  · have hpq4 : (p * q) % 4 = 1 := by norm_num [Nat.mul_mod, hp4, hq4]
    have hrecZ := legendreSym.quadratic_reciprocity_three_mod_four hp4 hq4
    have hrec : (legendreSym q (p : Int) : Complex) =
        -(legendreSym p (q : Int) : Complex) := by exact_mod_cast hrecZ
    simp [rt, hp4, hq4, hpq4]
    rw [hrec]
    ring_nf
    rw [hpsqPow]
    norm_num

/-- Quadratic reciprocity in the form of a product of two exactly evaluated
scaled quadratic Gauss sums. -/
theorem sum_sq_mul (p q : Nat) [Fact p.Prime] [Fact q.Prime]
    (hp : p % 2 = 1) (hq : q % 2 = 1) (hpq : p ≠ q) :
    Finset.sum (Finset.range p) (fun k : Nat =>
        ex ((q : Real) * (k : Real) ^ 2 / (p : Real))) *
      Finset.sum (Finset.range q) (fun k : Nat =>
        ex ((p : Real) * (k : Real) ^ 2 / (q : Real))) =
      rt (p * q) := by
  have hp2 : p ≠ 2 := by omega
  have hq2 : q ≠ 2 := by omega
  have hpqD : ¬ (p : Int) ∣ (q : Int) := odd_prime_not_dvd p q hpq
  have hqpD : ¬ (q : Int) ∣ (p : Int) := odd_prime_not_dvd q p hpq.symm
  rw [show Finset.sum (Finset.range p) (fun k : Nat =>
      ex ((q : Real) * (k : Real) ^ 2 / (p : Real))) =
        (legendreSym p (q : Int) : Complex) * rt p by
      simpa using sum_sq_mul_unit_eval p hp2 (q : Int) hpqD]
  rw [show Finset.sum (Finset.range q) (fun k : Nat =>
      ex ((p : Real) * (k : Real) ^ 2 / (q : Real))) =
        (legendreSym q (p : Int) : Complex) * rt q by
      simpa using sum_sq_mul_unit_eval q hq2 (p : Int) hqpD]
  exact rt_reciprocity p q hp hq hpq

end TuringTask
