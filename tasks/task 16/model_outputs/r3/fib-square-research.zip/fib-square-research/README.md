# Fibonacci squares: Lean/Mathlib proof research

## Status

`FibSquareResearch.lean` is a kernel-checked, unrestricted reduction of

```lean
Nat.fib n = x ^ 2 -> n = 0 ∨ n = 1 ∨ n = 2 ∨ n = 12
```

to two explicitly stated Ljunggren quartic classifications. It contains no
`sorry`, `admit`, `native_decide`, or added axiom. It deliberately does not
claim that Mathlib already proves the two quartic classifications.

## Exact reduction

Set

```text
L_n = 2 F_(n+1) - F_n.
```

Mathlib supplies the Cassini form

```lean
Int.fib_add_sq_sub_fib_mul_fib_add_two_mul
```

which, at `x = n`, `a = 1`, says

```text
F_(n+1)^2 - F_n F_(n+2) = (-1)^n.
```

Using `F_(n+2) = F_n + F_(n+1)` and expanding gives the verified identity

```text
L_n^2 - 5 F_n^2 = 4 (-1)^n.                 (1)
```

If `F_n = x^2`, (1) becomes one of these equations:

```text
n odd:   L_n^2 + 4 = 5 x^4,
n even:  L_n^2     = 5 x^4 + 4.
```

The exact required classifications (with nonnegative `y`) are:

```text
y^2 + 4 = 5 x^4  -> (x,y) = (1,1),
y^2 = 5 x^4 + 4  -> (x,y) = (0,2), (1,3), or (12,322).
```

These imply `F_n` is respectively `1`, or one of `0,1,144`. Mathlib's
`Nat.fib_pos`, `Nat.fib_mono`, and `Nat.fib_strictMonoOn` then recover the
indices. The whole implication is checked as
`FibSquare.classification_of_ljunggren`.

## Why this is the real obstruction

The local Mathlib environment has Fibonacci addition, doubling, gcd,
coprimality, monotonicity, and Cassini identities. It has a Pell API for the
norm-one equation and Pythagorean-triple classification. It does not have a
square-Fibonacci theorem, either Ljunggren quartic theorem above, or a general
kernel-checked integral-point solver.

Ordinary modular checking cannot finish the unrestricted theorem. For every
finite set of Fibonacci periods there are infinitely many indices congruent
to an allowed index (for example `1`) modulo all those periods. A modular
sieve is useful only after a proved global bound or as one step in a descent.

Likewise, reducing (1) to the Pell equations of norm `+4` and `-4` merely
reparametrizes their solutions as `(L_n,F_n)`; it does not prove which second
coordinates are squares.

## Feasible completion routes

### 1. Formalize Pocklington/Ljunggren descent

This is the most self-contained route and the recommended one. Isolate the
quartics in `Ljunggren.lean`, work over `Int`, normalize signs immediately,
and prove the two displayed classifiers by well-founded descent on `x` (or
the positive Pell coordinate). The reusable Mathlib pieces are:

```lean
Int.gcd
Nat.Coprime
PythagoreanTriple.classification
PythagoreanTriple.coprime_classification
Int.fib_add_sq_sub_fib_mul_fib_add_two_mul
ring_nf
nlinarith
omega
```

The proof must include, rather than assume, the parity and gcd side
conditions that make the descent integral. Package the descent step as a
lemma returning either one of the exceptional pairs or a new solution with
strictly smaller positive `x`; then invoke `Nat.strong_induction_on`. This is
well suited to Lean because termination becomes an explicit inequality and
all final exceptional branches are `norm_num` checks.

Useful exact algebraic forms are:

```text
y^2 - 5 z^2 = ±4, with z = x^2,
(y - 2)(y + 2) = 5 x^4                         (+4 case),
y^2 + 2^2 = 5 x^4                              (-4 case),
(5xy)^2 = (5x^2)^3 + 20(5x^2)                 (+4 elliptic form),
(5xy)^2 = (5x^2)^3 - 20(5x^2)                 (-4 elliptic form).
```

The first factorization gives `gcd(y-2,y+2) | 4`; this sharply restricts the
coprime fourth-power factors. The sum-of-two-squares form can use Mathlib's
primitive Pythagorean/Gaussian-integer infrastructure. A formalization should
follow a complete published descent line by line; inventing a shortened
descent is the highest-risk part of the project.

### 2. Elliptic integral-point certificate

The substitutions

```text
X = 5 x^2,  Y = 5 x y
```

send the quartics to `Y^2 = X^3 ± 20X`, with the extra condition that
`X / 5` is a square. This permits a certificate approach, but the certificate
checker still has to prove Mordell-Weil generation and integral-point
exhaustion. The supplied Mathlib does not provide a turnkey tactic for that,
so this route is practical only if a small, independently checked 2-descent
verifier is implemented.

### 3. Explicit bound plus finite reflection

After a theorem proving `x <= B` or `n <= B`, define a Boolean checker over
`Finset.range (B+1)` and prove its specification by induction. `decide` or
`norm_num` can close the resulting concrete finite statement. This is
kernel-checkable and does not require `native_decide`. The hard part remains
the proved bound: Mathlib lacks the linear-forms/Thue machinery needed to
obtain one cheaply. A finite check without that bound is not a proof.

## Alternative Fibonacci factorization

For an even index, Mathlib already has

```text
F_(2m) = F_m (2F_(m+1)-F_m) = F_m L_m.
```

Also

```text
gcd(F_m,L_m) = gcd(F_m,2),
L_(2m) = L_m^2 - 2(-1)^m,
L_(2m+1) = L_m L_(m+1) - (-1)^m.
```

These support the classical split into square Lucas numbers and twice-square
Lucas numbers. They do not remove the quartic obstruction: the simultaneous
square/twice-square factors lead back to the same Ljunggren equations. This
route requires more gcd bookkeeping than identity (1), so it is not the
preferred Lean architecture.

## Offline checking

The project intentionally uses the supplied local Mathlib path and therefore
is not self-contained on an arbitrary machine. In the supplied environment:

```bash
lean FibSquareResearch.lean
```

No network access or dependency download is needed.
