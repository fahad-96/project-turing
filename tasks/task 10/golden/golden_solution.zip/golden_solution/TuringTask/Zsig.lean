import Mathlib
import TuringTask.Size

/-!
# Zsigmondy's theorem

`zsigmondy`: for coprime `a > b ≥ 1` and `n ≥ 2`, outside the cases `n = 2` with `a + b` a power
of `2` and `(a, b, n) = (2, 1, 6)`, some prime divides `a ^ n - b ^ n` and no `a ^ k - b ^ k`
with `1 ≤ k < n`.
-/

open Polynomial Finset

namespace TuringTask

/-! ### Existence of a primitive prime divisor -/

theorem exists_good_prime (a b n : ℕ) (hba : b < a) (hb : 0 < b) (hcop : Nat.Coprime a b)
    (hn3 : 3 ≤ n) (h6 : ¬ (a = 2 ∧ b = 1 ∧ n = 6)) :
    ∃ q : ℕ, q.Prime ∧ (q : ℤ) ∣ hcyc n a b ∧ ¬ q ∣ n := by
  by_contra hcon
  push Not at hcon
  have hn : 0 < n := by omega
  obtain ⟨N, hN⟩ : ∃ N : ℕ, hcyc n a b = N :=
    ⟨(hcyc n a b).toNat, (Int.toNat_of_nonneg (hcyc_pos n a b hb hba).le).symm⟩
  have hN1 : 1 < N := by
    have h := hcyc_gt n a b (by omega) hb hba
    have hab' : (1 : ℝ) ≤ (a : ℝ) - b := by
      have : (b : ℝ) + 1 ≤ a := by exact_mod_cast Nat.succ_le_of_lt hba
      linarith
    have h1 : (1 : ℝ) ≤ ((a : ℝ) - b) ^ n.totient := one_le_pow₀ hab'
    rw [hN] at h
    push_cast at h
    exact_mod_cast h1.trans_lt h
  obtain ⟨q, hqp, hqN⟩ := Nat.exists_prime_and_dvd (show N ≠ 1 by omega)
  have hqZ : (q : ℤ) ∣ hcyc n a b := by
    rw [hN]
    exact_mod_cast hqN
  have hqn := hcon q hqp hqZ
  obtain ⟨k, m, hk, hqm, hnkm, hmq, -⟩ := structure_of_dvd hqp hb hba hcop hn hqZ hqn
  have hm0 : 0 < m := Nat.pos_of_ne_zero (by rintro rfl; rw [mul_zero] at hnkm; omega)
  -- every prime factor of `N` equals `q`
  have huniq : ∀ {d : ℕ}, d.Prime → d ∣ N → d = q := by
    intro d hd hdN
    have hdZ : (d : ℤ) ∣ hcyc n a b := by
      rw [hN]
      exact_mod_cast hdN
    have hdn := hcon d hd hdZ
    obtain ⟨k', m', -, -, hnkm', hmd', -⟩ := structure_of_dvd hd hb hba hcop hn hdZ hdn
    by_contra hne
    have hm'0 : 0 < m' := Nat.pos_of_ne_zero (by rintro rfl; rw [mul_zero] at hnkm'; omega)
    have hq_m' : q ∣ m' := by
      have h1 : q ∣ d ^ k' * m' := by
        rw [← hnkm']
        exact hqn
      rcases (Nat.Prime.dvd_mul hqp).mp h1 with h | h
      · exact absurd ((Nat.prime_dvd_prime_iff_eq hqp hd).mp (hqp.dvd_of_dvd_pow h)).symm hne
      · exact h
    have hd_m : d ∣ m := by
      have h1 : d ∣ q ^ k * m := by
        rw [← hnkm]
        exact hdn
      rcases (Nat.Prime.dvd_mul hd).mp h1 with h | h
      · exact absurd ((Nat.prime_dvd_prime_iff_eq hd hqp).mp (hd.dvd_of_dvd_pow h)) hne
      · exact h
    have h1 : q ≤ m' := Nat.le_of_dvd hm'0 hq_m'
    have h2 : m' ≤ d - 1 := Nat.le_of_dvd (by have := hd.two_le; omega) hmd'
    have h3 : d ≤ m := Nat.le_of_dvd hm0 hd_m
    have h4 : m ≤ q - 1 := Nat.le_of_dvd (by have := hqp.two_le; omega) hmq
    omega
  have hNpow : N = q ^ N.primeFactorsList.length :=
    Nat.eq_prime_pow_of_unique_prime_dvd (by omega) huniq
  obtain ⟨e, he⟩ : ∃ e, e = N.primeFactorsList.length := ⟨_, rfl⟩
  rw [← he] at hNpow
  have hsq := not_sq_dvd_hcyc hqp hb hba hcop hn3 hqZ hqn
  have hsize := size_bound hqp hb hba hk hqm hnkm hmq hn3 h6
  rw [hN] at hsq hsize
  rcases Nat.lt_or_ge e 2 with he2 | he2
  · interval_cases e <;> simp at hNpow <;> omega
  · apply hsq
    rw [hNpow]
    exact_mod_cast pow_dvd_pow q he2

theorem cast_pow_sub (a b n : ℕ) (hab : b ≤ a) :
    ((a ^ n - b ^ n : ℕ) : ℤ) = (a : ℤ) ^ n - (b : ℤ) ^ n := by
  rw [Nat.cast_sub (Nat.pow_le_pow_left hab n), Nat.cast_pow, Nat.cast_pow]

/-- Zsigmondy's theorem for `a ^ n - b ^ n`. -/
theorem zsigmondy (a b n : ℕ) (hba : b < a) (hb : 1 ≤ b) (hcop : Nat.Coprime a b)
    (hn : 2 ≤ n) (h2 : ¬ (n = 2 ∧ ∃ t : ℕ, a + b = 2 ^ t)) (h6 : ¬ (a = 2 ∧ b = 1 ∧ n = 6)) :
    ∃ q : ℕ, q.Prime ∧ q ∣ a ^ n - b ^ n ∧
      ∀ k : ℕ, 1 ≤ k → k < n → ¬ q ∣ a ^ k - b ^ k := by
  rcases Nat.lt_or_ge n 3 with hn2 | hn3
  · obtain rfl : n = 2 := by omega
    obtain ⟨q, hq, hqab, hq2⟩ : ∃ q, q.Prime ∧ q ∣ a + b ∧ q ≠ 2 := by
      by_contra hcon
      push Not at hcon
      exact h2 ⟨rfl, _, Nat.eq_prime_pow_of_unique_prime_dvd (by omega)
        (fun hd hdab => hcon _ hd hdab)⟩
    refine ⟨q, hq, ?_, ?_⟩
    · have h : (q : ℤ) ∣ (a : ℤ) ^ 2 - (b : ℤ) ^ 2 := by
        have : (q : ℤ) ∣ (a : ℤ) + b := by exact_mod_cast hqab
        exact this.trans ⟨(a : ℤ) - b, by ring⟩
      rw [← cast_pow_sub a b 2 hba.le] at h
      exact_mod_cast h
    · intro k hk1 hk2 hdvd
      obtain rfl : k = 1 := by omega
      rw [pow_one, pow_one] at hdvd
      have h2a : q ∣ 2 * a := by
        have := Nat.dvd_add hqab hdvd
        rwa [show a + b + (a - b) = 2 * a by omega] at this
      have h2b : q ∣ 2 * b := by
        have := Nat.dvd_sub hqab hdvd
        rwa [show a + b - (a - b) = 2 * b by omega] at this
      have hq2' : ¬ q ∣ 2 := fun h => hq2 ((Nat.prime_dvd_prime_iff_eq hq Nat.prime_two).mp h)
      have hqa : q ∣ a := ((Nat.Prime.dvd_mul hq).mp h2a).resolve_left hq2'
      have hqb : q ∣ b := ((Nat.Prime.dvd_mul hq).mp h2b).resolve_left hq2'
      have := Nat.dvd_gcd hqa hqb
      rw [Nat.Coprime.gcd_eq_one hcop] at this
      exact hq.one_lt.ne' (Nat.dvd_one.mp this)
  · obtain ⟨q, hq, hqN, hqn⟩ := exists_good_prime a b n hba (by omega) hcop hn3 h6
    refine ⟨q, hq, ?_, primitive_of_not_dvd hq (by omega) hba hcop (by omega) hqN hqn⟩
    have h := hqN.trans (hcyc_dvd n a b (by omega) (by omega))
    rw [← cast_pow_sub a b n hba.le] at h
    exact_mod_cast h

end TuringTask
