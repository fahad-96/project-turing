# TuringTask

This archive is an incomplete project scaffold.  The supplied Mathlib contains
generic Jacobi and Gauss sum machinery, but not the order-three Jacobi-sum
evaluation or cubic reciprocity result needed to prove the five requested
theorems.  No `sorry`, new axiom, or other kernel bypass has been inserted.

The scaffold can be checked offline in the supplied environment with:

```text
lean TuringTask/Basic.lean
lake build
```
