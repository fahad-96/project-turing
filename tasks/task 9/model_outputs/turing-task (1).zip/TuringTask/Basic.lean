import Mathlib

open scoped Classical

namespace TuringTask

open Finset Polynomial

/-! ### Section 1: Uniqueness of L -/

lemma L_unique (p : ℕ) [hp : Fact p.Prime] (L M L' M' : ℤ)
    (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1)
    (hLM' : 4 * (p : ℤ) = L' ^ 2 + 27 * M' ^ 2) (hL' : L' % 3 = 1) :
    L = L' := by
  have hp_pos : (p : ℤ) > 0 := Nat.cast_pos.mpr hp.out.pos
  have hp_sq_pos : (p : ℤ)^2 > 0 := sq_pos_of_pos hp_pos
  have hid1 : 27 * ((L * M' - L' * M) * (L * M' + L' * M)) = 27 * (4 * (p : ℤ) * (M'^2 - M^2)) := by
    linear_combination (L'^2 - 4 * (p : ℤ)) * hLM + (4 * (p : ℤ) - L^2) * hLM'
  have hid1' : (L * M' - L' * M) * (L * M' + L' * M) = 4 * (p : ℤ) * (M'^2 - M^2) :=
    mul_left_cancel₀ (by decide) hid1
  have hid2 : (L * L' + 27 * M * M')^2 + 27 * (L * M' - L' * M)^2 = 16 * (p : ℤ)^2 := by
    have H : (L * L' + 27 * M * M')^2 + 27 * (L * M' - L' * M)^2 = (L ^ 2 + 27 * M ^ 2) * (L' ^ 2 + 27 * M' ^ 2) := by ring
    rw [H, ← hLM, ← hLM']
    ring
  have hid3 : (L * L' - 27 * M * M')^2 + 27 * (L * M' + L' * M)^2 = 16 * (p : ℤ)^2 := by
    have H : (L * L' - 27 * M * M')^2 + 27 * (L * M' + L' * M)^2 = (L ^ 2 + 27 * M ^ 2) * (L' ^ 2 + 27 * M' ^ 2) := by ring
    rw [H, ← hLM, ← hLM']
    ring
  have hdvd : (p : ℤ) ∣ (L * M' - L' * M) * (L * M' + L' * M) := by
    rw [hid1']
    use 4 * (M'^2 - M^2)
    ring
  have hprime : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp hp.out
  rcases hprime.dvd_or_dvd hdvd with h1 | h2
  · have h_zero : L * M' - L' * M = 0 := by
      by_contra hne
      obtain ⟨k, hk⟩ := h1
      have hkne : k ≠ 0 := by rintro rfl; apply hne; rw [hk, mul_zero]
      have hk2 : 1 ≤ k^2 := sq_pos_of_ne_zero hkne
      have hle : (p : ℤ)^2 ≤ (L * M' - L' * M)^2 := by
        calc (p : ℤ)^2 ≤ (p : ℤ)^2 * k^2 := by nlinarith [hp_sq_pos]
        _ = (p * k)^2 := by ring
        _ = (L * M' - L' * M)^2 := by rw [← hk]
      have h_contra : 27 * (p : ℤ)^2 ≤ 16 * (p : ℤ)^2 := by
        calc 27 * (p : ℤ)^2 ≤ 27 * (L * M' - L' * M)^2 := by nlinarith [hle]
        _ ≤ (L * L' + 27 * M * M')^2 + 27 * (L * M' - L' * M)^2 := by nlinarith
        _ = 16 * (p : ℤ)^2 := hid2
      nlinarith [hp_sq_pos]
    have hM_sq : M'^2 = M^2 := by
      have H : (4 * (p : ℤ)) * M'^2 = (4 * (p : ℤ)) * M^2 := by
        calc (4 * (p : ℤ)) * M'^2 = (L^2 + 27 * M^2) * M'^2 := by rw [← hLM]
        _ = (L * M')^2 + 27 * M^2 * M'^2 := by ring
        _ = (L' * M)^2 + 27 * M^2 * M'^2 := by rw [sub_eq_zero.mp h_zero]
        _ = (L'^2 + 27 * M'^2) * M^2 := by ring
        _ = (4 * (p : ℤ)) * M^2 := by rw [← hLM']
      exact mul_left_cancel₀ (by linarith [hp_pos]) H
    have hL_sq : L'^2 = L^2 := by
      linear_combination -hLM' + hLM - 27 * hM_sq
    have h_or : L' = L ∨ L' = -L := sq_eq_sq_iff_eq_or_eq_neg.mp hL_sq
    rcases h_or with rfl | rfl
    · rfl
    · exfalso
      have : (-L) % 3 = 1 := by rw [← hL']
      omega
  · have h_zero : L * M' + L' * M = 0 := by
      by_contra hne
      obtain ⟨k, hk⟩ := h2
      have hkne : k ≠ 0 := by rintro rfl; apply hne; rw [hk, mul_zero]
      have hk2 : 1 ≤ k^2 := sq_pos_of_ne_zero hkne
      have hle : (p : ℤ)^2 ≤ (L * M' + L' * M)^2 := by
        calc (p : ℤ)^2 ≤ (p : ℤ)^2 * k^2 := by nlinarith [hp_sq_pos]
        _ = (p * k)^2 := by ring
        _ = (L * M' + L' * M)^2 := by rw [← hk]
      have h_contra : 27 * (p : ℤ)^2 ≤ 16 * (p : ℤ)^2 := by
        calc 27 * (p : ℤ)^2 ≤ 27 * (L * M' + L' * M)^2 := by nlinarith [hle]
        _ ≤ (L * L' - 27 * M * M')^2 + 27 * (L * M' + L' * M)^2 := by nlinarith
        _ = 16 * (p : ℤ)^2 := hid3
      nlinarith [hp_sq_pos]
    have hM_sq : M'^2 = M^2 := by
      have H : (4 * (p : ℤ)) * M'^2 = (4 * (p : ℤ)) * M^2 := by
        calc (4 * (p : ℤ)) * M'^2 = (L^2 + 27 * M^2) * M'^2 := by rw [← hLM]
        _ = (L * M')^2 + 27 * M^2 * M'^2 := by ring
        _ = (- (L' * M))^2 + 27 * M^2 * M'^2 := by rw [← add_eq_zero_iff_eq_neg.mp h_zero]
        _ = (L'^2 + 27 * M'^2) * M^2 := by ring
        _ = (4 * (p : ℤ)) * M^2 := by rw [← hLM']
      exact mul_left_cancel₀ (by linarith [hp_pos]) H
    have hL_sq : L'^2 = L^2 := by
      linear_combination -hLM' + hLM - 27 * hM_sq
    have h_or : L' = L ∨ L' = -L := sq_eq_sq_iff_eq_or_eq_neg.mp hL_sq
    rcases h_or with rfl | rfl
    · rfl
    · exfalso
      have : (-L) % 3 = 1 := by rw [← hL']
      omega

/-! ### Section 2: Standard Additive Character and Circle -/

lemma stdAddChar_eq (p : ℕ) [Fact p.Prime] (j : ZMod p) :
    (ZMod.stdAddChar j : ℂ) =
      Complex.exp (2 * Real.pi * Complex.I * (j.val : ℂ) / (p : ℂ)) := by
  haveI : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  rw [ZMod.stdAddChar_apply]
  change (ZMod.toCircle j : ℂ) = _
  rw [ZMod.toCircle, AddChar.compAddMonoidHom_apply, AddCircle.toCircle_addChar,
    AddChar.coe_mk, ZMod.toAddCircle_apply, AddCircle.toCircle_apply_mk]
  rw [Circle.coe_exp]
  push_cast
  ring_nf

lemma stdAddChar_mulShift_primitive (p : ℕ) [Fact p.Prime] (a : ZMod p) (ha : a ≠ 0) :
    ((ZMod.stdAddChar : AddChar (ZMod p) ℂ).mulShift a).IsPrimitive := by
  intro b hb
  have h_ab : a * b ≠ 0 := mul_ne_zero ha hb
  have h_prim := ZMod.isPrimitive_stdAddChar p
  have h_shift := h_prim h_ab
  rw [AddChar.mulShift_mulShift]
  exact h_shift

/-! ### Section 3: Jacobi and Gauss sums algebra -/

lemma cube_add (g1 g2 J1 J2 p : ℂ)
    (h1 : g1 ^ 3 = p * J1) (h2 : g2 ^ 3 = p * J2) (hm : g1 * g2 = p) :
    (g1 + g2) ^ 3 = 3 * p * (g1 + g2) + p * (J1 + J2) := by
  calc (g1 + g2) ^ 3
    _ = g1 ^ 3 + g2 ^ 3 + 3 * (g1 * g2) * (g1 + g2) := by ring
    _ = p * J1 + p * J2 + 3 * p * (g1 + g2) := by rw [h1, h2, hm]
    _ = 3 * p * (g1 + g2) + p * (J1 + J2) := by ring

lemma sub_inv_eq (p : ℕ) [Fact p.Prime] (x : ZMod p) (hx : 1 - x ≠ 0) :
    1 - (1 - x)⁻¹ = -x * (1 - x)⁻¹ := by
  have : 1 = (1 - x) * (1 - x)⁻¹ := (mul_inv_cancel₀ hx).symm
  nth_rw 1 [this]
  ring

lemma sigma_cube (p : ℕ) [Fact p.Prime] (x : ZMod p) (h0 : x ≠ 0) (h1 : x ≠ 1) :
    (1 - (1 - (1 - x)⁻¹)⁻¹)⁻¹ = x := by
  have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
  have e1 : 1 - (1 - x)⁻¹ = -x * (1 - x)⁻¹ := sub_inv_eq p x h1x
  have h2 : -x * (1 - x)⁻¹ ≠ 0 := mul_ne_zero (neg_ne_zero.mpr h0) (inv_ne_zero h1x)
  have e2 : (1 - (1 - x)⁻¹)⁻¹ = -(1 - x) * x⁻¹ := by
    rw [e1, mul_inv, inv_inv]
    ring
  have e3 : 1 - (1 - (1 - x)⁻¹)⁻¹ = x⁻¹ := by
    rw [e2]
    have : 1 = x * x⁻¹ := (mul_inv_cancel₀ h0).symm
    nth_rw 1 [this]
    ring
  rw [e3, inv_inv]

lemma J_algebra (c0 c1 c2 : ℂ) (ω : ℂ) (hω : ω^2 + ω + 1 = 0) :
    let J1 := c0 + c1 * ω + c2 * ω^2
    let J2 := c0 + c1 * ω^2 + c2 * ω
    J1 + J2 = 2 * c0 - c1 - c2 ∧
    (J1 - J2)^2 = -3 * (c1 - c2)^2 ∧
    4 * (J1 * J2) = (2 * c0 - c1 - c2)^2 + 3 * (c1 - c2)^2 := by
  dsimp
  have h_add : ω^2 + ω = -1 := by linear_combination hω
  have h_sub : (ω - ω^2)^2 = -3 := by linear_combination (ω^2 - 3 * ω + 3) * hω
  refine ⟨?_, ?_, ?_⟩
  · calc c0 + c1 * ω + c2 * ω^2 + (c0 + c1 * ω^2 + c2 * ω)
      _ = 2 * c0 + (c1 + c2) * (ω^2 + ω) := by ring
      _ = 2 * c0 + (c1 + c2) * (-1) := by rw [h_add]
      _ = 2 * c0 - c1 - c2 := by ring
  · calc (c0 + c1 * ω + c2 * ω^2 - (c0 + c1 * ω^2 + c2 * ω))^2
      _ = (c1 - c2)^2 * (ω - ω^2)^2 := by ring
      _ = (c1 - c2)^2 * (-3) := by rw [h_sub]
      _ = -3 * (c1 - c2)^2 := by ring
  · have p1 : c0 + c1 * ω + c2 * ω^2 + (c0 + c1 * ω^2 + c2 * ω) = 2 * c0 - c1 - c2 := by
      rw [show c0 + c1 * ω + c2 * ω^2 + (c0 + c1 * ω^2 + c2 * ω) = 2 * c0 + (c1 + c2) * (ω^2 + ω) by ring, h_add]
      ring
    have p2 : (c0 + c1 * ω + c2 * ω^2 - (c0 + c1 * ω^2 + c2 * ω))^2 = -3 * (c1 - c2)^2 := by
      rw [show (c0 + c1 * ω + c2 * ω^2 - (c0 + c1 * ω^2 + c2 * ω))^2 = (c1 - c2)^2 * (ω - ω^2)^2 by ring, h_sub]
      ring
    calc 4 * ((c0 + c1 * ω + c2 * ω^2) * (c0 + c1 * ω^2 + c2 * ω))
      _ = (c0 + c1 * ω + c2 * ω^2 + (c0 + c1 * ω^2 + c2 * ω))^2 -
          (c0 + c1 * ω + c2 * ω^2 - (c0 + c1 * ω^2 + c2 * ω))^2 := by ring
      _ = (2 * c0 - c1 - c2)^2 - (-3 * (c1 - c2)^2) := by rw [p1, p2]
      _ = (2 * c0 - c1 - c2)^2 + 3 * (c1 - c2)^2 := by ring

lemma jacobiSum_vals (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    jacobiSum (1 : MulChar (ZMod p) ℂ) 1 = (p : ℂ) - 2 ∧
    jacobiSum 1 χ = -1 ∧
    jacobiSum 1 (χ ^ 2) = -1 ∧
    jacobiSum χ 1 = -1 ∧
    jacobiSum (χ ^ 2) 1 = -1 ∧
    jacobiSum χ (χ ^ 2) = -1 ∧
    jacobiSum (χ ^ 2) χ = -1 := by
  have hχ_ne : χ ≠ 1 := by
    rintro rfl
    have : orderOf (1 : MulChar (ZMod p) ℂ) = 1 := orderOf_one
    rw [hχ] at this
    revert this; decide
  have hχ2_ne : χ ^ 2 ≠ 1 := by
    intro h
    have : orderOf χ ∣ 2 := orderOf_dvd_of_pow_eq_one h
    rw [hχ] at this
    revert this; decide
  have h_odd : Odd 3 := by decide
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have h_neg_one : χ (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd h_pow
  have hχ_inv : χ⁻¹ = χ ^ 2 := by
    have : χ * χ ^ 2 = 1 := by
      nth_rw 1 [← pow_one χ]
      rw [← pow_add]
      exact h_pow
    exact inv_eq_of_mul_eq_one_right this
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · have := @jacobiSum_one_one (ZMod p) ℂ _ _ _
    rw [this, ZMod.card p]
  · exact jacobiSum_one_nontrivial hχ_ne
  · exact jacobiSum_one_nontrivial hχ2_ne
  · rw [jacobiSum_comm]
    exact jacobiSum_one_nontrivial hχ_ne
  · rw [jacobiSum_comm]
    exact jacobiSum_one_nontrivial hχ2_ne
  · have := @jacobiSum_nontrivial_inv (ZMod p) ℂ _ _ _ _ χ hχ_ne
    rw [← hχ_inv]
    rw [this, h_neg_one]
  · rw [jacobiSum_comm]
    have := @jacobiSum_nontrivial_inv (ZMod p) ℂ _ _ _ _ χ hχ_ne
    rw [← hχ_inv]
    rw [this, h_neg_one]

lemma gaussSum_cube (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3)
    (ψ : AddChar (ZMod p) ℂ) (hψ : ψ.IsPrimitive) :
    gaussSum χ ψ ^ 3 = (p : ℂ) * jacobiSum χ χ ∧
    gaussSum (χ ^ 2) ψ ^ 3 = (p : ℂ) * jacobiSum (χ ^ 2) (χ ^ 2) := by
  have h_odd : Odd 3 := by decide
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have h_neg_one : χ (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd h_pow
  have hχ2_order : orderOf (χ ^ 2) = 3 := by
    rw [orderOf_pow, hχ]
    decide
  have hχ2_pow : (χ ^ 2) ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ2_order])
  have hχ2_neg_one : (χ ^ 2) (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd hχ2_pow
  have h1 : gaussSum χ ψ ^ 3 = (p : ℂ) * jacobiSum χ χ := by
    have h := gaussSum_pow_eq_prod_jacobiSum (χ := χ) (ψ := ψ) (by rw [hχ]; decide) hψ
    rw [hχ] at h
    have hIco : Finset.Ico 1 (3 - 1) = {1} := by decide
    rw [hIco, Finset.prod_singleton, pow_one, h_neg_one, ZMod.card p, one_mul] at h
    exact h
  have h2 : gaussSum (χ ^ 2) ψ ^ 3 = (p : ℂ) * jacobiSum (χ ^ 2) (χ ^ 2) := by
    have h := gaussSum_pow_eq_prod_jacobiSum (χ := χ ^ 2) (ψ := ψ) (by rw [hχ2_order]; decide) hψ
    rw [hχ2_order] at h
    have hIco : Finset.Ico 1 (3 - 1) = {1} := by decide
    rw [hIco, Finset.prod_singleton, pow_one, hχ2_neg_one, ZMod.card p, one_mul] at h
    exact h
  exact ⟨h1, h2⟩

lemma gaussSum_mul_sq (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3)
    (ψ : AddChar (ZMod p) ℂ) (hψ : ψ.IsPrimitive) :
    gaussSum χ ψ * gaussSum (χ ^ 2) ψ = (p : ℂ) := by
  have hχ_ne : χ ≠ 1 := by
    rintro rfl
    have : orderOf (1 : MulChar (ZMod p) ℂ) = 1 := orderOf_one
    rw [hχ] at this
    revert this; decide
  have h_odd : Odd 3 := by decide
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have h_neg_one : χ (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd h_pow
  have hχ_inv : χ⁻¹ = χ ^ 2 := by
    have : χ * χ ^ 2 = 1 := by
      nth_rw 1 [← pow_one χ]
      rw [← pow_add]
      exact h_pow
    exact inv_eq_of_mul_eq_one_right this
  have h := gaussSum_mul_gaussSum_eq_card (χ := χ) hχ_ne (ψ := ψ) hψ
  rw [ZMod.card p] at h
  have h_eq : gaussSum χ⁻¹ ψ⁻¹ = gaussSum (χ ^ 2) ψ := by
    rw [hχ_inv]
    unfold gaussSum
    rw [← Equiv.sum_comp (Equiv.neg (ZMod p)) (fun x => (χ ^ 2) x * ψ⁻¹ x)]
    apply Finset.sum_congr rfl
    intro x _
    simp only [Equiv.neg_apply, AddChar.inv_apply, neg_neg]
    have hχ2_pow : (χ ^ 2) ^ 3 = 1 := by
      rw [← pow_mul, show 2 * 3 = 3 * 2 by rfl, pow_mul, h_pow, one_pow]
    have hχ2_neg_one : (χ ^ 2) (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd hχ2_pow
    have : (χ ^ 2) (-x) = (χ ^ 2) x := by
      calc (χ ^ 2) (-x) = (χ ^ 2) (-1 * x) := by ring_nf
      _ = (χ ^ 2) (-1) * (χ ^ 2) x := map_mul _ _ _
      _ = 1 * (χ ^ 2) x := by rw [hχ2_neg_one]
      _ = (χ ^ 2) x := one_mul _
    rw [this]
  rw [h_eq] at h
  exact h

lemma inv_sq_eq_of_cube_eq_one {z : ℂ} (hz : z ^ 3 = 1) (hz0 : z ≠ 0) : (z⁻¹)^2 = z := by
  apply mul_left_cancel₀ (pow_ne_zero 2 hz0)
  calc z^2 * (z⁻¹)^2 = (z * z⁻¹)^2 := by ring
  _ = 1^2 := by rw [mul_inv_cancel₀ hz0]
  _ = 1 := one_pow 2
  _ = z^3 := hz.symm
  _ = z^2 * z := by ring

lemma chi_sigma_invariant (p : ℕ) [Fact p.Prime]
    (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3)
    (x : ZMod p) (h1 : x ≠ 1) :
    χ ((1 - x)⁻¹ * (1 - (1 - x)⁻¹)) = χ (x * (1 - x)) := by
  have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
  have e1 : 1 - (1 - x)⁻¹ = -x * (1 - x)⁻¹ := by
    have : 1 = (1 - x) * (1 - x)⁻¹ := (mul_inv_cancel₀ h1x).symm
    nth_rw 1 [this]
    ring
  rw [e1]
  have h_odd : Odd 3 := by decide
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have h_neg_one : χ (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd h_pow
  have : (1 - x)⁻¹ * (-x * (1 - x)⁻¹) = (-1) * x * ((1 - x)⁻¹)^2 := by ring
  rw [this]
  rw [map_mul, map_mul, h_neg_one, one_mul]
  have h_inv : χ ((1 - x)⁻¹ ^ 2) = χ (1 - x) := by
    rw [map_pow]
    have h_chi_inv : χ (1 - x)⁻¹ = (χ (1 - x))⁻¹ := by
      rw [← MulChar.inv_apply', MulChar.inv_apply_eq_inv']
    rw [h_chi_inv]
    have hu : IsUnit (1 - x) := Ne.isUnit h1x
    have h_pow3 : (χ (1 - x)) ^ 3 = 1 := by
      rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
    have h_ne : χ (1 - x) ≠ 0 := by
      intro hz
      rw [hz, zero_pow (by decide)] at h_pow3
      norm_num at h_pow3
    exact inv_sq_eq_of_cube_eq_one h_pow3 h_ne
  rw [h_inv, map_mul]

lemma fixed_sigma_not_mem (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ)
    (x : ZMod p) (h1 : x ≠ 1) (h_fix : (1 - x)⁻¹ = x) :
    χ (x * (1 - x)) = 1 := by
  have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
  have : x * (1 - x) = 1 := by
    nth_rw 1 [← h_fix]
    exact inv_mul_cancel₀ h1x
  rw [this, map_one]

lemma roots_quadratic_iff (p : ℕ) [Fact p.Prime] (w : ZMod p)
    (hw3 : w^3 = 1) (hw_geom : w^2 + w + 1 = 0) (x : ZMod p) :
    x^2 - x + 1 = 0 ↔ x = -w ∨ x = -w^2 := by
  have h_fac : (x - (-w)) * (x - (-w^2)) = x^2 - x + 1 := by
    calc (x - (-w)) * (x - (-w^2)) = x^2 + (w^2 + w) * x + (w^3 - 1) + 1 := by ring
    _ = x^2 + (-1 : ZMod p) * x + 0 + 1 := by
      have : w^2 + w = -1 := by linear_combination hw_geom
      have : w^3 - 1 = 0 := by linear_combination hw3
      rw [‹w^2 + w = -1›, ‹w^3 - 1 = 0›]
    _ = x^2 - x + 1 := by ring
  rw [← h_fac, mul_eq_zero, sub_eq_zero, sub_eq_zero]

lemma sum_chi_mul_chi (p : ℕ) [Fact p.Prime]
    (χ ψ : MulChar (ZMod p) ℂ) (h_odd : Odd 3) (h_pow : χ ^ 3 = 1) :
    ∑ x : ZMod p, χ x * ψ (x + 1) = jacobiSum χ ψ := by
  have h_neg_one : χ (-1) = 1 := MulChar.val_neg_one_eq_one_of_odd_order h_odd h_pow
  unfold jacobiSum
  rw [← Equiv.sum_comp (Equiv.neg (ZMod p)) (fun x => χ x * ψ (x + 1))]
  apply Finset.sum_congr rfl
  intro x _
  simp only [Equiv.neg_apply]
  have : χ (-x) = χ x := by
    calc χ (-x) = χ (-1 * x) := by ring_nf
    _ = χ (-1) * χ x := map_mul _ _ _
    _ = 1 * χ x := by rw [h_neg_one]
    _ = χ x := one_mul _
  have h1 : -x + 1 = 1 - x := by ring
  rw [this, h1]

lemma sum_nine_jacobi (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (L : ℤ)
    (h_jacobi_L : jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) = (L : ℂ))
    (j00 : jacobiSum (1 : MulChar (ZMod p) ℂ) 1 = (p : ℂ) - 2)
    (j01 : jacobiSum 1 χ = -1)
    (j02 : jacobiSum 1 (χ ^ 2) = -1)
    (j10 : jacobiSum χ 1 = -1)
    (j20 : jacobiSum (χ ^ 2) 1 = -1)
    (j12 : jacobiSum χ (χ ^ 2) = -1)
    (j21 : jacobiSum (χ ^ 2) χ = -1) :
    jacobiSum (1 : MulChar (ZMod p) ℂ) 1 + jacobiSum 1 χ + jacobiSum 1 (χ ^ 2) +
    jacobiSum χ 1 + jacobiSum (χ ^ 2) 1 +
    jacobiSum χ (χ ^ 2) + jacobiSum (χ ^ 2) χ +
    jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) = (p : ℂ) - 8 + (L : ℂ) := by
  linear_combination j00 + j01 + j02 + j10 + j20 + j12 + j21 + h_jacobi_L

lemma sum_noncube_jacobi (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (L : ℤ)
    (h_jacobi_L : jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) = (L : ℂ))
    (j00 : jacobiSum (1 : MulChar (ZMod p) ℂ) 1 = (p : ℂ) - 2)
    (j01 : jacobiSum 1 χ = -1)
    (j02 : jacobiSum 1 (χ ^ 2) = -1)
    (j10 : jacobiSum χ 1 = -1)
    (j20 : jacobiSum (χ ^ 2) 1 = -1)
    (j12 : jacobiSum χ (χ ^ 2) = -1)
    (j21 : jacobiSum (χ ^ 2) χ = -1) :
    2 * jacobiSum (1 : MulChar (ZMod p) ℂ) 1 - jacobiSum 1 χ - jacobiSum 1 (χ ^ 2) -
    jacobiSum χ 1 - jacobiSum (χ ^ 2) 1 -
    jacobiSum χ (χ ^ 2) - jacobiSum (χ ^ 2) χ +
    2 * (jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2)) = 2 * ((p : ℂ) + 1 + (L : ℂ)) := by
  linear_combination 2 * j00 - j01 - j02 - j10 - j20 - j12 - j21 + 2 * h_jacobi_L

lemma jacobiSum_mul_self (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    jacobiSum χ χ * jacobiSum (χ ^ 2) (χ ^ 2) = (p : ℂ) := by
  have hχ_ne : χ ≠ 1 := by
    rintro rfl
    have : orderOf (1 : MulChar (ZMod p) ℂ) = 1 := orderOf_one
    rw [hχ] at this
    revert this; decide
  have h_odd : Odd 3 := by decide
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have hχ_inv : χ⁻¹ = χ ^ 2 := by
    have : χ * χ ^ 2 = 1 := by
      nth_rw 1 [← pow_one χ]
      rw [← pow_add]
      exact h_pow
    exact inv_eq_of_mul_eq_one_right this
  have hχ_sq_ne : χ * χ ≠ 1 := by
    rw [← sq]
    intro h
    have : orderOf χ ∣ 2 := orderOf_dvd_of_pow_eq_one h
    rw [hχ] at this
    revert this; decide
  have h_char : ringChar ℂ ≠ ringChar (ZMod p) := by
    rw [ringChar.eq_zero, ZMod.ringChar_zmod_n]
    exact (Fact.out : Nat.Prime p).ne_zero.symm
  have h := jacobiSum_mul_jacobiSum_inv (χ := χ) (φ := χ) h_char hχ_ne hχ_ne hχ_sq_ne
  rw [ZMod.card p, hχ_inv] at h
  exact h

lemma exists_order_three (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    ∃ w : ZMod p, orderOf w = 3 := by
  haveI : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
  have hdvd : 3 ∣ Fintype.card (ZMod p)ˣ := by
    rw [ZMod.card_units p]
    exact Nat.dvd_of_mod_eq_zero (by omega)
  obtain ⟨u, hu⟩ := exists_prime_orderOf_dvd_card 3 hdvd
  refine ⟨u.val, ?_⟩
  have h_inj : orderOf (Units.coeHom (ZMod p) u) = orderOf u :=
    orderOf_injective (Units.coeHom (ZMod p)) Units.val_injective u
  rw [show (u : ZMod p) = Units.coeHom (ZMod p) u from rfl, h_inj, hu]

lemma sum_ite_mem_eq_card_mul {α M : Type*} [Fintype α] [DecidableEq α] [AddCommMonoid M]
    (s : Finset α) (c : M) :
    (∑ x, if x ∈ s then c else 0) = s.card • c := by
  have : (∑ x, if x ∈ s then c else 0) = ∑ x ∈ s, c := by
    rw [← sum_filter]
    congr 1
    ext x
    simp
  rw [this, sum_const]

lemma roots_of_unity_three (z : ℂ) (hz : z ^ 3 = 1) :
    let ω := Complex.exp (2 * Real.pi * Complex.I / 3)
    z = 1 ∨ z = ω ∨ z = ω^2 := by
  dsimp
  have h_root := Complex.isPrimitiveRoot_exp 3 (by decide)
  obtain ⟨k, hk, rfl⟩ := h_root.eq_pow_of_pow_eq_one hz
  interval_cases k
  · left; exact pow_zero _
  · right; left; exact pow_one _
  · right; right; rfl

lemma s0_mod_three (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    let s0 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = 1)
    s0.card ≡ 2 [MOD 3] := by
  dsimp
  have hp_ge : p ≥ 7 := by
    have hp_prime := (Fact.out : Nat.Prime p)
    have : p ≠ 2 := by rintro rfl; revert hp; decide
    have : p ≠ 3 := by rintro rfl; revert hp; decide
    have : p ≠ 5 := by rintro rfl; revert hp; decide
    have : p > 0 := hp_prime.pos
    have : p ≠ 1 := hp_prime.ne_one
    have : p ≠ 4 := by rintro rfl; contradiction
    have : p ≠ 6 := by rintro rfl; contradiction
    omega
  obtain ⟨w, hw⟩ := exists_order_three p hp
  have hw_ne1 : w ≠ 1 := by
    intro h
    rw [h, orderOf_one] at hw
    revert hw; decide
  have hw3 : w^3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hw])
  have hw_factor : (w - 1) * (w^2 + w + 1) = 0 := by
    calc (w - 1) * (w^2 + w + 1) = w^3 - 1 := by ring
    _ = 1 - 1 := by rw [hw3]
    _ = 0 := sub_self 1
  have hw_geom : w^2 + w + 1 = 0 := by
    rcases mul_eq_zero.mp hw_factor with h | h
    · exfalso; exact hw_ne1 (sub_eq_zero.mp h)
    · exact h
  have h_ne : -w ≠ -w^2 := by
    intro h
    have h_w : w = w^2 := by linear_combination -h
    have h_w3 : w^3 = w * w^2 := by ring
    rw [← h_w, ← sq] at h_w3
    have : (w - 1) * (w + 1) = 0 := by
      calc (w - 1) * (w + 1) = w^2 - 1 := by ring
      _ = w^3 - 1 := by rw [h_w3]
      _ = 1 - 1 := by rw [hw3]
      _ = 0 := sub_self 1
    rcases mul_eq_zero.mp this with h1 | h1
    · exact hw_ne1 (sub_eq_zero.mp h1)
    · have hw_neg : w = -1 := eq_neg_of_add_eq_zero_left h1
      have hw_cube : (-1 : ZMod p)^3 = 1 := by
        calc (-1 : ZMod p)^3 = w^3 := by rw [hw_neg]
        _ = 1 := hw3
      have h2 : (2 : ZMod p) = 0 := by
        calc (2 : ZMod p) = 1 - (-1 : ZMod p)^3 := by ring
        _ = 1 - 1 := by rw [hw_cube]
        _ = 0 := sub_self 1
      have hp2 : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp h2
      have hp_le2 : p ≤ 2 := Nat.le_of_dvd (by decide) hp2
      omega
  let s0 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = 1)
  let α := {x : ZMod p // x ∈ s0}
  have h_sigma : ∀ x : α, (1 - x.val)⁻¹ ∈ s0 := by
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx ⊢
    refine ⟨Finset.mem_univ _, ?_⟩
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hx
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hx
      exact zero_ne_one hx.2
    have := TuringTask.chi_sigma_invariant p χ hχ x h1
    rw [this, hx.2]
  let f : Function.End α := fun x => ⟨(1 - x.val)⁻¹, h_sigma x⟩
  have hf3 : f ^ 3 = 1 := by
    apply _root_.funext
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx
    have h0 : x ≠ 0 := by
      rintro rfl
      have : (0 : ZMod p) * (1 - 0) = 0 := by ring
      rw [this] at hx
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hx
      exact zero_ne_one hx.2
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hx
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hx
      exact zero_ne_one hx.2
    apply Subtype.ext
    change (1 - (1 - (1 - x)⁻¹)⁻¹)⁻¹ = x
    exact TuringTask.sigma_cube p x h0 h1
  haveI : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
  have hf_pow : f ^ (3 ^ 1) = 1 := by simpa using hf3
  have h_mod := Equiv.Perm.card_fixedPoints_modEq (p := 3) (n := 1) hf_pow
  have h_two : Fintype.card ↑(Function.fixedPoints (f : α → α)) = 2 := by
    have h_rw : ∀ x : α, (f : α → α) x = x ↔ (x.val = -w ∨ x.val = -w^2) := by
      rintro ⟨x, hx⟩
      rw [Subtype.ext_iff]
      change (1 - x)⁻¹ = x ↔ x = -w ∨ x = -w^2
      rw [Finset.mem_filter] at hx
      have h1 : x ≠ 1 := by
        rintro rfl
        have : (1 : ZMod p) * (1 - 1) = 0 := by ring
        rw [this] at hx
        have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
        rw [MulChar.map_nonunit χ h00] at hx
        exact zero_ne_one hx.2
      have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
      have : (1 - x)⁻¹ = x ↔ x^2 - x + 1 = 0 := by
        constructor
        · intro h
          calc x^2 - x + 1 = 1 - x * (1 - x) := by ring
          _ = 1 - (1 - x)⁻¹ * (1 - x) := by nth_rw 1 [← h]
          _ = 1 - 1 := by rw [inv_mul_cancel₀ h1x]
          _ = 0 := sub_self 1
        · intro h
          have : 1 - x * (1 - x) = 0 := by
            calc 1 - x * (1 - x) = x^2 - x + 1 := by ring
            _ = 0 := h
          have : x * (1 - x) = 1 := by linear_combination -this
          calc (1 - x)⁻¹ = (1 - x)⁻¹ * 1 := by ring
          _ = (1 - x)⁻¹ * (x * (1 - x)) := by rw [this]
          _ = ((1 - x)⁻¹ * (1 - x)) * x := by ring
          _ = 1 * x := by rw [inv_mul_cancel₀ h1x]
          _ = x := one_mul x
      rw [this]
      exact TuringTask.roots_quadratic_iff p w hw3 hw_geom x
    let S_fixed : Set α := Function.fixedPoints (f : α → α)
    have h_w_in_s0 : -w ∈ s0 := by
      rw [Finset.mem_filter]
      refine ⟨Finset.mem_univ _, ?_⟩
      have : -w * (1 - -w) = 1 := by
        calc -w * (1 - -w) = -(w^2 + w + 1) + 1 := by ring
        _ = -0 + 1 := by rw [hw_geom]
        _ = 1 := by ring
      rw [this, map_one]
    have h_w2_in_s0 : -w^2 ∈ s0 := by
      rw [Finset.mem_filter]
      refine ⟨Finset.mem_univ _, ?_⟩
      have : -w^2 * (1 - -w^2) = 1 := by
        calc -w^2 * (1 - -w^2) = -w * (w^3 - 1) - (w^2 + w + 1) + 1 := by ring
        _ = -w * (1 - 1) - 0 + 1 := by rw [hw3, hw_geom]
        _ = 1 := by ring
      rw [this, map_one]
    let a1 : α := ⟨-w, h_w_in_s0⟩
    let a2 : α := ⟨-w^2, h_w2_in_s0⟩
    have ha_ne : a1 ≠ a2 := by
      intro h
      rw [Subtype.ext_iff] at h
      exact h_ne h
    have h_set_coe : S_fixed = ↑({a1, a2} : Finset α) := by
      ext ⟨x, hx⟩
      change (f : α → α) ⟨x, hx⟩ = ⟨x, hx⟩ ↔ ⟨x, hx⟩ ∈ ({a1, a2} : Finset α)
      rw [h_rw ⟨x, hx⟩]
      simp only [Finset.mem_insert, Finset.mem_singleton]
      constructor
      · rintro (h | h)
        · left; exact Subtype.ext h
        · right; exact Subtype.ext h
      · rintro (h | h)
        · left; exact congr_arg Subtype.val h
        · right; exact congr_arg Subtype.val h
    have e : ↑S_fixed ≃ ↑({a1, a2} : Finset α) := Equiv.setCongr h_set_coe
    rw [Fintype.card_congr e, Fintype.card_coe, Finset.card_pair ha_ne]
  have h_card_α : Fintype.card α = s0.card := Fintype.card_coe s0
  rw [h_card_α] at h_mod
  calc s0.card ≡ Fintype.card ↑(Function.fixedPoints (f : α → α)) [MOD 3] := h_mod
  _ ≡ 2 [MOD 3] := by rw [h_two]

lemma s1_mod_three (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    let ω := Complex.exp (2 * Real.pi * Complex.I / 3)
    let s1 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω)
    s1.card ≡ 0 [MOD 3] := by
  dsimp
  have h_root := Complex.isPrimitiveRoot_exp 3 (by decide)
  have hω_ne1 : Complex.exp (2 * Real.pi * Complex.I / 3) ≠ 1 := h_root.ne_one (by decide)
  have hω_ne0 : Complex.exp (2 * Real.pi * Complex.I / 3) ≠ 0 := by
    intro hz
    have : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 3 = 1 := by
      have := h_root.pow_eq_one; push_cast at this; exact this
    rw [hz, zero_pow (by decide)] at this; norm_num at this
  let s1 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = Complex.exp (2 * Real.pi * Complex.I / 3))
  let α := {x : ZMod p // x ∈ s1}
  have h_sigma : ∀ x : α, (1 - x.val)⁻¹ ∈ s1 := by
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx ⊢
    refine ⟨Finset.mem_univ _, ?_⟩
    have hne : χ (x * (1 - x)) ≠ 0 := by
      rw [hx.2]
      intro hz
      have : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 3 = 1 := by
        have := h_root.pow_eq_one; push_cast at this; exact this
      rw [hz, zero_pow (by decide)] at this
      norm_num at this
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    have := TuringTask.chi_sigma_invariant p χ hχ x h1
    rw [this, hx.2]
  let f : Function.End α := fun x => ⟨(1 - x.val)⁻¹, h_sigma x⟩
  have hf3 : f ^ 3 = 1 := by
    apply _root_.funext
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx
    have hne : χ (x * (1 - x)) ≠ 0 := by
      rw [hx.2]
      intro hz
      have : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 3 = 1 := by
        have := h_root.pow_eq_one; push_cast at this; exact this
      rw [hz, zero_pow (by decide)] at this
      norm_num at this
    have h0 : x ≠ 0 := by
      rintro rfl
      have : (0 : ZMod p) * (1 - 0) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    apply Subtype.ext
    change (1 - (1 - (1 - x)⁻¹)⁻¹)⁻¹ = x
    exact TuringTask.sigma_cube p x h0 h1
  have h_no_fix : ∀ x : α, (f : α → α) x ≠ x := by
    rintro ⟨x, hx⟩ h_eq
    rw [Subtype.ext_iff] at h_eq
    change (1 - x)⁻¹ = x at h_eq
    rw [Finset.mem_filter] at hx
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hx
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hx
      exact hω_ne0 hx.2.symm
    have h_chi1 := TuringTask.fixed_sigma_not_mem p χ x h1 h_eq
    have : (1 : ℂ) = Complex.exp (2 * Real.pi * Complex.I / 3) := by rw [← h_chi1, hx.2]
    exact hω_ne1 this.symm
  haveI : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
  have hf_pow : f ^ (3 ^ 1) = 1 := by simpa using hf3
  have h_mod := Equiv.Perm.card_fixedPoints_modEq (p := 3) (n := 1) hf_pow
  have h_empty : IsEmpty ↑(Function.fixedPoints (f : α → α)) := by
    constructor
    rintro ⟨x, hx⟩
    exact h_no_fix x hx
  have h_zero : Fintype.card ↑(Function.fixedPoints (f : α → α)) = 0 :=
    Fintype.card_eq_zero
  have h_card_α : Fintype.card α = s1.card := Fintype.card_coe s1
  rw [h_card_α] at h_mod
  calc s1.card ≡ Fintype.card ↑(Function.fixedPoints (f : α → α)) [MOD 3] := h_mod
  _ ≡ 0 [MOD 3] := by rw [h_zero]

lemma s2_mod_three (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    let ω := Complex.exp (2 * Real.pi * Complex.I / 3)
    let s2 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω^2)
    s2.card ≡ 0 [MOD 3] := by
  dsimp
  have h_root := Complex.isPrimitiveRoot_exp 3 (by decide)
  have h_pow_one : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 3 = 1 := by
    have := h_root.pow_eq_one; push_cast at this; exact this
  have hω_ne0 : Complex.exp (2 * Real.pi * Complex.I / 3) ≠ 0 := by
    intro hz; rw [hz, zero_pow (by decide)] at h_pow_one; norm_num at h_pow_one
  have hω2_ne0 : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2 ≠ 0 := pow_ne_zero 2 hω_ne0
  have hω2_ne1 : Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2 ≠ 1 := by
    intro h
    have : 3 ∣ 2 := h_root.dvd_of_pow_eq_one 2 h
    revert this; decide
  let s2 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2)
  let α := {x : ZMod p // x ∈ s2}
  have h_sigma : ∀ x : α, (1 - x.val)⁻¹ ∈ s2 := by
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx ⊢
    refine ⟨Finset.mem_univ _, ?_⟩
    have hne : χ (x * (1 - x)) ≠ 0 := by
      rw [hx.2]
      intro hz
      have : (Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2) ^ 3 = 1 := by
        rw [← pow_mul, show 2 * 3 = 3 * 2 by rfl, pow_mul]
        have := h_root.pow_eq_one; push_cast at this; rw [this, one_pow]
      rw [hz, zero_pow (by decide)] at this
      norm_num at this
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    have := TuringTask.chi_sigma_invariant p χ hχ x h1
    rw [this, hx.2]
  let f : Function.End α := fun x => ⟨(1 - x.val)⁻¹, h_sigma x⟩
  have hf3 : f ^ 3 = 1 := by
    apply _root_.funext
    rintro ⟨x, hx⟩
    rw [Finset.mem_filter] at hx
    have hne : χ (x * (1 - x)) ≠ 0 := by
      rw [hx.2]
      intro hz
      have : (Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2) ^ 3 = 1 := by
        rw [← pow_mul, show 2 * 3 = 3 * 2 by rfl, pow_mul]
        have := h_root.pow_eq_one; push_cast at this; rw [this, one_pow]
      rw [hz, zero_pow (by decide)] at this
      norm_num at this
    have h0 : x ≠ 0 := by
      rintro rfl
      have : (0 : ZMod p) * (1 - 0) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hne
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hne
      exact hne rfl
    apply Subtype.ext
    change (1 - (1 - (1 - x)⁻¹)⁻¹)⁻¹ = x
    exact TuringTask.sigma_cube p x h0 h1
  have h_no_fix : ∀ x : α, (f : α → α) x ≠ x := by
    rintro ⟨x, hx⟩ h_eq
    rw [Subtype.ext_iff] at h_eq
    change (1 - x)⁻¹ = x at h_eq
    rw [Finset.mem_filter] at hx
    have h1 : x ≠ 1 := by
      rintro rfl
      have : (1 : ZMod p) * (1 - 1) = 0 := by ring
      rw [this] at hx
      have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit χ h00] at hx
      exact hω2_ne0 hx.2.symm
    have h_chi1 := TuringTask.fixed_sigma_not_mem p χ x h1 h_eq
    have : (1 : ℂ) = Complex.exp (2 * Real.pi * Complex.I / 3) ^ 2 := by rw [← h_chi1, hx.2]
    exact hω2_ne1 this.symm
  haveI : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
  have hf_pow : f ^ (3 ^ 1) = 1 := by simpa using hf3
  have h_mod := Equiv.Perm.card_fixedPoints_modEq (p := 3) (n := 1) hf_pow
  have h_empty : IsEmpty ↑(Function.fixedPoints (f : α → α)) := by
    constructor
    rintro ⟨x, hx⟩
    exact h_no_fix x hx
  have h_zero : Fintype.card ↑(Function.fixedPoints (f : α → α)) = 0 :=
    Fintype.card_eq_zero
  have h_card_α : Fintype.card α = s2.card := Fintype.card_coe s2
  rw [h_card_α] at h_mod
  calc s2.card ≡ Fintype.card ↑(Function.fixedPoints (f : α → α)) [MOD 3] := h_mod
  _ ≡ 0 [MOD 3] := by rw [h_zero]

lemma jacobiSum_add_eq_L (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) (L M : ℤ)
    (hLM : 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1)
    (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) :
    jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) = (L : ℂ) := by
  let ω : ℂ := Complex.exp (2 * Real.pi * Complex.I / 3)
  haveI : NeZero (3 : ℕ) := ⟨by decide⟩
  have h_root : IsPrimitiveRoot ω 3 := Complex.isPrimitiveRoot_exp 3 (by decide)
  let s0 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = 1)
  let s1 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω)
  let s2 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω^2)
  have h_mod0 : s0.card ≡ 2 [MOD 3] := s0_mod_three p hp χ hχ
  have h_mod1 : s1.card ≡ 0 [MOD 3] := s1_mod_three p χ hχ
  have h_mod2 : s2.card ≡ 0 [MOD 3] := s2_mod_three p χ hχ
  let c0 := s0.card
  let c1 := s1.card
  let c2 := s2.card
  have h_dvd : 3 ∣ ((c1 : ℤ) - (c2 : ℤ)) := by
    have : ((c1 : ℤ) - (c2 : ℤ)) % 3 = 0 := by
      have hc1 : c1 % 3 = 0 := h_mod1
      have hc2 : c2 % 3 = 0 := h_mod2
      omega
    exact Int.dvd_of_emod_eq_zero this
  obtain ⟨M', hM'⟩ := h_dvd
  let L' : ℤ := 2 * (c0 : ℤ) - (c1 : ℤ) - (c2 : ℤ)
  have hL'_mod : L' % 3 = 1 := by
    have hc0 : c0 % 3 = 2 := h_mod0
    have hc1 : c1 % 3 = 0 := h_mod1
    have hc2 : c2 % 3 = 0 := h_mod2
    dsimp [L']
    omega
  have h_pow_one : ω ^ 3 = 1 := h_root.pow_eq_one
  have hω_ne0 : ω ≠ 0 := by
    intro hz; rw [hz, zero_pow (by decide)] at h_pow_one; norm_num at h_pow_one
  have hω2_ne0 : ω ^ 2 ≠ 0 := pow_ne_zero 2 hω_ne0
  have hω_ne_sq : ω ≠ ω ^ 2 := by
    intro hz
    have : ω * (ω - 1) = 0 := by linear_combination -hz
    rcases mul_eq_zero.mp this with h | h
    · exact hω_ne0 h
    · exact (h_root.ne_one (by decide)) (sub_eq_zero.mp h)
  have hω_geom : ω^2 + ω + 1 = 0 := by
    have h_geom := h_root.geom_sum_eq_zero (by decide)
    have h_sum : (∑ i ∈ Finset.range 3, ω ^ i) = ω^2 + ω + 1 := by
      rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
      ring
    rw [← h_sum, h_geom]
  have h_alg := J_algebra (c0 : ℂ) (c1 : ℂ) (c2 : ℂ) ω hω_geom
  have h_J1 : jacobiSum χ χ = (c0 : ℂ) + (c1 : ℂ) * ω + (c2 : ℂ) * ω^2 := by
    unfold jacobiSum
    have h_split : ∀ x : ZMod p, χ x * χ (1 - x) =
        (if x ∈ s0 then 1 else 0) + (if x ∈ s1 then ω else 0) + (if x ∈ s2 then ω^2 else 0) := by
      intro x
      rw [← map_mul]
      have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
      by_cases h0 : x = 0
      · subst h0
        have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
        have : (0 : ZMod p) * (1 - 0) = 0 := by ring
        rw [this, MulChar.map_nonunit χ h00]
        have hs0 : 0 ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; norm_num at hx
        have hs1 : 0 ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω_ne0 hx.symm
        have hs2 : 0 ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω2_ne0 hx.symm
        rw [if_neg hs0, if_neg hs1, if_neg hs2]
        ring
      by_cases h1 : x = 1
      · subst h1
        have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
        have : (1 : ZMod p) * (1 - 1) = 0 := by ring
        rw [this, MulChar.map_nonunit χ h00]
        have hs0 : 1 ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; norm_num at hx
        have hs1 : 1 ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω_ne0 hx.symm
        have hs2 : 1 ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω2_ne0 hx.symm
        rw [if_neg hs0, if_neg hs1, if_neg hs2]
        ring
      have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
      have h_prod_ne : x * (1 - x) ≠ 0 := mul_ne_zero h0 h1x
      have hu : IsUnit (x * (1 - x)) := Ne.isUnit h_prod_ne
      have h_pow3 : (χ (x * (1 - x))) ^ 3 = 1 := by
        rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
      obtain ⟨k, hk, hk_eq⟩ := h_root.eq_pow_of_pow_eq_one h_pow3
      have h_chi := hk_eq.symm
      interval_cases k
      · have : (ω ^ 0) = 1 := pow_zero ω
        rw [this] at h_chi
        have hs0 : x ∈ s0 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        have hs1 : x ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx; exact (h_root.ne_one (by decide)) hx.symm
        have hs2 : x ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx.symm
        rw [h_chi, if_pos hs0, if_neg hs1, if_neg hs2]
        ring
      · have : (ω ^ 1) = ω := pow_one ω
        rw [this] at h_chi
        have hs0 : x ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx; exact (h_root.ne_one (by decide)) hx
        have hs1 : x ∈ s1 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        have hs2 : x ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          exact hω_ne_sq hx
        rw [h_chi, if_neg hs0, if_pos hs1, if_neg hs2]
        ring
      · have hs0 : x ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx
        have hs1 : x ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          exact hω_ne_sq.symm hx
        have hs2 : x ∈ s2 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        rw [h_chi, if_neg hs0, if_neg hs1, if_pos hs2]
        ring
    simp_rw [h_split]
    rw [sum_add_distrib, sum_add_distrib]
    have h0_sum : (∑ x : ZMod p, if x ∈ s0 then (1 : ℂ) else 0) = (c0 : ℂ) := by
      have := sum_ite_mem_eq_card_mul s0 (1 : ℂ)
      rw [this, nsmul_eq_mul, mul_one]
    have h1_sum : (∑ x : ZMod p, if x ∈ s1 then ω else 0) = (c1 : ℂ) * ω := by
      have := sum_ite_mem_eq_card_mul s1 ω
      rw [this, nsmul_eq_mul]
    have h2_sum : (∑ x : ZMod p, if x ∈ s2 then ω^2 else 0) = (c2 : ℂ) * ω^2 := by
      have := sum_ite_mem_eq_card_mul s2 (ω^2)
      rw [this, nsmul_eq_mul]
    rw [h0_sum, h1_sum, h2_sum]
  have h_J2 : jacobiSum (χ ^ 2) (χ ^ 2) = (c0 : ℂ) + (c1 : ℂ) * ω^2 + (c2 : ℂ) * ω := by
    unfold jacobiSum
    have h_split : ∀ x : ZMod p, (χ ^ 2) x * (χ ^ 2) (1 - x) =
        (if x ∈ s0 then 1 else 0) + (if x ∈ s1 then ω^2 else 0) + (if x ∈ s2 then ω else 0) := by
      intro x
      rw [← map_mul]
      have : (χ ^ 2) (x * (1 - x)) = (χ (x * (1 - x))) ^ 2 := by
        rw [← MulChar.pow_apply' χ (by decide)]
      rw [this]
      by_cases hs0 : x ∈ s0
      · have hx := (Finset.mem_filter.mp hs0).2
        rw [hx, one_pow, if_pos hs0]
        have hs1 : x ∉ s1 := by
          intro h; have hx1 := (Finset.mem_filter.mp h).2; rw [hx] at hx1
          exact (h_root.ne_one (by decide)) hx1.symm
        have hs2 : x ∉ s2 := by
          intro h; have hx2 := (Finset.mem_filter.mp h).2; rw [hx] at hx2
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx2.symm
        rw [if_neg hs1, if_neg hs2]
        ring
      by_cases hs1 : x ∈ s1
      · have hx := (Finset.mem_filter.mp hs1).2
        have hs2 : x ∉ s2 := fun h => hω_ne_sq (hx.symm.trans (Finset.mem_filter.mp h).2)
        rw [hx, if_neg hs0, if_pos hs1, if_neg hs2]
        ring
      by_cases hs2 : x ∈ s2
      · have hx := (Finset.mem_filter.mp hs2).2
        rw [hx, if_neg hs0, if_neg hs1, if_pos hs2]
        have : (ω ^ 2) ^ 2 = ω := by
          calc (ω ^ 2) ^ 2 = ω * ω ^ 3 := by ring
          _ = ω * 1 := by rw [h_pow_one]
          _ = ω := mul_one ω
        rw [this]
        ring
      · rw [if_neg hs0, if_neg hs1, if_neg hs2]
        have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
        have h_zero : χ (x * (1 - x)) = 0 := by
          by_contra hz
          have h_pow3 : (χ (x * (1 - x))) ^ 3 = 1 := by
            have hu : IsUnit (x * (1 - x)) := by
              by_contra hu_not
              have : x * (1 - x) = 0 := by
                by_contra h_ne_zero
                exact hu_not (Ne.isUnit h_ne_zero)
              have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
              rw [this, MulChar.map_nonunit χ h00] at hz
              exact hz rfl
            rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
          obtain ⟨k, hk, hk_eq⟩ := h_root.eq_pow_of_pow_eq_one h_pow3
          have h_chi := hk_eq.symm
          interval_cases k
          · apply hs0; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, ?_⟩; rw [pow_zero] at h_chi; exact h_chi
          · apply hs1; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, ?_⟩; rw [pow_one] at h_chi; exact h_chi
          · apply hs2; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        rw [h_zero, zero_pow (by decide)]
        ring
    simp_rw [h_split]
    rw [sum_add_distrib, sum_add_distrib]
    have h0_sum : (∑ x : ZMod p, if x ∈ s0 then (1 : ℂ) else 0) = (c0 : ℂ) := by
      have := sum_ite_mem_eq_card_mul s0 (1 : ℂ)
      rw [this, nsmul_eq_mul, mul_one]
    have h1_sum : (∑ x : ZMod p, if x ∈ s1 then ω^2 else 0) = (c1 : ℂ) * ω^2 := by
      have := sum_ite_mem_eq_card_mul s1 (ω^2)
      rw [this, nsmul_eq_mul]
    have h2_sum : (∑ x : ZMod p, if x ∈ s2 then ω else 0) = (c2 : ℂ) * ω := by
      have := sum_ite_mem_eq_card_mul s2 ω
      rw [this, nsmul_eq_mul]
    rw [h0_sum, h1_sum, h2_sum]
  have h_sum_L' : jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) = (L' : ℂ) := by
    rw [h_J1, h_J2, h_alg.1]
    dsimp only [L']
    push_cast
    ring
  have h_prod : jacobiSum χ χ * jacobiSum (χ ^ 2) (χ ^ 2) = (p : ℂ) :=
    jacobiSum_mul_self p χ hχ
  have h_alg_p : 4 * (p : ℂ) = (L' : ℂ)^2 + 27 * (M' : ℂ)^2 := by
    calc 4 * (p : ℂ) = 4 * (jacobiSum χ χ * jacobiSum (χ ^ 2) (χ ^ 2)) := by rw [h_prod]
    _ = (2 * (c0 : ℂ) - (c1 : ℂ) - (c2 : ℂ))^2 + 3 * ((c1 : ℂ) - (c2 : ℂ))^2 := by
      rw [h_J1, h_J2]
      exact h_alg.2.2
    _ = (L' : ℂ)^2 + 27 * (M' : ℂ)^2 := by
      have : ((c1 : ℂ) - (c2 : ℂ)) = 3 * (M' : ℂ) := by
        exact_mod_cast hM'
      rw [this]
      dsimp only [L']
      push_cast
      ring
  have h_alg_int : 4 * (p : ℤ) = L'^2 + 27 * M'^2 := by
    exact_mod_cast h_alg_p
  have h_eq_L : L = L' := L_unique p L M L' M' hLM hL h_alg_int hL'_mod
  rw [h_sum_L', h_eq_L]

lemma exists_L_M (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    ∃ L M : ℤ, 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2 ∧ L % 3 = 1 := by
  have hdvd : 3 ∣ Fintype.card (ZMod p) - 1 := by rw [ZMod.card p]; omega
  obtain ⟨χ, hχ⟩ := MulChar.exists_mulChar_orderOf (ZMod p) hdvd (Complex.isPrimitiveRoot_exp 3 (by decide))
  let ω : ℂ := Complex.exp (2 * Real.pi * Complex.I / 3)
  haveI : NeZero (3 : ℕ) := ⟨by decide⟩
  have h_root : IsPrimitiveRoot ω 3 := Complex.isPrimitiveRoot_exp 3 (by decide)
  let s0 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = 1)
  let s1 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω)
  let s2 := Finset.univ.filter (fun x : ZMod p => χ (x * (1 - x)) = ω^2)
  have h_mod0 : s0.card ≡ 2 [MOD 3] := s0_mod_three p hp χ hχ
  have h_mod1 : s1.card ≡ 0 [MOD 3] := s1_mod_three p χ hχ
  have h_mod2 : s2.card ≡ 0 [MOD 3] := s2_mod_three p χ hχ
  let c0 := s0.card
  let c1 := s1.card
  let c2 := s2.card
  have h_dvd : 3 ∣ ((c1 : ℤ) - (c2 : ℤ)) := by
    have : ((c1 : ℤ) - (c2 : ℤ)) % 3 = 0 := by
      have hc1 : c1 % 3 = 0 := h_mod1
      have hc2 : c2 % 3 = 0 := h_mod2
      omega
    exact Int.dvd_of_emod_eq_zero this
  obtain ⟨M', hM'⟩ := h_dvd
  let L' : ℤ := 2 * (c0 : ℤ) - (c1 : ℤ) - (c2 : ℤ)
  have hL'_mod : L' % 3 = 1 := by
    have hc0 : c0 % 3 = 2 := h_mod0
    have hc1 : c1 % 3 = 0 := h_mod1
    have hc2 : c2 % 3 = 0 := h_mod2
    dsimp [L']
    omega
  have h_pow_one : ω ^ 3 = 1 := h_root.pow_eq_one
  have hω_ne0 : ω ≠ 0 := by
    intro hz; rw [hz, zero_pow (by decide)] at h_pow_one; norm_num at h_pow_one
  have hω2_ne0 : ω ^ 2 ≠ 0 := pow_ne_zero 2 hω_ne0
  have hω_ne_sq : ω ≠ ω ^ 2 := by
    intro hz
    have : ω * (ω - 1) = 0 := by linear_combination -hz
    rcases mul_eq_zero.mp this with h | h
    · exact hω_ne0 h
    · exact (h_root.ne_one (by decide)) (sub_eq_zero.mp h)
  have hω_geom : ω^2 + ω + 1 = 0 := by
    have h_geom := h_root.geom_sum_eq_zero (by decide)
    have h_sum : (∑ i ∈ Finset.range 3, ω ^ i) = ω^2 + ω + 1 := by
      rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
      ring
    rw [← h_sum, h_geom]
  have h_alg := J_algebra (c0 : ℂ) (c1 : ℂ) (c2 : ℂ) ω hω_geom
  have h_J1 : jacobiSum χ χ = (c0 : ℂ) + (c1 : ℂ) * ω + (c2 : ℂ) * ω^2 := by
    unfold jacobiSum
    have h_split : ∀ x : ZMod p, χ x * χ (1 - x) =
        (if x ∈ s0 then 1 else 0) + (if x ∈ s1 then ω else 0) + (if x ∈ s2 then ω^2 else 0) := by
      intro x
      rw [← map_mul]
      have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
      by_cases h0 : x = 0
      · subst h0
        have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
        have : (0 : ZMod p) * (1 - 0) = 0 := by ring
        rw [this, MulChar.map_nonunit χ h00]
        have hs0 : 0 ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; norm_num at hx
        have hs1 : 0 ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω_ne0 hx.symm
        have hs2 : 0 ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω2_ne0 hx.symm
        rw [if_neg hs0, if_neg hs1, if_neg hs2]
        ring
      by_cases h1 : x = 1
      · subst h1
        have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
        have : (1 : ZMod p) * (1 - 1) = 0 := by ring
        rw [this, MulChar.map_nonunit χ h00]
        have hs0 : 1 ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; norm_num at hx
        have hs1 : 1 ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω_ne0 hx.symm
        have hs2 : 1 ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [this, MulChar.map_nonunit χ h00] at hx; exact hω2_ne0 hx.symm
        rw [if_neg hs0, if_neg hs1, if_neg hs2]
        ring
      have h1x : 1 - x ≠ 0 := sub_ne_zero.mpr (Ne.symm h1)
      have h_prod_ne : x * (1 - x) ≠ 0 := mul_ne_zero h0 h1x
      have hu : IsUnit (x * (1 - x)) := Ne.isUnit h_prod_ne
      have h_pow3 : (χ (x * (1 - x))) ^ 3 = 1 := by
        rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
      obtain ⟨k, hk, hk_eq⟩ := h_root.eq_pow_of_pow_eq_one h_pow3
      have h_chi := hk_eq.symm
      interval_cases k
      · have : (ω ^ 0) = 1 := pow_zero ω
        rw [this] at h_chi
        have hs0 : x ∈ s0 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        have hs1 : x ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx; exact (h_root.ne_one (by decide)) hx.symm
        have hs2 : x ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx.symm
        rw [h_chi, if_pos hs0, if_neg hs1, if_neg hs2]
        ring
      · have : (ω ^ 1) = ω := pow_one ω
        rw [this] at h_chi
        have hs0 : x ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx; exact (h_root.ne_one (by decide)) hx
        have hs1 : x ∈ s1 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        have hs2 : x ∉ s2 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          exact hω_ne_sq hx
        rw [h_chi, if_neg hs0, if_pos hs1, if_neg hs2]
        ring
      · have hs0 : x ∉ s0 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx
        have hs1 : x ∉ s1 := by
          intro h; have hx := (Finset.mem_filter.mp h).2; rw [h_chi] at hx
          exact hω_ne_sq.symm hx
        have hs2 : x ∈ s2 := by rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        rw [h_chi, if_neg hs0, if_neg hs1, if_pos hs2]
        ring
    simp_rw [h_split]
    rw [sum_add_distrib, sum_add_distrib]
    have h0_sum : (∑ x : ZMod p, if x ∈ s0 then (1 : ℂ) else 0) = (c0 : ℂ) := by
      have := sum_ite_mem_eq_card_mul s0 (1 : ℂ)
      rw [this, nsmul_eq_mul, mul_one]
    have h1_sum : (∑ x : ZMod p, if x ∈ s1 then ω else 0) = (c1 : ℂ) * ω := by
      have := sum_ite_mem_eq_card_mul s1 ω
      rw [this, nsmul_eq_mul]
    have h2_sum : (∑ x : ZMod p, if x ∈ s2 then ω^2 else 0) = (c2 : ℂ) * ω^2 := by
      have := sum_ite_mem_eq_card_mul s2 (ω^2)
      rw [this, nsmul_eq_mul]
    rw [h0_sum, h1_sum, h2_sum]
  have h_J2 : jacobiSum (χ ^ 2) (χ ^ 2) = (c0 : ℂ) + (c1 : ℂ) * ω^2 + (c2 : ℂ) * ω := by
    unfold jacobiSum
    have h_split : ∀ x : ZMod p, (χ ^ 2) x * (χ ^ 2) (1 - x) =
        (if x ∈ s0 then 1 else 0) + (if x ∈ s1 then ω^2 else 0) + (if x ∈ s2 then ω else 0) := by
      intro x
      rw [← map_mul]
      have : (χ ^ 2) (x * (1 - x)) = (χ (x * (1 - x))) ^ 2 := by
        rw [← MulChar.pow_apply' χ (by decide)]
      rw [this]
      by_cases hs0 : x ∈ s0
      · have hx := (Finset.mem_filter.mp hs0).2
        rw [hx, one_pow, if_pos hs0]
        have hs1 : x ∉ s1 := by
          intro h; have hx1 := (Finset.mem_filter.mp h).2; rw [hx] at hx1
          exact (h_root.ne_one (by decide)) hx1.symm
        have hs2 : x ∉ s2 := by
          intro h; have hx2 := (Finset.mem_filter.mp h).2; rw [hx] at hx2
          have : ω ^ 2 ≠ 1 := by intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
          exact this hx2.symm
        rw [if_neg hs1, if_neg hs2]
        ring
      by_cases hs1 : x ∈ s1
      · have hx := (Finset.mem_filter.mp hs1).2
        have hs2 : x ∉ s2 := fun h => hω_ne_sq (hx.symm.trans (Finset.mem_filter.mp h).2)
        rw [hx, if_neg hs0, if_pos hs1, if_neg hs2]
        ring
      by_cases hs2 : x ∈ s2
      · have hx := (Finset.mem_filter.mp hs2).2
        rw [hx, if_neg hs0, if_neg hs1, if_pos hs2]
        have : (ω ^ 2) ^ 2 = ω := by
          calc (ω ^ 2) ^ 2 = ω * ω ^ 3 := by ring
          _ = ω * 1 := by rw [h_pow_one]
          _ = ω := mul_one ω
        rw [this]
        ring
      · rw [if_neg hs0, if_neg hs1, if_neg hs2]
        have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
        have h_zero : χ (x * (1 - x)) = 0 := by
          by_contra hz
          have h_pow3 : (χ (x * (1 - x))) ^ 3 = 1 := by
            have hu : IsUnit (x * (1 - x)) := by
              by_contra hu_not
              have : x * (1 - x) = 0 := by
                by_contra h_ne_zero
                exact hu_not (Ne.isUnit h_ne_zero)
              have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
              rw [this, MulChar.map_nonunit χ h00] at hz
              exact hz rfl
            rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
          obtain ⟨k, hk, hk_eq⟩ := h_root.eq_pow_of_pow_eq_one h_pow3
          have h_chi := hk_eq.symm
          interval_cases k
          · apply hs0; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, ?_⟩; rw [pow_zero] at h_chi; exact h_chi
          · apply hs1; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, ?_⟩; rw [pow_one] at h_chi; exact h_chi
          · apply hs2; rw [Finset.mem_filter]; refine ⟨Finset.mem_univ _, h_chi⟩
        rw [h_zero, zero_pow (by decide)]
        ring
    simp_rw [h_split]
    rw [sum_add_distrib, sum_add_distrib]
    have h0_sum : (∑ x : ZMod p, if x ∈ s0 then (1 : ℂ) else 0) = (c0 : ℂ) := by
      have := sum_ite_mem_eq_card_mul s0 (1 : ℂ)
      rw [this, nsmul_eq_mul, mul_one]
    have h1_sum : (∑ x : ZMod p, if x ∈ s1 then ω^2 else 0) = (c1 : ℂ) * ω^2 := by
      have := sum_ite_mem_eq_card_mul s1 (ω^2)
      rw [this, nsmul_eq_mul]
    have h2_sum : (∑ x : ZMod p, if x ∈ s2 then ω else 0) = (c2 : ℂ) * ω := by
      have := sum_ite_mem_eq_card_mul s2 ω
      rw [this, nsmul_eq_mul]
    rw [h0_sum, h1_sum, h2_sum]
  have h_prod : jacobiSum χ χ * jacobiSum (χ ^ 2) (χ ^ 2) = (p : ℂ) :=
    jacobiSum_mul_self p χ hχ
  have h_alg_p : 4 * (p : ℂ) = (L' : ℂ)^2 + 27 * (M' : ℂ)^2 := by
    calc 4 * (p : ℂ) = 4 * (jacobiSum χ χ * jacobiSum (χ ^ 2) (χ ^ 2)) := by rw [h_prod]
    _ = (2 * (c0 : ℂ) - (c1 : ℂ) - (c2 : ℂ))^2 + 3 * ((c1 : ℂ) - (c2 : ℂ))^2 := by
      rw [h_J1, h_J2]
      exact h_alg.2.2
    _ = (L' : ℂ)^2 + 27 * (M' : ℂ)^2 := by
      have : ((c1 : ℂ) - (c2 : ℂ)) = 3 * (M' : ℂ) := by
        exact_mod_cast hM'
      rw [this]
      dsimp only [L']
      push_cast
      ring
  have h_alg_int : 4 * (p : ℤ) = L'^2 + 27 * M'^2 := by
    exact_mod_cast h_alg_p
  exact ⟨L', M', h_alg_int, hL'_mod⟩

lemma sum_one_mulchar_mul_psi (p : ℕ) [Fact p.Prime] (ψ : AddChar (ZMod p) ℂ) (hψ : ψ ≠ 1) :
    ψ 0 + ∑ j : ZMod p, (1 : MulChar (ZMod p) ℂ) j * ψ j = 0 := by
  have h_pw : ∀ j : ZMod p, (1 : MulChar (ZMod p) ℂ) j * ψ j = ψ j - (if j = 0 then ψ 0 else 0) := by
    intro j
    by_cases hj : j = 0
    · subst hj
      have h0 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit 1 h0, zero_mul, if_pos rfl, sub_self]
    · rw [if_neg hj, sub_zero, MulChar.one_apply (Ne.isUnit hj), one_mul]
  simp_rw [h_pw]
  rw [sum_sub_distrib]
  have h_sum : (∑ j : ZMod p, ψ j) = 0 := AddChar.sum_eq_zero_of_ne_one hψ
  have h_ite : (∑ j : ZMod p, if j = 0 then ψ 0 else 0) = ψ 0 := by
    rw [sum_ite_eq' univ 0 (fun _ => ψ 0)]
    simp
  rw [h_sum, h_ite]
  ring

lemma cube_roots_one_card (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    (Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1)).card = 3 := by
  have hdvd : 3 ∣ Fintype.card (ZMod p)ˣ := by
    rw [ZMod.card_units p]
    exact Nat.dvd_of_mod_eq_zero (by omega)
  have h_ker := IsCyclic.card_powMonoidHom_ker (ZMod p)ˣ 3
  rw [Nat.card_eq_fintype_card (α := (ZMod p)ˣ), ZMod.card_units p] at h_ker
  have h_gcd : (p - 1).gcd 3 = 3 := by
    have : 3 ∣ p - 1 := Nat.dvd_of_mod_eq_zero (by omega)
    exact Nat.gcd_eq_right this
  rw [h_gcd] at h_ker
  have e : ↥(powMonoidHom 3 : (ZMod p)ˣ →* (ZMod p)ˣ).ker ≃
      {w : ZMod p // w ^ 3 = 1} := by
    refine Equiv.ofBijective (fun ⟨u, hu⟩ => ⟨u.val, ?_⟩) ⟨?_, ?_⟩
    · rw [MonoidHom.mem_ker] at hu
      exact congr_arg Units.val hu
    · rintro ⟨u1, h1⟩ ⟨u2, h2⟩ h_eq
      ext
      exact Subtype.ext_iff.mp h_eq
    · rintro ⟨w, hw⟩
      have hw_unit : IsUnit w := by
        apply isUnit_of_dvd_one
        use w^2
        rw [← hw]
        ring
      obtain ⟨u, rfl⟩ := hw_unit
      refine ⟨⟨u, ?_⟩, rfl⟩
      rw [MonoidHom.mem_ker]
      ext
      exact hw
  have h_card_set : Fintype.card {w : ZMod p // w ^ 3 = 1} = 3 := by
    rw [← Fintype.card_congr e, ← Nat.card_eq_fintype_card]
    exact h_ker
  have h_flt : (Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1)).card =
      Fintype.card {w : ZMod p // w ^ 3 = 1} := by
    rw [← Fintype.card_subtype]
  rw [h_flt]
  exact h_card_set

lemma card_fiber_eq_cube_roots (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1)
    (x u : ZMod p) (hu : u ^ 3 = x) (hx : x ≠ 0) :
    (Finset.univ.filter (fun y : ZMod p => y ^ 3 = x)).card = 3 := by
  have hu0 : u ≠ 0 := by rintro rfl; rw [zero_pow (by decide)] at hu; exact hx hu.symm
  have e : {y : ZMod p // y ^ 3 = x} ≃ {w : ZMod p // w ^ 3 = 1} := by
    refine Equiv.ofBijective (fun ⟨y, hy⟩ => ⟨y * u⁻¹, ?_⟩) ⟨?_, ?_⟩
    · calc (y * u⁻¹)^3 = y^3 * (u⁻¹)^3 := mul_pow y u⁻¹ 3
      _ = x * (u^3)⁻¹ := by rw [inv_pow, hy]
      _ = x * x⁻¹ := by rw [hu]
      _ = 1 := mul_inv_cancel₀ hx
    · rintro ⟨y1, h1⟩ ⟨y2, h2⟩ h_eq
      apply Subtype.ext
      have : y1 * u⁻¹ = y2 * u⁻¹ := congr_arg Subtype.val h_eq
      exact mul_right_cancel₀ (inv_ne_zero hu0) this
    · rintro ⟨w, hw⟩
      refine ⟨⟨w * u, ?_⟩, ?_⟩
      · calc (w * u)^3 = w^3 * u^3 := mul_pow w u 3
        _ = 1 * x := by rw [hw, hu]
        _ = x := one_mul x
      · ext
        dsimp
        calc (w * u) * u⁻¹ = w * (u * u⁻¹) := by ring
        _ = w * 1 := by rw [mul_inv_cancel₀ hu0]
        _ = w := mul_one w
  have : (Finset.univ.filter (fun y : ZMod p => y ^ 3 = x)).card =
      Fintype.card {y : ZMod p // y ^ 3 = x} := by
    rw [← Fintype.card_subtype]
  rw [this, Fintype.card_congr e]
  have h_one : Fintype.card {w : ZMod p // w ^ 3 = 1} =
      (Finset.univ.filter (fun w : ZMod p => w ^ 3 = 1)).card := by
    rw [← Fintype.card_subtype]
  rw [h_one]
  exact cube_roots_one_card p hp

lemma chi_sum_eq_three_or_zero (z : ℂ) (hz3 : z ^ 3 = 1) :
    1 + z + z ^ 2 = if z = 1 then 3 else 0 := by
  by_cases hz : z = 1
  · subst hz; rw [if_pos rfl]; ring
  · rw [if_neg hz]
    have : (z - 1) * (z^2 + z + 1) = 0 := by
      calc (z - 1) * (z^2 + z + 1) = z^3 - 1 := by ring
      _ = 1 - 1 := by rw [hz3]
      _ = 0 := sub_self 1
    rcases mul_eq_zero.mp this with h | h
    · exfalso; exact hz (sub_eq_zero.mp h)
    · linear_combination h

lemma cube_of_chi_one (p : ℕ) [Fact p.Prime] (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3)
    (x : ZMod p) (hx0 : x ≠ 0) (hx1 : χ x = 1) :
    ∃ u : ZMod p, u ^ 3 = x := by
  have hu_x : IsUnit x := Ne.isUnit hx0
  obtain ⟨ux, rfl⟩ := hu_x
  obtain ⟨g, hg⟩ := IsCyclic.exists_monoid_generator (α := (ZMod p)ˣ)
  obtain ⟨k, hk⟩ : ∃ k : ℕ, g ^ k = ux := (Submonoid.mem_powers_iff ux g).mp (hg ux)
  have hχ_ne : χ ≠ 1 := by
    rintro rfl
    have : orderOf (1 : MulChar (ZMod p) ℂ) = 1 := orderOf_one
    rw [hχ] at this
    revert this; decide
  have hχ_g_ne : χ (g : ZMod p) ≠ 1 := by
    intro h1
    apply hχ_ne
    apply MulChar.ext
    intro v
    obtain ⟨m, hm⟩ := (Submonoid.mem_powers_iff v g).mp (hg v)
    have h_v_eq : (v : ZMod p) = (g : ZMod p) ^ m := by
      rw [← hm]
      push_cast
      rfl
    rw [h_v_eq, map_pow, h1, one_pow, ← h_v_eq, MulChar.one_apply v.isUnit]
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  have h_g_pow3 : (χ (g : ZMod p)) ^ 3 = 1 := by
    rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply g.isUnit]
  have h_ord_g : orderOf (χ (g : ZMod p)) = 3 := by
    have hdvd : orderOf (χ (g : ZMod p)) ∣ 3 := orderOf_dvd_of_pow_eq_one h_g_pow3
    have hne : orderOf (χ (g : ZMod p)) ≠ 1 := by
      intro h; rw [orderOf_eq_one_iff] at h; exact hχ_g_ne h
    have : Nat.Prime 3 := Nat.prime_three
    rcases (Nat.dvd_prime this).mp hdvd with h | h
    · contradiction
    · exact h
  have h_gx : (ux : ZMod p) = (g : ZMod p) ^ k := by
    rw [← hk]
    push_cast
    rfl
  have h_chi_pow : χ (ux : ZMod p) = (χ (g : ZMod p)) ^ k := by
    rw [h_gx, map_pow]
  rw [hx1] at h_chi_pow
  have hdvd_k : 3 ∣ k := by
    have : orderOf (χ (g : ZMod p)) ∣ k := orderOf_dvd_of_pow_eq_one h_chi_pow.symm
    rw [h_ord_g] at this
    exact this
  obtain ⟨m, rfl⟩ := hdvd_k
  refine ⟨(g : ZMod p) ^ m, ?_⟩
  calc ((g : ZMod p) ^ m) ^ 3 = (g : ZMod p) ^ (m * 3) := by rw [← pow_mul]
  _ = (g : ZMod p) ^ (3 * m) := by rw [mul_comm]
  _ = (ux : ZMod p) := h_gx.symm

lemma card_fiber_cube (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1)
    (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) (x : ZMod p) :
    ((univ.filter (fun y : ZMod p => y ^ 3 = x)).card : ℂ) =
      (if x = 0 then 1 else (1 : MulChar (ZMod p) ℂ) x + χ x + (χ ^ 2) x) := by
  have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
  by_cases hx : x = 0
  · subst hx
    rw [if_pos rfl]
    have : (univ.filter (fun y : ZMod p => y ^ 3 = 0)) = {0} := by
      ext y
      simp only [mem_filter, mem_univ, true_and, mem_singleton]
      have : y ^ 3 = 0 ↔ y = 0 := pow_eq_zero_iff (n := 3) (by decide)
      exact this
    rw [this, card_singleton]
    simp
  · rw [if_neg hx]
    have hu : IsUnit x := Ne.isUnit hx
    rw [MulChar.one_apply hu]
    have h_pow3 : (χ x) ^ 3 = 1 := by
      rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu]
    have h_chi_sum := chi_sum_eq_three_or_zero (χ x) h_pow3
    rw [show χ x ^ 2 = (χ ^ 2) x by rw [MulChar.pow_apply' χ (by decide)]] at h_chi_sum
    rw [h_chi_sum]
    by_cases h_cube : ∃ u : ZMod p, u ^ 3 = x
    · obtain ⟨u, hu3⟩ := h_cube
      have h_card := card_fiber_eq_cube_roots p hp x u hu3 hx
      rw [h_card]
      have h_chi1 : χ x = 1 := by
        rw [← hu3, map_pow]
        have hu_unit : IsUnit u := by
          apply isUnit_of_dvd_one
          use u^2 * x⁻¹
          calc 1 = x * x⁻¹ := (mul_inv_cancel₀ hx).symm
          _ = u * (u^2 * x⁻¹) := by rw [← hu3]; ring
        have : (χ u) ^ 3 = 1 := by
          rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu_unit]
        exact this
      rw [if_pos h_chi1]
      simp
    · have h_card : (univ.filter (fun y : ZMod p => y ^ 3 = x)) = ∅ := by
        rw [filter_eq_empty_iff]
        intro y _ hy
        exact h_cube ⟨y, hy⟩
      rw [h_card, card_empty, CharP.cast_eq_zero]
      have h_chi_ne1 : χ x ≠ 1 := by
        intro h1
        exact h_cube (cube_of_chi_one p χ hχ x hx h1)
      rw [if_neg h_chi_ne1]

lemma G_eq_sum_gaussSum (p : ℕ) [Fact p.Prime] (_hp : p % 3 = 1)
    (χ : MulChar (ZMod p) ℂ) (_hχ : orderOf χ = 3)
    (a : ZMod p) (ha : a ≠ 0)
    (h_fiber : ∀ x : ZMod p, ((univ.filter (fun y : ZMod p => y ^ 3 = x)).card : ℂ) =
      (if x = 0 then 1 else (1 : MulChar (ZMod p) ℂ) x + χ x + (χ ^ 2) x)) :
    let ψa := (ZMod.stdAddChar : AddChar (ZMod p) ℂ).mulShift a
    (∑ x : ZMod p, ψa (x ^ 3)) = gaussSum χ ψa + gaussSum (χ ^ 2) ψa := by
  intro ψa
  have h_fiberwise := sum_fiberwise (ι := ZMod p) (κ := ZMod p) (M := ℂ) univ (fun x => x ^ 3) (fun x => ψa (x ^ 3))
  have h_step : ∑ j : ZMod p, ∑ i ∈ univ.filter (fun x => x ^ 3 = j), ψa (i ^ 3) = ∑ x : ZMod p, ψa (x ^ 3) := h_fiberwise
  rw [← h_step]
  have h_inner : ∀ j : ZMod p, (∑ i ∈ univ.filter (fun x => x ^ 3 = j), ψa (i ^ 3)) =
      ((univ.filter (fun x => x ^ 3 = j)).card : ℂ) * ψa j := by
    intro j
    have : ∀ i ∈ univ.filter (fun x => x ^ 3 = j), ψa (i ^ 3) = ψa j := by
      intro i hi
      rw [mem_filter] at hi
      rw [hi.2]
    rw [sum_congr rfl this, sum_const, nsmul_eq_mul]
  simp_rw [h_inner]
  simp_rw [h_fiber]
  have h_split : ∀ j : ZMod p,
      (if j = 0 then 1 else (1 : MulChar (ZMod p) ℂ) j + χ j + (χ ^ 2) j) * ψa j =
      (if j = 0 then ψa 0 else 0) + ((1 : MulChar (ZMod p) ℂ) j + χ j + (χ ^ 2) j) * ψa j := by
    intro j
    by_cases hj : j = 0
    · subst hj
      have h0 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
      rw [MulChar.map_nonunit 1 h0, MulChar.map_nonunit χ h0, MulChar.map_nonunit (χ^2) h0]
      rw [if_pos rfl, if_pos rfl]
      ring
    · rw [if_neg hj, if_neg hj]
      ring
  simp_rw [h_split]
  rw [sum_add_distrib]
  have h_zero_term : (∑ j : ZMod p, if j = 0 then ψa 0 else 0) = ψa 0 := by
    rw [sum_ite_eq' univ 0 (fun _ => ψa 0)]
    simp
  rw [h_zero_term]
  have hψa : ψa ≠ 1 := by
    intro h
    have hprim := stdAddChar_mulShift_primitive p a ha
    have : ψa.mulShift 1 = 1 := by rw [h]; ext; simp
    have h_shift := hprim (a := 1) one_ne_zero
    exact h_shift this
  have h_zero_cancel := sum_one_mulchar_mul_psi p ψa hψa
  have : (∑ j : ZMod p, ((1 : MulChar (ZMod p) ℂ) j + χ j + (χ ^ 2) j) * ψa j) =
      (∑ j : ZMod p, (1 : MulChar (ZMod p) ℂ) j * ψa j) + gaussSum χ ψa + gaussSum (χ ^ 2) ψa := by
    calc (∑ j : ZMod p, ((1 : MulChar (ZMod p) ℂ) j + χ j + (χ ^ 2) j) * ψa j)
      _ = ∑ j : ZMod p, ((1 : MulChar (ZMod p) ℂ) j * ψa j + (χ j * ψa j + (χ ^ 2) j * ψa j)) := by
        apply sum_congr rfl; intro j _; ring
      _ = (∑ j : ZMod p, (1 : MulChar (ZMod p) ℂ) j * ψa j) + ∑ j : ZMod p, (χ j * ψa j + (χ ^ 2) j * ψa j) := sum_add_distrib
      _ = (∑ j : ZMod p, (1 : MulChar (ZMod p) ℂ) j * ψa j) + (∑ j : ZMod p, χ j * ψa j) + (∑ j : ZMod p, (χ ^ 2) j * ψa j) := by
        rw [sum_add_distrib, add_assoc]
  rw [this]
  linear_combination h_zero_cancel

lemma ite_mul_ite_nine (P Q : Prop) [Decidable P] [Decidable Q] :
    (if P then (3 : ℂ) else 0) * (if Q then 3 else 0) = if (P ∧ Q) then 9 else 0 := by
  by_cases hP : P <;> by_cases hQ : Q
  · rw [if_pos hP, if_pos hQ, if_pos ⟨hP, hQ⟩]; ring
  · rw [if_pos hP, if_neg hQ, if_neg (fun h => hQ h.2)]; ring
  · rw [if_neg hP, if_pos hQ, if_neg (fun h => hP h.1)]; ring
  · rw [if_neg hP, if_neg hQ, if_neg (fun h => hP h.1)]; ring

lemma F_eval (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1)
    (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) (x : ZMod p) :
    (1 : MulChar (ZMod p) ℂ) x + χ x + (χ ^ 2) x =
      if (x ≠ 0 ∧ ∃ u : ZMod p, u ^ 3 = x) then 3 else 0 := by
  have h_fib := card_fiber_cube p hp χ hχ x
  by_cases hx : x = 0
  · subst hx
    have h0 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
    rw [MulChar.map_nonunit 1 h0, MulChar.map_nonunit χ h0, MulChar.map_nonunit (χ^2) h0]
    split_ifs with h_if
    · exfalso; exact h_if.1 rfl
    · ring
  · rw [if_neg hx] at h_fib
    rw [← h_fib]
    by_cases hc : ∃ u : ZMod p, u ^ 3 = x
    · obtain ⟨u, hu⟩ := hc
      have h3 := card_fiber_eq_cube_roots p hp x u hu hx
      rw [h3]
      have h_pos : (x ≠ 0 ∧ ∃ u : ZMod p, u ^ 3 = x) := ⟨hx, ⟨u, hu⟩⟩
      rw [if_pos h_pos]
      simp
    · have h0 : (univ.filter (fun y : ZMod p => y ^ 3 = x)) = ∅ := by
        rw [filter_eq_empty_iff]
        intro y _ hy
        exact hc ⟨y, hy⟩
      rw [h0, card_empty, CharP.cast_eq_zero]
      have h_neg : ¬ (x ≠ 0 ∧ ∃ u : ZMod p, u ^ 3 = x) := fun h => hc h.2
      rw [if_neg h_neg]

lemma card_s0 (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    let S := (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1))
    (S.filter (fun q => q.1 = 0)).card = 3 := by
  intro S
  have e : {q : Prod (ZMod p) (ZMod p) // q ∈ S ∧ q.1 = 0} ≃ {y : ZMod p // y ^ 3 = 1} := by
    refine Equiv.ofBijective (fun ⟨q, hq⟩ => ⟨q.2, ?_⟩) ⟨?_, ?_⟩
    · have hq1 : q.1 = 0 := hq.2
      have hqS : q.1 ^ 3 + q.2 ^ 3 = 1 := (mem_filter.mp hq.1).2
      rw [hq1, zero_pow (by decide), zero_add] at hqS
      exact hqS
    · rintro ⟨q1, h1⟩ ⟨q2, h2⟩ h_eq
      apply Subtype.ext
      ext
      · rw [h1.2, h2.2]
      · exact congr_arg Subtype.val h_eq
    · rintro ⟨y, hy⟩
      have h_mem : ((0 : ZMod p), y) ∈ S := by
        rw [mem_filter]
        refine ⟨mem_univ _, ?_⟩
        dsimp
        rw [zero_pow (by decide), zero_add, hy]
      refine ⟨⟨(0, y), ⟨h_mem, rfl⟩⟩, rfl⟩
  have h_set : (S.filter (fun q => q.1 = 0)) = univ.filter (fun q => q ∈ S ∧ q.1 = 0) := by
    ext q; simp
  rw [h_set, ← Fintype.card_subtype, Fintype.card_congr e, Fintype.card_subtype]
  exact cube_roots_one_card p hp

lemma card_s1 (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    let S := (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1))
    (S.filter (fun q => q.1 ≠ 0 ∧ q.2 = 0)).card = 3 := by
  intro S
  have e : {q : Prod (ZMod p) (ZMod p) // q ∈ S ∧ q.1 ≠ 0 ∧ q.2 = 0} ≃ {x : ZMod p // x ^ 3 = 1} := by
    refine Equiv.ofBijective (fun ⟨q, hq⟩ => ⟨q.1, ?_⟩) ⟨?_, ?_⟩
    · have hq2 : q.2 = 0 := hq.2.2
      have hqS : q.1 ^ 3 + q.2 ^ 3 = 1 := (mem_filter.mp hq.1).2
      rw [hq2, zero_pow (by decide), add_zero] at hqS
      exact hqS
    · rintro ⟨q1, h1⟩ ⟨q2, h2⟩ h_eq
      apply Subtype.ext
      ext
      · exact congr_arg Subtype.val h_eq
      · rw [h1.2.2, h2.2.2]
    · rintro ⟨x, hx⟩
      have hx0 : x ≠ 0 := by
        rintro rfl
        rw [zero_pow (by decide)] at hx
        norm_num at hx
      have h_mem : (x, (0 : ZMod p)) ∈ S := by
        rw [mem_filter]
        refine ⟨mem_univ _, ?_⟩
        dsimp
        rw [zero_pow (by decide), add_zero, hx]
      refine ⟨⟨(x, 0), ⟨h_mem, hx0, rfl⟩⟩, rfl⟩
  have h_set : (S.filter (fun q => q.1 ≠ 0 ∧ q.2 = 0)) = univ.filter (fun q => q ∈ S ∧ q.1 ≠ 0 ∧ q.2 = 0) := by
    ext q; simp
  rw [h_set, ← Fintype.card_subtype, Fintype.card_congr e, Fintype.card_subtype]
  exact cube_roots_one_card p hp

lemma card_s_rest (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    let S := (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1))
    let C := (Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1)))
    (S.filter (fun q => q.1 ≠ 0 ∧ q.2 ≠ 0)).card = 9 * C.card := by
  intro S C
  let S_rest := S.filter (fun q => q.1 ≠ 0 ∧ q.2 ≠ 0)
  let f : (ZMod p × ZMod p) → ZMod p := fun q => -q.1^3
  have h_maps : ∀ q ∈ S_rest, f q ∈ C := by
    rintro ⟨x, y⟩ hq
    rw [mem_filter] at hq
    have hqS : x ^ 3 + y ^ 3 = 1 := (mem_filter.mp hq.1).2
    have hx0 : x ≠ 0 := hq.2.1
    have hy0 : y ≠ 0 := hq.2.2
    rw [mem_filter]
    refine ⟨mem_univ _, ?_⟩
    dsimp [f]
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro h
      have : x ^ 3 = 0 := by linear_combination -h
      have : x = 0 := (pow_eq_zero_iff (n := 3) (by decide)).mp this
      exact hx0 this
    · intro h
      have : y ^ 3 = 0 := by
        calc y ^ 3 = (x ^ 3 + y ^ 3) - x ^ 3 := by ring
        _ = 1 + (-x ^ 3) := by rw [hqS]; ring
        _ = 0 := by linear_combination h
      have : y = 0 := (pow_eq_zero_iff (n := 3) (by decide)).mp this
      exact hy0 this
    · refine ⟨-x, by ring⟩
    · refine ⟨y, by linear_combination hqS⟩
  have h_fiber : ∀ c ∈ C, (S_rest.filter (fun q => f q = c)).card = 9 := by
    intro c hc
    rw [mem_filter] at hc
    obtain ⟨hc0, hc1, ⟨u, hu⟩, ⟨v, hv⟩⟩ := hc.2
    have e : {q : ZMod p × ZMod p // q ∈ S_rest ∧ f q = c} ≃
        {x : ZMod p // (-x)^3 = c} × {y : ZMod p // y^3 = c + 1} := by
      refine Equiv.ofBijective (fun ⟨⟨x, y⟩, hq⟩ => ⟨⟨x, ?_⟩, ⟨y, ?_⟩⟩) ⟨?_, ?_⟩
      · have : f (x, y) = c := hq.2
        dsimp [f] at this
        calc (-x)^3 = -x^3 := by ring
        _ = c := this
      · have hS : (x, y) ∈ S := (mem_filter.mp hq.1).1
        have h_sum : x^3 + y^3 = 1 := (mem_filter.mp hS).2
        have h_f : f (x, y) = c := hq.2
        dsimp [f] at h_f
        linear_combination h_sum + h_f
      · rintro ⟨⟨x1, y1⟩, h1⟩ ⟨⟨x2, y2⟩, h2⟩ h_eq
        apply Subtype.ext
        ext
        · exact congr_arg (fun a => a.1.val) h_eq
        · exact congr_arg (fun a => a.2.val) h_eq
      · rintro ⟨⟨x, hx⟩, ⟨y, hy⟩⟩
        have hx0 : x ≠ 0 := by
          rintro rfl
          have : (- (0 : ZMod p))^3 = 0 := by ring
          rw [this] at hx
          exact hc0 hx.symm
        have hy0 : y ≠ 0 := by
          rintro rfl
          have : (0 : ZMod p)^3 = 0 := by ring
          rw [this] at hy
          have : c + 1 = 0 := hy.symm
          exact hc1 this
        have h_sum : x^3 + y^3 = 1 := by
          calc x^3 + y^3 = -((-x)^3) + (c + 1) := by rw [hy]; ring
          _ = -c + (c + 1) := by rw [hx]
          _ = 1 := by ring
        have h_mem_S : (x, y) ∈ S := by
          rw [mem_filter]; refine ⟨mem_univ _, h_sum⟩
        have h_mem_rest : (x, y) ∈ S_rest := by
          rw [mem_filter]; refine ⟨h_mem_S, hx0, hy0⟩
        have h_f_eq : f (x, y) = c := by
          dsimp [f]
          calc -x^3 = (-x)^3 := by ring
          _ = c := hx
        refine ⟨⟨(x, y), ⟨h_mem_rest, h_f_eq⟩⟩, rfl⟩
    have h_card_fiber : (S_rest.filter (fun q => f q = c)).card =
        Fintype.card {x : ZMod p // (-x)^3 = c} * Fintype.card {y : ZMod p // y^3 = c + 1} := by
      have : (S_rest.filter (fun q => f q = c)) = univ.filter (fun q => q ∈ S_rest ∧ f q = c) := by
        ext q; simp
      rw [this, ← Fintype.card_subtype, Fintype.card_congr e, Fintype.card_prod]
    rw [h_card_fiber]
    have e_neg : {x : ZMod p // (-x)^3 = c} ≃ {x : ZMod p // x^3 = c} := by
      refine Equiv.ofBijective (fun ⟨x, hx⟩ => ⟨-x, hx⟩) ⟨?_, ?_⟩
      · rintro ⟨x1, h1⟩ ⟨x2, h2⟩ h_eq
        apply Subtype.ext
        have : -x1 = -x2 := congr_arg Subtype.val h_eq
        exact neg_inj.mp this
      · rintro ⟨x, hx⟩
        refine ⟨⟨-x, ?_⟩, ?_⟩
        · rw [neg_neg]; exact hx
        · ext; simp
    have h_card_x : Fintype.card {x : ZMod p // (-x)^3 = c} = 3 := by
      rw [Fintype.card_congr e_neg, Fintype.card_subtype]
      exact card_fiber_eq_cube_roots p hp c u hu hc0
    have h_card_y : Fintype.card {y : ZMod p // y^3 = c + 1} = 3 := by
      rw [Fintype.card_subtype]
      exact card_fiber_eq_cube_roots p hp (c + 1) v hv hc1
    rw [h_card_x, h_card_y]
  have := card_eq_sum_card_fiberwise h_maps
  rw [this]
  have h_sum : (∑ c ∈ C, (S_rest.filter (fun q => f q = c)).card) = ∑ c ∈ C, 9 := by
    apply sum_congr rfl
    intro c hc
    exact h_fiber c hc
  rw [h_sum, sum_const, smul_eq_mul, mul_comm]

lemma card_cube_pairs_aux (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : Int) =
      (p : Int) - 8 + L := by
  have hdvd : 3 ∣ Fintype.card (ZMod p) - 1 := by rw [ZMod.card p]; omega
  obtain ⟨χ, hχ⟩ := MulChar.exists_mulChar_orderOf (ZMod p) hdvd (Complex.isPrimitiveRoot_exp 3 (by decide))
  have h_jacobi_L := TuringTask.jacobiSum_add_eq_L p hp L M hLM hL χ hχ
  let χ₀ : MulChar (ZMod p) ℂ := 1
  let F := fun x : ZMod p => χ₀ x + χ x + (χ ^ 2) x
  have h_sum_exp : (∑ x : ZMod p, F x * F (x + 1)) =
      jacobiSum χ₀ χ₀ + jacobiSum χ₀ χ + jacobiSum χ₀ (χ ^ 2) +
      jacobiSum χ χ₀ + jacobiSum (χ ^ 2) χ₀ +
      jacobiSum χ (χ ^ 2) + jacobiSum (χ ^ 2) χ +
      jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2) := by
    have h_odd : Odd 3 := by decide
    have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
    have h0 : (χ₀ : MulChar (ZMod p) ℂ) ^ 3 = 1 := one_pow 3
    have h2 : (χ ^ 2) ^ 3 = 1 := by
      rw [← pow_mul, show 2 * 3 = 3 * 2 by rfl, pow_mul, h_pow, one_pow]
    have s00 := TuringTask.sum_chi_mul_chi p χ₀ χ₀ h_odd h0
    have s01 := TuringTask.sum_chi_mul_chi p χ₀ χ h_odd h0
    have s02 := TuringTask.sum_chi_mul_chi p χ₀ (χ ^ 2) h_odd h0
    have s10 := TuringTask.sum_chi_mul_chi p χ χ₀ h_odd h_pow
    have s11 := TuringTask.sum_chi_mul_chi p χ χ h_odd h_pow
    have s12 := TuringTask.sum_chi_mul_chi p χ (χ ^ 2) h_odd h_pow
    have s20 := TuringTask.sum_chi_mul_chi p (χ ^ 2) χ₀ h_odd h2
    have s21 := TuringTask.sum_chi_mul_chi p (χ ^ 2) χ h_odd h2
    have s22 := TuringTask.sum_chi_mul_chi p (χ ^ 2) (χ ^ 2) h_odd h2
    have h_ring : ∀ x : ZMod p, F x * F (x + 1) =
        χ₀ x * χ₀ (x + 1) + χ₀ x * χ (x + 1) + χ₀ x * (χ ^ 2) (x + 1) +
        χ x * χ₀ (x + 1) + χ x * χ (x + 1) + χ x * (χ ^ 2) (x + 1) +
        (χ ^ 2) x * χ₀ (x + 1) + (χ ^ 2) x * χ (x + 1) + (χ ^ 2) x * (χ ^ 2) (x + 1) := by
      intro x; dsimp [F]; ring
    simp_rw [h_ring]
    repeat rw [sum_add_distrib]
    rw [s00, s01, s02, s10, s11, s12, s20, s21, s22]
    ring
  have ⟨j00, j01, j02, j10, j20, j12, j21⟩ := TuringTask.jacobiSum_vals p χ hχ
  have h_nine := TuringTask.sum_nine_jacobi p χ L h_jacobi_L j00 j01 j02 j10 j20 j12 j21
  have h_sum_L : (∑ x : ZMod p, F x * F (x + 1)) = (p : ℂ) - 8 + (L : ℂ) := by
    rw [h_sum_exp]
    linear_combination h_nine
  have h_eval : ∀ x : ZMod p, F x * F (x + 1) =
      if (¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u : ZMod p, u ^ 3 = x) ∧ (∃ v : ZMod p, v ^ 3 = x + 1)) then 9 else 0 := by
    intro x
    change ((1 : MulChar (ZMod p) ℂ) x + χ x + (χ ^ 2) x) *
      ((1 : MulChar (ZMod p) ℂ) (x + 1) + χ (x + 1) + (χ ^ 2) (x + 1)) = _
    rw [F_eval p hp χ hχ x, F_eval p hp χ hχ (x + 1)]
    rw [ite_mul_ite_nine]
    have : ((x ≠ 0 ∧ ∃ u : ZMod p, u ^ 3 = x) ∧ (x + 1 ≠ 0 ∧ ∃ v : ZMod p, v ^ 3 = x + 1)) ↔
        (¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u : ZMod p, u ^ 3 = x) ∧ ∃ v, v ^ 3 = x + 1) := by tauto
    rw [if_congr this rfl rfl]
  have h_sum_card : (∑ x : ZMod p, F x * F (x + 1)) =
      9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
        (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : ℂ) := by
    simp_rw [h_eval]
    have := TuringTask.sum_ite_mem_eq_card_mul (Finset.univ.filter (fun x : ZMod p => ¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u, u ^ 3 = x) ∧ ∃ v, v ^ 3 = x + 1)) (9 : ℂ)
    have h_rw_set : ∀ x : ZMod p, (if ¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u, u ^ 3 = x) ∧ ∃ v, v ^ 3 = x + 1 then (9 : ℂ) else 0) =
        (if x ∈ Finset.univ.filter (fun x : ZMod p => ¬x = 0 ∧ ¬x + 1 = 0 ∧ (∃ u, u ^ 3 = x) ∧ ∃ v, v ^ 3 = x + 1) then (9 : ℂ) else 0) := by
      intro x
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    simp_rw [h_rw_set]
    rw [this, nsmul_eq_mul]
    ring
  have h_main : 9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : ℂ) =
      (p : ℂ) - 8 + (L : ℂ) := by
    rw [← h_sum_card, h_sum_L]
  exact_mod_cast h_main

lemma chi_ne_one_iff_not_cube (p : ℕ) [Fact p.Prime] (_hp : p % 3 = 1)
    (χ : MulChar (ZMod p) ℂ) (hχ : orderOf χ = 3) (x : ZMod p) (hx : x ≠ 0) :
    χ x ≠ 1 ↔ ¬ ∃ u : ZMod p, u ^ 3 = x := by
  constructor
  · intro h ⟨u, hu⟩
    apply h
    rw [← hu, map_pow]
    have hu0 : u ≠ 0 := by rintro rfl; rw [zero_pow (by decide)] at hu; exact hx hu.symm
    have hu_unit : IsUnit u := Ne.isUnit hu0
    have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
    rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu_unit]
  · intro h h1
    exact h (cube_of_chi_one p χ hχ x hx h1)

lemma P_symm (u v : ℂ) :
    2 - v - v^2 - u - u^2 + 2 * u * v + 2 * u^2 * v^2 - u * v^2 - u^2 * v =
    2 - u - u^2 - v - v^2 + 2 * v * u + 2 * v^2 * u^2 - v * u^2 - v^2 * u := by
  ring

lemma P_one_left (v : ℂ) :
    2 - v - v^2 - 1 - 1^2 + 2 * 1 * v + 2 * 1^2 * v^2 - 1 * v^2 - 1^2 * v = 0 := by
  ring

lemma P_one_right (u : ℂ) :
    2 - 1 - 1^2 - u - u^2 + 2 * u * 1 + 2 * u^2 * 1^2 - u * 1^2 - u^2 * 1 = 0 := by
  ring

lemma P_same_omega (ω : ℂ) (h_cube : ω^3 = 1) :
    2 - ω - ω^2 - ω - ω^2 + 2 * ω * ω + 2 * ω^2 * ω^2 - ω * ω^2 - ω^2 * ω = 0 := by
  have h4 : (ω^2)^2 = ω := by
    calc (ω^2)^2 = ω * ω^3 := by ring
    _ = ω * 1 := by rw [h_cube]
    _ = ω := by ring
  have H : 2 - ω - ω^2 - ω - ω^2 + 2 * ω * ω + 2 * ω^2 * ω^2 - ω * ω^2 - ω^2 * ω =
      2 - 2 * ω - 2 * ω^2 + 2 * ω^2 + 2 * (ω^2)^2 - 2 * ω^3 := by ring
  rw [H, h4, h_cube]
  ring

lemma P_same_omega2 (ω : ℂ) (h_cube : ω^3 = 1) :
    2 - ω^2 - (ω^2)^2 - ω^2 - (ω^2)^2 + 2 * ω^2 * ω^2 + 2 * (ω^2)^2 * (ω^2)^2 - ω^2 * (ω^2)^2 - (ω^2)^2 * ω^2 = 0 := by
  have h4 : (ω^2)^2 = ω := by
    calc (ω^2)^2 = ω * ω^3 := by ring
    _ = ω * 1 := by rw [h_cube]
    _ = ω := by ring
  have H : 2 - ω^2 - (ω^2)^2 - ω^2 - (ω^2)^2 + 2 * ω^2 * ω^2 + 2 * (ω^2)^2 * (ω^2)^2 - ω^2 * (ω^2)^2 - (ω^2)^2 * ω^2 =
      2 - 2 * ω^2 - 2 * (ω^2)^2 + 2 * (ω^2)^2 + 2 * ((ω^2)^2 * (ω^2)^2) - 2 * (ω^2 * (ω^2)^2) := by ring
  rw [H, h4]
  have h3 : ω^2 * ω = 1 := by
    calc ω^2 * ω = ω^3 := by ring
    _ = 1 := h_cube
  have h_sq : ω * ω = ω^2 := by ring
  rw [h_sq, h3]
  ring

lemma P_omega_case (ω : ℂ) (hω : ω^2 + ω + 1 = 0) (h_cube : ω^3 = 1) :
    2 - ω^2 - (ω^2)^2 - ω - ω^2 + 2 * ω * ω^2 + 2 * ω^2 * (ω^2)^2 - ω * (ω^2)^2 - ω^2 * ω^2 = 9 := by
  have h4 : (ω^2)^2 = ω := by
    calc (ω^2)^2 = ω * ω^3 := by ring
    _ = ω * 1 := by rw [h_cube]
    _ = ω := by ring
  have h_sq : ω^2 * ω^2 = ω := by
    rw [show ω^2 * ω^2 = (ω^2)^2 by ring, h4]
  have h_cube' : ω * ω^2 = 1 := by
    calc ω * ω^2 = ω^3 := by ring
    _ = 1 := h_cube
  rw [h4, h_sq]
  have e1 : 2 * ω * ω^2 = 2 := by
    calc 2 * ω * ω^2 = 2 * (ω * ω^2) := by ring
    _ = 2 * 1 := by rw [h_cube']
    _ = 2 := by ring
  have e2 : 2 * ω^2 * ω = 2 := by
    calc 2 * ω^2 * ω = 2 * (ω * ω^2) := by ring
    _ = 2 * 1 := by rw [h_cube']
    _ = 2 := by ring
  rw [e1, e2]
  have e3 : ω * ω = ω^2 := by ring
  rw [e3]
  linear_combination (-3) * hω

lemma P_eval (u v ω : ℂ) (hu : u = 1 ∨ u = ω ∨ u = ω^2) (hv : v = 1 ∨ v = ω ∨ v = ω^2)
    (hω : ω^2 + ω + 1 = 0) (h_root : IsPrimitiveRoot ω 3) :
    2 - v - v^2 - u - u^2 + 2 * u * v + 2 * u^2 * v^2 - u * v^2 - u^2 * v =
      if (u ≠ 1 ∧ v ≠ 1 ∧ u * v = 1) then 9 else 0 := by
  have h_cube : ω^3 = 1 := h_root.pow_eq_one
  have h_om_ne1 : ω ≠ 1 := h_root.ne_one (by decide)
  have h_om_sq_ne1 : ω ^ 2 ≠ 1 := by
    intro hz; have := h_root.dvd_of_pow_eq_one 2 hz; revert this; decide
  have h_om3 : ω * ω^2 = 1 := by
    calc ω * ω^2 = ω^3 := by ring
    _ = 1 := h_cube
  have h_om_sq3 : ω^2 * ω = 1 := by
    calc ω^2 * ω = ω^3 := by ring
    _ = 1 := h_cube
  rcases hu with hu1 | hu_om | hu_om2
  · rw [hu1, P_one_left]
    split_ifs with h_if
    · exfalso; exact h_if.1 rfl
    · rfl
  · rcases hv with hv1 | hv_om | hv_om2
    · rw [hv1, P_one_right]
      split_ifs with h_if
      · exfalso; exact h_if.2.1 rfl
      · rfl
    · rw [hu_om, hv_om, P_same_omega ω h_cube]
      split_ifs with h_if
      · exfalso; apply h_om_sq_ne1
        calc ω^2 = ω * ω := by ring
        _ = 1 := h_if.2.2
      · rfl
    · rw [hu_om, hv_om2, P_omega_case ω hω h_cube]
      split_ifs with h_if
      · rfl
      · exfalso; exact h_if ⟨h_om_ne1, h_om_sq_ne1, h_om3⟩
  · rcases hv with hv1 | hv_om | hv_om2
    · rw [hv1, P_one_right]
      split_ifs with h_if
      · exfalso; exact h_if.2.1 rfl
      · rfl
    · rw [hu_om2, hv_om, P_symm (ω^2) ω, P_omega_case ω hω h_cube]
      split_ifs with h_if
      · rfl
      · exfalso; exact h_if ⟨h_om_sq_ne1, h_om_ne1, h_om_sq3⟩
    · rw [hu_om2, hv_om2, P_same_omega2 ω h_cube]
      have h_om4 : ¬ (ω^2 * ω^2 = 1) := by
        intro h
        rw [show ω^2 * ω^2 = ω * ω^3 by ring, h_cube, mul_one] at h
        exact h_om_ne1 h
      split_ifs with h_if
      · exfalso; exact h_om4 h_if.2.2
      · rfl

lemma not_dvd_sq_four (M : ℤ) (h_odd : Odd M) : ¬ (4 : ℤ) ∣ M^2 := by
  obtain ⟨k, rfl⟩ := h_odd
  intro ⟨q, hq⟩
  have : (2 * k + 1)^2 = 4 * (k^2 + k) + 1 := by ring
  rw [this] at hq
  have h_contra : (1 : ℤ) = 4 * (q - (k^2 + k)) := by linear_combination hq
  have : (4 : ℤ) ∣ 1 := ⟨q - (k^2 + k), h_contra⟩
  revert this; decide

lemma even_L_even_M (p : ℤ) (L M : ℤ) (hLM : 4 * p = L ^ 2 + 27 * M ^ 2) (hL : Even L) :
    Even M := by
  obtain ⟨x, hx⟩ := hL
  have h4 : 4 ∣ 27 * M^2 := by
    use p - x^2
    calc 27 * M^2 = 4 * p - L^2 := by linear_combination -hLM
    _ = 4 * p - (x + x)^2 := by rw [hx]
    _ = 4 * (p - x^2) := by ring
  have h_cop : IsCoprime (4 : ℤ) 27 := by decide
  rw [mul_comm] at h4
  have h_dvd : (4 : ℤ) ∣ M^2 := h_cop.dvd_of_dvd_mul_right h4
  have : Even M := by
    by_contra h_not_even
    have h_odd : Odd M := Int.not_even_iff_odd.mp h_not_even
    obtain ⟨k, rfl⟩ := h_odd
    obtain ⟨q, hq⟩ := h_dvd
    have : (2 * k + 1)^2 = 4 * (k^2 + k) + 1 := by ring
    rw [this] at hq
    have h_contra : (1 : ℤ) = 4 * (q - (k^2 + k)) := by linear_combination hq
    have : (4 : ℤ) ∣ 1 := ⟨q - (k^2 + k), h_contra⟩
    revert this; decide
  exact this

lemma L_even_gives_sum_sq (p L M : ℤ) (hLM : 4 * p = L ^ 2 + 27 * M ^ 2) (hL_even : Even L) :
    ∃ x y : ℤ, p = x ^ 2 + 27 * y ^ 2 := by
  have hM_even : Even M := even_L_even_M p L M hLM hL_even
  obtain ⟨x, hx⟩ := hL_even
  obtain ⟨y, hy⟩ := hM_even
  refine ⟨x, y, ?_⟩
  have : 4 * p = 4 * (x^2 + 27 * y^2) := by
    calc 4 * p = L^2 + 27 * M^2 := hLM
    _ = (x + x)^2 + 27 * (y + y)^2 := by rw [hx, hy]
    _ = 4 * (x^2 + 27 * y^2) := by ring
  exact mul_left_cancel₀ (by decide) this

lemma sq_mod_three_cases (k : ℤ) (h : k^2 % 3 = 1) : k % 3 = 1 ∨ (-k) % 3 = 1 := by
  have : k % 3 = 0 ∨ k % 3 = 1 ∨ k % 3 = 2 := by omega
  rcases this with h0 | h1 | h2
  · exfalso
    have : k^2 % 3 = 0 := by
      calc k^2 % 3 = (k * k) % 3 := by ring_nf
      _ = ((k % 3) * (k % 3)) % 3 := by rw [Int.mul_emod]
      _ = 0 := by rw [h0]; rfl
    omega
  · left; exact h1
  · right; omega

lemma sum_sq_gives_L_M (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) (x y : ℤ) (h_p : (p : ℤ) = x ^ 2 + 27 * y ^ 2) :
    ∃ L M : ℤ, 4 * (p : ℤ) = L ^ 2 + 27 * M ^ 2 ∧ L % 3 = 1 ∧ Even L := by
  have hp_int : (p : ℤ) % 3 = 1 := by
    have : (p : ℤ) % (3 : ℤ) = (p : ℤ) % ((3 : ℕ) : ℤ) := rfl
    rw [this, ← Int.natCast_emod, hp]
    rfl
  have h_sq : (2 * x)^2 % 3 = 1 := by
    calc (2 * x)^2 % 3 = (4 * x^2) % 3 := by ring_nf
    _ = (x^2) % 3 := by omega
    _ = (x^2 + 27 * y^2) % 3 := by omega
    _ = (p : ℤ) % 3 := by rw [← h_p]
    _ = 1 := hp_int
  have h_cases := sq_mod_three_cases (2 * x) h_sq
  rcases h_cases with h1 | h2
  · refine ⟨2 * x, 2 * y, ?_, h1, ⟨x, by ring⟩⟩
    calc 4 * (p : ℤ) = 4 * (x ^ 2 + 27 * y ^ 2) := by rw [h_p]
    _ = (2 * x)^2 + 27 * (2 * y)^2 := by ring
  · refine ⟨- (2 * x), 2 * y, ?_, h2, ⟨-x, by ring⟩⟩
    calc 4 * (p : ℤ) = 4 * (x ^ 2 + 27 * y ^ 2) := by rw [h_p]
    _ = (- (2 * x))^2 + 27 * (2 * y)^2 := by ring

lemma inv_in_C (p : ℕ) [Fact p.Prime] (x : ZMod p)
    (hx0 : x ≠ 0) (hx1 : x + 1 ≠ 0)
    (hu : ∃ u : ZMod p, u ^ 3 = x) (hv : ∃ v : ZMod p, v ^ 3 = x + 1) :
    x⁻¹ ≠ 0 ∧ x⁻¹ + 1 ≠ 0 ∧ (∃ u : ZMod p, u ^ 3 = x⁻¹) ∧ (∃ v : ZMod p, v ^ 3 = x⁻¹ + 1) := by
  have hx_inv0 : x⁻¹ ≠ 0 := inv_ne_zero hx0
  have hx_inv1 : x⁻¹ + 1 ≠ 0 := by
    intro h
    have : x⁻¹ = -1 := eq_neg_of_add_eq_zero_left h
    have : x = -1 := by rw [← inv_inv x, this, inv_neg, inv_one]
    have : x + 1 = 0 := by linear_combination this
    exact hx1 this
  obtain ⟨u, rfl⟩ := hu
  obtain ⟨v, hv3⟩ := hv
  have hu0 : u ≠ 0 := by rintro rfl; rw [zero_pow (by decide)] at hx0; exact hx0 rfl
  have h_cube_inv : (u⁻¹)^3 = (u^3)⁻¹ := by rw [inv_pow]
  have h_cube_add : (v * u⁻¹)^3 = (u^3)⁻¹ + 1 := by
    calc (v * u⁻¹)^3 = v^3 * (u⁻¹)^3 := mul_pow v u⁻¹ 3
    _ = (u^3 + 1) * (u^3)⁻¹ := by rw [hv3, inv_pow]
    _ = (u^3) * (u^3)⁻¹ + (u^3)⁻¹ := by ring
    _ = 1 + (u^3)⁻¹ := by rw [mul_inv_cancel₀ hx0]
    _ = (u^3)⁻¹ + 1 := by ring
  exact ⟨hx_inv0, hx_inv1, ⟨u⁻¹, h_cube_inv⟩, ⟨v * u⁻¹, h_cube_add⟩⟩

lemma two_cube_iff_card_odd (p : ℕ) [Fact p.Prime] (hp : p % 3 = 1) :
    let C := (Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1)))
    (exists z : ZMod p, z ^ 3 = 2) ↔ C.card % 2 = 1 := by
  intro C
  have h_inv_maps : ∀ x ∈ C, x⁻¹ ∈ C := by
    intro x hx
    rw [mem_filter] at hx ⊢
    refine ⟨mem_univ _, ?_⟩
    exact inv_in_C p x hx.2.1 hx.2.2.1 hx.2.2.2.1 hx.2.2.2.2
  let f : Function.End {x // x ∈ C} := fun x => ⟨x.val⁻¹, h_inv_maps x.val x.property⟩
  have hf2 : f ^ 2 = 1 := by
    apply _root_.funext
    rintro ⟨x, hx⟩
    apply Subtype.ext
    dsimp [f]
    exact inv_inv x
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  have hf_pow : f ^ (2 ^ 1) = 1 := by simpa using hf2
  have h_mod := Equiv.Perm.card_fixedPoints_modEq (p := 2) (n := 1) hf_pow
  have h_C_card_α : Fintype.card {x // x ∈ C} = C.card := Fintype.card_coe C
  have h_fix_iff : ∀ x : {x // x ∈ C}, (f : {x // x ∈ C} → {x // x ∈ C}) x = x ↔ x.val = 1 := by
    rintro ⟨x, hx⟩
    rw [Subtype.ext_iff]
    dsimp [f]
    constructor
    · intro h
      have hx0 : x ≠ 0 := (mem_filter.mp hx).2.1
      have hx1 : x + 1 ≠ 0 := (mem_filter.mp hx).2.2.1
      have : x^2 = 1 := by
        calc x^2 = x * x := sq x
        _ = x⁻¹ * x := by rw [h]
        _ = 1 := inv_mul_cancel₀ hx0
      have : (x - 1) * (x + 1) = 0 := by
        calc (x - 1) * (x + 1) = x^2 - 1 := by ring
        _ = 1 - 1 := by rw [‹x^2 = 1›]
        _ = 0 := sub_self 1
      rcases mul_eq_zero.mp this with h_one | h_neg_one
      · exact sub_eq_zero.mp h_one
      · exfalso; exact hx1 h_neg_one
    · intro h
      rw [h, inv_one]
  constructor
  · intro ⟨z, hz⟩
    have h1_in_C : (1 : ZMod p) ∈ C := by
      have hp7 : p ≥ 7 := by
        have hp_prime := (Fact.out : Nat.Prime p)
        have : p ≠ 2 := by rintro rfl; revert hp; decide
        have : p ≠ 3 := by rintro rfl; revert hp; decide
        have : p ≠ 5 := by rintro rfl; revert hp; decide
        have : p > 0 := hp_prime.pos
        have : p ≠ 1 := hp_prime.ne_one
        have : p ≠ 4 := by rintro rfl; contradiction
        have : p ≠ 6 := by rintro rfl; contradiction
        omega
      rw [mem_filter]
      refine ⟨mem_univ _, ?_⟩
      refine ⟨one_ne_zero, ?_, ⟨1, one_pow 3⟩, ⟨z, ?_⟩⟩
      · intro h
        have : (2 : ZMod p) = 0 := by linear_combination h
        have hp2 : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
        have : p ≤ 2 := Nat.le_of_dvd (by decide) hp2
        omega
      · rw [hz]; ring
    let a1 : {x // x ∈ C} := ⟨1, h1_in_C⟩
    have h_sub : (Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) = {a1} := by
      ext ⟨x, hx⟩
      simp only [Set.mem_singleton_iff, Subtype.ext_iff]
      exact h_fix_iff ⟨x, hx⟩
    have h_card_one : Fintype.card ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) = 1 := by
      have e : ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) ≃ ↑({a1} : Finset {x // x ∈ C}) := by
        apply Equiv.setCongr
        ext ⟨x, hx⟩
        simp only [h_sub, Set.mem_singleton_iff, mem_coe, mem_singleton]
      rw [Fintype.card_congr e, Fintype.card_coe, card_singleton]
    rw [h_C_card_α] at h_mod
    have : C.card ≡ 1 [MOD 2] := by
      calc C.card ≡ Fintype.card ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) [MOD 2] := h_mod
      _ ≡ 1 [MOD 2] := by rw [h_card_one]
    exact this
  · intro h_odd
    by_contra h_no_cube
    have h1_not_C : (1 : ZMod p) ∉ C := by
      intro h1
      have : ∃ v : ZMod p, v ^ 3 = (1 : ZMod p) + 1 := (mem_filter.mp h1).2.2.2.2
      rw [show (1 : ZMod p) + 1 = 2 by ring] at this
      exact h_no_cube this
    have h_empty : IsEmpty ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) := by
      constructor
      rintro ⟨⟨x, hx⟩, hx_fix⟩
      rw [Function.mem_fixedPoints] at hx_fix
      have hx1 : x = 1 := (h_fix_iff ⟨x, hx⟩).mp hx_fix
      rw [hx1] at hx
      exact h1_not_C hx
    have h_card_zero : Fintype.card ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) = 0 := Fintype.card_eq_zero
    rw [h_C_card_α] at h_mod
    have : C.card ≡ 0 [MOD 2] := by
      calc C.card ≡ Fintype.card ↑(Function.fixedPoints (f : {x // x ∈ C} → {x // x ∈ C})) [MOD 2] := h_mod
      _ ≡ 0 [MOD 2] := by rw [h_card_zero]
    rw [Nat.ModEq] at this
    omega

/-! ### Section 4: Main Theorems -/

theorem card_cubic (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1)).card : Int) =
      (p : Int) - 2 + L := by
  let S := (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.1 ^ 3 + q.2 ^ 3 = 1))
  have h_s0 := card_s0 p hp
  have h_s1 := card_s1 p hp
  have h_s_rest := card_s_rest p hp
  have h1 := (card_filter_add_card_filter_not (fun q : ZMod p × ZMod p => q.1 = 0) (s := S)).symm
  have h2 := (card_filter_add_card_filter_not (fun q : ZMod p × ZMod p => q.2 = 0) (s := S.filter (fun q => ¬q.1 = 0))).symm
  have e1 : {a ∈ S.filter (fun q => ¬q.1 = 0) | a.2 = 0} = S.filter (fun q => q.1 ≠ 0 ∧ q.2 = 0) :=
    filter_filter (fun q => ¬q.1 = 0) (fun q => q.2 = 0) S
  have e2 : {a ∈ S.filter (fun q => ¬q.1 = 0) | ¬a.2 = 0} = S.filter (fun q => q.1 ≠ 0 ∧ q.2 ≠ 0) :=
    filter_filter (fun q => ¬q.1 = 0) (fun q => ¬q.2 = 0) S
  rw [e1, e2] at h2
  have h_card_S : (S.card : ℤ) = 6 + 9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : ℤ) := by
    have : S.card = 3 + 3 + 9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card) := by
      rw [h1, h2, h_s0, h_s1, h_s_rest]
      omega
    exact_mod_cast this
  have h_cube_pairs := card_cube_pairs_aux p hp L M hLM hL
  calc (S.card : ℤ) = 6 + 9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
        (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : ℤ) := h_card_S
    _ = 6 + ((p : ℤ) - 8 + L) := by rw [h_cube_pairs]
    _ = (p : ℤ) - 2 + L := by ring

theorem card_cube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
      (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1))).card : Int) =
      (p : Int) - 8 + L :=
  card_cube_pairs_aux p hp L M hLM hL

theorem card_noncube_pairs (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1) :
    9 * ((Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
      Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1)))).card : Int) =
      2 * ((p : Int) + 1 + L) := by
  have hdvd : 3 ∣ Fintype.card (ZMod p) - 1 := by rw [ZMod.card p]; omega
  obtain ⟨χ, hχ⟩ := MulChar.exists_mulChar_orderOf (ZMod p) hdvd (Complex.isPrimitiveRoot_exp 3 (by decide))
  have h_jacobi_L := TuringTask.jacobiSum_add_eq_L p hp L M hLM hL χ hχ
  let χ₀ : MulChar (ZMod p) ℂ := 1
  let term := fun x : ZMod p =>
    2 * χ₀ x * χ₀ (x + 1) - χ₀ x * χ (x + 1) - χ₀ x * (χ ^ 2) (x + 1) -
    χ x * χ₀ (x + 1) - (χ ^ 2) x * χ₀ (x + 1) +
    2 * χ x * χ (x + 1) + 2 * (χ ^ 2) x * (χ ^ 2) (x + 1) -
    χ x * (χ ^ 2) (x + 1) - (χ ^ 2) x * χ (x + 1)
  have h_sum_exp : (∑ x : ZMod p, term x) =
      2 * jacobiSum χ₀ χ₀ - jacobiSum χ₀ χ - jacobiSum χ₀ (χ ^ 2) -
      jacobiSum χ χ₀ - jacobiSum (χ ^ 2) χ₀ +
      2 * (jacobiSum χ χ + jacobiSum (χ ^ 2) (χ ^ 2)) -
      jacobiSum χ (χ ^ 2) - jacobiSum (χ ^ 2) χ := by
    have h_odd : Odd 3 := by decide
    have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
    have h0 : (χ₀ : MulChar (ZMod p) ℂ) ^ 3 = 1 := one_pow 3
    have h2 : (χ ^ 2) ^ 3 = 1 := by
      rw [← pow_mul, show 2 * 3 = 3 * 2 by rfl, pow_mul, h_pow, one_pow]
    have s00 := TuringTask.sum_chi_mul_chi p χ₀ χ₀ h_odd h0
    have s01 := TuringTask.sum_chi_mul_chi p χ₀ χ h_odd h0
    have s02 := TuringTask.sum_chi_mul_chi p χ₀ (χ ^ 2) h_odd h0
    have s10 := TuringTask.sum_chi_mul_chi p χ χ₀ h_odd h_pow
    have s11 := TuringTask.sum_chi_mul_chi p χ χ h_odd h_pow
    have s12 := TuringTask.sum_chi_mul_chi p χ (χ ^ 2) h_odd h_pow
    have s20 := TuringTask.sum_chi_mul_chi p (χ ^ 2) χ₀ h_odd h2
    have s21 := TuringTask.sum_chi_mul_chi p (χ ^ 2) χ h_odd h2
    have s22 := TuringTask.sum_chi_mul_chi p (χ ^ 2) (χ ^ 2) h_odd h2
    have h_ring : ∀ x : ZMod p, term x =
        2 * (χ₀ x * χ₀ (x + 1)) - (χ₀ x * χ (x + 1)) - (χ₀ x * (χ ^ 2) (x + 1)) -
        (χ x * χ₀ (x + 1)) - ((χ ^ 2) x * χ₀ (x + 1)) +
        2 * (χ x * χ (x + 1)) + 2 * ((χ ^ 2) x * (χ ^ 2) (x + 1)) -
        (χ x * (χ ^ 2) (x + 1)) - ((χ ^ 2) x * χ (x + 1)) := by
      intro x; dsimp [term]; ring
    simp_rw [h_ring]
    simp only [sum_sub_distrib, sum_add_distrib]
    simp_rw [← mul_sum]
    rw [s00, s01, s02, s10, s20, s11, s22, s12, s21]
    ring
  have ⟨j00, j01, j02, j10, j20, j12, j21⟩ := TuringTask.jacobiSum_vals p χ hχ
  have h_noncube := TuringTask.sum_noncube_jacobi p χ L h_jacobi_L j00 j01 j02 j10 j20 j12 j21
  have h_sum_L : (∑ x : ZMod p, term x) = 2 * ((p : ℂ) + 1 + (L : ℂ)) := by
    rw [h_sum_exp]
    linear_combination h_noncube
  have h_eval : ∀ x : ZMod p, term x =
      if (¬ (∃ u : ZMod p, u ^ 3 = x) ∧ ¬ (∃ v : ZMod p, v ^ 3 = x + 1) ∧ (∃ w : ZMod p, w ^ 3 = x * (x + 1))) then 9 else 0 := by
    intro x
    have h00 : ¬ IsUnit (0 : ZMod p) := not_isUnit_zero
    by_cases h0 : x = 0
    · subst h0
      have hc : ∃ u : ZMod p, u ^ 3 = 0 := ⟨0, zero_pow (by decide)⟩
      split_ifs with h_cond
      · exfalso; exact h_cond.1 hc
      · dsimp [term]
        rw [MulChar.map_nonunit 1 h00, MulChar.map_nonunit χ h00, MulChar.map_nonunit (χ^2) h00]
        ring
    by_cases h1 : x + 1 = 0
    · have hc : ∃ v : ZMod p, v ^ 3 = x + 1 := by rw [h1]; exact ⟨0, zero_pow (by decide)⟩
      split_ifs with h_cond
      · exfalso; exact h_cond.2.1 hc
      · dsimp [term]
        rw [h1, MulChar.map_nonunit 1 h00, MulChar.map_nonunit χ h00, MulChar.map_nonunit (χ^2) h00]
        ring
    have hu0 : IsUnit x := Ne.isUnit h0
    have hu1 : IsUnit (x + 1) := Ne.isUnit h1
    dsimp [term]
    rw [MulChar.one_apply hu0, MulChar.one_apply hu1]
    have h_prod_ne : x * (x + 1) ≠ 0 := mul_ne_zero h0 h1
    have h_pow : χ ^ 3 = 1 := orderOf_dvd_iff_pow_eq_one.mp (by rw [hχ])
    have h_root := Complex.isPrimitiveRoot_exp 3 (by decide)
    have h_pow3_u : (χ x) ^ 3 = 1 := by
      rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu0]
    have h_pow3_v : (χ (x + 1)) ^ 3 = 1 := by
      rw [← MulChar.pow_apply' χ (by decide), h_pow, MulChar.one_apply hu1]
    have h_u_cases := roots_of_unity_three (χ x) h_pow3_u
    have h_v_cases := roots_of_unity_three (χ (x + 1)) h_pow3_v
    let ω := Complex.exp (2 * ↑Real.pi * Complex.I / ↑3)
    have hω_geom : ω^2 + ω + 1 = 0 := by
      have h_geom := h_root.geom_sum_eq_zero (by decide)
      have h_sum : (∑ i ∈ Finset.range 3, ω ^ i) = ω^2 + ω + 1 := by
        rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_one]
        ring
      rw [← h_sum]
      exact h_geom
    have h_P_eq : 2 * 1 * 1 - 1 * χ (x + 1) - 1 * (χ ^ 2) (x + 1) -
        χ x * 1 - (χ ^ 2) x * 1 +
        2 * χ x * χ (x + 1) + 2 * (χ ^ 2) x * (χ ^ 2) (x + 1) -
        χ x * (χ ^ 2) (x + 1) - (χ ^ 2) x * χ (x + 1) =
        2 - χ (x + 1) - (χ (x + 1))^2 - χ x - (χ x)^2 + 2 * χ x * χ (x + 1) +
        2 * (χ x)^2 * (χ (x + 1))^2 - χ x * (χ (x + 1))^2 - (χ x)^2 * χ (x + 1) := by
      rw [show (χ ^ 2) x = (χ x)^2 by rw [MulChar.pow_apply' χ (by decide)]]
      rw [show (χ ^ 2) (x + 1) = (χ (x + 1))^2 by rw [MulChar.pow_apply' χ (by decide)]]
      ring
    rw [h_P_eq]
    have h_iff_u : χ x ≠ 1 ↔ ¬ ∃ u : ZMod p, u ^ 3 = x := chi_ne_one_iff_not_cube p hp χ hχ x h0
    have h_iff_v : χ (x + 1) ≠ 1 ↔ ¬ ∃ v : ZMod p, v ^ 3 = x + 1 := chi_ne_one_iff_not_cube p hp χ hχ (x + 1) h1
    have h_iff_prod : χ x * χ (x + 1) = 1 ↔ ∃ w : ZMod p, w ^ 3 = x * (x + 1) := by
      rw [← map_mul, ← not_ne_iff]
      rw [chi_ne_one_iff_not_cube p hp χ hχ (x * (x + 1)) h_prod_ne]
      exact not_not
    have h_goal_cond : (χ x ≠ 1 ∧ χ (x + 1) ≠ 1 ∧ χ x * χ (x + 1) = 1) ↔
        (¬ (∃ u, u ^ 3 = x) ∧ ¬ (∃ v, v ^ 3 = x + 1) ∧ ∃ w, w ^ 3 = x * (x + 1)) := by
      rw [← h_iff_u, ← h_iff_v, ← h_iff_prod]
    rw [← if_congr h_goal_cond rfl rfl]
    exact P_eval (χ x) (χ (x + 1)) ω h_u_cases h_v_cases hω_geom h_root
  have h_sum_card : (∑ x : ZMod p, term x) =
      9 * ((Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
        Not (exists v : ZMod p, v ^ 3 = x + 1) /\
        (exists w : ZMod p, w ^ 3 = x * (x + 1)))).card : ℂ) := by
    simp_rw [h_eval]
    have := TuringTask.sum_ite_mem_eq_card_mul (Finset.univ.filter (fun x : ZMod p =>
      ¬(∃ u, u ^ 3 = x) ∧ ¬(∃ v, v ^ 3 = x + 1) ∧ ∃ w, w ^ 3 = x * (x + 1))) (9 : ℂ)
    have h_rw_set : ∀ x : ZMod p,
        (if ¬(∃ u, u ^ 3 = x) ∧ ¬(∃ v, v ^ 3 = x + 1) ∧ ∃ w, w ^ 3 = x * (x + 1) then (9 : ℂ) else 0) =
        (if x ∈ Finset.univ.filter (fun x : ZMod p => ¬(∃ u, u ^ 3 = x) ∧ ¬(∃ v, v ^ 3 = x + 1) ∧ ∃ w, w ^ 3 = x * (x + 1)) then (9 : ℂ) else 0) := by
      intro x
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    simp_rw [h_rw_set]
    rw [this, nsmul_eq_mul]
    ring
  have h_main : 9 * ((Finset.univ.filter (fun x : ZMod p => Not (exists u : ZMod p, u ^ 3 = x) /\
      Not (exists v : ZMod p, v ^ 3 = x + 1) /\
      (exists w : ZMod p, w ^ 3 = x * (x + 1)))).card : ℂ) =
      2 * ((p : ℂ) + 1 + (L : ℂ)) := by
    rw [← h_sum_card, h_sum_L]
  exact_mod_cast h_main

theorem two_cube_iff (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) :
    (exists z : ZMod p, z ^ 3 = 2) <-> exists x y : Int, (p : Int) = x ^ 2 + 27 * y ^ 2 := by
  have h_odd_card := two_cube_iff_card_odd p hp
  let C := (Finset.univ.filter (fun x : ZMod p => Not (x = 0) /\ Not (x + 1 = 0) /\
    (exists u : ZMod p, u ^ 3 = x) /\ (exists v : ZMod p, v ^ 3 = x + 1)))
  constructor
  · intro h2
    have hC_odd : C.card % 2 = 1 := h_odd_card.mp h2
    obtain ⟨L0, M0, hLM0, hL0⟩ := exists_L_M p hp
    have h_cp := card_cube_pairs_aux p hp L0 M0 hLM0 hL0
    have hp7 : p ≥ 7 := by
      have hp_prime := (Fact.out : Nat.Prime p)
      have : p ≠ 2 := by rintro rfl; revert hp; decide
      have : p ≠ 3 := by rintro rfl; revert hp; decide
      have : p ≠ 5 := by rintro rfl; revert hp; decide
      have : p > 0 := hp_prime.pos
      have : p ≠ 1 := hp_prime.ne_one
      have : p ≠ 4 := by rintro rfl; contradiction
      have : p ≠ 6 := by rintro rfl; contradiction
      omega
    have h_p_odd : (p : ℤ) % 2 = 1 := by
      have : Odd p := (Fact.out : Nat.Prime p).odd_of_ne_two (by omega)
      obtain ⟨k, rfl⟩ := this
      omega
    have h_even_L0 : Even L0 := by
      have : (9 * (C.card : ℤ)) % 2 = ((p : ℤ) - 8 + L0) % 2 := by rw [h_cp]
      have : L0 % 2 = 0 := by omega
      exact even_iff_two_dvd.mpr (Int.dvd_of_emod_eq_zero this)
    exact L_even_gives_sum_sq (p : ℤ) L0 M0 hLM0 h_even_L0
  · rintro ⟨x, y, h_p⟩
    obtain ⟨L0, M0, hLM0, hL0, hL0_even⟩ := sum_sq_gives_L_M p hp x y h_p
    have h_cp := card_cube_pairs_aux p hp L0 M0 hLM0 hL0
    have h_even_L0 : L0 % 2 = 0 := by
      obtain ⟨k, rfl⟩ := hL0_even
      ring_nf; omega
    have hp7 : p ≥ 7 := by
      have hp_prime := (Fact.out : Nat.Prime p)
      have : p ≠ 2 := by rintro rfl; revert hp; decide
      have : p ≠ 3 := by rintro rfl; revert hp; decide
      have : p ≠ 5 := by rintro rfl; revert hp; decide
      have : p > 0 := hp_prime.pos
      have : p ≠ 1 := hp_prime.ne_one
      have : p ≠ 4 := by rintro rfl; contradiction
      have : p ≠ 6 := by rintro rfl; contradiction
      omega
    have h_p_odd : (p : ℤ) % 2 = 1 := by
      have : Odd p := (Fact.out : Nat.Prime p).odd_of_ne_two (by omega)
      obtain ⟨k, rfl⟩ := this
      omega
    have : (9 * (C.card : ℤ)) % 2 = ((p : ℤ) - 8 + L0) % 2 := by rw [h_cp]
    have hC_odd : C.card % 2 = 1 := by omega
    exact h_odd_card.mpr hC_odd

theorem cubic_sum (p : Nat) [Fact p.Prime] (hp : p % 3 = 1) (L M : Int)
    (hLM : 4 * (p : Int) = L ^ 2 + 27 * M ^ 2) (hL : L % 3 = 1)
    (a : ZMod p) (ha : Not (a = 0)) (G : Complex)
    (hG : G = Finset.sum Finset.univ (fun x : ZMod p =>
      Complex.exp (2 * Real.pi * Complex.I * ((a * x ^ 3).val : Complex) / (p : Complex)))) :
    G ^ 3 = 3 * (p : Complex) * G + (p : Complex) * (L : Complex) := by
  have hdvd : 3 ∣ Fintype.card (ZMod p) - 1 := by rw [ZMod.card p]; omega
  obtain ⟨χ, hχ⟩ := MulChar.exists_mulChar_orderOf (ZMod p) hdvd (Complex.isPrimitiveRoot_exp 3 (by decide))
  have h_jacobi_L := TuringTask.jacobiSum_add_eq_L p hp L M hLM hL χ hχ
  let ψa := (ZMod.stdAddChar : AddChar (ZMod p) ℂ).mulShift a
  have hψa : ψa.IsPrimitive := stdAddChar_mulShift_primitive p a ha
  have ⟨h1, h2⟩ := gaussSum_cube p χ hχ ψa hψa
  have hm := gaussSum_mul_sq p χ hχ ψa hψa
  have hG_eq : G = ∑ x : ZMod p, ψa (x ^ 3) := by
    rw [hG]
    apply Finset.sum_congr rfl
    intro x _
    have h_std := stdAddChar_eq p (a * x ^ 3)
    rw [show ψa (x ^ 3) = ZMod.stdAddChar (a * x ^ 3) from rfl]
    rw [h_std]
  have h_fiber := card_fiber_cube p hp χ hχ
  have h_G_split : (∑ x : ZMod p, ψa (x ^ 3)) = gaussSum χ ψa + gaussSum (χ ^ 2) ψa :=
    G_eq_sum_gaussSum p hp χ hχ a ha h_fiber
  have h_cube := cube_add (gaussSum χ ψa) (gaussSum (χ ^ 2) ψa) (jacobiSum χ χ) (jacobiSum (χ ^ 2) (χ ^ 2)) p h1 h2 hm
  rw [h_jacobi_L] at h_cube
  rw [hG_eq, h_G_split]
  exact h_cube

end TuringTask

export TuringTask (card_cubic card_cube_pairs card_noncube_pairs two_cube_iff cubic_sum)

