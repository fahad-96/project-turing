import OddGaussSum.Spectral

open scoped BigOperators ComplexConjugate

namespace OddGaussSum

noncomputable section

def fourierMatrix (n : ℕ) [NeZero n] : Matrix (ZMod n) (ZMod n) ℂ :=
  fun i j => ZMod.stdAddChar (i * j)

def negMatrix (n : ℕ) [NeZero n] : Matrix (ZMod n) (ZMod n) ℂ :=
  fun i j => if i = -j then 1 else 0

theorem fourierMatrix_sq (n : ℕ) [NeZero n] :
    fourierMatrix n * fourierMatrix n = (n : ℂ) • negMatrix n := by
  ext i k
  rw [Matrix.mul_apply]
  have hsum := AddChar.sum_mulShift (ψ := ZMod.stdAddChar) (i + k)
    (ZMod.isPrimitive_stdAddChar n)
  simp only [fourierMatrix] at hsum ⊢
  rw [show (∑ x : ZMod n, ZMod.stdAddChar (i * x) *
      ZMod.stdAddChar (x * k)) =
      ∑ x : ZMod n, ZMod.stdAddChar (x * (i + k)) by
    apply Finset.sum_congr rfl
    intro x _
    rw [← AddChar.map_add_eq_mul]
    congr 2 <;> ring]
  change (∑ x : ZMod n, ZMod.stdAddChar (x * (i + k))) =
    (n : ℂ) * negMatrix n i k
  rw [show (∑ x : ZMod n, ZMod.stdAddChar (x * (i + k))) =
      (if i + k = 0 then (n : ℂ) else 0) by
    simpa [ZMod.card] using hsum]
  simp only [negMatrix]
  by_cases h : i + k = 0
  · have hik : i = -k := eq_neg_iff_add_eq_zero.2 h
    simp [h, hik]
  · have hik : i ≠ -k := by
      intro hik
      apply h
      exact eq_neg_iff_add_eq_zero.1 hik
    simp [h, hik]

theorem negMatrix_sq (n : ℕ) [NeZero n] :
    negMatrix n * negMatrix n = 1 := by
  ext i k
  rw [Matrix.mul_apply]
  simp only [negMatrix, Matrix.one_apply]
  by_cases hik : i = k
  · subst k
    simp
  · simp [hik]

def normalizedFourierMatrix (n : ℕ) [NeZero n] :
    Matrix (ZMod n) (ZMod n) ℂ :=
  ((Real.sqrt n : ℂ)⁻¹) • fourierMatrix n

theorem normalizedFourierMatrix_sq (n : ℕ) [NeZero n] :
    normalizedFourierMatrix n * normalizedFourierMatrix n = negMatrix n := by
  have hn : 0 < n := Nat.pos_of_ne_zero (NeZero.ne n)
  have hsqrt : (Real.sqrt n : ℂ) ^ 2 = n := by
    exact_mod_cast Real.sq_sqrt (by positivity : (0 : ℝ) ≤ n)
  rw [normalizedFourierMatrix, Matrix.smul_mul, Matrix.mul_smul,
    fourierMatrix_sq, smul_smul]
  have hsqrt0 : (Real.sqrt n : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.2 (by positivity : (0 : ℝ) < n)))
  have hc : (Real.sqrt n : ℂ)⁻¹ * (Real.sqrt n : ℂ)⁻¹ * (n : ℂ) = 1 := by
    rw [← hsqrt]
    field_simp
  rw [smul_smul, hc, one_smul]

theorem normalizedFourierMatrix_fourth (n : ℕ) [NeZero n] :
    normalizedFourierMatrix n ^ 4 = 1 := by
  rw [show normalizedFourierMatrix n ^ 4 =
      (normalizedFourierMatrix n * normalizedFourierMatrix n) *
        (normalizedFourierMatrix n * normalizedFourierMatrix n) by
    noncomm_ring,
    normalizedFourierMatrix_sq, negMatrix_sq]

theorem trace_negMatrix_of_odd (n : ℕ) [NeZero n] (hodd : Odd n) :
    (negMatrix n).trace = 1 := by
  have hcop : Nat.Coprime 2 n := (Nat.coprime_comm.mp hodd.coprime_two_right)
  have hu : IsUnit (2 : ZMod n) := (ZMod.isUnit_iff_coprime 2 n).2 hcop
  rw [Matrix.trace]
  have hterm (i : ZMod n) : (if i = -i then (1 : ℂ) else 0) =
      if i = 0 then 1 else 0 := by
    by_cases hi : i = 0
    · simp [hi]
    · have hin : i ≠ -i := by
        intro h
        have h2 : (2 : ZMod n) * i = (2 : ZMod n) * 0 := by
          rw [mul_zero]
          simpa [two_mul, eq_comm] using congrArg (fun z => z + i) h
        exact hi (hu.mul_left_cancel h2)
      simp [hi, hin]
  change (∑ i : ZMod n, if i = -i then (1 : ℂ) else 0) = 1
  calc
    _ = ∑ i : ZMod n, if i = 0 then (1 : ℂ) else 0 := by
      apply Finset.sum_congr rfl
      intro i _
      exact hterm i
    _ = 1 := by simp

theorem trace_normalized_sq_of_odd (n : ℕ) [NeZero n] (hodd : Odd n) :
    (normalizedFourierMatrix n * normalizedFourierMatrix n).trace = 1 := by
  rw [normalizedFourierMatrix_sq, trace_negMatrix_of_odd n hodd]

def quadraticSumZMod (n : ℕ) [NeZero n] : ℂ :=
  ∑ x : ZMod n, ZMod.stdAddChar (x ^ 2)

theorem trace_fourierMatrix (n : ℕ) [NeZero n] :
    (fourierMatrix n).trace = quadraticSumZMod n := by
  simp [Matrix.trace, fourierMatrix, quadraticSumZMod, pow_two]

theorem quadraticSumZMod_norm (n : ℕ) [NeZero n] (hodd : Odd n) :
    ‖quadraticSumZMod n‖ = Real.sqrt n := by
  have hcop : Nat.Coprime 2 n := (Nat.coprime_comm.mp hodd.coprime_two_right)
  have hu : IsUnit (2 : ZMod n) := (ZMod.isUnit_iff_coprime 2 n).2 hcop
  have hstar (z : ZMod n) : (starRingEnd ℂ) (ZMod.stdAddChar z) =
      ZMod.stdAddChar (-z) := by
    rw [AddChar.map_neg_eq_inv, AddChar.inv_apply_eq_conj]
  have htranslate (x : ZMod n) :
      (∑ y : ZMod n, ZMod.stdAddChar (y ^ 2 - x ^ 2)) =
        ∑ u : ZMod n, ZMod.stdAddChar ((u + x) ^ 2 - x ^ 2) := by
    symm
    simpa using Equiv.sum_comp (Equiv.addRight x)
      (fun y : ZMod n => ZMod.stdAddChar (y ^ 2 - x ^ 2))
  have hinner (u : ZMod n) :
      (∑ x : ZMod n, ZMod.stdAddChar ((u + x) ^ 2 - x ^ 2)) =
        if u = 0 then (n : ℂ) else 0 := by
    calc
      _ = ZMod.stdAddChar (u ^ 2) *
          ∑ x : ZMod n, ZMod.stdAddChar (x * (2 * u)) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro x _
        rw [← AddChar.map_add_eq_mul]
        congr 1
        ring
      _ = ZMod.stdAddChar (u ^ 2) *
          (if 2 * u = 0 then (n : ℂ) else 0) := by
        rw [AddChar.sum_mulShift (2 * u) (ZMod.isPrimitive_stdAddChar n)]
        simp [ZMod.card]
      _ = if u = 0 then (n : ℂ) else 0 := by
        have h2 : (2 : ZMod n) * u = 0 ↔ u = 0 := by
          constructor
          · intro h
            apply hu.mul_left_cancel
            simpa using h
          · rintro rfl
            simp
        simp only [h2]
        split_ifs with h
        · subst u; simp
        · simp
  have hnormSq : Complex.normSq (quadraticSumZMod n) = n := by
    apply Complex.ofReal_injective
    rw [Complex.normSq_eq_conj_mul_self]
    change star (quadraticSumZMod n) * quadraticSumZMod n = (n : ℂ)
    rw [quadraticSumZMod, Complex.star_def,
      map_sum (starRingEnd ℂ) (fun x : ZMod n => ZMod.stdAddChar (x ^ 2))
        Finset.univ]
    simp_rw [hstar]
    rw [Finset.sum_mul]
    simp_rw [Finset.mul_sum]
    calc
      (∑ x : ZMod n, ∑ y : ZMod n,
          ZMod.stdAddChar (-(x ^ 2)) * ZMod.stdAddChar (y ^ 2)) =
          ∑ x : ZMod n, ∑ y : ZMod n,
            ZMod.stdAddChar (y ^ 2 - x ^ 2) := by
        apply Finset.sum_congr rfl
        intro x _
        apply Finset.sum_congr rfl
        intro y _
        rw [← AddChar.map_add_eq_mul]
        congr 1
        ring
      _ = ∑ x : ZMod n, ∑ u : ZMod n,
          ZMod.stdAddChar ((u + x) ^ 2 - x ^ 2) := by
        apply Finset.sum_congr rfl
        intro x _
        exact htranslate x
      _ = ∑ u : ZMod n, ∑ x : ZMod n,
          ZMod.stdAddChar ((u + x) ^ 2 - x ^ 2) := by
        rw [Finset.sum_comm]
      _ = ∑ u : ZMod n, if u = 0 then (n : ℂ) else 0 := by
        apply Finset.sum_congr rfl
        intro u _
        exact hinner u
      _ = (n : ℂ) := by simp
  rw [Complex.norm_def, hnormSq]

theorem normalized_trace_norm (n : ℕ) [NeZero n] (hodd : Odd n) :
    ‖(normalizedFourierMatrix n).trace‖ = 1 := by
  have hsqrt_pos : 0 < Real.sqrt n :=
    Real.sqrt_pos.2 (by
      exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne n)) : (0 : ℝ) < n)
  rw [normalizedFourierMatrix, Matrix.trace_smul, norm_smul,
    trace_fourierMatrix, quadraticSumZMod_norm n hodd]
  simp [abs_of_pos hsqrt_pos, hsqrt_pos.ne']

end

end OddGaussSum
