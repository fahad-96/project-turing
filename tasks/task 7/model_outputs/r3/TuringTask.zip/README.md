# TuringTask

This project uses the supplied Lean 4.33.0-rc1 toolchain and the local Mathlib
installation at `/opt/mathlib4`. It is not self-contained on machines without
that environment.

Build and audit it offline with:

```sh
lean-offline-init
lake build
lake env lean TuringTask/AxiomAudit.lean
```
