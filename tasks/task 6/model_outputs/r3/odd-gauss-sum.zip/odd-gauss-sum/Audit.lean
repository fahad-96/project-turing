import OddGaussSum

#check OddGaussSum.sum_sq
#print axioms OddGaussSum.sum_sq
