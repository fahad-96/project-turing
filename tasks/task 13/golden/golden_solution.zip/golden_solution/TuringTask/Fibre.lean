import Mathlib

/-!
# Fibres of the power map on primitive roots of unity

For `m, d >= 1` the map `a -> a ^ d` sends the primitive `m`-th roots of unity in `C` onto the
primitive `k`-th roots of unity, `k = m / gcd m d`, and every fibre has `phi m / phi k` elements.
The uniformity of the fibres comes from the action of the units modulo `m` (powering by an
exponent coprime to `m`), together with the lift of units modulo `k` to units modulo `m`.

The consequence used later: for an integer polynomial `G`,
`Res(Phi_m, G(X ^ d)) = Res(Phi_k, G) ^ (phi m / phi k)`.
-/

namespace TuringTask

open Polynomial

/-- A residue class coprime to `k` lifts to a residue class coprime to `m` when `k ∣ m`. -/
theorem exists_coprime_lift {k m v : ℕ} (hm : m ≠ 0) (hk : k ∣ m) (hv : Nat.Coprime v k) :
    ∃ u : ℕ, Nat.Coprime u m ∧ u ≡ v [MOD k] := by
  haveI : NeZero m := ⟨hm⟩
  obtain ⟨u, hu⟩ := ZMod.unitsMap_surjective hk (ZMod.unitOfCoprime v hv)
  refine ⟨(u : ZMod m).val, ZMod.val_coe_unit_coprime u, ?_⟩
  rw [← ZMod.natCast_eq_natCast_iff]
  have h1 : ((((u : ZMod m).val : ℕ) : ZMod m).cast : ZMod k) = ((u : ZMod m).val : ZMod k) :=
    ZMod.cast_natCast hk _
  rw [ZMod.natCast_zmod_val] at h1
  rw [← h1, ← ZMod.unitsMap_val hk u, hu, ZMod.coe_unitOfCoprime]

/-- Exponents congruent modulo the order give equal powers of a primitive root. -/
theorem primitiveRoot_pow_eq_pow_of_modEq {m : ℕ} (hm : 0 < m) {α : ℂ}
    (hα : IsPrimitiveRoot α m) {a b : ℕ} (h : a ≡ b [MOD m]) : α ^ a = α ^ b := by
  have hfin : IsOfFinOrder α := isOfFinOrder_iff_pow_eq_one.mpr ⟨m, hm, hα.pow_eq_one⟩
  rw [hfin.pow_eq_pow_iff_modEq, ← hα.eq_orderOf]
  exact h

/-- The `d`-th power of a primitive `m`-th root of unity is a primitive `m / gcd m d`-th root. -/
theorem pow_mem_primitiveRoots {m d : ℕ} (hm : 0 < m) (hd : 0 < d) {α : ℂ}
    (hα : α ∈ primitiveRoots m ℂ) : α ^ d ∈ primitiveRoots (m / Nat.gcd m d) ℂ := by
  rw [mem_primitiveRoots hm] at hα
  have hk : 0 < m / Nat.gcd m d :=
    Nat.div_pos (Nat.gcd_le_left d hm) (Nat.gcd_pos_of_pos_left d hm)
  rw [mem_primitiveRoots hk]
  have h := IsPrimitiveRoot.orderOf (α ^ d)
  rwa [orderOf_pow' α hd.ne', ← hα.eq_orderOf] at h

/-- Powering by an exponent coprime to `m` is injective on the primitive `m`-th roots. -/
theorem pow_injOn_primitiveRoots {m u : ℕ} (hm : 0 < m) (hu : Nat.Coprime u m) :
    Set.InjOn (fun α : ℂ => α ^ u) (primitiveRoots m ℂ : Set ℂ) := by
  intro α hα β hβ h
  simp only [Finset.mem_coe, mem_primitiveRoots hm] at hα hβ
  simp only at h
  obtain ⟨w, -, hw⟩ := Nat.exists_mul_mod_eq_of_coprime 1 hu hm.ne'
  have key : ∀ γ : ℂ, IsPrimitiveRoot γ m → γ ^ (u * w) = γ := by
    intro γ hγ
    have h1 : γ ^ (u * w) = γ ^ 1 := by
      apply primitiveRoot_pow_eq_pow_of_modEq hm hγ
      exact hw
    rw [h1, pow_one]
  calc α = α ^ (u * w) := (key α hα).symm
    _ = (α ^ u) ^ w := by rw [pow_mul]
    _ = (β ^ u) ^ w := by rw [h]
    _ = β ^ (u * w) := by rw [pow_mul]
    _ = β := key β hβ

/-- The fibre lemma: a product over the primitive `m`-th roots of a function of `a ^ d`
collapses to a power of the product over the primitive `m / gcd m d`-th roots. -/
theorem prod_pow_primitiveRoots (m d : ℕ) (hm : 0 < m) (hd : 0 < d) (F : ℂ → ℂ) :
    ∏ α ∈ primitiveRoots m ℂ, F (α ^ d) =
      (∏ η ∈ primitiveRoots (m / Nat.gcd m d) ℂ, F η) ^
        (Nat.totient m / Nat.totient (m / Nat.gcd m d)) := by
  set k := m / Nat.gcd m d with hk_def
  have hk : 0 < k := Nat.div_pos (Nat.gcd_le_left d hm) (Nat.gcd_pos_of_pos_left d hm)
  have hkm : k ∣ m := Nat.div_dvd_of_dvd (Nat.gcd_dvd_left m d)
  have hmaps : ∀ α ∈ primitiveRoots m ℂ, α ^ d ∈ primitiveRoots k ℂ :=
    fun α hα => pow_mem_primitiveRoots hm hd hα
  -- all fibres have the same cardinality
  have hle : ∀ η₁ ∈ primitiveRoots k ℂ, ∀ η₂ ∈ primitiveRoots k ℂ,
      ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η₁)).card ≤
        ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η₂)).card := by
    intro η₁ hη₁ η₂ hη₂
    haveI : NeZero k := ⟨hk.ne'⟩
    have hη₁' := (mem_primitiveRoots hk).mp hη₁
    have hη₂' := (mem_primitiveRoots hk).mp hη₂
    obtain ⟨v, -, hvk, hv⟩ := hη₁'.isPrimitiveRoot_iff.mp hη₂'
    obtain ⟨u, hum, huv⟩ := exists_coprime_lift hm.ne' hkm hvk
    apply Finset.card_le_card_of_injOn (fun α : ℂ => α ^ u)
    · intro α hα
      simp only [Finset.mem_coe, Finset.mem_filter] at hα ⊢
      obtain ⟨hαm, hαd⟩ := hα
      have hα' := (mem_primitiveRoots hm).mp hαm
      refine ⟨(mem_primitiveRoots hm).mpr (hα'.pow_of_coprime u hum), ?_⟩
      rw [← pow_mul, mul_comm, pow_mul, hαd, ← hv]
      exact primitiveRoot_pow_eq_pow_of_modEq hk hη₁' huv
    · exact (pow_injOn_primitiveRoots hm hum).mono
        (Finset.coe_subset.mpr (Finset.filter_subset _ _))
  have heq : ∀ η₁ ∈ primitiveRoots k ℂ, ∀ η₂ ∈ primitiveRoots k ℂ,
      ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η₁)).card =
        ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η₂)).card :=
    fun η₁ h₁ η₂ h₂ => le_antisymm (hle η₁ h₁ η₂ h₂) (hle η₂ h₂ η₁ h₁)
  -- the common value is phi m / phi k
  have hcardk : (primitiveRoots k ℂ).card = Nat.totient k := Complex.card_primitiveRoots k
  have hkpos : 0 < (primitiveRoots k ℂ).card := by
    rw [hcardk]; exact Nat.totient_pos.mpr hk
  obtain ⟨η₀, hη₀⟩ := Finset.card_pos.mp hkpos
  have hsum : (primitiveRoots m ℂ).card =
      ∑ η ∈ primitiveRoots k ℂ, ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η)).card :=
    Finset.card_eq_sum_card_fiberwise hmaps
  have hsum' : Nat.totient m =
      Nat.totient k * ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η₀)).card := by
    rw [← Complex.card_primitiveRoots m, hsum, ← hcardk, ← smul_eq_mul, ← Finset.sum_const]
    exact Finset.sum_congr rfl fun η hη => heq η hη η₀ hη₀
  have hfib : ∀ η ∈ primitiveRoots k ℂ,
      ((primitiveRoots m ℂ).filter (fun α : ℂ => α ^ d = η)).card =
        Nat.totient m / Nat.totient k := by
    intro η hη
    rw [heq η hη η₀ hη₀]
    exact (Nat.div_eq_of_eq_mul_right (Nat.totient_pos.mpr hk) hsum').symm
  -- assemble
  rw [← Finset.prod_fiberwise_of_maps_to hmaps, ← Finset.prod_pow]
  refine Finset.prod_congr rfl fun η hη => ?_
  rw [Finset.prod_congr rfl (fun α hα => by rw [(Finset.mem_filter.mp hα).2]),
    Finset.prod_const, hfib η hη]

/-- The resultant of `Phi_m` with an integer polynomial `g`, as a product over the primitive
`m`-th roots of unity in `C`. -/
theorem resultant_cyclotomic_eq_prod (m : ℕ) (hm : 0 < m) (g : ℤ[X]) :
    ((resultant (cyclotomic m ℤ) g : ℤ) : ℂ) =
      ∏ α ∈ primitiveRoots m ℂ, (g.map (Int.castRingHom ℂ)).eval α := by
  have hinj : Function.Injective (Int.castRingHom ℂ) := Int.cast_injective
  haveI : NeZero (m : ℂ) := ⟨by exact_mod_cast hm.ne'⟩
  have h := resultant_map_map (cyclotomic m ℤ) g (cyclotomic m ℤ).natDegree g.natDegree
    (Int.castRingHom ℂ)
  rw [eq_intCast] at h
  rw [← h, map_cyclotomic_int, natDegree_cyclotomic, ← natDegree_cyclotomic m ℂ,
    ← natDegree_map_eq_of_injective hinj g,
    resultant_eq_prod_eval _ _ _ le_rfl (IsAlgClosed.splits _), (cyclotomic.monic m ℂ).leadingCoeff,
    one_pow, one_mul, cyclotomic.roots_eq_primitiveRoots_val, Finset.prod_eq_multiset_prod]

/-- Resultant of a cyclotomic polynomial with an expanded polynomial. -/
theorem resultant_cyclotomic_expand (m d : ℕ) (hm : 0 < m) (hd : 0 < d) (G : ℤ[X]) :
    resultant (cyclotomic m ℤ) (expand ℤ d G) =
      (resultant (cyclotomic (m / Nat.gcd m d) ℤ) G) ^
        (Nat.totient m / Nat.totient (m / Nat.gcd m d)) := by
  have hk : 0 < m / Nat.gcd m d :=
    Nat.div_pos (Nat.gcd_le_left d hm) (Nat.gcd_pos_of_pos_left d hm)
  apply Int.cast_injective (α := ℂ)
  rw [Int.cast_pow, resultant_cyclotomic_eq_prod m hm, resultant_cyclotomic_eq_prod _ hk,
    Polynomial.map_expand]
  simp only [expand_eval]
  exact prod_pow_primitiveRoots m d hm hd (fun x => (G.map (Int.castRingHom ℂ)).eval x)

end TuringTask
