import Mathlib

namespace TuringTask

noncomputable def csum (p : Nat) [Fact p.Prime] (c : Int) : Int :=
  Finset.sum (Finset.range p) (fun x : Nat => legendreSym p ((x : Int) ^ 3 - c * (x : Int)))

def χ (p : ℕ) [Fact p.Prime] (x : ZMod p) : ℤ := legendreSym p x.val

def S (p : ℕ) [Fact p.Prime] (c : ZMod p) : ℤ :=
  ∑ x : ZMod p, χ p (x ^ 3 - c * x)

lemma legendreSym_cast_zmod (p : ℕ) [Fact p.Prime] (a : ℤ) :
    legendreSym p ((a : ZMod p).val : ℤ) = legendreSym p a := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  rw [legendreSym.mod p a, ← ZMod.val_intCast (n := p) a]

lemma zmod_sum_eq_range (p : ℕ) [Fact p.Prime] (f : ZMod p → ℤ) :
    (∑ x : ZMod p, f x) = ∑ x ∈ Finset.range p, f (x : ZMod p) := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  symm
  apply Finset.sum_bij (fun (x : ℕ) _ => (x : ZMod p))
  · intro a ha
    exact Finset.mem_univ _
  · intro a₁ ha₁ a₂ ha₂ h
    rw [Finset.mem_range] at ha₁ ha₂
    have h1 := congrArg ZMod.val h
    rwa [ZMod.val_natCast_of_lt ha₁, ZMod.val_natCast_of_lt ha₂] at h1
  · intro b _
    refine ⟨b.val, ?_, ?_⟩
    · rw [Finset.mem_range]
      exact b.val_lt
    · exact ZMod.natCast_zmod_val b
  · intro a ha
    rfl

lemma csum_eq_S (p : ℕ) [Fact p.Prime] (c : ℤ) :
    csum p c = S p (c : ZMod p) := by
  dsimp [csum, S, χ]
  rw [zmod_sum_eq_range]
  apply Finset.sum_congr rfl
  intro x hx
  have hcast : (((x : ZMod p) ^ 3 - (c : ZMod p) * (x : ZMod p) : ZMod p) : ZMod p) =
      (((x : ℤ) ^ 3 - c * (x : ℤ) : ℤ) : ZMod p) := by
    push_cast
    rfl
  rw [← legendreSym_cast_zmod, hcast]

lemma χ_cast (p : ℕ) [Fact p.Prime] (x : ZMod p) :
    ((x.val : ℤ) : ZMod p) = x := by
  simp only [Int.cast_natCast, ZMod.natCast_zmod_val]

lemma χ_eq_one_iff (p : ℕ) [Fact p.Prime] {x : ZMod p} (hx : x ≠ 0) :
    χ p x = 1 ↔ IsSquare x := by
  dsimp [χ]
  have hne : ((x.val : ℤ) : ZMod p) ≠ 0 := by
    rw [χ_cast]
    exact hx
  have h := legendreSym.eq_one_iff p hne
  rw [χ_cast] at h
  exact h

lemma χ_eq_neg_one_iff (p : ℕ) [Fact p.Prime] (x : ZMod p) :
    χ p x = -1 ↔ ¬IsSquare x := by
  dsimp [χ]
  have h := legendreSym.eq_neg_one_iff p (a := x.val)
  rw [χ_cast] at h
  exact h

lemma legendreSym_eq_zero_of_cast_eq_zero (p : ℕ) [Fact p.Prime] (c : ℤ) (hc : (c : ZMod p) = 0) :
    legendreSym p c = 0 := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  rw [legendreSym.mod p c]
  have h := ZMod.val_intCast (n := p) c
  have hc_val : (c : ZMod p).val = 0 := by rw [hc, ZMod.val_zero]
  have : c % (p : ℤ) = 0 := by
    rw [← h, hc_val, Nat.cast_zero]
  rw [this, legendreSym.at_zero]

lemma χ_mul (p : ℕ) [Fact p.Prime] (x y : ZMod p) :
    χ p (x * y) = χ p x * χ p y := by
  dsimp [χ]
  have hcast : (x * y : ZMod p) = (((x.val : ℤ) * (y.val : ℤ) : ℤ) : ZMod p) := by
    push_cast
    simp only [ZMod.natCast_zmod_val]
  rw [← legendreSym.mul, ← legendreSym_cast_zmod p ((x.val : ℤ) * (y.val : ℤ)), ← hcast]

lemma χ_zero (p : ℕ) [Fact p.Prime] : χ p 0 = 0 := by
  dsimp [χ]
  rw [ZMod.val_zero]
  exact legendreSym.at_zero p

lemma χ_one (p : ℕ) [Fact p.Prime] : χ p 1 = 1 := by
  dsimp [χ]
  have : (1 : ZMod p) = ((1 : ℤ) : ZMod p) := by push_cast; rfl
  rw [this, legendreSym_cast_zmod, legendreSym.at_one]

lemma χ_neg_one (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) :
    χ p (-1) = 1 := by
  dsimp [χ]
  have hp2 : p ≠ 2 := by
    rintro rfl
    norm_num at hp
  have : (-1 : ZMod p) = ((-1 : ℤ) : ZMod p) := by push_cast; rfl
  rw [this, legendreSym_cast_zmod p (-1), legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp]

lemma χ_neg (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (x : ZMod p) :
    χ p (-x) = χ p x := by
  have : -x = -1 * x := by ring
  rw [this, χ_mul, χ_neg_one p hp, one_mul]

lemma χ_sq' (p : ℕ) [Fact p.Prime] {j : ZMod p} (hj : j ≠ 0) : (χ p j) ^ 2 = 1 := by
  dsimp [χ]
  have hne' : ((j.val : ℤ) : ZMod p) ≠ 0 := by
    rw [Int.cast_natCast, ZMod.natCast_zmod_val]
    exact hj
  exact legendreSym.sq_one p hne'

lemma S_eq_sum_mul (p : ℕ) [Fact p.Prime] (c : ZMod p) :
    S p c = ∑ x : ZMod p, χ p x * χ p (x ^ 2 - c) := by
  dsimp [S]
  apply Finset.sum_congr rfl
  intro x _
  have h : x ^ 3 - c * x = x * (x ^ 2 - c) := by ring
  rw [h, χ_mul]

lemma sum_card_sqrts_eq (p : ℕ) [NeZero p] :
    ∑ x : ZMod p, {y : ZMod p | y ^ 2 = x}.toFinset.card = p := by
  have h := (Finset.card_eq_sum_card_fiberwise (f := fun y : ZMod p => y ^ 2) (s := Finset.univ) (t := Finset.univ)
    (fun _ _ => Finset.mem_univ _)).symm
  have hcard : (Finset.univ : Finset (ZMod p)).card = p := by simp
  have hstep : (∑ x : ZMod p, {y : ZMod p | y ^ 2 = x}.toFinset.card) =
      ∑ b : ZMod p, {a ∈ (Finset.univ : Finset (ZMod p)) | a ^ 2 = b}.card := by
    apply Finset.sum_congr rfl
    intro x _
    congr 1
    ext y
    simp
  exact hstep.trans (h.trans hcard)

lemma sum_χ_eq_zero (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) :
    ∑ x : ZMod p, χ p x = 0 := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have h : (∑ x : ZMod p, (χ p x + 1 : ℤ)) = p := by
    have h2 : ∀ x : ZMod p, (χ p x + 1 : ℤ) =
        ({y : ZMod p | y ^ 2 = x}.toFinset.card : ℤ) := by
      intro x
      have := (legendreSym.card_sqrts p hp x.val).symm
      have hval : ((x.val : ℤ) : ZMod p) = x := by
        simp only [Int.cast_natCast, ZMod.natCast_zmod_val]
      rw [hval] at this
      exact this
    simp_rw [h2]
    exact_mod_cast sum_card_sqrts_eq p
  rw [Finset.sum_add_distrib] at h
  simp only [Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul, mul_one] at h
  linarith

lemma sum_χ_sq (p : ℕ) [Fact p.Prime] :
    ∑ j : ZMod p, (χ p j) ^ 2 = (p : ℤ) - 1 := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
  have hsplit := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun j => (χ p j) ^ 2) h0
  rw [χ_zero, zero_pow two_ne_zero, add_zero] at hsplit
  rw [← hsplit]
  have h1 : ∀ j ∈ Finset.univ.erase (0 : ZMod p), (χ p j) ^ 2 = 1 := by
    intro j hj
    rw [Finset.mem_erase] at hj
    exact χ_sq' p hj.1
  rw [Finset.sum_congr rfl h1]
  simp only [Finset.sum_const, nsmul_eq_mul, mul_one]
  rw [Finset.card_erase_of_mem h0, Finset.card_univ, ZMod.card]
  have hp : p ≥ 1 := (Fact.out : p.Prime).one_lt.le
  omega

lemma sum_χ_sub_mul_sub (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) (u v : ZMod p) :
    ∑ k : ZMod p, χ p (u - k) * χ p (v - k) = (if u = v then (p : ℤ) else 0) - 1 := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  by_cases h : u = v
  · subst h
    simp only [if_true]
    have e := (Equiv.sum_comp (Equiv.subLeft u) (fun j => (χ p j) ^ 2))
    simp only [Equiv.subLeft_apply, sq] at e
    rw [e]
    simp_rw [← sq]
    rw [sum_χ_sq]
  · simp only [h, if_false, zero_sub]
    have hequiv : ∑ k : ZMod p, χ p (u - k) * χ p (v - k) =
        ∑ j : ZMod p, χ p j * χ p (j + (v - u)) := by
      have e := Equiv.sum_comp (Equiv.subLeft u) (fun j => χ p j * χ p (j + (v - u)))
      have hcongr : (fun k => χ p (Equiv.subLeft u k) * χ p (Equiv.subLeft u k + (v - u))) =
          (fun k => χ p (u - k) * χ p (v - k)) := by
        ext k
        dsimp [Equiv.subLeft]
        have : u - k + (v - u) = v - k := by ring
        rw [this]
      rw [hcongr] at e
      exact e
    rw [hequiv]
    have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
    have hsplit := Finset.sum_erase_add (Finset.univ : Finset (ZMod p))
      (fun j => χ p j * χ p (j + (v - u))) h0
    rw [χ_zero, zero_mul, add_zero] at hsplit
    rw [← hsplit]
    let d := v - u
    have hd : d ≠ 0 := sub_ne_zero.mpr (Ne.symm h)
    have hbij : ∑ j ∈ (Finset.univ : Finset (ZMod p)).erase 0, χ p j * χ p (j + d) =
        ∑ w ∈ (Finset.univ : Finset (ZMod p)).erase 1, χ p w := by
      apply Finset.sum_bij (fun (j : ZMod p) _ => 1 + d * j⁻¹)
      · intro j hj
        rw [Finset.mem_erase] at hj ⊢
        refine ⟨?_, Finset.mem_univ _⟩
        intro h1
        have : d * j⁻¹ = 0 := by linear_combination h1
        have hj0 : j⁻¹ ≠ 0 := inv_ne_zero hj.1
        exact mul_ne_zero hd hj0 this
      · intro j₁ hj₁ j₂ hj₂ heq
        rw [Finset.mem_erase] at hj₁ hj₂
        have h1 : d * j₁⁻¹ = d * j₂⁻¹ := by linear_combination heq
        have h2 : j₁⁻¹ = j₂⁻¹ := mul_left_cancel₀ hd h1
        exact inv_injective h2
      · intro w hw
        rw [Finset.mem_erase] at hw
        refine ⟨d * (w - 1)⁻¹, ?_, ?_⟩
        · rw [Finset.mem_erase]
          have hw1 : w - 1 ≠ 0 := sub_ne_zero.mpr hw.1
          refine ⟨mul_ne_zero hd (inv_ne_zero hw1), Finset.mem_univ _⟩
        · have hw1 : w - 1 ≠ 0 := sub_ne_zero.mpr hw.1
          rw [mul_inv, inv_inv]
          have : d * (d⁻¹ * (w - 1)) = (d * d⁻¹) * (w - 1) := by ring
          rw [this, mul_inv_cancel₀ hd, one_mul, add_sub_cancel]
      · intro j hj
        rw [Finset.mem_erase] at hj
        have heq : j + d = j * (1 + d * j⁻¹) := by
          calc j + d = j * 1 + (j * j⁻¹) * d := by rw [mul_inv_cancel₀ hj.1, one_mul, mul_one]
          _ = j * (1 + d * j⁻¹) := by ring
        rw [heq, χ_mul, ← mul_assoc, ← sq, χ_sq' p hj.1, one_mul]
    rw [hbij]
    have htot := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun w => χ p w)
      (Finset.mem_univ (1 : ZMod p))
    rw [sum_χ_eq_zero p hp, χ_one] at htot
    linarith

lemma ne_neg_self_of_ne_zero (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) {x : ZMod p} (hx : x ≠ 0) :
    x ≠ -x := by
  intro h
  have : 2 * x = 0 := by linear_combination h
  have h2 : (2 : ZMod p) ≠ 0 := by
    intro hz
    have : (p : ℕ) ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp hz
    have hp_gt : p > 2 := (Fact.out : p.Prime).two_le.lt_of_ne hp2.symm
    exact Nat.not_dvd_of_pos_of_lt (by decide) hp_gt this
  exact mul_ne_zero h2 hx this

lemma sum_sq_eq_two_mul (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) (hp : p % 4 = 1) (x : ZMod p) (hx : x ≠ 0) :
    (∑ y : ZMod p, (if x^2 = y^2 then (1 : ℤ) else 0) * χ p y) = 2 * χ p x := by
  have hne : x ≠ -x := ne_neg_self_of_ne_zero p hp2 hx
  have hpair : ({x, -x} : Finset (ZMod p)).card = 2 := Finset.card_pair hne
  have hsum : (∑ y ∈ ({x, -x} : Finset (ZMod p)), (if x^2 = y^2 then (1 : ℤ) else 0) * χ p y) =
      (∑ y : ZMod p, (if x^2 = y^2 then (1 : ℤ) else 0) * χ p y) := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro y _ hy
    rw [Finset.mem_insert, Finset.mem_singleton, not_or] at hy
    have : ¬(x ^ 2 = y ^ 2) := by
      intro hsq
      rw [sq_eq_sq_iff_eq_or_eq_neg] at hsq
      cases hsq with
      | inl h1 => exact hy.1 h1.symm
      | inr h2 =>
        have : y = -x := by rw [h2, neg_neg]
        exact hy.2 this
    simp [this]
  have h2 : x ^ 2 = (-x) ^ 2 := by ring
  rw [← hsum, Finset.sum_pair hne]
  simp only [h2, if_true, one_mul]
  rw [χ_neg p hp x]
  ring

lemma sum_swap_3 {α : Type*} [Fintype α] {β : Type*} [AddCommMonoid β]
    (f : α → α → α → β) :
    (∑ k : α, ∑ x : α, ∑ y : α, f k x y) = ∑ x : α, ∑ y : α, ∑ k : α, f k x y := by
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x _
  rw [Finset.sum_comm]

lemma sum_S_sq (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) :
    ∑ k : ZMod p, (S p k) ^ 2 = 2 * (p : ℤ) * ((p : ℤ) - 1) := by
  have hp2 : p ≠ 2 := by
    rintro rfl
    norm_num at hp
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have hS : ∀ k : ZMod p, (S p k) ^ 2 =
      ∑ x : ZMod p, ∑ y : ZMod p, (χ p x * χ p (x ^ 2 - k)) * (χ p y * χ p (y ^ 2 - k)) := by
    intro k
    rw [S_eq_sum_mul, sq, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro x _
    rw [Finset.mul_sum]
  simp_rw [hS]
  rw [sum_swap_3]
  have hinner : ∀ x y : ZMod p,
      (∑ k : ZMod p, (χ p x * χ p (x ^ 2 - k)) * (χ p y * χ p (y ^ 2 - k))) =
      χ p x * χ p y * ((if x ^ 2 = y ^ 2 then (p : ℤ) else 0) - 1) := by
    intro x y
    have : (fun k => (χ p x * χ p (x ^ 2 - k)) * (χ p y * χ p (y ^ 2 - k))) =
        fun k => (χ p x * χ p y) * (χ p (x ^ 2 - k) * χ p (y ^ 2 - k)) := by
      ext k
      ring
    rw [this, ← Finset.mul_sum, sum_χ_sub_mul_sub p hp2 (x ^ 2) (y ^ 2)]
  simp_rw [hinner]
  have hterm_sum : (∑ x : ZMod p, ∑ y : ZMod p, χ p x * χ p y * ((if x ^ 2 = y ^ 2 then (p : ℤ) else 0) - 1)) =
      (∑ x : ZMod p, ∑ y : ZMod p, (χ p x * (p : ℤ) * ((if x ^ 2 = y ^ 2 then (1 : ℤ) else 0) * χ p y) - χ p x * χ p y)) := by
    apply Finset.sum_congr rfl
    intro x _
    apply Finset.sum_congr rfl
    intro y _
    split_ifs <;> ring
  rw [hterm_sum]
  simp_rw [Finset.sum_sub_distrib]
  have hzero : (∑ x : ZMod p, ∑ y : ZMod p, χ p x * χ p y) = 0 := by
    have : (∑ x : ZMod p, ∑ y : ZMod p, χ p x * χ p y) = ∑ x : ZMod p, χ p x * ∑ y : ZMod p, χ p y := by
      apply Finset.sum_congr rfl
      intro x _
      rw [← Finset.mul_sum]
    rw [this]
    simp [sum_χ_eq_zero p hp2]
  rw [hzero, sub_zero]
  have h1 : (∑ x : ZMod p, ∑ y : ZMod p, χ p x * (p : ℤ) * ((if x ^ 2 = y ^ 2 then (1 : ℤ) else 0) * χ p y)) =
      ∑ x : ZMod p, χ p x * (p : ℤ) * ∑ y : ZMod p, ((if x ^ 2 = y ^ 2 then (1 : ℤ) else 0) * χ p y) := by
    apply Finset.sum_congr rfl
    intro x _
    rw [← Finset.mul_sum]
  rw [h1]
  have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
  rw [← Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) _ h0]
  have hz : χ p 0 * (p : ℤ) * ∑ y : ZMod p, ((if (0 : ZMod p) ^ 2 = y ^ 2 then (1 : ℤ) else 0) * χ p y) = 0 := by
    rw [χ_zero]; ring
  rw [hz, add_zero]
  have hmain : ∀ x ∈ (Finset.univ : Finset (ZMod p)).erase 0,
      χ p x * (p : ℤ) * ∑ y : ZMod p, ((if x ^ 2 = y ^ 2 then (1 : ℤ) else 0) * χ p y) =
      2 * (p : ℤ) := by
    intro x hx
    rw [Finset.mem_erase] at hx
    rw [sum_sq_eq_two_mul p hp2 hp x hx.1]
    have : χ p x * (p : ℤ) * (2 * χ p x) = 2 * (p : ℤ) * (χ p x) ^ 2 := by ring
    rw [this, χ_sq' p hx.1, mul_one]
  rw [Finset.sum_congr rfl hmain]
  simp only [Finset.sum_const, nsmul_eq_mul]
  rw [Finset.card_erase_of_mem h0, Finset.card_univ, ZMod.card]
  have hp_ge : p ≥ 1 := (Fact.out : p.Prime).one_lt.le
  have : ((p - 1 : ℕ) : ℤ) = (p : ℤ) - 1 := by omega
  rw [this]
  ring

lemma S_mul_sq (p : ℕ) [Fact p.Prime] (c : ZMod p) (t : ZMod p) (ht : t ≠ 0) :
    S p (t ^ 2 * c) = χ p t * S p c := by
  dsimp [S]
  let e := Equiv.mulLeft₀ t ht
  have hequiv := (Equiv.sum_comp e (fun x => χ p (x ^ 3 - t ^ 2 * c * x))).symm
  rw [hequiv]
  have hterm : ∀ u : ZMod p, χ p ((e u) ^ 3 - t ^ 2 * c * (e u)) = χ p t * χ p (u ^ 3 - c * u) := by
    intro u
    change χ p ((t * u) ^ 3 - t ^ 2 * c * (t * u)) = χ p t * χ p (u ^ 3 - c * u)
    have hid : (t * u) ^ 3 - t ^ 2 * c * (t * u) = t * (t ^ 2 * (u ^ 3 - c * u)) := by ring
    rw [hid, χ_mul, χ_mul, sq, χ_mul]
    have : χ p t * (χ p t * χ p t * χ p (u ^ 3 - c * u)) = (χ p t) ^ 2 * (χ p t * χ p (u ^ 3 - c * u)) := by ring
    rw [this, χ_sq' p ht, one_mul]
  rw [Finset.sum_congr rfl (fun u _ => hterm u), ← Finset.mul_sum]

lemma S_sq_mul_sq (p : ℕ) [Fact p.Prime] (c : ZMod p) (t : ZMod p) (ht : t ≠ 0) :
    (S p (t ^ 2 * c)) ^ 2 = (S p c) ^ 2 := by
  rw [S_mul_sq p c t ht, mul_pow, χ_sq' p ht, one_mul]

lemma S_sq_eq_of_isSquare (p : ℕ) [Fact p.Prime] (c k : ZMod p)
    (hc : IsSquare c) (hc0 : c ≠ 0) (hk : IsSquare k) (hk0 : k ≠ 0) :
    (S p k) ^ 2 = (S p c) ^ 2 := by
  obtain ⟨s, rfl⟩ := hc
  obtain ⟨t, rfl⟩ := hk
  have hs0 : s ≠ 0 := by rintro rfl; exact hc0 (by ring)
  have ht0 : t ≠ 0 := by rintro rfl; exact hk0 (by ring)
  let m := t * s⁻¹
  have hm0 : m ≠ 0 := mul_ne_zero ht0 (inv_ne_zero hs0)
  have hkeq : t * t = m ^ 2 * (s * s) := by
    dsimp [m]
    have : (t * s⁻¹) ^ 2 * (s * s) = (t * t) * (s⁻¹ * s) ^ 2 := by ring
    rw [this, inv_mul_cancel₀ hs0, one_pow, mul_one]
  rw [hkeq, S_sq_mul_sq p (s * s) m hm0]

lemma S_sq_eq_of_not_isSquare (p : ℕ) [Fact p.Prime] (r k : ZMod p)
    (hr : ¬IsSquare r) (hk : ¬IsSquare k) :
    (S p k) ^ 2 = (S p r) ^ 2 := by
  have hr_chi : χ p r = -1 := (χ_eq_neg_one_iff p r).mpr hr
  have hk_chi : χ p k = -1 := (χ_eq_neg_one_iff p k).mpr hk
  have hr0 : r ≠ 0 := by rintro rfl; exact hr ⟨0, (mul_zero 0).symm⟩
  have hk0 : k ≠ 0 := by rintro rfl; exact hk ⟨0, (mul_zero 0).symm⟩
  have hr_inv_chi : χ p r⁻¹ = -1 := by
    have h1 : χ p (r * r⁻¹) = χ p 1 := by rw [mul_inv_cancel₀ hr0]
    rw [χ_mul, hr_chi, χ_one] at h1
    linear_combination -1 * h1
  have hprod : χ p (k * r⁻¹) = 1 := by
    rw [χ_mul, hk_chi, hr_inv_chi]
    rfl
  have hne0 : k * r⁻¹ ≠ 0 := mul_ne_zero hk0 (inv_ne_zero hr0)
  have hsq : IsSquare (k * r⁻¹) := (χ_eq_one_iff p hne0).mp hprod
  obtain ⟨m, hm⟩ := hsq
  have hm0 : m ≠ 0 := by
    rintro rfl
    rw [mul_zero] at hm
    exact hne0 hm
  have hkeq : k = m ^ 2 * r := by
    have : m ^ 2 * r = (m * m) * r := by rw [sq]
    rw [this, ← hm, mul_assoc, inv_mul_cancel₀ hr0, mul_one]
  rw [hkeq, S_sq_mul_sq p r m hm0]

lemma S_zero (p : ℕ) [Fact p.Prime] (hp2 : p ≠ 2) : S p 0 = 0 := by
  dsimp [S]
  have h : ∀ x : ZMod p, χ p (x ^ 3 - 0 * x) = χ p x := by
    intro x
    have : x ^ 3 - 0 * x = x * x ^ 2 := by ring
    rw [this, χ_mul, sq, χ_mul]
    by_cases hx : x = 0
    · subst hx
      rw [χ_zero, mul_zero, mul_zero]
    · have : χ p x * (χ p x * χ p x) = (χ p x) ^ 2 * χ p x := by ring
      rw [this, χ_sq' p hx, one_mul]
  simp_rw [h]
  exact sum_χ_eq_zero p hp2

theorem csum_sq_add_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (c r : Int)
    (hc : legendreSym p c = 1) (hr : legendreSym p r = -1) :
    csum p c ^ 2 + csum p r ^ 2 = 4 * (p : Int) := by
  have hp2 : p ≠ 2 := by
    rintro rfl
    norm_num at hp
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  rw [csum_eq_S p c, csum_eq_S p r]
  have hc0 : (c : ZMod p) ≠ 0 := by
    intro hz
    have := legendreSym_eq_zero_of_cast_eq_zero p c hz
    rw [hc] at this
    contradiction
  have hr0 : (r : ZMod p) ≠ 0 := by
    intro hz
    have := legendreSym_eq_zero_of_cast_eq_zero p r hz
    rw [hr] at this
    contradiction
  have hc_sq : IsSquare (c : ZMod p) := by
    have hchi : χ p (c : ZMod p) = 1 := by
      dsimp [χ]
      rw [legendreSym_cast_zmod, hc]
    exact (χ_eq_one_iff p hc0).mp hchi
  have hr_nsq : ¬IsSquare (r : ZMod p) := by
    have hchi : χ p (r : ZMod p) = -1 := by
      dsimp [χ]
      rw [legendreSym_cast_zmod, hr]
    exact (χ_eq_neg_one_iff p (r : ZMod p)).mp hchi
  have hsplit_k : ∀ k ∈ (Finset.univ : Finset (ZMod p)).erase 0,
      2 * (S p k) ^ 2 = (1 + χ p k) * (S p (c : ZMod p)) ^ 2 + (1 - χ p k) * (S p (r : ZMod p)) ^ 2 := by
    intro k hk
    rw [Finset.mem_erase] at hk
    by_cases hsq : IsSquare k
    · have hk_chi : χ p k = 1 := (χ_eq_one_iff p hk.1).mpr hsq
      rw [hk_chi, S_sq_eq_of_isSquare p (c : ZMod p) k hc_sq hc0 hsq hk.1]
      ring
    · have hk_chi : χ p k = -1 := (χ_eq_neg_one_iff p k).mpr hsq
      rw [hk_chi, S_sq_eq_of_not_isSquare p (r : ZMod p) k hr_nsq hsq]
      ring
  have hsum_k : 2 * ∑ k ∈ (Finset.univ : Finset (ZMod p)).erase 0, (S p k) ^ 2 =
      ((p : ℤ) - 1) * (S p (c : ZMod p)) ^ 2 + ((p : ℤ) - 1) * (S p (r : ZMod p)) ^ 2 := by
    rw [Finset.mul_sum]
    have heq := Finset.sum_congr rfl hsplit_k
    rw [heq]
    have heq2 : (∑ k ∈ (Finset.univ : Finset (ZMod p)).erase 0,
        ((1 + χ p k) * (S p (c : ZMod p)) ^ 2 + (1 - χ p k) * (S p (r : ZMod p)) ^ 2)) =
        ((p : ℤ) - 1) * (S p (c : ZMod p)) ^ 2 + ((p : ℤ) - 1) * (S p (r : ZMod p)) ^ 2 := by
      have h1 : (fun k => (1 + χ p k) * (S p (c : ZMod p)) ^ 2 + (1 - χ p k) * (S p (r : ZMod p)) ^ 2) =
          (fun k => ((S p (c : ZMod p)) ^ 2 + χ p k * (S p (c : ZMod p)) ^ 2) +
                    ((S p (r : ZMod p)) ^ 2 - χ p k * (S p (r : ZMod p)) ^ 2)) := by
        ext k
        ring
      rw [h1, Finset.sum_add_distrib]
      have hsum_1 : ∑ k ∈ (Finset.univ : Finset (ZMod p)).erase 0,
          ((S p (c : ZMod p)) ^ 2 + χ p k * (S p (c : ZMod p)) ^ 2) =
          ((p : ℤ) - 1) * (S p (c : ZMod p)) ^ 2 := by
        rw [Finset.sum_add_distrib, ← Finset.sum_mul]
        have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
        have htot := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun k => χ p k) h0
        rw [sum_χ_eq_zero p hp2, χ_zero, add_zero] at htot
        rw [htot, zero_mul, add_zero]
        simp only [Finset.sum_const, nsmul_eq_mul]
        rw [Finset.card_erase_of_mem h0, Finset.card_univ, ZMod.card]
        have : ((p - 1 : ℕ) : ℤ) = (p : ℤ) - 1 := by omega
        rw [this]
      have hsum_2 : ∑ k ∈ (Finset.univ : Finset (ZMod p)).erase 0,
          ((S p (r : ZMod p)) ^ 2 - χ p k * (S p (r : ZMod p)) ^ 2) =
          ((p : ℤ) - 1) * (S p (r : ZMod p)) ^ 2 := by
        rw [Finset.sum_sub_distrib, ← Finset.sum_mul]
        have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
        have htot := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun k => χ p k) h0
        rw [sum_χ_eq_zero p hp2, χ_zero, add_zero] at htot
        rw [htot, zero_mul, sub_zero]
        simp only [Finset.sum_const, nsmul_eq_mul]
        rw [Finset.card_erase_of_mem h0, Finset.card_univ, ZMod.card]
        have : ((p - 1 : ℕ) : ℤ) = (p : ℤ) - 1 := by omega
        rw [this]
      rw [hsum_1, hsum_2]
    rw [heq2]
  have htot_S : (∑ k ∈ (Finset.univ : Finset (ZMod p)).erase 0, (S p k) ^ 2) =
      2 * (p : ℤ) * ((p : ℤ) - 1) := by
    have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
    have hsplit := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun k => (S p k) ^ 2) h0
    rw [S_zero p hp2, zero_pow two_ne_zero, add_zero] at hsplit
    rw [hsplit, sum_S_sq p hp]
  rw [htot_S] at hsum_k
  have hpm1 : ((p : ℤ) - 1) ≠ 0 := by
    have : p ≥ 2 := (Fact.out : p.Prime).two_le
    omega
  have hcancel : ((p : ℤ) - 1) * (S p (c : ZMod p) ^ 2 + S p (r : ZMod p) ^ 2) =
      ((p : ℤ) - 1) * (4 * (p : ℤ)) := by
    calc ((p : ℤ) - 1) * (S p (c : ZMod p) ^ 2 + S p (r : ZMod p) ^ 2)
      _ = ((p : ℤ) - 1) * (S p (c : ZMod p)) ^ 2 + ((p : ℤ) - 1) * (S p (r : ZMod p)) ^ 2 := by ring
      _ = 2 * (2 * (p : ℤ) * ((p : ℤ) - 1)) := hsum_k.symm
      _ = ((p : ℤ) - 1) * (4 * (p : ℤ)) := by ring
  exact mul_left_cancel₀ hpm1 hcancel

lemma p_ge_five (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) : p ≥ 5 := by
  have hp2 : p ≥ 2 := (Fact.out : p.Prime).two_le
  by_contra! hlt
  interval_cases p <;> revert hp <;> decide

lemma exists_sq_neg_one (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) :
    ∃ u : ZMod p, u ^ 2 = -1 := by
  have hp2 : p ≠ 2 := by
    rintro rfl
    norm_num at hp
  have hchi : legendreSym p (-1) = 1 := by
    rw [legendreSym.at_neg_one hp2, ZMod.χ₄_nat_one_mod_four hp]
  have hne : ((-1 : ℤ) : ZMod p) ≠ 0 := by
    intro hz
    have h1 : ((-1 : ℤ) : ZMod p) = -1 := by push_cast; rfl
    rw [h1] at hz
    have h2 : (1 : ZMod p) = 0 := neg_eq_zero.mp hz
    have h3 : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast h2
    have h4 : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp h3
    have : p ≤ 1 := Nat.le_of_dvd (by decide) h4
    have : p ≥ 2 := (Fact.out : p.Prime).two_le
    omega
  have hsq := (legendreSym.eq_one_iff p hne).mp hchi
  obtain ⟨u, hu⟩ := hsq
  use u
  rw [sq, ← hu]
  push_cast
  rfl

lemma chi_u_int (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (u : ZMod p) (hu : u ^ 2 = -1) :
    legendreSym p u.val = (-1) ^ (p / 4) := by
  have hp5 : p ≥ 5 := p_ge_five p hp
  have hmod : (legendreSym p u.val : ZMod p) = (-1 : ZMod p) ^ (p / 4) := by
    have h := legendreSym.eq_pow p u.val
    have hu_val : ((u.val : ℤ) : ZMod p) = u := by
      simp only [Int.cast_natCast, ZMod.natCast_zmod_val]
    rw [hu_val] at h
    rw [h]
    have hdiv : p / 2 = 2 * (p / 4) := by omega
    rw [hdiv, pow_mul, hu]
  have hu0 : ((u.val : ℤ) : ZMod p) ≠ 0 := by
    have hu_val : ((u.val : ℤ) : ZMod p) = u := by
      simp only [Int.cast_natCast, ZMod.natCast_zmod_val]
    rw [hu_val]
    intro hz
    rw [hz, zero_pow two_ne_zero] at hu
    have h1 : (-1 : ZMod p) = 0 := hu.symm
    have h2 : (1 : ZMod p) = 0 := neg_eq_zero.mp h1
    have h4 : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp (by exact_mod_cast h2)
    have : p ≤ 1 := Nat.le_of_dvd (by decide) h4
    omega
  have hor := legendreSym.eq_one_or_neg_one p hu0
  have hcast_inj : ∀ a b : ℤ, (a = 1 ∨ a = -1) → (b = 1 ∨ b = -1) →
      (a : ZMod p) = (b : ZMod p) → a = b := by
    intro a b ha hb heq
    rcases ha with rfl | rfl <;> rcases hb with rfl | rfl
    · rfl
    · exfalso
      have : (2 : ZMod p) = 0 := by linear_combination heq
      have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp (by exact_mod_cast this)
      have : p ≤ 2 := Nat.le_of_dvd (by decide) this
      omega
    · exfalso
      have : (2 : ZMod p) = 0 := by linear_combination -1 * heq
      have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp (by exact_mod_cast this)
      have : p ≤ 2 := Nat.le_of_dvd (by decide) this
      omega
    · rfl
  have hpow_or : (-1 : ℤ) ^ (p / 4) = 1 ∨ (-1 : ℤ) ^ (p / 4) = -1 := by
    rcases (Nat.even_or_odd (p / 4)) with he | ho
    · left; exact Even.neg_one_pow he
    · right; exact Odd.neg_one_pow ho
  apply hcast_inj _ _ hor hpow_or
  push_cast
  exact hmod

lemma chi_two_int (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) :
    legendreSym p 2 = if p % 8 = 1 then 1 else -1 := by
  have hp2 : p ≠ 2 := by
    rintro rfl
    norm_num at hp
  rw [legendreSym.at_two hp2, ZMod.χ₈_nat_eq_if_mod_eight]
  have hp_odd : p % 2 = 1 := by omega
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases hp8 with h1 | h5
  · simp [hp_odd, h1]
  · have h7 : ¬(p % 8 = 7) := by omega
    have h1' : ¬(p % 8 = 1) := by omega
    simp [hp_odd, h1', h7]

lemma f_u_eq_one (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (u : ZMod p) (hu : u ^ 2 = -1) :
    χ p (u ^ 3 - u) = 1 := by
  have hid : u ^ 3 - u = -1 * (2 * u) := by
    calc u ^ 3 - u = u * (u ^ 2 - 1) := by ring
    _ = u * (-1 - 1) := by rw [hu]
    _ = -1 * (2 * u) := by ring
  rw [hid, χ_mul, χ_neg_one p hp, one_mul]
  have h2u : (2 * u : ZMod p) = (((2 : ℤ) : ZMod p) * u) := by push_cast; rfl
  rw [h2u, χ_mul]
  have h2 : χ p ((2 : ℤ) : ZMod p) = legendreSym p 2 := by
    dsimp [χ]
    rw [legendreSym_cast_zmod]
  have hu_sym : χ p u = (-1 : ℤ) ^ (p / 4) := by
    dsimp [χ]
    exact chi_u_int p hp u hu
  rw [h2, hu_sym, chi_two_int p hp]
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases hp8 with h1 | h5
  · simp only [h1, ↓reduceIte]
    have : Even (p / 4) := by use (p / 8); omega
    rw [Even.neg_one_pow this, mul_one]
  · have : ¬(p % 8 = 1) := by omega
    simp only [this, ↓reduceIte]
    have : Odd (p / 4) := by use (p / 8); omega
    rw [Odd.neg_one_pow this]
    ring

lemma special_set_card (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (u : ZMod p) (hu : u ^ 2 = -1) :
    ({0, 1, -1, u, -u} : Finset (ZMod p)).card = 5 := by
  have hp5 : p ≥ 5 := p_ge_five p hp
  have h_ne_zero_one : (0 : ZMod p) ≠ 1 := by
    intro hz
    have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast hz.symm
    have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
    have : p ≤ 1 := Nat.le_of_dvd (by decide) this
    omega
  have h_ne_zero_neg_one : (0 : ZMod p) ≠ -1 := by
    intro hz
    have : (1 : ZMod p) = 0 := neg_eq_zero.mp hz.symm
    have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
    have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
    have : p ≤ 1 := Nat.le_of_dvd (by decide) this
    omega
  have h_ne_one_neg_one : (1 : ZMod p) ≠ -1 := by
    intro hz
    have : (2 : ZMod p) = 0 := by linear_combination hz
    have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
    have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
    have : p ≤ 2 := Nat.le_of_dvd (by decide) this
    omega
  have hu0 : u ≠ 0 := by
    intro hz
    rw [hz, zero_pow two_ne_zero] at hu
    have : (1 : ZMod p) = 0 := neg_eq_zero.mp hu.symm
    have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
    have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
    have : p ≤ 1 := Nat.le_of_dvd (by decide) this
    omega
  have hnu0 : -u ≠ 0 := neg_ne_zero.mpr hu0
  have hu1 : u ≠ 1 := by
    intro hz
    have : u ^ 2 = 1 := by rw [hz, one_pow]
    have : (-1 : ZMod p) = 1 := hu.symm.trans this
    exact h_ne_one_neg_one this.symm
  have hu_neg1 : u ≠ -1 := by
    intro hz
    have : u ^ 2 = 1 := by rw [hz, neg_one_sq]
    have : (-1 : ZMod p) = 1 := hu.symm.trans this
    exact h_ne_one_neg_one this.symm
  have hnu1 : -u ≠ 1 := by
    intro hz
    have : u = -1 := by linear_combination -1 * hz
    exact hu_neg1 this
  have hnu_neg1 : -u ≠ -1 := by
    intro hz
    have : u = 1 := by linear_combination -1 * hz
    exact hu1 this
  have hu_nu : u ≠ -u := by
    intro hz
    have : 2 * u = 0 := by linear_combination hz
    have h2 : (2 : ZMod p) ≠ 0 := by
      intro h
      have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast h
      have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
      have : p ≤ 2 := Nat.le_of_dvd (by decide) this
      omega
    exact mul_ne_zero h2 hu0 this
  rw [Finset.card_insert_of_notMem]
  · rw [Finset.card_insert_of_notMem]
    · rw [Finset.card_insert_of_notMem]
      · rw [Finset.card_insert_of_notMem]
        · rw [Finset.card_singleton]
        · simp [hu_nu]
      · simp [hu_neg1.symm, hnu_neg1.symm]
    · simp [h_ne_one_neg_one, hu1.symm, hnu1.symm]
  · simp [h_ne_zero_one, h_ne_zero_neg_one, hu0.symm, hnu0.symm]

lemma sum_eq_two_mul_of_involution {p : ℕ} [Fact p.Prime] (s : Finset (ZMod p))
    (σ : ZMod p → ZMod p)
    (hσ_mem : ∀ x ∈ s, σ x ∈ s)
    (hσ_invol : ∀ x ∈ s, σ (σ x) = x)
    (hσ_ne : ∀ x ∈ s, σ x ≠ x)
    (f : ZMod p → ℤ)
    (hf : ∀ x ∈ s, f (σ x) = f x) :
    let s₁ := s.filter (fun x => x.val < (σ x).val)
    ∑ x ∈ s, f x = 2 * ∑ x ∈ s₁, f x ∧ s.card = 2 * s₁.card := by
  intro s₁
  let s₂ := s.filter (fun x => (σ x).val < x.val)
  have hdisj : Disjoint s₁ s₂ := by
    rw [Finset.disjoint_filter]
    intro x _ h1 h2
    omega
  have hunion : s = s₁ ∪ s₂ := by
    ext x
    simp only [s₁, s₂, Finset.mem_union, Finset.mem_filter]
    constructor
    · intro hx
      have hne : x.val ≠ (σ x).val := by
        intro heq
        have hx_eq : x = σ x := by
          have := congrArg (fun (n : ℕ) => (n : ZMod p)) heq
          simp only [ZMod.natCast_zmod_val] at this
          exact this
        exact hσ_ne x hx hx_eq.symm
      rcases lt_or_gt_of_ne hne with h1 | h2
      · left; exact ⟨hx, h1⟩
      · right; exact ⟨hx, h2⟩
    · rintro (⟨hx, _⟩ | ⟨hx, _⟩) <;> exact hx
  have hequiv : s₂ = s₁.image σ := by
    ext y
    simp only [s₁, s₂, Finset.mem_filter, Finset.mem_image]
    constructor
    · intro ⟨hy, hlt⟩
      refine ⟨σ y, ?_, ?_⟩
      · refine ⟨hσ_mem y hy, ?_⟩
        rw [hσ_invol y hy]
        exact hlt
      · exact hσ_invol y hy
    · rintro ⟨x, ⟨hx, hlt⟩, rfl⟩
      refine ⟨hσ_mem x hx, ?_⟩
      rw [hσ_invol x hx]
      exact hlt
  have hinj : Set.InjOn σ s₁ := by
    intro x hx y hy heq
    have := congrArg σ heq
    have hx' := Finset.mem_filter.mp hx
    have hy' := Finset.mem_filter.mp hy
    rw [hσ_invol x hx'.1, hσ_invol y hy'.1] at this
    exact this
  have hsum_s₂ : ∑ x ∈ s₂, f x = ∑ x ∈ s₁, f x := by
    rw [hequiv, Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro x hx
    have hx' := Finset.mem_filter.mp hx
    exact hf x hx'.1
  have hcard_s₂ : s₂.card = s₁.card := by
    rw [hequiv]
    exact Finset.card_image_of_injOn hinj
  constructor
  · conv_lhs => rw [hunion]
    rw [Finset.sum_union hdisj, hsum_s₂, two_mul]
  · conv_lhs => rw [hunion]
    rw [Finset.card_union_of_disjoint hdisj, hcard_s₂, two_mul]

lemma f_inv (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) {x : ZMod p} (hx : x ≠ 0) :
    χ p (x⁻¹ ^ 3 - x⁻¹) = χ p (x ^ 3 - x) := by
  have hid : x⁻¹ ^ 3 - x⁻¹ = -1 * (x ^ 3 - x) * (x⁻¹ ^ 2) ^ 2 := by
    have : (x ^ 3 - x) * (x⁻¹ ^ 2) ^ 2 = x⁻¹ - x⁻¹ ^ 3 := by
      calc (x ^ 3 - x) * (x⁻¹ ^ 2) ^ 2
        _ = (x ^ 3 - x) * (x⁻¹ ^ 4) := by ring
        _ = x ^ 3 * x⁻¹ ^ 4 - x * x⁻¹ ^ 4 := by ring
        _ = (x * x⁻¹) ^ 3 * x⁻¹ - (x * x⁻¹) * x⁻¹ ^ 3 := by ring
        _ = 1 ^ 3 * x⁻¹ - 1 * x⁻¹ ^ 3 := by rw [mul_inv_cancel₀ hx]
        _ = x⁻¹ - x⁻¹ ^ 3 := by ring
    rw [mul_assoc, this]
    ring
  rw [hid, χ_mul, χ_mul, χ_neg_one p hp, one_mul]
  have hx2 : x⁻¹ ^ 2 ≠ 0 := by
    have : x⁻¹ ≠ 0 := inv_ne_zero hx
    exact pow_ne_zero 2 this
  have hsq := χ_sq' p hx2
  have : (x⁻¹ ^ 2) ^ 2 = (x⁻¹ ^ 2) * (x⁻¹ ^ 2) := by ring
  rw [this, χ_mul]
  have : (x⁻¹ ^ 2) * (x⁻¹ ^ 2) = (x⁻¹ ^ 2) ^ 2 := by ring
  have : χ p (x ^ 3 - x) * (χ p (x⁻¹ ^ 2) * χ p (x⁻¹ ^ 2)) = χ p (x ^ 3 - x) * (χ p (x⁻¹ ^ 2)) ^ 2 := by ring
  rw [this, hsq, mul_one]

def tau (x : ZMod p) : ZMod p :=
  if x⁻¹.val < (-x⁻¹).val then x⁻¹ else -x⁻¹

lemma tau_invol (p : ℕ) [Fact p.Prime] (x : ZMod p) (h_in_s1 : x.val < (-x).val) :
    tau (tau x) = x := by
  dsimp [tau]
  split_ifs with h1 h2 h3
  · rw [inv_inv]
  · rw [inv_inv] at h2
    have : (-x⁻¹⁻¹) = -x := by rw [inv_inv]
    omega
  · have hinv : (-x⁻¹)⁻¹ = -x := by rw [inv_neg, inv_inv]
    rw [hinv, neg_neg] at h3
    omega
  · have hneg : -(-x⁻¹)⁻¹ = x := by rw [inv_neg, inv_inv, neg_neg]
    rw [hneg]

lemma tau_ne (p : ℕ) [Fact p.Prime] (x : ZMod p) (hx0 : x ≠ 0)
    (h1 : x ≠ 1) (hn1 : x ≠ -1) (hu : x ^ 2 ≠ -1) :
    tau x ≠ x := by
  intro heq
  dsimp [tau] at heq
  split_ifs at heq with hlt
  · have : x ^ 2 = 1 := by
      calc x ^ 2 = x * x := sq x
      _ = x * x⁻¹ := by rw [heq]
      _ = 1 := mul_inv_cancel₀ hx0
    rw [sq_eq_one_iff] at this
    rcases this with rfl | rfl
    · exact h1 rfl
    · exact hn1 rfl
  · have : x ^ 2 = -1 := by
      calc x ^ 2 = x * x := sq x
      _ = x * (-x⁻¹) := by rw [heq]
      _ = - (x * x⁻¹) := mul_neg x x⁻¹
      _ = -1 := by rw [mul_inv_cancel₀ hx0]
    exact hu this

lemma tau_f (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (x : ZMod p) (hx0 : x ≠ 0) :
    χ p (tau x ^ 3 - tau x) = χ p (x ^ 3 - x) := by
  dsimp [tau]
  split_ifs
  · exact f_inv p hp hx0
  · have : (-x⁻¹) ^ 3 - (-x⁻¹) = - (x⁻¹ ^ 3 - x⁻¹) := by ring
    rw [this, χ_neg p hp, f_inv p hp hx0]

lemma sum_four_mul_mod_eight {α : Type*} (s : Finset α) (f : α → ℤ)
    (hf : ∀ x ∈ s, f x = 1 ∨ f x = -1) :
    (4 * ∑ x ∈ s, f x) % 8 = (4 * (s.card : ℤ)) % 8 := by
  have hdiff : 4 * ∑ x ∈ s, f x - 4 * (s.card : ℤ) = ∑ x ∈ s, (4 * f x - 4) := by
    rw [Finset.mul_sum]
    have : 4 * (s.card : ℤ) = ∑ x ∈ s, (4 : ℤ) := by
      simp only [Finset.sum_const, nsmul_eq_mul]
      ring
    rw [this, ← Finset.sum_sub_distrib]
  have hdvd : 8 ∣ 4 * ∑ x ∈ s, f x - 4 * (s.card : ℤ) := by
    rw [hdiff]
    apply Finset.dvd_sum
    intro x hx
    rcases hf x hx with h1 | h2
    · rw [h1]
      use 0
      ring
    · rw [h2]
      use -1
      ring
  obtain ⟨k, hk⟩ := hdvd
  have : 4 * ∑ x ∈ s, f x = 4 * (s.card : ℤ) + 8 * k := by linarith
  rw [this]
  omega

lemma test_mod8_arith (p : ℕ) (hp : p % 4 = 1) :
    ((p : ℤ) - 3) % 8 = if p % 8 = 5 then 2 else 6 := by
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases hp8 with h1 | h5
  · have h_ne : ¬(p % 8 = 5) := by omega
    simp only [h_ne, ↓reduceIte]
    have : ((p : ℤ) - 3) = 8 * ((p : ℤ) / 8 - 1) + 5 + 1 := by omega
    have : ((p : ℤ) - 3) % 8 = 6 := by omega
    exact this
  · simp only [h5, ↓reduceIte]
    have : ((p : ℤ) - 3) % 8 = 2 := by omega
    exact this

lemma csum_one_mod8_helper (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    csum p 1 % 8 = if p % 8 = 5 then 2 else 6 := by
  have hp2 : p ≠ 2 := by rintro rfl; norm_num at hp
  have hp5 : p ≥ 5 := p_ge_five p hp
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  rw [csum_eq_S p 1]
  have h1cast : ((1 : ℤ) : ZMod p) = (1 : ZMod p) := by push_cast; rfl
  rw [h1cast]
  have hS_1 : S p (1 : ZMod p) = ∑ x : ZMod p, χ p (x ^ 3 - x) := by
    dsimp [S]
    apply Finset.sum_congr rfl
    intro x _
    congr 2
    ring
  rw [hS_1]
  obtain ⟨u, hu⟩ := exists_sq_neg_one p hp
  let S_spec : Finset (ZMod p) := {0, 1, -1, u, -u}
  have hS_spec_card : S_spec.card = 5 := special_set_card p hp u hu
  let X := (Finset.univ : Finset (ZMod p)) \ S_spec
  have hX_card : X.card = p - 5 := by
    have : X.card = (Finset.univ : Finset (ZMod p)).card - S_spec.card :=
      Finset.card_sdiff_of_subset (Finset.subset_univ _)
    rw [this, Finset.card_univ, ZMod.card, hS_spec_card]
  let f := fun x : ZMod p => χ p (x ^ 3 - x)
  have h_not_in_spec : ∀ x ∈ X, x ≠ 0 ∧ x ≠ 1 ∧ x ≠ -1 ∧ x ≠ u ∧ x ≠ -u := by
    intro x hx
    simp only [X, Finset.mem_sdiff, Finset.mem_univ, true_and, S_spec,
      Finset.mem_insert, Finset.mem_singleton, not_or] at hx
    exact hx
  have h_not_in_spec_sq : ∀ x ∈ X, x ^ 2 ≠ -1 := by
    intro x hx hsq
    have h_or : x = u ∨ x = -u := by
      have : x ^ 2 = u ^ 2 := by rw [hsq, hu]
      rw [sq_eq_sq_iff_eq_or_eq_neg] at this
      exact this
    have h := h_not_in_spec x hx
    rcases h_or with rfl | rfl
    · exact h.2.2.2.1 rfl
    · exact h.2.2.2.2 rfl
  have hσ_mem : ∀ x ∈ X, -x ∈ X := by
    intro x hx
    have h := h_not_in_spec x hx
    simp only [X, Finset.mem_sdiff, Finset.mem_univ, true_and, S_spec,
      Finset.mem_insert, Finset.mem_singleton, not_or]
    refine ⟨?_, ?_, ?_, ?_, ?_⟩
    · intro hz
      have : x = 0 := neg_eq_zero.mp hz
      exact h.1 this
    · intro hz
      have : x = -1 := by linear_combination -1 * hz
      exact h.2.2.1 this
    · intro hz
      have : x = 1 := by linear_combination -1 * hz
      exact h.2.1 this
    · intro hz
      have : x = -u := by linear_combination -1 * hz
      exact h.2.2.2.2 this
    · intro hz
      have : x = u := by linear_combination -1 * hz
      exact h.2.2.2.1 this
  have hσ_invol : ∀ x ∈ X, -(-x) = x := fun _ _ => neg_neg _
  have hσ_ne : ∀ x ∈ X, -x ≠ x := by
    intro x hx heq
    have : 2 * x = 0 := by
      have : -x - x = 0 := by rw [heq, sub_self]
      linear_combination -1 * this
    have h2 : (2 : ZMod p) ≠ 0 := by
      intro h
      have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast h
      have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
      have : p ≤ 2 := Nat.le_of_dvd (by decide) this
      omega
    have := mul_ne_zero h2 (h_not_in_spec x hx).1
    contradiction
  have hf_neg : ∀ x ∈ X, f (-x) = f x := by
    intro x _
    dsimp [f]
    have : (-x) ^ 3 - (-x) = - (x ^ 3 - x) := by ring
    rw [this, χ_neg p hp]
  have h_step1 := sum_eq_two_mul_of_involution X (fun x => -x) hσ_mem hσ_invol hσ_ne f hf_neg
  let s₁ := X.filter (fun x => x.val < (-x).val)
  rcases h_step1 with ⟨h_sum1, h_card1⟩
  have hs₁_spec : ∀ x ∈ s₁, x ≠ 0 ∧ x ≠ 1 ∧ x ≠ -1 ∧ x ^ 2 ≠ -1 := by
    intro x hx
    have hxX := (Finset.mem_filter.mp hx).1
    have h1 := h_not_in_spec x hxX
    exact ⟨h1.1, h1.2.1, h1.2.2.1, h_not_in_spec_sq x hxX⟩
  have hτ_mem : ∀ x ∈ s₁, tau x ∈ s₁ := by
    intro x hx
    have hx_filt := Finset.mem_filter.mp hx
    have hxX := hx_filt.1
    have h_lt := hx_filt.2
    have hx_spec := hs₁_spec x hx
    rw [Finset.mem_filter]
    refine ⟨?_, ?_⟩
    · simp only [X, Finset.mem_sdiff, Finset.mem_univ, true_and, S_spec,
        Finset.mem_insert, Finset.mem_singleton, not_or]
      dsimp [tau]
      split_ifs
      · refine ⟨?_, ?_, ?_, ?_, ?_⟩
        · intro hz
          exact inv_ne_zero hx_spec.1 hz
        · intro hz
          have : x = 1 := by rw [← inv_inv x, hz, inv_one]
          exact hx_spec.2.1 this
        · intro hz
          have : x = -1 := by rw [← inv_inv x, hz, inv_neg, inv_one]
          exact hx_spec.2.2.1 this
        · intro hz
          have : x ^ 2 = -1 := by
            calc x ^ 2 = (x⁻¹ ^ 2)⁻¹ := by rw [← inv_pow, inv_inv]
            _ = (u ^ 2)⁻¹ := by rw [hz]
            _ = (-1)⁻¹ := by rw [hu]
            _ = -1 := by norm_num
          exact hx_spec.2.2.2 this
        · intro hz
          have : x ^ 2 = -1 := by
            calc x ^ 2 = (x⁻¹ ^ 2)⁻¹ := by rw [← inv_pow, inv_inv]
            _ = ((-u) ^ 2)⁻¹ := by rw [hz]
            _ = (u ^ 2)⁻¹ := by rw [neg_sq]
            _ = (-1)⁻¹ := by rw [hu]
            _ = -1 := by norm_num
          exact hx_spec.2.2.2 this
      · refine ⟨?_, ?_, ?_, ?_, ?_⟩
        · intro hz
          have : x⁻¹ = 0 := neg_eq_zero.mp hz
          exact inv_ne_zero hx_spec.1 this
        · intro hz
          have h_neg : x⁻¹ = -1 := by linear_combination -1 * hz
          have : x = -1 := by rw [← inv_inv x, h_neg, inv_neg, inv_one]
          exact hx_spec.2.2.1 this
        · intro hz
          have h_neg : x⁻¹ = 1 := by linear_combination -1 * hz
          have : x = 1 := by rw [← inv_inv x, h_neg, inv_one]
          exact hx_spec.2.1 this
        · intro hz
          have h_neg : x⁻¹ = -u := by linear_combination -1 * hz
          have : x ^ 2 = -1 := by
            calc x ^ 2 = (x⁻¹ ^ 2)⁻¹ := by rw [← inv_pow, inv_inv]
            _ = ((-u) ^ 2)⁻¹ := by rw [h_neg]
            _ = (u ^ 2)⁻¹ := by rw [neg_sq]
            _ = (-1)⁻¹ := by rw [hu]
            _ = -1 := by norm_num
          exact hx_spec.2.2.2 this
        · intro hz
          have h_neg : x⁻¹ = u := by linear_combination -1 * hz
          have : x ^ 2 = -1 := by
            calc x ^ 2 = (x⁻¹ ^ 2)⁻¹ := by rw [← inv_pow, inv_inv]
            _ = (u ^ 2)⁻¹ := by rw [h_neg]
            _ = (-1)⁻¹ := by rw [hu]
            _ = -1 := by norm_num
          exact hx_spec.2.2.2 this
    · dsimp [tau]
      split_ifs with hlt
      · exact hlt
      · have hne : x⁻¹ ≠ -x⁻¹ := by
          intro heq
          have h2x : 2 * x⁻¹ = 0 := by linear_combination heq
          have h2 : (2 : ZMod p) ≠ 0 := by
            intro h
            have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast h
            have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
            have : p ≤ 2 := Nat.le_of_dvd (by decide) this
            omega
          exact mul_ne_zero h2 (inv_ne_zero hx_spec.1) h2x
        have hne_val : x⁻¹.val ≠ (-x⁻¹).val := by
          intro heq
          have := congrArg (fun (n : ℕ) => (n : ZMod p)) heq
          simp only [ZMod.natCast_zmod_val] at this
          exact hne this
        have : (-x⁻¹).val < x⁻¹.val := by omega
        have hneg : -(-x⁻¹) = x⁻¹ := neg_neg _
        rw [hneg]
        exact this
  have hτ_invol : ∀ x ∈ s₁, tau (tau x) = x := by
    intro x hx
    exact tau_invol p x (Finset.mem_filter.mp hx).2
  have hτ_ne : ∀ x ∈ s₁, tau x ≠ x := by
    intro x hx
    have h := hs₁_spec x hx
    exact tau_ne p x h.1 h.2.1 h.2.2.1 h.2.2.2
  have hf_tau : ∀ x ∈ s₁, f (tau x) = f x := by
    intro x hx
    exact tau_f p hp x (hs₁_spec x hx).1
  have h_step2 := sum_eq_two_mul_of_involution s₁ tau hτ_mem hτ_invol hτ_ne f hf_tau
  let s₂ := s₁.filter (fun x => x.val < (tau x).val)
  rcases h_step2 with ⟨h_sum2, h_card2⟩
  have h_sumX : ∑ x ∈ X, f x = 4 * ∑ x ∈ s₂, f x := by
    calc ∑ x ∈ X, f x = 2 * ∑ x ∈ s₁, f x := h_sum1
    _ = 2 * (2 * ∑ x ∈ s₂, f x) := by rw [h_sum2]
    _ = 4 * ∑ x ∈ s₂, f x := by ring
  have h_cardX : (X.card : ℤ) = 4 * (s₂.card : ℤ) := by
    have : X.card = 2 * s₁.card := h_card1
    have : s₁.card = 2 * s₂.card := h_card2
    omega
  have hf_pm : ∀ x ∈ s₂, f x = 1 ∨ f x = -1 := by
    intro x hx
    have hx_spec := hs₁_spec x (Finset.mem_filter.mp hx).1
    have hne : x ^ 3 - x ≠ 0 := by
      intro hz
      have : x * (x ^ 2 - 1) = 0 := by
        calc x * (x ^ 2 - 1) = x ^ 3 - x := by ring
        _ = 0 := hz
      cases mul_eq_zero.mp this with
      | inl h0 => exact hx_spec.1 h0
      | inr h1 =>
        rw [sub_eq_zero, sq_eq_one_iff] at h1
        rcases h1 with rfl | rfl
        · exact hx_spec.2.1 rfl
        · exact hx_spec.2.2.1 rfl
    have hcast : (((x ^ 3 - x).val : ℤ) : ZMod p) ≠ 0 := by
      rw [Int.cast_natCast, ZMod.natCast_zmod_val]
      exact hne
    dsimp [f, χ]
    exact legendreSym.eq_one_or_neg_one p hcast
  have h_mod8 : (4 * ∑ x ∈ s₂, f x) % 8 = ((p : ℤ) - 5) % 8 := by
    have h1 := sum_four_mul_mod_eight s₂ f hf_pm
    rw [← h_cardX] at h1
    rw [h1, hX_card]
    have : ((p - 5 : ℕ) : ℤ) = (p : ℤ) - 5 := by omega
    rw [this]
  have h_tot_sum : (∑ x : ZMod p, f x) = (∑ x ∈ S_spec, f x) + ∑ x ∈ X, f x := by
    have heq := Finset.sum_sdiff (Finset.subset_univ S_spec (α := ZMod p)) (f := f)
    rw [add_comm]
    exact heq.symm
  have h_spec_sum : ∑ x ∈ S_spec, f x = 2 := by
    dsimp [S_spec]
    have hf0 : f 0 = 0 := by
      dsimp [f]
      have : (0 : ZMod p) ^ 3 - 0 = 0 := by ring
      rw [this, χ_zero]
    have hf1 : f 1 = 0 := by
      dsimp [f]
      have : (1 : ZMod p) ^ 3 - 1 = 0 := by ring
      rw [this, χ_zero]
    have hfn1 : f (-1) = 0 := by
      dsimp [f]
      have : (-1 : ZMod p) ^ 3 - (-1) = 0 := by ring
      rw [this, χ_zero]
    have hfu : f u = 1 := f_u_eq_one p hp u hu
    have hfnu : f (-u) = 1 := by
      dsimp [f]
      have : (-u) ^ 3 - (-u) = - (u ^ 3 - u) := by ring
      rw [this, χ_neg p hp, f_u_eq_one p hp u hu]
    have hu_nu : u ≠ -u := by
      intro hz
      have : 2 * u = 0 := by linear_combination hz
      have h2 : (2 : ZMod p) ≠ 0 := by
        intro h
        have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast h
        have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
        have : p ≤ 2 := Nat.le_of_dvd (by decide) this
        omega
      have hu0 : u ≠ 0 := by
        intro h
        rw [h, zero_pow two_ne_zero] at hu
        have : (1 : ZMod p) = 0 := neg_eq_zero.mp hu.symm
        have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
        have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
        have : p ≤ 1 := Nat.le_of_dvd (by decide) this
        omega
      exact mul_ne_zero h2 hu0 this
    have h_ne_one_neg_one : (1 : ZMod p) ≠ -1 := by
      intro hz
      have : (2 : ZMod p) = 0 := by linear_combination hz
      have : ((2 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
      have : p ∣ 2 := (CharP.cast_eq_zero_iff (ZMod p) p 2).mp this
      have : p ≤ 2 := Nat.le_of_dvd (by decide) this
      omega
    have hu_neg1 : u ≠ -1 := by
      intro hz
      have : u ^ 2 = 1 := by rw [hz, neg_one_sq]
      have : (-1 : ZMod p) = 1 := hu.symm.trans this
      exact h_ne_one_neg_one this.symm
    have hu1 : u ≠ 1 := by
      intro hz
      have : u ^ 2 = 1 := by rw [hz, one_pow]
      have : (-1 : ZMod p) = 1 := hu.symm.trans this
      exact h_ne_one_neg_one this.symm
    have hnu_neg1 : -u ≠ -1 := by
      intro hz
      have : u = 1 := by linear_combination -1 * hz
      exact hu1 this
    have hnu1 : -u ≠ 1 := by
      intro hz
      have : u = -1 := by linear_combination -1 * hz
      exact hu_neg1 this
    have h_ne_zero_one : (0 : ZMod p) ≠ 1 := by
      intro hz
      have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast hz.symm
      have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
      have : p ≤ 1 := Nat.le_of_dvd (by decide) this
      omega
    have h_ne_zero_neg_one : (0 : ZMod p) ≠ -1 := by
      intro hz
      have : (1 : ZMod p) = 0 := neg_eq_zero.mp hz.symm
      have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
      have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
      have : p ≤ 1 := Nat.le_of_dvd (by decide) this
      omega
    have hu0 : u ≠ 0 := by
      intro hz
      rw [hz, zero_pow two_ne_zero] at hu
      have : (1 : ZMod p) = 0 := neg_eq_zero.mp hu.symm
      have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
      have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
      have : p ≤ 1 := Nat.le_of_dvd (by decide) this
      omega
    have hnu0 : -u ≠ 0 := neg_ne_zero.mpr hu0
    rw [Finset.sum_insert]
    · rw [Finset.sum_insert]
      · rw [Finset.sum_insert]
        · rw [Finset.sum_insert]
          · rw [Finset.sum_singleton, hf0, hf1, hfn1, hfu, hfnu]
            ring
          · simp [hu_nu]
        · simp [hu_neg1.symm, hnu_neg1.symm]
      · simp [h_ne_one_neg_one, hu1.symm, hnu1.symm]
    · simp [h_ne_zero_one, h_ne_zero_neg_one, hu0.symm, hnu0.symm]
  rw [h_tot_sum, h_spec_sum, h_sumX]
  have h_final : (2 + 4 * ∑ x ∈ s₂, f x) % 8 = ((p : ℤ) - 3) % 8 := by
    have : (2 + 4 * ∑ x ∈ s₂, f x) % 8 = (2 % 8 + (4 * ∑ x ∈ s₂, f x) % 8) % 8 := by omega
    rw [this, h_mod8]
    omega
  rw [h_final, test_mod8_arith p hp]

lemma even_of_sq_mul_four (R : ℤ) (h : 4 ∣ R ^ 2) : 2 ∣ R := by
  have : R % 2 = 0 ∨ R % 2 = 1 := by omega
  rcases this with h0 | h1
  · exact Int.dvd_of_emod_eq_zero h0
  · exfalso
    have : R ^ 2 % 4 = 1 := by
      have : R = 2 * (R / 2) + 1 := by omega
      nth_rw 1 [this]
      have : (2 * (R / 2) + 1) ^ 2 = 4 * ((R / 2) ^ 2 + (R / 2)) + 1 := by ring
      rw [this]
      omega
    obtain ⟨k, hk⟩ := h
    rw [hk] at this
    omega

lemma test_A_odd (S : ℤ) (hS : S % 8 = 2 ∨ S % 8 = 6) :
    (S / 2) % 2 = 1 := by
  have : (S / 2) % 2 = 0 ∨ (S / 2) % 2 = 1 := by omega
  rcases this with h | h
  · exfalso
    have : S % 4 = 0 := by omega
    rcases hS with h1 | h2 <;> omega
  · exact h

lemma test_B_div (S R : ℤ) (p : ℤ) (h : S ^ 2 + R ^ 2 = 4 * p) (hS : 2 ∣ S) :
    2 ∣ R := by
  obtain ⟨A, rfl⟩ := hS
  have : R ^ 2 = 4 * (p - A ^ 2) := by linarith
  have : 4 ∣ R ^ 2 := ⟨p - A ^ 2, by linarith⟩
  exact even_of_sq_mul_four R this

lemma exists_nonsquare (p : ℕ) [Fact p.Prime] (hp : p ≠ 2) :
    ∃ r : ℤ, legendreSym p r = -1 := by
  have hchar : ringChar (ZMod p) ≠ 2 := by
    rw [ringChar.eq (ZMod p) p]
    exact hp
  obtain ⟨r, hr⟩ := FiniteField.exists_nonsquare (F := ZMod p) hchar
  use r.val
  rw [legendreSym.eq_neg_one_iff]
  intro hsq
  have : IsSquare (r : ZMod p) := by
    have hcast : (r : ZMod p) = ((r.val : ℤ) : ZMod p) := by
      push_cast
      simp only [ZMod.natCast_zmod_val]
    rwa [hcast]
  exact hr this

lemma sq_emod_two (x : ℤ) (hx : x % 2 = 1) : x ^ 2 % 2 = 1 := by
  have : x = 2 * (x / 2) + 1 := by omega
  nth_rw 1 [this]
  have : (2 * (x / 2) + 1) ^ 2 = 2 * (2 * (x / 2) ^ 2 + 2 * (x / 2)) + 1 := by ring
  rw [this]
  omega

lemma test_not_zero (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (a b : ℤ) (hab : a ^ 2 + b ^ 2 = (p : ℤ))
    (ha : a % 2 = 1) (S T : ℤ) (hzero : S * a + T * b = 0) (hST : S ^ 2 + T ^ 2 = (p : ℤ))
    (hS : S % 2 = 1) : False := by
  have hp0 : (p : ℤ) ≠ 0 := by exact_mod_cast (Fact.out : p.Prime).ne_zero
  have hid : S ^ 2 * a ^ 2 = T ^ 2 * b ^ 2 := by
    have : S * a = - (T * b) := by linear_combination hzero
    have hsq : (S * a) ^ 2 = (- (T * b)) ^ 2 := by rw [this]
    ring_nf at hsq ⊢
    exact hsq
  have hT : T ^ 2 = (p : ℤ) - S ^ 2 := by linarith [hST]
  have hb : b ^ 2 = (p : ℤ) - a ^ 2 := by linarith [hab]
  rw [hT, hb] at hid
  have hp_eq : (p : ℤ) = S ^ 2 + a ^ 2 := by
    have : (p : ℤ) * ((p : ℤ) - (S ^ 2 + a ^ 2)) = 0 := by
      calc (p : ℤ) * ((p : ℤ) - (S ^ 2 + a ^ 2))
        _ = ((p : ℤ) - S ^ 2) * ((p : ℤ) - a ^ 2) - S ^ 2 * a ^ 2 := by ring
        _ = 0 := by linarith [hid]
    cases mul_eq_zero.mp this with
    | inl h => exact False.elim (hp0 h)
    | inr h => linarith
  have hS2_b2 : S ^ 2 = b ^ 2 := by linarith [hab, hp_eq]
  have hb2 : b ^ 2 = (p : ℤ) - a ^ 2 := by linarith [hab]
  have hS_sq : S ^ 2 = 2 * (2 * (S / 2) ^ 2 + 2 * (S / 2)) + 1 := by
    have : S = 2 * (S / 2) + 1 := by omega
    nth_rw 1 [this]
    ring
  have ha_sq : a ^ 2 = 2 * (2 * (a / 2) ^ 2 + 2 * (a / 2)) + 1 := by
    have : a = 2 * (a / 2) + 1 := by omega
    nth_rw 1 [this]
    ring
  have hp_int : (p : ℤ) = 2 * (2 * ((p / 4 : ℕ) : ℤ)) + 1 := by
    have : p = 2 * (2 * (p / 4)) + 1 := by omega
    exact_mod_cast this
  have hb_even : b ^ 2 = 2 * (2 * ((p / 4 : ℕ) : ℤ) - (2 * (a / 2) ^ 2 + 2 * (a / 2))) := by
    rw [hb2, hp_int, ha_sq]
    ring
  have hS_odd : S ^ 2 % 2 = 1 := by
    rw [hS_sq]
    omega
  have hS_even : S ^ 2 % 2 = 0 := by
    rw [hS2_b2, hb_even]
    omega
  omega

lemma test_k_bounds (p : ℕ) [Fact p.Prime] (k : ℤ) (hk_sq : (p : ℤ) ^ 2 * k ^ 2 ≤ (p : ℤ) ^ 2) :
    k = -1 ∨ k = 0 ∨ k = 1 := by
  have hp0 : (p : ℤ) ≠ 0 := by exact_mod_cast (Fact.out : p.Prime).ne_zero
  have hp_pos : (p : ℤ) ^ 2 > 0 := by positivity
  have hk_le : k ^ 2 ≤ 1 := by nlinarith
  have hk_ge : -1 ≤ k := by
    by_contra!
    have : k ^ 2 ≥ 4 := by nlinarith
    linarith
  have hk_le' : k ≤ 1 := by
    by_contra!
    have : k ^ 2 ≥ 4 := by nlinarith
    linarith
  interval_cases k <;> simp

lemma sq_eq_sq_of_prime_sum_two_squares (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (a b A B : ℤ)
    (hab : a ^ 2 + b ^ 2 = (p : ℤ)) (hAB : A ^ 2 + B ^ 2 = (p : ℤ))
    (ha : a % 2 = 1) (hA : A % 2 = 1) :
    A ^ 2 = a ^ 2 := by
  have hp_prime : Prime (p : ℤ) := Nat.prime_iff_prime_int.mp Fact.out
  have hp0 : (p : ℤ) ≠ 0 := by exact_mod_cast (Fact.out : p.Prime).ne_zero
  have hbrahma1 : (A * a + B * b) ^ 2 + (A * b - B * a) ^ 2 = (p : ℤ) ^ 2 := by
    calc (A * a + B * b) ^ 2 + (A * b - B * a) ^ 2
      _ = (A ^ 2 + B ^ 2) * (a ^ 2 + b ^ 2) := by ring
      _ = (p : ℤ) ^ 2 := by rw [hAB, hab, sq]
  have hbrahma2 : (A * a - B * b) ^ 2 + (A * b + B * a) ^ 2 = (p : ℤ) ^ 2 := by
    calc (A * a - B * b) ^ 2 + (A * b + B * a) ^ 2
      _ = (A ^ 2 + B ^ 2) * (a ^ 2 + b ^ 2) := by ring
      _ = (p : ℤ) ^ 2 := by rw [hAB, hab, sq]
  have hprod : (A * a + B * b) * (A * a - B * b) = (p : ℤ) * (A ^ 2 + a ^ 2 - (p : ℤ)) := by
    calc (A * a + B * b) * (A * a - B * b)
      _ = A ^ 2 * a ^ 2 - B ^ 2 * b ^ 2 := by ring
      _ = A ^ 2 * a ^ 2 - ((p : ℤ) - A ^ 2) * ((p : ℤ) - a ^ 2) := by
        have hB : B ^ 2 = (p : ℤ) - A ^ 2 := by linarith [hAB]
        have hb : b ^ 2 = (p : ℤ) - a ^ 2 := by linarith [hab]
        rw [hB, hb]
      _ = (p : ℤ) * (A ^ 2 + a ^ 2 - (p : ℤ)) := by ring
  have hdvd : (p : ℤ) ∣ (A * a + B * b) * (A * a - B * b) := ⟨A ^ 2 + a ^ 2 - (p : ℤ), by rw [hprod, mul_comm]⟩
  rcases hp_prime.dvd_mul.mp hdvd with h1 | h2
  · rcases h1 with ⟨k, hk⟩
    have hk_sq : (p : ℤ) ^ 2 * k ^ 2 ≤ (p : ℤ) ^ 2 := by
      calc (p : ℤ) ^ 2 * k ^ 2 = (p * k) ^ 2 := by ring
      _ = (A * a + B * b) ^ 2 := by rw [hk]
      _ ≤ (A * a + B * b) ^ 2 + (A * b - B * a) ^ 2 := by
        have : (A * b - B * a) ^ 2 ≥ 0 := sq_nonneg _
        linarith
      _ = (p : ℤ) ^ 2 := hbrahma1
    rcases test_k_bounds p k hk_sq with rfl | rfl | rfl
    · have hk1 : (A * a + B * b) ^ 2 = (p : ℤ) ^ 2 := by rw [hk]; ring
      have : (A * b - B * a) ^ 2 = 0 := by linarith [hbrahma1, hk1]
      have : A * b = B * a := by
        have := sq_eq_zero_iff.mp this
        linarith
      have hid : A ^ 2 * (p : ℤ) = a ^ 2 * (p : ℤ) := by
        calc A ^ 2 * (p : ℤ) = A ^ 2 * (a ^ 2 + b ^ 2) := by rw [hab]
        _ = A ^ 2 * a ^ 2 + (A * b) ^ 2 := by ring
        _ = A ^ 2 * a ^ 2 + (B * a) ^ 2 := by rw [this]
        _ = (A ^ 2 + B ^ 2) * a ^ 2 := by ring
        _ = (p : ℤ) * a ^ 2 := by rw [hAB]
        _ = a ^ 2 * (p : ℤ) := by ring
      exact mul_right_cancel₀ hp0 hid
    · have hk0 : A * a + B * b = 0 := by rw [hk, mul_zero]
      exact False.elim (test_not_zero p hp a b hab ha A B hk0 hAB hA)
    · have hk1 : (A * a + B * b) ^ 2 = (p : ℤ) ^ 2 := by rw [hk]; ring
      have : (A * b - B * a) ^ 2 = 0 := by linarith [hbrahma1, hk1]
      have : A * b = B * a := by
        have := sq_eq_zero_iff.mp this
        linarith
      have hid : A ^ 2 * (p : ℤ) = a ^ 2 * (p : ℤ) := by
        calc A ^ 2 * (p : ℤ) = A ^ 2 * (a ^ 2 + b ^ 2) := by rw [hab]
        _ = A ^ 2 * a ^ 2 + (A * b) ^ 2 := by ring
        _ = A ^ 2 * a ^ 2 + (B * a) ^ 2 := by rw [this]
        _ = (A ^ 2 + B ^ 2) * a ^ 2 := by ring
        _ = (p : ℤ) * a ^ 2 := by rw [hAB]
        _ = a ^ 2 * (p : ℤ) := by ring
      exact mul_right_cancel₀ hp0 hid
  · rcases h2 with ⟨k, hk⟩
    have hk_sq : (p : ℤ) ^ 2 * k ^ 2 ≤ (p : ℤ) ^ 2 := by
      calc (p : ℤ) ^ 2 * k ^ 2 = (p * k) ^ 2 := by ring
      _ = (A * a - B * b) ^ 2 := by rw [hk]
      _ ≤ (A * a - B * b) ^ 2 + (A * b + B * a) ^ 2 := by
        have : (A * b + B * a) ^ 2 ≥ 0 := sq_nonneg _
        linarith
      _ = (p : ℤ) ^ 2 := hbrahma2
    rcases test_k_bounds p k hk_sq with rfl | rfl | rfl
    · have hk1 : (A * a - B * b) ^ 2 = (p : ℤ) ^ 2 := by rw [hk]; ring
      have : (A * b + B * a) ^ 2 = 0 := by linarith [hbrahma2, hk1]
      have : A * b = - (B * a) := by
        have := sq_eq_zero_iff.mp this
        linarith
      have hid : A ^ 2 * (p : ℤ) = a ^ 2 * (p : ℤ) := by
        calc A ^ 2 * (p : ℤ) = A ^ 2 * (a ^ 2 + b ^ 2) := by rw [hab]
        _ = A ^ 2 * a ^ 2 + (A * b) ^ 2 := by ring
        _ = A ^ 2 * a ^ 2 + (- (B * a)) ^ 2 := by rw [this]
        _ = (A ^ 2 + B ^ 2) * a ^ 2 := by ring
        _ = (p : ℤ) * a ^ 2 := by rw [hAB]
        _ = a ^ 2 * (p : ℤ) := by ring
      exact mul_right_cancel₀ hp0 hid
    · have hk0 : A * a - B * b = 0 := by rw [hk, mul_zero]
      have hzero : A * a + (-B) * b = 0 := by linear_combination hk0
      have hAnB : A ^ 2 + (-B) ^ 2 = (p : ℤ) := by
        have : (-B) ^ 2 = B ^ 2 := by ring
        rw [this, hAB]
      exact False.elim (test_not_zero p hp a b hab ha A (-B) hzero hAnB hA)
    · have hk1 : (A * a - B * b) ^ 2 = (p : ℤ) ^ 2 := by rw [hk]; ring
      have : (A * b + B * a) ^ 2 = 0 := by linarith [hbrahma2, hk1]
      have : A * b = - (B * a) := by
        have := sq_eq_zero_iff.mp this
        linarith
      have hid : A ^ 2 * (p : ℤ) = a ^ 2 * (p : ℤ) := by
        calc A ^ 2 * (p : ℤ) = A ^ 2 * (a ^ 2 + b ^ 2) := by rw [hab]
        _ = A ^ 2 * a ^ 2 + (A * b) ^ 2 := by ring
        _ = A ^ 2 * a ^ 2 + (- (B * a)) ^ 2 := by rw [this]
        _ = (A ^ 2 + B ^ 2) * a ^ 2 := by ring
        _ = (p : ℤ) * a ^ 2 := by rw [hAB]
        _ = a ^ 2 * (p : ℤ) := by ring
      exact mul_right_cancel₀ hp0 hid

theorem csum_sq_of_sq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b c : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 2 = 1) (hc : legendreSym p c = 1) :
    csum p c ^ 2 = 4 * a ^ 2 := by
  have hp2 : p ≠ 2 := by rintro rfl; norm_num at hp
  obtain ⟨r, hr⟩ := exists_nonsquare p hp2
  have h_add := csum_sq_add_sq p hp 1 r (by rw [legendreSym.at_one]) hr
  set S₁ := csum p 1
  set R₁ := csum p r
  have h_mod8 := csum_one_mod8_helper p hp
  have hS_mod8 : S₁ % 8 = 2 ∨ S₁ % 8 = 6 := by
    rw [h_mod8]
    split_ifs <;> [left; right] <;> rfl
  have hS_even : 2 ∣ S₁ := by
    have : S₁ % 2 = 0 := by
      rcases hS_mod8 with h1 | h2 <;> omega
    exact Int.dvd_of_emod_eq_zero this
  have hR_even : 2 ∣ R₁ := test_B_div S₁ R₁ p h_add hS_even
  obtain ⟨A, hA_eq⟩ := hS_even
  obtain ⟨B, hB_eq⟩ := hR_even
  have hA_odd : A % 2 = 1 := by
    have : A = S₁ / 2 := by omega
    rw [this]
    exact test_A_odd S₁ hS_mod8
  have hAB : A ^ 2 + B ^ 2 = (p : ℤ) := by
    have : 4 * (A ^ 2 + B ^ 2) = 4 * (p : ℤ) := by
      calc 4 * (A ^ 2 + B ^ 2) = (2 * A) ^ 2 + (2 * B) ^ 2 := by ring
      _ = S₁ ^ 2 + R₁ ^ 2 := by rw [← hA_eq, ← hB_eq]
      _ = 4 * (p : ℤ) := h_add
    linarith
  have hA2 : A ^ 2 = a ^ 2 := sq_eq_sq_of_prime_sum_two_squares p hp a b A B hab hAB ha hA_odd
  have hS_sq : S₁ ^ 2 = 4 * a ^ 2 := by
    calc S₁ ^ 2 = (2 * A) ^ 2 := by rw [← hA_eq]
    _ = 4 * A ^ 2 := by ring
    _ = 4 * a ^ 2 := by rw [hA2]
  have hc0 : (c : ZMod p) ≠ 0 := by
    intro hz
    have := legendreSym_eq_zero_of_cast_eq_zero p c hz
    rw [hc] at this
    contradiction
  have hc_sq : IsSquare (c : ZMod p) := by
    have hchi : χ p (c : ZMod p) = 1 := by
      dsimp [χ]
      rw [legendreSym_cast_zmod, hc]
    exact (χ_eq_one_iff p hc0).mp hchi
  have h1_sq : IsSquare (1 : ZMod p) := ⟨1, (mul_one 1).symm⟩
  have h1_0 : (1 : ZMod p) ≠ 0 := by
    intro hz
    have : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast hz
    have : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp this
    have : p ≤ 1 := Nat.le_of_dvd (by decide) this
    have : p ≥ 2 := (Fact.out : p.Prime).two_le
    omega
  have heq_S : (S p (c : ZMod p)) ^ 2 = (S p 1) ^ 2 :=
    S_sq_eq_of_isSquare p 1 (c : ZMod p) h1_sq h1_0 hc_sq hc0
  have h1cast : ((1 : ℤ) : ZMod p) = (1 : ZMod p) := by push_cast; rfl
  rw [csum_eq_S p c, heq_S, ← h1cast, ← csum_eq_S p 1]
  exact hS_sq

theorem csum_one_emod (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) :
    csum p 1 % 8 = if p % 8 = 5 then 2 else 6 :=
  csum_one_mod8_helper p hp

lemma disambiguate_sign (p : ℕ) (hp : p % 4 = 1) (a : ℤ) (ha : a % 4 = 1)
    (S : ℤ) (hS_sq : S ^ 2 = 4 * a ^ 2)
    (hS_mod8 : S % 8 = if p % 8 = 5 then 2 else 6) :
    S = -2 * (-1 : ℤ) ^ (p / 4) * a := by
  have hS_or : S = 2 * a ∨ S = -2 * a := by
    have : (S - 2 * a) * (S + 2 * a) = 0 := by
      calc (S - 2 * a) * (S + 2 * a) = S ^ 2 - 4 * a ^ 2 := by ring
      _ = 0 := by linarith [hS_sq]
    cases mul_eq_zero.mp this with
    | inl h => left; linarith
    | inr h => right; linarith
  have h2a_mod : (2 * a) % 8 = 2 := by omega
  have hn2a_mod : (-2 * a) % 8 = 6 := by omega
  have hp8 : p % 8 = 1 ∨ p % 8 = 5 := by omega
  rcases hp8 with h1 | h5
  · have hp4_even : Even (p / 4) := by
      use (p / 8)
      omega
    have hpow : (-1 : ℤ) ^ (p / 4) = 1 := Even.neg_one_pow hp4_even
    have hS_mod : S % 8 = 6 := by
      have : ¬(p % 8 = 5) := by omega
      rw [hS_mod8]
      simp [this]
    rcases hS_or with h | h
    · exfalso
      rw [h, h2a_mod] at hS_mod
      revert hS_mod
      decide
    · rw [h, hpow]
      ring
  · have hp4_odd : Odd (p / 4) := by
      use (p / 8)
      omega
    have hpow : (-1 : ℤ) ^ (p / 4) = -1 := Odd.neg_one_pow hp4_odd
    have hS_mod : S % 8 = 2 := by
      rw [hS_mod8]
      simp [h5]
    rcases hS_or with h | h
    · rw [h, hpow]
      ring
    · exfalso
      rw [h, hn2a_mod] at hS_mod
      revert hS_mod
      decide

lemma csum_one_eq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    csum p 1 = - 2 * (-1 : ℤ) ^ (p / 4) * a := by
  have ha2 : a % 2 = 1 := by omega
  have h1 : legendreSym p 1 = 1 := legendreSym.at_one p
  have hsq := csum_sq_of_sq p hp a b 1 hab ha2 h1
  have hmod8 := csum_one_emod p hp
  exact disambiguate_sign p hp a ha (csum p 1) hsq hmod8

lemma div_dvd_range (p : ℕ) (hp : p % 4 = 1) (hp5 : p ≥ 5) (k : ℕ) (hk : k ≤ p / 2) :
    (p - 1 ∣ 2 * k + p / 2) ↔ k = p / 4 := by
  have hm : p / 2 = 2 * (p / 4) := by omega
  have hp1 : p - 1 = 4 * (p / 4) := by omega
  set q := p / 4
  have hq : q ≥ 1 := by omega
  have hkq : k ≤ 2 * q := by omega
  constructor
  · intro ⟨c, hc⟩
    have h1 : 2 * k + 2 * q = (4 * q) * c := by
      rw [← hm, ← hp1]
      exact hc
    have hc_ge : c ≥ 1 := by
      by_contra!
      interval_cases c
      omega
    have hc_le : c ≤ 1 := by
      by_contra!
      have : 4 * q * c ≥ 4 * q * 2 := by nlinarith
      nlinarith
    have hc1 : c = 1 := by omega
    subst hc1
    omega
  · rintro rfl
    use 1
    omega

lemma sum_pow_zmod (p : ℕ) [Fact p.Prime] (N : ℕ) (hN : N > 0) :
    (∑ x : ZMod p, x ^ N) = if (p - 1) ∣ N then (-1 : ZMod p) else 0 := by
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have h0 : (0 : ZMod p) ∈ (Finset.univ : Finset (ZMod p)) := Finset.mem_univ 0
  have hsplit := Finset.sum_erase_add (Finset.univ : Finset (ZMod p)) (fun x => x ^ N) h0
  rw [zero_pow (by omega), add_zero] at hsplit
  rw [← hsplit]
  have hequiv : (∑ x ∈ Finset.univ.erase (0 : ZMod p), x ^ N) = ∑ u : (ZMod p)ˣ, (u : ZMod p) ^ N := by
    apply Finset.sum_bij (fun (x : ZMod p) hx => Units.mk0 x (Finset.mem_erase.mp hx).1)
    · intro x hx
      exact Finset.mem_univ _
    · intro x₁ hx₁ x₂ h₂ h
      exact congrArg Units.val h
    · intro u hu
      refine ⟨u.val, ?_, ?_⟩
      · rw [Finset.mem_erase]
        exact ⟨u.ne_zero, Finset.mem_univ _⟩
      · exact Units.ext rfl
    · intro x hx
      rfl
  rw [hequiv]
  have hsum := FiniteField.sum_pow_units (ZMod p) N
  rw [ZMod.card] at hsum
  exact hsum

lemma sum_range_single {α : Type*} [AddCommMonoid α] (n : ℕ) (k : ℕ) (hk : k < n) (f : ℕ → α)
    (h_zero : ∀ j ∈ Finset.range n, j ≠ k → f j = 0) :
    ∑ j ∈ Finset.range n, f j = f k := by
  have hk_mem : k ∈ Finset.range n := Finset.mem_range.mpr hk
  have hsplit := Finset.sum_erase_add (Finset.range n) f hk_mem
  have h0 : ∑ j ∈ (Finset.range n).erase k, f j = 0 := by
    apply Finset.sum_eq_zero
    intro j hj
    rw [Finset.mem_erase] at hj
    exact h_zero j hj.2 hj.1
  rw [h0, zero_add] at hsplit
  exact hsplit.symm

lemma poly_identity (p : ℕ) [Fact p.Prime] (hp : p % 4 = 1) (hp5 : p ≥ 5) :
    (∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2)) =
      - (-1 : ZMod p) ^ (p / 4) * ((Nat.choose (p / 2) (p / 4) : ℕ) : ZMod p) := by
  let m := p / 2
  have hm_pos : m > 0 := by omega
  have h_binom : ∀ x : ZMod p, (x ^ 3 - x) ^ m =
      ∑ k ∈ Finset.range (m + 1), (-1 : ZMod p) ^ (m - k) * ((m.choose k : ℕ) : ZMod p) * x ^ (2 * k + m) := by
    intro x
    have hid : x ^ 3 - x = x * (x ^ 2 + (-1)) := by ring
    rw [hid, mul_pow]
    have h_add := add_pow (x ^ 2) (-1 : ZMod p) m
    rw [h_add, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k hk
    have : (x ^ 2) ^ k = x ^ (2 * k) := by rw [← pow_mul]
    rw [this]
    ring
  have h_sum : (∑ x : ZMod p, (x ^ 3 - x) ^ m) =
      ∑ k ∈ Finset.range (m + 1), (-1 : ZMod p) ^ (m - k) * ((m.choose k : ℕ) : ZMod p) * ∑ x : ZMod p, x ^ (2 * k + m) := by
    simp_rw [h_binom]
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro k hk
    rw [← Finset.mul_sum]
  rw [h_sum]
  let term := fun k => (-1 : ZMod p) ^ (m - k) * ((m.choose k : ℕ) : ZMod p) * ∑ x : ZMod p, x ^ (2 * k + m)
  have h_term_zero : ∀ k ∈ Finset.range (m + 1), k ≠ p / 4 → term k = 0 := by
    intro k hk hne
    rw [Finset.mem_range] at hk
    dsimp [term]
    have hk_le : k ≤ p / 2 := by omega
    have hN_pos : 2 * k + m > 0 := by omega
    rw [sum_pow_zmod p (2 * k + m) hN_pos]
    have h_not_dvd : ¬(p - 1 ∣ 2 * k + m) := by
      intro hdvd
      have : p - 1 ∣ 2 * k + p / 2 := hdvd
      have := (div_dvd_range p hp hp5 k hk_le).mp this
      exact hne this
    simp only [if_neg h_not_dvd, mul_zero]
  have hk_lt : p / 4 < m + 1 := by omega
  have h_single := sum_range_single (m + 1) (p / 4) hk_lt term h_term_zero
  rw [h_single]
  dsimp [term]
  have hk_le : p / 4 ≤ p / 2 := by omega
  have hN_pos : 2 * (p / 4) + m > 0 := by omega
  rw [sum_pow_zmod p (2 * (p / 4) + m) hN_pos]
  have h_dvd : p - 1 ∣ 2 * (p / 4) + m := by
    have : p - 1 ∣ 2 * (p / 4) + p / 2 := (div_dvd_range p hp hp5 (p / 4) hk_le).mpr rfl
    exact this
  simp only [if_pos h_dvd]
  have hm_sub : m - p / 4 = p / 4 := by omega
  rw [hm_sub]
  ring

theorem choose_modEq (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    Int.ModEq (p : Int) ((Nat.choose (p / 2) (p / 4) : Nat) : Int) (2 * a) := by
  have hp5 : p ≥ 5 := p_ge_five p hp
  have h_csum_eq := csum_one_eq p hp a b hab ha
  have h_csum_cast : ((csum p 1 : ℤ) : ZMod p) = -2 * (-1 : ZMod p) ^ (p / 4) * (a : ZMod p) := by
    have hcast := congrArg (fun (x : ℤ) => (x : ZMod p)) h_csum_eq
    push_cast at hcast
    exact hcast
  rw [csum_eq_S p 1] at h_csum_cast
  have h1cast : ((1 : ℤ) : ZMod p) = (1 : ZMod p) := by push_cast; rfl
  rw [h1cast] at h_csum_cast
  have hS_1 : S p (1 : ZMod p) = ∑ x : ZMod p, χ p (x ^ 3 - x) := by
    dsimp [S]
    apply Finset.sum_congr rfl
    intro x _
    congr 2
    ring
  rw [hS_1] at h_csum_cast
  have h_poly_eval : ((∑ x : ZMod p, χ p (x ^ 3 - x) : ℤ) : ZMod p) =
      ∑ x : ZMod p, (x ^ 3 - x) ^ (p / 2) := by
    push_cast
    apply Finset.sum_congr rfl
    intro x _
    dsimp [χ]
    have h := legendreSym.eq_pow p (x ^ 3 - x).val
    have hcast : (((x ^ 3 - x).val : ℤ) : ZMod p) = x ^ 3 - x := by
      simp only [Int.cast_natCast, ZMod.natCast_zmod_val]
    rw [hcast] at h
    exact h
  rw [h_poly_eval, poly_identity p hp hp5] at h_csum_cast
  have heq : - (-1 : ZMod p) ^ (p / 4) * ((Nat.choose (p / 2) (p / 4) : ℕ) : ZMod p) =
      -2 * (-1 : ZMod p) ^ (p / 4) * (a : ZMod p) := h_csum_cast
  have hunit : (-1 : ZMod p) ^ (p / 4) ≠ 0 := by
    have : (-1 : ZMod p) ≠ 0 := by
      intro hz
      have : (1 : ZMod p) = 0 := neg_eq_zero.mp hz
      have h3 : ((1 : ℕ) : ZMod p) = 0 := by exact_mod_cast this
      have h4 : p ∣ 1 := (CharP.cast_eq_zero_iff (ZMod p) p 1).mp h3
      have : p ≤ 1 := Nat.le_of_dvd (by decide) h4
      have : p ≥ 2 := (Fact.out : p.Prime).two_le
      omega
    exact pow_ne_zero _ this
  have hunit' : - (-1 : ZMod p) ^ (p / 4) ≠ 0 := neg_ne_zero.mpr hunit
  have heq' : - (-1 : ZMod p) ^ (p / 4) * ((Nat.choose (p / 2) (p / 4) : ℕ) : ZMod p) =
      - (-1 : ZMod p) ^ (p / 4) * (2 * (a : ZMod p)) := by
    calc - (-1 : ZMod p) ^ (p / 4) * ((Nat.choose (p / 2) (p / 4) : ℕ) : ZMod p)
      _ = -2 * (-1 : ZMod p) ^ (p / 4) * (a : ZMod p) := heq
      _ = - (-1 : ZMod p) ^ (p / 4) * (2 * (a : ZMod p)) := by ring
  have hcancel := mul_left_cancel₀ hunit' heq'
  rw [← ZMod.intCast_eq_intCast_iff]
  push_cast
  exact hcancel

lemma card_fiber_curve (p : ℕ) [NeZero p] (x : ZMod p) :
    {q ∈ (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)) | q.1 = x}.card =
    {y : ZMod p | y ^ 2 = x ^ 3 - x}.toFinset.card := by
  apply Finset.card_bij (fun q _ => q.2)
  · intro q hq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq
    simp only [Set.mem_toFinset, Set.mem_setOf_eq]
    rw [← hq.2]
    exact hq.1
  · intro q₁ hq₁ q₂ hq₂ heq
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hq₁ hq₂
    ext
    · rw [hq₁.2, hq₂.2]
    · exact heq
  · intro y hy
    simp only [Set.mem_toFinset, Set.mem_setOf_eq] at hy
    refine ⟨(x, y), ?_, rfl⟩
    simp [hy]

theorem card_curve (p : Nat) [Fact p.Prime] (hp : p % 4 = 1) (a b : Int)
    (hab : a ^ 2 + b ^ 2 = (p : Int)) (ha : a % 4 = 1) :
    ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card : Int) =
      (p : Int) - 2 * (-1) ^ (p / 4) * a := by
  have hp2 : p ≠ 2 := by rintro rfl; norm_num at hp
  have : NeZero p := ⟨(Fact.out : p.Prime).ne_zero⟩
  have hequiv : (Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card =
      ∑ x : ZMod p, {y : ZMod p | y ^ 2 = x ^ 3 - x}.toFinset.card := by
    have hfib := (Finset.card_eq_sum_card_fiberwise
      (f := fun q : Prod (ZMod p) (ZMod p) => q.1)
      (s := Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1))
      (t := Finset.univ)
      (fun _ _ => Finset.mem_univ _)).symm
    rw [← hfib]
    apply Finset.sum_congr rfl
    intro x _
    exact card_fiber_curve p x
  have hterm : ∀ x : ZMod p, ({y : ZMod p | y ^ 2 = x ^ 3 - x}.toFinset.card : ℤ) =
      legendreSym p (x ^ 3 - x).val + 1 := by
    intro x
    have hsq := legendreSym.card_sqrts p hp2 (x ^ 3 - x).val
    have hcast : (((x ^ 3 - x).val : ℤ) : ZMod p) = x ^ 3 - x := by
      simp only [Int.cast_natCast, ZMod.natCast_zmod_val]
    rw [hcast] at hsq
    exact hsq
  have hsum_int : ((Finset.univ.filter (fun q : Prod (ZMod p) (ZMod p) => q.2 ^ 2 = q.1 ^ 3 - q.1)).card : ℤ) =
      (p : ℤ) + ∑ x : ZMod p, legendreSym p (x ^ 3 - x).val := by
    push_cast [hequiv]
    simp_rw [hterm, Finset.sum_add_distrib]
    simp only [Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul, mul_one]
    ring
  have hS_1 : (∑ x : ZMod p, legendreSym p (x ^ 3 - x).val) = csum p 1 := by
    rw [csum_eq_S p 1]
    have h1cast : ((1 : ℤ) : ZMod p) = (1 : ZMod p) := by push_cast; rfl
    rw [h1cast]
    dsimp [S, χ]
    apply Finset.sum_congr rfl
    intro x _
    have : x ^ 3 - 1 * x = x ^ 3 - x := by ring
    rw [this]
  rw [hsum_int, hS_1, csum_one_eq p hp a b hab ha]
  ring

end TuringTask
