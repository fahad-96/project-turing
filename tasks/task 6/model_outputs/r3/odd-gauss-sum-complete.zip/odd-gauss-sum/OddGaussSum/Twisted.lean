import OddGaussSum.Determinant

open scoped BigOperators ComplexConjugate

namespace OddGaussSum

noncomputable section

def twistedFourierMatrix (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) :
    Matrix (ZMod n) (ZMod n) ℂ :=
  fun i j => ZMod.stdAddChar ((u : ZMod n) * i * j)

def twistedNormalizedFourierMatrix (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) :
    Matrix (ZMod n) (ZMod n) ℂ :=
  ((Real.sqrt n : ℂ)⁻¹) • twistedFourierMatrix n u

def twistedQuadraticSumZMod (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) : ℂ :=
  ∑ x : ZMod n, ZMod.stdAddChar ((u : ZMod n) * x ^ 2)

theorem twistedFourierMatrix_sq (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) :
    twistedFourierMatrix n u * twistedFourierMatrix n u =
      (n : ℂ) • negMatrix n := by
  ext i k
  rw [Matrix.mul_apply]
  have hsum := AddChar.sum_mulShift
    (ψ := ZMod.stdAddChar) ((u : ZMod n) * (i + k))
    (ZMod.isPrimitive_stdAddChar n)
  simp only [twistedFourierMatrix] at hsum ⊢
  rw [show (∑ x : ZMod n,
      ZMod.stdAddChar ((u : ZMod n) * i * x) *
        ZMod.stdAddChar ((u : ZMod n) * x * k)) =
      ∑ x : ZMod n, ZMod.stdAddChar
        (x * ((u : ZMod n) * (i + k))) by
    apply Finset.sum_congr rfl
    intro x _
    rw [← AddChar.map_add_eq_mul]
    congr 2 <;> ring]
  change (∑ x : ZMod n,
      ZMod.stdAddChar (x * ((u : ZMod n) * (i + k)))) =
    (n : ℂ) * negMatrix n i k
  rw [show (∑ x : ZMod n,
      ZMod.stdAddChar (x * ((u : ZMod n) * (i + k)))) =
      (if (u : ZMod n) * (i + k) = 0 then (n : ℂ) else 0) by
    simpa [ZMod.card] using hsum]
  have hu : IsUnit (u : ZMod n) := u.isUnit
  have hz : (u : ZMod n) * (i + k) = 0 ↔ i + k = 0 := by
    constructor
    · intro h
      apply hu.mul_left_cancel
      simpa using h
    · rintro h
      simp [h]
  simp only [hz, negMatrix]
  by_cases h : i + k = 0
  · have hik : i = -k := eq_neg_iff_add_eq_zero.2 h
    simp [h, hik]
  · have hik : i ≠ -k := fun hik => h (eq_neg_iff_add_eq_zero.1 hik)
    simp [h, hik]

theorem twistedNormalizedFourierMatrix_sq (n : ℕ) [NeZero n]
    (u : (ZMod n)ˣ) :
    twistedNormalizedFourierMatrix n u * twistedNormalizedFourierMatrix n u =
      negMatrix n := by
  have hn : 0 < n := Nat.pos_of_ne_zero (NeZero.ne n)
  have hsqrt : (Real.sqrt n : ℂ) ^ 2 = n := by
    exact_mod_cast Real.sq_sqrt (by positivity : (0 : ℝ) ≤ n)
  rw [twistedNormalizedFourierMatrix, Matrix.smul_mul, Matrix.mul_smul,
    twistedFourierMatrix_sq, smul_smul]
  have hsqrt0 : (Real.sqrt n : ℂ) ≠ 0 := by
    exact_mod_cast (ne_of_gt (Real.sqrt_pos.2 (by positivity : (0 : ℝ) < n)))
  have hc : (Real.sqrt n : ℂ)⁻¹ * (Real.sqrt n : ℂ)⁻¹ * (n : ℂ) = 1 := by
    rw [← hsqrt]
    field_simp
  rw [smul_smul, hc, one_smul]

theorem twistedNormalizedFourierMatrix_fourth (n : ℕ) [NeZero n]
    (u : (ZMod n)ˣ) : twistedNormalizedFourierMatrix n u ^ 4 = 1 := by
  rw [show twistedNormalizedFourierMatrix n u ^ 4 =
      (twistedNormalizedFourierMatrix n u * twistedNormalizedFourierMatrix n u) *
        (twistedNormalizedFourierMatrix n u * twistedNormalizedFourierMatrix n u) by
    noncomm_ring,
    twistedNormalizedFourierMatrix_sq, negMatrix_sq]

theorem trace_twistedFourierMatrix (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) :
    (twistedFourierMatrix n u).trace = twistedQuadraticSumZMod n u := by
  simp only [Matrix.trace, twistedFourierMatrix, twistedQuadraticSumZMod]
  apply Finset.sum_congr rfl
  intro x _
  change ZMod.stdAddChar ((u : ZMod n) * x * x) = _
  congr 1
  simp [pow_two, mul_assoc]

theorem twistedQuadraticSumZMod_norm (n : ℕ) [NeZero n] (hodd : Odd n)
    (u : (ZMod n)ˣ) : ‖twistedQuadraticSumZMod n u‖ = Real.sqrt n := by
  have hcop : Nat.Coprime 2 n := (Nat.coprime_comm.mp hodd.coprime_two_right)
  have htwo : IsUnit (2 : ZMod n) := (ZMod.isUnit_iff_coprime 2 n).2 hcop
  have hu : IsUnit (u : ZMod n) := u.isUnit
  have hua : IsUnit ((u : ZMod n) * 2) := hu.mul htwo
  have hstar (z : ZMod n) : (starRingEnd ℂ) (ZMod.stdAddChar z) =
      ZMod.stdAddChar (-z) := by
    rw [AddChar.map_neg_eq_inv, AddChar.inv_apply_eq_conj]
  have htranslate (x : ZMod n) :
      (∑ y : ZMod n, ZMod.stdAddChar
        ((u : ZMod n) * y ^ 2 - (u : ZMod n) * x ^ 2)) =
      ∑ v : ZMod n, ZMod.stdAddChar
        ((u : ZMod n) * (v + x) ^ 2 - (u : ZMod n) * x ^ 2) := by
    symm
    simpa using Equiv.sum_comp (Equiv.addRight x)
      (fun y : ZMod n => ZMod.stdAddChar
        ((u : ZMod n) * y ^ 2 - (u : ZMod n) * x ^ 2))
  have hinner (v : ZMod n) :
      (∑ x : ZMod n, ZMod.stdAddChar
        ((u : ZMod n) * (v + x) ^ 2 - (u : ZMod n) * x ^ 2)) =
      if v = 0 then (n : ℂ) else 0 := by
    calc
      _ = ZMod.stdAddChar ((u : ZMod n) * v ^ 2) *
          ∑ x : ZMod n, ZMod.stdAddChar (x * ((u : ZMod n) * 2 * v)) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro x _
        rw [← AddChar.map_add_eq_mul]
        congr 1
        ring
      _ = ZMod.stdAddChar ((u : ZMod n) * v ^ 2) *
          (if (u : ZMod n) * 2 * v = 0 then (n : ℂ) else 0) := by
        rw [AddChar.sum_mulShift ((u : ZMod n) * 2 * v)
          (ZMod.isPrimitive_stdAddChar n)]
        simp [ZMod.card]
      _ = if v = 0 then (n : ℂ) else 0 := by
        have hv : (u : ZMod n) * 2 * v = 0 ↔ v = 0 := by
          constructor
          · intro h
            apply hua.mul_left_cancel
            simpa using h
          · rintro rfl
            simp
        simp only [hv]
        split_ifs with h
        · subst v; simp
        · simp
  have hnormSq : Complex.normSq (twistedQuadraticSumZMod n u) = n := by
    apply Complex.ofReal_injective
    rw [Complex.normSq_eq_conj_mul_self]
    change star (twistedQuadraticSumZMod n u) * twistedQuadraticSumZMod n u = (n : ℂ)
    rw [twistedQuadraticSumZMod, Complex.star_def,
      map_sum (starRingEnd ℂ)
        (fun x : ZMod n => ZMod.stdAddChar ((u : ZMod n) * x ^ 2)) Finset.univ]
    simp_rw [hstar]
    rw [Finset.sum_mul]
    simp_rw [Finset.mul_sum]
    calc
      (∑ x : ZMod n, ∑ y : ZMod n,
          ZMod.stdAddChar (-((u : ZMod n) * x ^ 2)) *
            ZMod.stdAddChar ((u : ZMod n) * y ^ 2)) =
          ∑ x : ZMod n, ∑ y : ZMod n, ZMod.stdAddChar
            ((u : ZMod n) * y ^ 2 - (u : ZMod n) * x ^ 2) := by
        apply Finset.sum_congr rfl
        intro x _
        apply Finset.sum_congr rfl
        intro y _
        rw [← AddChar.map_add_eq_mul]
        congr 1
        ring
      _ = ∑ x : ZMod n, ∑ v : ZMod n, ZMod.stdAddChar
          ((u : ZMod n) * (v + x) ^ 2 - (u : ZMod n) * x ^ 2) := by
        apply Finset.sum_congr rfl
        intro x _
        exact htranslate x
      _ = ∑ v : ZMod n, ∑ x : ZMod n, ZMod.stdAddChar
          ((u : ZMod n) * (v + x) ^ 2 - (u : ZMod n) * x ^ 2) := by
        rw [Finset.sum_comm]
      _ = ∑ v : ZMod n, if v = 0 then (n : ℂ) else 0 := by
        apply Finset.sum_congr rfl
        intro v _
        exact hinner v
      _ = (n : ℂ) := by simp
  rw [Complex.norm_def, hnormSq]

theorem twistedNormalized_trace_norm (n : ℕ) [NeZero n] (hodd : Odd n)
    (u : (ZMod n)ˣ) : ‖(twistedNormalizedFourierMatrix n u).trace‖ = 1 := by
  have hsqrt_pos : 0 < Real.sqrt n := Real.sqrt_pos.2 (by
    exact_mod_cast (Nat.pos_of_ne_zero (NeZero.ne n)) : (0 : ℝ) < n)
  rw [twistedNormalizedFourierMatrix, Matrix.trace_smul, norm_smul,
    trace_twistedFourierMatrix, twistedQuadraticSumZMod_norm n hodd u]
  simp [abs_of_pos hsqrt_pos, hsqrt_pos.ne']

theorem twistedNormalized_det (n : ℕ) [NeZero n] (u : (ZMod n)ˣ) :
    (twistedNormalizedFourierMatrix n u).det =
      ((Equiv.Perm.sign (Units.mulLeft u) : ℤˣ) : ℂ) *
        (normalizedFourierMatrix n).det := by
  let p : Equiv.Perm (ZMod n) := Units.mulLeft u
  have hm : twistedNormalizedFourierMatrix n u =
      Matrix.reindex p.symm (Equiv.refl (ZMod n)) (normalizedFourierMatrix n) := by
    ext i j
    simp [p, twistedNormalizedFourierMatrix, normalizedFourierMatrix,
      twistedFourierMatrix, fourierMatrix, Matrix.reindex_apply]
  rw [hm, Matrix.det_reindex]
  simp [p]

end

end OddGaussSum
