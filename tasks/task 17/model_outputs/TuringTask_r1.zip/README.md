# TuringTask

This Lean 4 project contains complete, verified proofs of the five theorems in `TuringTask/Basic.lean`.

## Environment Requirements

This project relies on the pre-installed, offline Lean 4 environment:
- Lean toolchain: `leanprover/lean4:v4.33.0-rc1`
- Mathlib commit: `9944fe2973b8dc0b86949101ed98232c07cd54a0` (located at `/opt/mathlib4`)

The local path dependency in `lakefile.toml` requires the supplied environment at `/opt/mathlib4`.

## Offline Build Instructions

To build the project offline using the supplied Lean/Mathlib environment:

```bash
# Initialize local package links if needed
lean-offline-init

# Build the project
lake build
```

Or verify the file directly:

```bash
lean TuringTask/Basic.lean
```

## Theorems Proved

1. `card_squarefree_sub_le`:
   $\forall N \ge 1, \left| Q(N) - \frac{6}{\pi^2} N \right| \le 3 \sqrt{N}$
2. `card_coprime_sub_le`:
   $\forall N \ge 1, \left| C(N) - \frac{6}{\pi^2} N^2 \right| \le 6 N (\log N + 1)$
3. `sum_totient_sub_le`:
   $\forall N \ge 1, \left| \sum_{n=1}^N \varphi(n) - \frac{3}{\pi^2} N^2 \right| \le 4 N (\log N + 1)$
4. `sum_totient_div_sub_le`:
   $\forall N \ge 1, \left| \sum_{n=1}^N \frac{\varphi(n)}{n} - \frac{6}{\pi^2} N \right| \le \log N + 2$
5. `tendsto_card_squarefree_div`:
   $Q(N) / N \to 6 / \pi^2$ as $N \to \infty$

All five theorems use strictly the standard Lean axioms: `propext`, `Classical.choice`, and `Quot.sound`.
