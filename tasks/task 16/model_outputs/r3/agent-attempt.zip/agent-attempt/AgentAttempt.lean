import Mathlib
import Mathlib.NumberTheory.Pell

namespace FibQuarticResearch

def lucas (n : ℕ) : ℤ := 2 * Int.fib (n + 1) - Int.fib n

theorem lucas_sq_sub_five_fib_sq (n : ℕ) :
    lucas n ^ 2 - 5 * (Nat.fib n : ℤ) ^ 2 = 4 * (-1 : ℤ) ^ n := by
  have h := Int.fib_add_sq_sub_fib_mul_fib_add_two_mul (n : ℤ) 1
  rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega] at h
  rw [show (n : ℤ) + 2 * 1 = ((n + 2 : ℕ) : ℤ) by omega] at h
  simp only [Int.fib_natCast, Int.fib_one, one_pow, Int.natAbs_natCast] at h
  have hrec : (Nat.fib (n + 2) : ℤ) =
      (Nat.fib n : ℤ) + Nat.fib (n + 1) := by
    rw [Nat.fib_add_two]
    omega
  rw [hrec] at h
  have hn : Int.fib (n + 1) = (Nat.fib (n + 1) : ℤ) := by
    rw [show (n : ℤ) + 1 = ((n + 1 : ℕ) : ℤ) by omega, Int.fib_natCast]
  have h0 : Int.fib n = (Nat.fib n : ℤ) := Int.fib_natCast n
  unfold lucas
  rw [hn, h0]
  nlinarith [h]

theorem pell_four_step (X Y X' Y' : ℤ)
    (hX : 2 * X' = Y - X) (hY : 2 * Y' = 5 * X - Y) :
    Y' ^ 2 - 5 * X' ^ 2 = -(Y ^ 2 - 5 * X ^ 2) := by
  have hX2 := congrArg (fun z : ℤ => z ^ 2) hX
  have hY2 := congrArg (fun z : ℤ => z ^ 2) hY
  nlinarith

def pocklingtonForm (a b : ℤ) : ℤ :=
  a ^ 4 - 6 * a ^ 2 * b ^ 2 + b ^ 4 + 2 * a * b * (a ^ 2 - b ^ 2)

theorem pocklingtonForm_eq_norm (a b : ℤ) :
    pocklingtonForm a b = (a ^ 2 + a * b - b ^ 2) ^ 2 - 5 * (a * b) ^ 2 := by
  unfold pocklingtonForm
  ring

theorem factor_plus_four (x y : ℤ) (h : y ^ 2 = 5 * x ^ 4 + 4) :
    (y - 2) * (y + 2) = 5 * x ^ 4 := by
  nlinarith

theorem consecutive_factor (u v k : ℤ) (hv : v = 2 * k + 1)
    (h : v ^ 2 = 20 * u ^ 4 + 1) : k * (k + 1) = 5 * u ^ 4 := by
  subst v
  nlinarith

end FibQuarticResearch
