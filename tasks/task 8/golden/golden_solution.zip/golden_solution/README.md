# Project Turing - Task 8 golden answer

Lean 4 project with complete proofs of five equidistribution statements for fractional parts of
polynomial sequences: the frequency of `{n^2 x}` in `[a, b)` tends to `b - a` uniformly in
`0 <= a <= b <= 1` (x irrational), the same limit for `{P(n)}` when the real polynomial `P` has
degree at least 1 and an irrational leading coefficient, the leading-digit frequencies of
`2^(n^2)`, the mean of `|sin(n^2)|`, and the mean of `cos(n^2 x)` for `x / pi` irrational. The
required file is `TuringTask/Basic.lean`.

## Pinned environment

- Lean toolchain: `leanprover/lean4:v4.33.0-rc1` (file `lean-toolchain`)
- Mathlib: the pinned checkout at `/opt/mathlib4`, commit `9944fe2973b8dc0b86949101ed98232c07cd54a0`
  (files `lakefile.toml` and `lake-manifest.json`; the other packages are the ones locked by
  that Mathlib commit)

## Build and check (offline, no edits needed)

    lake build
    lake env lean StatementAndAxiomsCheck.lean

If the environment requires it, run `lean-offline-init` first; it only links the locally
installed Mathlib dependencies into `.lake/packages` and downloads nothing.

The second command re-states the five theorems of the prompt, so it fails if any of them was
changed, and it prints the axioms used by each of the five theorems.

The seven source files form one import chain, so `lake build` compiles them one after the other.

## Files

- `TuringTask/Phase.lean`: the phase `ephase t = exp(2 pi i t)` and the differencing inequality
  for averages of complex numbers of modulus at most 1 (`tendsto_avg_zero_of_corr`)
- `TuringTask/PolySum.lean`: `(1/N) sum_(n<N) ephase(P(n)) -> 0` for a polynomial `P` with
  irrational leading coefficient (geometric sum for degree 1, induction on the degree)
- `TuringTask/Circle.lean`: averages of a continuous function on `AddCircle 1` tend to its
  integral (uniform approximation by finite Fourier sums)
- `TuringTask/Counting.lean`: frequencies of `fract (u n)` in intervals, their limit `b - a`,
  and the uniform version
- `TuringTask/LeadDigit.lean`: `log_10 2` is irrational; the leading decimal digit through the
  fractional part of `log_10`
- `TuringTask/Main.lean`: the applications and the five theorems under their own names
- `TuringTask/Basic.lean`: the required file; each theorem calls its proof
