import TuringTask.Rank

/-!
# The primitive part `psi n = ∏_{d ∣ n} F d ^ μ(n/d)`

`psi n` is a positive rational with `∏_{d ∣ n} psi d = F n`.  Its `p`-adic valuation is computed
from the exponent formulas of `Rank.lean` by Möbius inversion: for an odd prime `p` of rank `r`,
`v_p (psi n) = v_p (F r)` if `n = r`, `1` if `n = r p^j` (`j ≥ 1`), `0` otherwise; for `p = 2`
(rank 3) the values are `1, 2, 1` at `n = 3, 6, 3 * 2^a` (`a ≥ 2`) and `0` otherwise.
Hence `psi n` is a positive integer `Psi n`, and a prime factor of `Psi n` that divides an earlier
Fibonacci number is tightly constrained (`nonprim_odd`, `nonprim_two`).
-/

open scoped ArithmeticFunction.Moebius
open Finset ArithmeticFunction

namespace TuringTask

/-- The primitive part, as a rational number. -/
noncomputable def psi (n : ℕ) : ℚ :=
  ∏ x ∈ n.divisorsAntidiagonal, (Nat.fib x.2 : ℚ) ^ (μ x.1 : ℤ)

theorem snd_pos_of_mem_antidiag {n : ℕ} {x : ℕ × ℕ} (hx : x ∈ n.divisorsAntidiagonal) :
    0 < x.2 := by
  rw [Nat.mem_divisorsAntidiagonal] at hx
  rcases Nat.eq_zero_or_pos x.2 with h | h
  · rw [h, mul_zero] at hx
    exact absurd hx.1.symm hx.2
  · exact h

theorem fst_pos_of_mem_antidiag {n : ℕ} {x : ℕ × ℕ} (hx : x ∈ n.divisorsAntidiagonal) :
    0 < x.1 := by
  rw [Nat.mem_divisorsAntidiagonal] at hx
  rcases Nat.eq_zero_or_pos x.1 with h | h
  · rw [h, zero_mul] at hx
    exact absurd hx.1.symm hx.2
  · exact h

theorem psi_pos (n : ℕ) : 0 < psi n := by
  unfold psi
  apply Finset.prod_pos
  intro x hx
  exact zpow_pos (by exact_mod_cast fib_pos' (snd_pos_of_mem_antidiag hx)) _

theorem psi_ne_zero (n : ℕ) : psi n ≠ 0 := (psi_pos n).ne'

/-- `∏_{d ∣ n} psi d = F n`. -/
theorem prod_psi (n : ℕ) (hn : 0 < n) : ∏ d ∈ n.divisors, psi d = Nat.fib n := by
  have key := (prod_eq_iff_prod_pow_moebius_eq_of_nonzero (R := ℚ) (f := psi)
    (g := fun n => (Nat.fib n : ℚ)) (fun n _ => psi_ne_zero n)
    (fun n hn => by exact_mod_cast (fib_pos' hn).ne')).mpr
  exact key (fun n _ => rfl) n hn

/-! ### Valuations -/

theorem padicValRat_prod {ι : Type*} (s : Finset ι) (f : ι → ℚ) (hf : ∀ i ∈ s, f i ≠ 0)
    (p : ℕ) [Fact p.Prime] :
    padicValRat p (∏ i ∈ s, f i) = ∑ i ∈ s, padicValRat p (f i) := by
  induction s using Finset.cons_induction with
  | empty => simp
  | cons a s has ih =>
    rw [prod_cons, sum_cons, padicValRat.mul (hf a (mem_cons_self a s))
      (prod_ne_zero_iff.mpr fun i hi => hf i (mem_cons_of_mem hi)),
      ih fun i hi => hf i (mem_cons_of_mem hi)]

theorem padicValRat_psi (p : ℕ) [Fact p.Prime] (n : ℕ) :
    padicValRat p (psi n) =
      ∑ x ∈ n.divisorsAntidiagonal, (μ x.1 : ℤ) * (padicValNat p (Nat.fib x.2) : ℤ) := by
  unfold psi
  rw [padicValRat_prod _ _ (fun x hx => zpow_ne_zero _
    (by exact_mod_cast (fib_pos' (snd_pos_of_mem_antidiag hx)).ne'))]
  refine sum_congr rfl fun x _ => ?_
  rw [padicValRat.zpow, padicValRat.of_nat]

/-! ### Three Möbius inversions -/

open Classical in
/-- `lam p m = 1` if `m` is a positive power of `p`, and `0` otherwise. -/
noncomputable def lam (p m : ℕ) : ℤ := if ∃ j, 0 < j ∧ m = p ^ j then 1 else 0

theorem lam_nonneg (p m : ℕ) : 0 ≤ lam p m := by
  unfold lam; split_ifs <;> norm_num

theorem lam_le_one (p m : ℕ) : lam p m ≤ 1 := by
  unfold lam; split_ifs <;> norm_num

theorem lam_eq_one_iff (p m : ℕ) : lam p m = 1 ↔ ∃ j, 0 < j ∧ m = p ^ j := by
  unfold lam
  split_ifs with h
  · exact ⟨fun _ => h, fun _ => rfl⟩
  · exact ⟨fun h1 => absurd h1 (by norm_num), fun h1 => absurd h1 h⟩

theorem lam_one (p : ℕ) (hp : 1 < p) : lam p 1 = 0 := by
  unfold lam
  rw [if_neg]
  rintro ⟨j, hj, hj1⟩
  have := Nat.one_lt_pow hj.ne' hp
  omega

theorem sum_lam (p : ℕ) [hp : Fact p.Prime] (n : ℕ) (hn : 0 < n) :
    ∑ i ∈ n.divisors, lam p i = padicValNat p n := by
  classical
  have h1 : ∑ i ∈ n.divisors, lam p i =
      ((n.divisors.filter fun i => ∃ j, 0 < j ∧ i = p ^ j).card : ℤ) := by
    rw [card_filter]
    push_cast
    unfold lam
    rfl
  have h2 : (n.divisors.filter fun i => ∃ j, 0 < j ∧ i = p ^ j) =
      (Icc 1 (padicValNat p n)).image (fun j => p ^ j) := by
    ext i
    simp only [mem_filter, Nat.mem_divisors, mem_image, mem_Icc]
    constructor
    · rintro ⟨⟨hi, -⟩, j, hj, rfl⟩
      exact ⟨j, ⟨hj, (padicValNat_dvd_iff_le hn.ne').mp hi⟩, rfl⟩
    · rintro ⟨j, ⟨hj1, hj2⟩, rfl⟩
      exact ⟨⟨(padicValNat_dvd_iff_le hn.ne').mpr hj2, hn.ne'⟩, j, hj1, rfl⟩
  rw [h1, h2, card_image_of_injective _ (Nat.pow_right_injective hp.out.two_le)]
  simp

theorem moebius_sum_one (m : ℕ) (hm : 0 < m) :
    ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * 1 = if m = 1 then 1 else 0 := by
  have key := (sum_eq_iff_sum_mul_moebius_eq (R := ℤ) (f := fun n => if n = 1 then 1 else 0)
    (g := fun _ => 1)).mp
  refine key (fun n hn => ?_) m hm
  rw [sum_ite_eq']
  simp [hn.ne']

theorem moebius_sum_lam (p : ℕ) [Fact p.Prime] (m : ℕ) (hm : 0 < m) :
    ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * (padicValNat p x.2 : ℤ) = lam p m := by
  have key := (sum_eq_iff_sum_mul_moebius_eq (R := ℤ) (f := lam p)
    (g := fun n => (padicValNat p n : ℤ))).mp
  exact key (fun n hn => sum_lam p n hn) m hm

theorem moebius_sum_two (m : ℕ) (hm : 0 < m) :
    ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * (if 2 ∣ x.2 then 1 else 0) =
      if m = 2 then 1 else 0 := by
  have key := (sum_eq_iff_sum_mul_moebius_eq (R := ℤ) (f := fun n => if n = 2 then 1 else 0)
    (g := fun n => if 2 ∣ n then 1 else 0)).mp
  refine key (fun n hn => ?_) m hm
  rw [sum_ite_eq']
  simp [Nat.mem_divisors, hn.ne']

/-- The Möbius sum of a weight supported on the multiples of `r`. -/
theorem moebius_sum_rank (p : ℕ) [Fact p.Prime] (r : ℕ) (hr : 0 < r) (c κ : ℤ) (m : ℕ)
    (hm : 0 < m) :
    ∑ x ∈ (r * m).divisorsAntidiagonal, (μ x.1 : ℤ) *
      (if r ∣ x.2 then c + (padicValNat p (x.2 / r) : ℤ) + κ * (if 2 ∣ x.2 / r then 1 else 0)
        else 0) =
      c * (if m = 1 then 1 else 0) + lam p m + κ * (if m = 2 then 1 else 0) := by
  classical
  set g : ℕ → ℤ := fun e => c + (padicValNat p e : ℤ) + κ * (if 2 ∣ e then 1 else 0) with hg
  have h1 : ∑ x ∈ (r * m).divisorsAntidiagonal, (μ x.1 : ℤ) *
      (if r ∣ x.2 then g (x.2 / r) else 0) =
      ∑ d ∈ (r * m).divisors, (μ (r * m / d) : ℤ) * (if r ∣ d then g (d / r) else 0) :=
    Nat.sum_divisorsAntidiagonal' (fun a b => (μ a : ℤ) * (if r ∣ b then g (b / r) else 0))
  have h2 : ∑ d ∈ (r * m).divisors, (μ (r * m / d) : ℤ) * (if r ∣ d then g (d / r) else 0) =
      ∑ d ∈ (r * m).divisors.filter (fun d => r ∣ d), (μ (r * m / d) : ℤ) * g (d / r) := by
    rw [sum_filter]
    refine sum_congr rfl fun d _ => ?_
    split_ifs <;> simp
  have h3 : (r * m).divisors.filter (fun d => r ∣ d) = m.divisors.image (fun e => r * e) := by
    ext d
    simp only [mem_filter, Nat.mem_divisors, mem_image]
    constructor
    · rintro ⟨⟨hd, -⟩, e, rfl⟩
      exact ⟨e, ⟨(Nat.mul_dvd_mul_iff_left hr).mp hd, hm.ne'⟩, rfl⟩
    · rintro ⟨e, ⟨he, -⟩, rfl⟩
      exact ⟨⟨Nat.mul_dvd_mul_left r he, by positivity⟩, dvd_mul_right r e⟩
  have h4 : ∑ d ∈ m.divisors.image (fun e => r * e), (μ (r * m / d) : ℤ) * g (d / r) =
      ∑ e ∈ m.divisors, (μ (m / e) : ℤ) * g e := by
    rw [sum_image (fun a _ b _ hab => Nat.eq_of_mul_eq_mul_left hr hab)]
    refine sum_congr rfl fun e he => ?_
    rw [Nat.mul_div_mul_left _ _ hr, Nat.mul_div_cancel_left _ hr]
  have h5 : ∑ e ∈ m.divisors, (μ (m / e) : ℤ) * g e =
      ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * g x.2 :=
    (Nat.sum_divisorsAntidiagonal' (fun a b => (μ a : ℤ) * g b)).symm
  have h6 : ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * g x.2 =
      c * ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * 1
      + ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * (padicValNat p x.2 : ℤ)
      + κ * ∑ x ∈ m.divisorsAntidiagonal, (μ x.1 : ℤ) * (if 2 ∣ x.2 then 1 else 0) := by
    rw [mul_sum, mul_sum, ← sum_add_distrib, ← sum_add_distrib]
    refine sum_congr rfl fun x _ => ?_
    simp only [hg]
    ring
  rw [h1, h2, h3, h4, h5, h6, moebius_sum_one m hm, moebius_sum_lam p m hm, moebius_sum_two m hm]

/-! ### The valuation of `psi n` -/

theorem padicValRat_psi_odd (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) (h : HasRank p) (n : ℕ)
    (hn : 0 < n) :
    padicValRat p (psi n) =
      if rk p h ∣ n then
        (padicValNat p (Nat.fib (rk p h)) : ℤ) * (if n / rk p h = 1 then 1 else 0)
          + lam p (n / rk p h)
      else 0 := by
  rw [padicValRat_psi]
  by_cases hr : rk p h ∣ n
  · rw [if_pos hr]
    obtain ⟨m, rfl⟩ := hr
    have hm : 0 < m := by
      rcases Nat.eq_zero_or_pos m with h0 | h0
      · simp [h0] at hn
      · exact h0
    rw [Nat.mul_div_cancel_left _ (rk_pos p h)]
    have key := moebius_sum_rank p (rk p h) (rk_pos p h) (padicValNat p (Nat.fib (rk p h)) : ℤ) 0
      m hm
    simp only [zero_mul, add_zero] at key
    rw [← key]
    refine sum_congr rfl fun x hx => ?_
    congr 1
    rw [padicValNat_fib_eq p hp2 h x.2 (snd_pos_of_mem_antidiag hx)]
    split_ifs <;> (push_cast; try ring)
  · rw [if_neg hr]
    apply sum_eq_zero
    intro x hx
    have hx2 : x.2 ∣ n := (Nat.mem_divisors.mp (Nat.snd_mem_divisors_of_mem_antidiagonal hx)).1
    rw [padicValNat_fib_eq p hp2 h x.2 (snd_pos_of_mem_antidiag hx), if_neg]
    · simp
    · intro hd
      exact hr (hd.trans hx2)

theorem padicValRat_psi_two (n : ℕ) (hn : 0 < n) :
    padicValRat 2 (psi n) =
      if 3 ∣ n then (if n / 3 = 1 then 1 else 0) + lam 2 (n / 3) + (if n / 3 = 2 then 1 else 0)
      else 0 := by
  rw [padicValRat_psi]
  by_cases hr : 3 ∣ n
  · rw [if_pos hr]
    obtain ⟨m, rfl⟩ := hr
    have hm : 0 < m := by
      rcases Nat.eq_zero_or_pos m with h0 | h0
      · simp [h0] at hn
      · exact h0
    rw [Nat.mul_div_cancel_left _ (by norm_num : 0 < 3)]
    have key := moebius_sum_rank 2 3 (by norm_num) 1 1 m hm
    simp only [one_mul] at key
    rw [← key]
    refine sum_congr rfl fun x hx => ?_
    congr 1
    have hx2 : 0 < x.2 := snd_pos_of_mem_antidiag hx
    rw [padicValNat_two_fib x.2 hx2]
    by_cases h3 : 3 ∣ x.2
    · obtain ⟨e, he'⟩ := h3
      rw [he', if_pos (dvd_mul_right 3 e), if_pos (dvd_mul_right 3 e),
        Nat.mul_div_cancel_left _ (by norm_num : 0 < 3)]
      have he : 0 < e := by omega
      by_cases h2 : 2 ∣ e
      · rw [if_pos (by omega), if_pos h2]
        have : padicValNat 2 (3 * e) = padicValNat 2 e := by
          rw [padicValNat.mul (by norm_num) he.ne', padicValNat.eq_zero_of_not_dvd (by norm_num)]
          ring
        rw [this]; push_cast; try ring
      · rw [if_neg (by omega), if_neg h2, padicValNat.eq_zero_of_not_dvd h2]
        push_cast; try ring
    · rw [if_neg h3, if_neg h3]; simp
  · rw [if_neg hr]
    apply sum_eq_zero
    intro x hx
    have hx2 : x.2 ∣ n := (Nat.mem_divisors.mp (Nat.snd_mem_divisors_of_mem_antidiagonal hx)).1
    rw [padicValNat_two_fib x.2 (snd_pos_of_mem_antidiag hx), if_neg]
    · simp
    · intro hd
      exact hr (hd.trans hx2)

theorem padicValRat_psi_nonneg (p : ℕ) [hp : Fact p.Prime] (n : ℕ) (hn : 0 < n) :
    0 ≤ padicValRat p (psi n) := by
  by_cases hp2 : p = 2
  · subst hp2
    rw [padicValRat_psi_two n hn]
    have := lam_nonneg 2 (n / 3)
    split_ifs <;> omega
  · by_cases h : HasRank p
    · rw [padicValRat_psi_odd p hp2 h n hn]
      have := lam_nonneg p (n / rk p h)
      split_ifs <;> positivity
    · rw [padicValRat_psi]
      apply sum_nonneg
      intro x hx
      have : padicValNat p (Nat.fib x.2) = 0 := by
        apply padicValNat.eq_zero_of_not_dvd
        intro hd
        exact h ⟨x.2, snd_pos_of_mem_antidiag hx, hd⟩
      simp [this]

/-! ### `psi n` is a positive integer -/

theorem psi_den_eq_one (n : ℕ) (hn : 0 < n) : (psi n).den = 1 := by
  by_contra hden
  obtain ⟨p, hp, hpd⟩ := Nat.exists_prime_and_dvd hden
  haveI := Fact.mk hp
  have h1 := padicValRat_psi_nonneg p n hn
  rw [padicValRat_def] at h1
  have h2 : 1 ≤ padicValNat p (psi n).den := one_le_padicValNat_of_dvd (psi n).den_ne_zero hpd
  have h3 : padicValInt p (psi n).num = 0 := by
    unfold padicValInt
    apply padicValNat.eq_zero_of_not_dvd
    intro hnum
    have h4 := Nat.dvd_gcd hnum hpd
    rw [(psi n).reduced.gcd_eq_one] at h4
    exact hp.one_lt.ne' (Nat.dvd_one.mp h4)
  rw [h3] at h1
  omega

/-- The primitive part as a natural number. -/
noncomputable def Psi (n : ℕ) : ℕ := (psi n).num.toNat

theorem Psi_cast (n : ℕ) (hn : 0 < n) : (Psi n : ℚ) = psi n := by
  unfold Psi
  have hnum : 0 < (psi n).num := Rat.num_pos.mpr (psi_pos n)
  have h1 : ((psi n).num.toNat : ℤ) = (psi n).num := Int.toNat_of_nonneg hnum.le
  have h2 : ((psi n).num : ℚ) = psi n := Rat.coe_int_num_of_den_eq_one (psi_den_eq_one n hn)
  rw [← h2, ← h1]
  push_cast
  rfl

theorem Psi_pos (n : ℕ) (hn : 0 < n) : 0 < Psi n := by
  have : (0 : ℚ) < Psi n := by rw [Psi_cast n hn]; exact psi_pos n
  exact_mod_cast this

theorem prod_Psi (n : ℕ) (hn : 0 < n) : ∏ d ∈ n.divisors, Psi d = Nat.fib n := by
  have h := prod_psi n hn
  have : ((∏ d ∈ n.divisors, Psi d : ℕ) : ℚ) = ((Nat.fib n : ℕ) : ℚ) := by
    push_cast
    rw [← h]
    refine prod_congr rfl fun d hd => ?_
    exact Psi_cast d (Nat.pos_of_mem_divisors hd)
  exact_mod_cast this

theorem Psi_dvd_fib (d n : ℕ) (hn : 0 < n) (hd : d ∣ n) : Psi d ∣ Nat.fib n := by
  rw [← prod_Psi n hn]
  exact dvd_prod_of_mem _ (Nat.mem_divisors.mpr ⟨hd, hn.ne'⟩)

theorem padicValNat_Psi (p : ℕ) [Fact p.Prime] (n : ℕ) (hn : 0 < n) :
    (padicValNat p (Psi n) : ℤ) = padicValRat p (psi n) := by
  rw [← Psi_cast n hn, padicValRat.of_nat]

/-! ### Non-primitive prime factors of `Psi n` -/

/-- An odd prime factor `p` of `Psi n` that divides some earlier `F k` satisfies
`n = rk p * p ^ j` with `j ≥ 1`, and `p ^ 2 ∤ Psi n`. -/
theorem nonprim_odd (p : ℕ) [hp : Fact p.Prime] (hp2 : p ≠ 2) (n : ℕ) (hn : 0 < n)
    (hdvd : p ∣ Psi n) (k : ℕ) (hk : 0 < k) (hkn : k < n) (hpk : p ∣ Nat.fib k) :
    ∃ h : HasRank p, ∃ j, 1 ≤ j ∧ n = rk p h * p ^ j ∧ ¬ p ^ 2 ∣ Psi n := by
  have h : HasRank p := hasRank_of_dvd hk hpk
  refine ⟨h, ?_⟩
  have hv : 1 ≤ padicValNat p (Psi n) := one_le_padicValNat_of_dvd (Psi_pos n hn).ne' hdvd
  have hv' := padicValNat_Psi p n hn
  rw [padicValRat_psi_odd p hp2 h n hn] at hv'
  have hrk : rk p h ≤ k := rk_le p h hk hpk
  split_ifs at hv' with h1 h2
  · exfalso
    have : n = rk p h := by
      have := Nat.div_eq_iff_eq_mul_left (rk_pos p h) h1 |>.mp h2
      omega
    omega
  · rw [mul_zero, zero_add] at hv'
    have hlam : lam p (n / rk p h) = 1 := by
      have := lam_le_one p (n / rk p h)
      omega
    obtain ⟨j, hj, hj'⟩ := (lam_eq_one_iff p _).mp hlam
    refine ⟨j, hj, ?_, ?_⟩
    · rw [← hj', Nat.mul_div_cancel' h1]
    · rw [padicValNat_dvd_iff_le (Psi_pos n hn).ne']
      omega
  · omega

/-- The prime `2` dividing `Psi n` and some earlier `F k` forces `n = 3 * 2 ^ a` with `a ≥ 1`, and
`4 ∤ Psi n` unless `a = 1`. -/
theorem nonprim_two (n : ℕ) (hn : 0 < n) (hdvd : 2 ∣ Psi n) (k : ℕ) (hk : 0 < k) (hkn : k < n)
    (h2k : 2 ∣ Nat.fib k) :
    ∃ a, 1 ≤ a ∧ n = 3 * 2 ^ a ∧ (a = 1 ∨ ¬ 4 ∣ Psi n) := by
  have hv : 1 ≤ padicValNat 2 (Psi n) := one_le_padicValNat_of_dvd (Psi_pos n hn).ne' hdvd
  have hv' := padicValNat_Psi 2 n hn
  rw [padicValRat_psi_two n hn] at hv'
  have h3k : 3 ∣ k := (two_dvd_fib_iff k).mp h2k
  have hk3 : 3 ≤ k := Nat.le_of_dvd hk h3k
  split_ifs at hv' with h1 h2 h3 h3
  · exfalso
    have : n = 3 := by
      have := Nat.div_eq_iff_eq_mul_left (by norm_num : 0 < 3) h1 |>.mp h2
      omega
    omega
  · exfalso
    have : n = 3 := by
      have := Nat.div_eq_iff_eq_mul_left (by norm_num : 0 < 3) h1 |>.mp h2
      omega
    omega
  · -- `n / 3 = 2`, so `n = 6`
    refine ⟨1, le_refl 1, ?_, Or.inl rfl⟩
    have := Nat.div_eq_iff_eq_mul_left (by norm_num : 0 < 3) h1 |>.mp h3
    omega
  · simp only [zero_add, add_zero] at hv'
    have hlam : lam 2 (n / 3) = 1 := by
      have := lam_le_one 2 (n / 3)
      omega
    obtain ⟨j, hj, hj'⟩ := (lam_eq_one_iff 2 _).mp hlam
    refine ⟨j, hj, ?_, Or.inr ?_⟩
    · rw [← hj', Nat.mul_div_cancel' h1]
    · rw [show (4 : ℕ) = 2 ^ 2 by norm_num, padicValNat_dvd_iff_le (Psi_pos n hn).ne']
      omega
  · omega

end TuringTask
