import Mathlib
import TuringTask.Prelim

/-!
# Resultants and discriminants of cyclotomic polynomials

This file contains the five requested theorems.  All the mathematical work is done in
`TuringTask.Prelim`; here we only assemble the statements in the exact form requested.

The structure of the arguments is as follows.

* Everything is computed by passing to `ℂ`, where `cyclotomic n ℂ` splits and its roots are
  exactly the primitive `n`-th roots of unity.  A resultant `Res(Φ_n, g)` then becomes the
  product of `g` over those roots (`TTAux.res_eq_prod`).

* The combinatorial heart is `TTAux.prod_prim_pow`: for `k ∣ M`, the map `ζ ↦ ζ ^ (M/k)` sends
  the primitive `M`-th roots onto the primitive `k`-th roots, uniformly `φ M / φ k`-to-one.
  This is proved by transporting to the reduction map `(ZMod M)ˣ → (ZMod k)ˣ`, a surjection of
  finite groups, whose fibres therefore all have the same size.

* This gives `Res(Φ_m, X^N - 1) = Φ_{m/gcd(m,N)}(1) ^ (φ m / φ(m/gcd(m,N)))` for `m ≥ 3`
  (`TTAux.resultant_cyclotomic_X_pow_sub_one'`), which is Theorem 5.

* Factoring `X^N - 1 = ∏_{d ∣ N} Φ_d` and inducting on `N`, together with the arithmetic
  identity `TTAux.key_identity`, yields `Res(Φ_m, Φ_n) = Φ_{m/n}(1) ^ φ(n)` when `n ∣ m`
  and `1` otherwise (`TTAux.resultant_cyclotomic_eq_claimed`).  Theorems 1, 2 and 4 follow.

* For Theorem 3 we differentiate `X^n - 1 = Φ_n · G` with `G = ∏_{d < n} Φ_d`, which gives
  `Res(Φ_n, Φ_n') · Res(Φ_n, G) = n ^ φ(n)`.  Mathlib's `Polynomial.resultant_deriv` turns the
  first factor into the discriminant, and the second arithmetic identity
  `TTAux.key_identity_two` turns the second factor into `∏_{p ∣ n} p ^ (φ(n)/(p-1))`.
-/

open Polynomial Finset Nat TTAux

namespace TuringTask

/-- **Theorem 1.**  If `1 ≤ n < m` and `m` is not of the form `n * p ^ k` with `p` prime, then
`Res(Φ_m, Φ_n) = 1`. -/
theorem resultant_cyclotomic_eq_one (m n : Nat) (hn : 1 <= n) (hnm : n < m)
    (h : forall p k : Nat, p.Prime -> Not (m = n * p ^ k)) :
    Polynomial.resultant (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic n Int) = 1 := by
  -- First, `m ≥ 3`: otherwise `m = 2` and `n = 1`, and then `m = n * 2 ^ 1`.
  have hm3 : 3 ≤ m := by
    rcases Nat.lt_or_ge m 3 with hlt | hge
    · interval_cases m
      · omega
      · omega
      · have hn1 : n = 1 := by omega
        subst hn1
        exact absurd (show (2 : ℕ) = 1 * 2 ^ 1 by norm_num) (h 2 1 Nat.prime_two)
    · exact hge
  rw [resultant_cyclotomic_eq_claimed hm3 n hn hnm]
  unfold claimed
  split_ifs with hdvd
  · -- `n ∣ m`, so `m / n ≠ 1`; and `m / n` is not a prime power, else `m = n * p ^ k`.
    have hmn1 : m / n ≠ 1 := by
      intro h1
      have := Nat.div_mul_cancel hdvd
      rw [h1, one_mul] at this
      omega
    have hnpp : ¬ IsPrimePow (m / n) := by
      rintro ⟨p, k, hp, hk, hpk⟩
      refine h p k hp.nat_prime ?_
      rw [hpk]
      exact (Nat.mul_div_cancel' hdvd).symm
    rw [eval_one_cyclotomic_of_not_isPrimePow hmn1 hnpp, one_pow]
  · rfl

/-- **Theorem 2.**  If `n ≥ 1`, `p` is prime, `k ≥ 1` and `(n, p, k) ≠ (1, 2, 1)`, then
`Res(Φ_{n p^k}, Φ_n) = p ^ φ(n)`. -/
theorem resultant_cyclotomic_mul_prime_pow (n p k : Nat) (hn : 1 <= n) (hp : p.Prime)
    (hk : 1 <= k) (h : Not (n = 1 /\ p = 2 /\ k = 1)) :
    Polynomial.resultant (Polynomial.cyclotomic (n * p ^ k) Int) (Polynomial.cyclotomic n Int) =
      (p : Int) ^ n.totient := by
  set m := n * p ^ k with hm
  have hp2 : 2 ≤ p := hp.two_le
  have hpk2 : 2 ≤ p ^ k := le_trans hp2 (Nat.le_self_pow (by omega) p)
  have hnm : n < m := by
    rw [hm]
    calc n = n * 1 := (mul_one n).symm
      _ < n * p ^ k := Nat.mul_lt_mul_of_le_of_lt (le_refl n) (by omega) (by omega)
  -- `m ≥ 3`: the only way to have `m ≤ 2` is `n = 1`, `p = 2`, `k = 1`, which is excluded.
  have hm3 : 3 ≤ m := by
    rcases Nat.lt_or_ge m 3 with hlt | hge
    · have hm2 : m = 2 := by omega
      have hn1 : n = 1 := by nlinarith [hm, hpk2]
      have hpk : p ^ k = 2 := by rw [hn1, one_mul] at hm; omega
      have hp2' : p = 2 ∧ k = 1 := by
        rcases k with _ | _ | k
        · omega
        · simp at hpk; omega
        · exfalso
          have hle : 2 ^ (k + 2) ≤ p ^ (k + 2) := Nat.pow_le_pow_left hp2 _
          have h4 : (4 : ℕ) ≤ 2 ^ (k + 2) := by
            calc (4 : ℕ) = 2 ^ 2 := by norm_num
              _ ≤ 2 ^ (k + 2) := Nat.pow_le_pow_right (by norm_num) (by omega)
          rw [hpk] at hle
          omega
      exact absurd ⟨hn1, hp2'.1, hp2'.2⟩ h
    · exact hge
  rw [resultant_cyclotomic_eq_claimed hm3 n hn hnm]
  unfold claimed
  have hdvd : n ∣ m := ⟨p ^ k, hm⟩
  rw [if_pos hdvd]
  have hmn : m / n = p ^ k := by rw [hm]; exact Nat.mul_div_cancel_left _ (by omega)
  rw [hmn, eval_one_cyclotomic_prime_pow' hp hk]

/-- **Theorem 3.**  `disc(Φ_n) * ∏_{p ∣ n} p ^ (φ(n)/(p-1)) = (-1) ^ (φ(n)/2) * n ^ φ(n)`. -/
theorem discr_cyclotomic (n : Nat) (hn : 1 <= n) :
    Polynomial.discr (Polynomial.cyclotomic n Int) *
        n.primeFactors.prod (fun p => (p : Int) ^ (n.totient / (p - 1))) =
      (-1) ^ (n.totient / 2) * (n : Int) ^ n.totient := by
  rcases Nat.lt_or_ge n 3 with hlt | hn3
  · -- `n = 1` and `n = 2`: here `Φ_n` has degree one, so its discriminant is `1`.
    interval_cases n
    · have h1 : (cyclotomic 1 ℤ).degree = 1 := by rw [degree_cyclotomic]; decide
      rw [Polynomial.discr_of_degree_eq_one h1]
      norm_num
    · have h1 : (cyclotomic 2 ℤ).degree = 1 := by rw [degree_cyclotomic]; decide
      rw [Polynomial.discr_of_degree_eq_one h1]
      norm_num [Nat.primeFactors]
  · -- `n ≥ 3`.
    have heven : Even n.totient := Nat.totient_even hn3
    have h1 := resultant_derivative_mul n hn3
    rw [resultant_derivative_cyclotomic n hn3, resultant_prod_properDivisors n hn3,
      neg_one_pow_half heven] at h1
    calc Polynomial.discr (cyclotomic n ℤ) *
            n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1)))
        = (-1) ^ (n.totient / 2) * ((-1) ^ (n.totient / 2) * Polynomial.discr (cyclotomic n ℤ)
            * n.primeFactors.prod (fun p => (p : ℤ) ^ (n.totient / (p - 1)))) := by
          rw [← mul_assoc, ← mul_assoc, ← pow_add, ← two_mul,
            show ((-1 : ℤ)) ^ (2 * (n.totient / 2)) = 1 from by rw [pow_mul]; norm_num, one_mul]
      _ = (-1) ^ (n.totient / 2) * (n : ℤ) ^ n.totient := by rw [h1]

/-- **Theorem 4.**  For `1 ≤ n < m`, `Φ_m` and `Φ_n` are coprime in `ℤ[X]` if and only if `m`
is not of the form `n * p ^ k` with `p` prime. -/
theorem isCoprime_cyclotomic_iff (m n : Nat) (hn : 1 <= n) (hnm : n < m) :
    IsCoprime (Polynomial.cyclotomic m Int) (Polynomial.cyclotomic n Int) <->
      forall p k : Nat, p.Prime -> Not (m = n * p ^ k) := by
  rw [← Polynomial.isUnit_resultant_iff_isCoprime (cyclotomic.monic m ℤ)]
  constructor
  · intro hu p k hp hrep
    have hk1 : 1 ≤ k := by
      rcases Nat.eq_zero_or_pos k with rfl | hpos
      · simp at hrep; omega
      · exact hpos
    by_cases hspec : n = 1 ∧ p = 2 ∧ k = 1
    · -- the exceptional case: here the resultant is `-2`, still not a unit
      obtain ⟨rfl, rfl, rfl⟩ := hspec
      norm_num at hrep
      subst hrep
      rw [resultant_cyclotomic_two_one, Int.isUnit_iff] at hu
      omega
    · rw [hrep, resultant_cyclotomic_mul_prime_pow n p k hn hp hk1 hspec] at hu
      exact not_isUnit_prime_pow_totient hp hn hu
  · intro h
    rw [resultant_cyclotomic_eq_one m n hn hnm h]
    exact isUnit_one

set_option linter.unusedVariables false in
/-- **Theorem 5.**  For `n ≥ 3`, `m ≥ 1` and `n ∤ m`, writing `k = n / gcd(n, m)`,
`Res(Φ_n, X^m - 1) = Φ_k(1) ^ (φ(n)/φ(k))`.

The hypotheses `hm : 1 ≤ m` and `h : ¬ (m % n = 0)` are kept to match the requested statement,
but they are in fact not needed: the identity holds for every `m` once `n ≥ 3`.  The general
version is `TTAux.resultant_cyclotomic_X_pow_sub_one'`.  (When `n ∣ m` both sides are `0`,
since then `k = 1` and `Φ_1(1) = 0`.) -/
theorem resultant_cyclotomic_X_pow_sub_one (n m : Nat) (hn : 3 <= n) (hm : 1 <= m)
    (h : Not (m % n = 0)) :
    Polynomial.resultant (Polynomial.cyclotomic n Int) (Polynomial.X ^ m - 1) =
      Polynomial.eval 1 (Polynomial.cyclotomic (n / Nat.gcd n m) Int) ^
        (n.totient / (n / Nat.gcd n m).totient) :=
  resultant_cyclotomic_X_pow_sub_one' n m hn

end TuringTask
